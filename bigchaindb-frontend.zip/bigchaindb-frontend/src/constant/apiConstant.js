export const API_URL = 'http://10.1.0.234:3005';
export const API_URL_BIG_CHAIN = 'http://192.168.75.162:8080';
