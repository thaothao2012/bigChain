import axios from 'axios';
import * as configApi from '../constant/apiConstant';

export default function CallApi(endpoint, method = 'GET', data){
  const bodyReq = {
    method : method,
    url : `${configApi.API_URL_BIG_CHAIN}/${endpoint}`,
  }
  if (method === 'GET') {
    bodyReq.params = data
  } else {
    bodyReq.data = data
  }
  return axios(bodyReq).catch(err =>{
    console.log(err);
  })
}
