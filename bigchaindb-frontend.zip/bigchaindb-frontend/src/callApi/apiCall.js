import axios from 'axios';
import * as configApi from '../constant/apiConstant';

export default function CallApi(endpoint,method='GET',data){
  return axios({
      method : method,
      url : `${configApi.API_URL}/${endpoint}`,
      data : data
  }).catch(err =>{
    console.log(err);
  })
}
