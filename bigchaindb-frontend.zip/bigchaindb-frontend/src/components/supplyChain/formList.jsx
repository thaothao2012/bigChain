import React from 'react';
import { Icon, Label, Menu, Table, Button, Sidebar, Segment, Header, Dropdown, Grid } from 'semantic-ui-react';
import CallApi from '../../apiService';
import FormInfo from './assetInfo';

class HomePage extends React.Component {
	constructor(props) {
		super(props);

		this.state = {
			data: [],
			dataSelected: {},
			visible: false,
			activeItem: 'home'
		}
	}

	componentDidMount() {
		const arrData = [
			{
				asset: {
					id: "f0f9d26815c703beb02e9cc02d1c4230e89b82b4825f884a73d85d950589636c",
					name: "pork",
					data: {
						"id": "HM353040816",
						"originName": "Heo VietGap",
						"dateOut": "8/2/2019",
						"farmName": "Organic",
						"farmAddress": "Lam dong",
						"healthStatus": "Good",
						"quantity": "18",
						"grossWeight": "2000",
						"porkFeed": "Cam Cargil"
					}
				},
				metadata: [
					{
						operation: "CREATE",
						name: "vaccination",
						data: {
							"vacc1": "4/2/2019",
							"vacc2": "6/2/2019"
						},
						date: "2019-05-20T07:04:03.674Z"
					},
					{
						operation: "TRANSFER",
						name: "Vissan",
						data: {
							"timeStamp": "8/2/2019",
							"finishedProduct": "meat",
							"producerAddress": "Ho Chi Minh",
							"quality": "Good",
							"grossWeight": "500",
							"manufactureDate": "4/2/2019",
							"expiryDate": "6/2/2019"
						},
						date: "2019-05-20T06:48:34.943Z"
					},
					{
						operation: "TRANSFER",
						name: "Vissan",
						data: {
							"timeStamp": "8/2/2019",
							"finishedProduct": "meat",
							"producerAddress": "Ho Chi Minh",
							"quality": "Good",
							"grossWeight": "500",
							"manufactureDate": "4/2/2019",
							"expiryDate": "6/2/2019"
						},
						date: "2019-05-20T07:04:03.674Z"
					},
					{
						operation: "TRANSFER",
						name: "transfer_to",
						data: "my best friend",
						date: "2019-05-20T07:04:03.674Z"
					},
					{
						operation: "TRANSFER",
						name: "Metro",
						data: {
							"timeStamp": "8/2/2019",
							"finishedProduct": "canned",
							"distributorAddress": "Ho Chi Minh",
							"quality": "Good",
							"grossWeight": "500",
							"humidityStore": "45",
							"temperatureStore": "-18"
						},
						date: "2019-05-21T03:07:02.466Z"
					},
					{
						operation: "TRANSFER",
						name: "Metro",
						data: {
							"timeStamp": "8/2/2019",
							"finishedProduct": "canned",
							"distributorAddress": "Ho Chi Minh",
							"quality": "Good",
							"grossWeight": "500",
							"humidityStore": "45",
							"temperatureStore": "-18"
						},
						date: "2019-05-21T03:22:19.037Z"
					},
					{
						operation: "TRANSFER",
						name: "Co-oop mart",
						data: {
							"id": "c999999",
							"timestamp": "8/2/2019",
							"finishedProduct": "canned",
							"retailAddress": "Ho Chi Minh",
							"quality": "Good",
							"grossWeight": "500",
							"quarantineNum": "123456",
							"NormalPrice": "45",
							"PromotionPrice": "30"
						},
						date: "2019-05-21T03:41:58.447Z"
					},
				]
			}
		];
		this.setState({
			data: arrData
		});
	}


	handleOnClick = (id) => {
		const { data } = this.state;
		const asset_id = this.findIndex(id, data);
		if (id !== -1) {
			CallApi('/getHistoricalAsset?asset_id=', 'GET', {
				id: asset_id
			}).then(res => {

			})
		}
	}

	findIndex = (id, arr) => {
		var result = -1;
		for (var i = 0; i < arr.length; i++) {
			if (arr[i].id === id) {
				result = i;
			}
		}
		return result;
	}

	handleOpenMenu = (e, { name }) => this.setState({ visible: !this.state.visible, activeItem: name })

	render() {
		const { data, visible, activeItem } = this.state;
		return (
			<div>
				<Menu size='tiny'>
					<Menu.Item name='home' active={activeItem === 'home'} onClick={this.handleOpenMenu}>
						<Icon name='content' />
					</Menu.Item>

					<Menu.Menu position='right'>
						<Dropdown item text='Language'>
							<Dropdown.Menu>
								<Dropdown.Item>English</Dropdown.Item>
								<Dropdown.Item>Russian</Dropdown.Item>
								<Dropdown.Item>Spanish</Dropdown.Item>
							</Dropdown.Menu>
						</Dropdown>

						<Menu.Item>
							<Button primary>Sign Up</Button>
						</Menu.Item>
					</Menu.Menu>
				</Menu>

				<Sidebar.Pushable as={Segment}>
					<Sidebar
						as={Menu}
						animation='overlay'
						icon='labeled'
						inverted
						onHide={this.handleSidebarHide}
						vertical
						visible={visible}
						width='thin'
					>
						<Menu.Item as='a'>
							<Icon name='home' />
							Home
            </Menu.Item>
						<Menu.Item as='a'>
							<Icon name='gamepad' />
							Games
            </Menu.Item>
						<Menu.Item as='a'>
							<Icon name='camera' />
							Channels
            </Menu.Item>
					</Sidebar>

					<Sidebar.Pusher>
						<Segment basic>
							<Grid divided='vertically'>
								<Grid.Row columns={2}>
									<Grid.Column>
										<Segment>
											<Header as='h4'>Asset Info</Header>
											<Icon name='add' className='' color='blue' />
											<FormInfo />
										</Segment>										
									</Grid.Column>
									<Grid.Column>
										<Segment>
											<Header as='h4'>History of Item</Header>
											<FormInfo />
										</Segment>
									</Grid.Column>
								</Grid.Row>
							</Grid>
							<Header as='h3'>Big Chain Info</Header>
							<Table celled>
								<Table.Header>
									<Table.Row>
										<Table.HeaderCell>No</Table.HeaderCell>
										<Table.HeaderCell>Origin Name</Table.HeaderCell>
										<Table.HeaderCell>Pork Feed</Table.HeaderCell>
										<Table.HeaderCell>Farm Name</Table.HeaderCell>
										<Table.HeaderCell>Farm Address</Table.HeaderCell>
										<Table.HeaderCell>Gross Weight</Table.HeaderCell>
										<Table.HeaderCell>Health Status</Table.HeaderCell>
										<Table.HeaderCell>Quantity</Table.HeaderCell>
										<Table.HeaderCell>Date Out</Table.HeaderCell>
										<Table.HeaderCell>Action</Table.HeaderCell>
									</Table.Row>
								</Table.Header>

								<Table.Body>
									{data.map((row, idx) => (
										<Table.Row key={row.asset.id}>
											<Table.Cell>{idx + 1}</Table.Cell>
											<Table.Cell>{row.asset.data['originName']}</Table.Cell>
											<Table.Cell>{row.asset.data['farmName']}</Table.Cell>
											<Table.Cell>{row.asset.data['porkFeed']}</Table.Cell>
											<Table.Cell>{row.asset.data['farmAddress']}</Table.Cell>
											<Table.Cell>{row.asset.data['grossWeight']}</Table.Cell>
											<Table.Cell>{row.asset.data['healthStatus']}</Table.Cell>
											<Table.Cell>{row.asset.data['quantity']}</Table.Cell>
											<Table.Cell>{row.asset.data['dateOut']}</Table.Cell>
											<Table.Cell>
												<Button variant="contained" color="blue" content='Edit' onClick={() => this.handleOnClick(row.asset['id'])} />
												<Button variant="contained" color="red" content='Delete' />
											</Table.Cell>
										</Table.Row>
									))}
								</Table.Body>

								<Table.Footer>
									<Table.Row>
										<Table.HeaderCell colSpan='10'>
											<Menu floated='right' pagination>
												<Menu.Item as='a' icon>
													<Icon name='chevron left' />
												</Menu.Item>
												<Menu.Item as='a'>1</Menu.Item>
												<Menu.Item as='a'>2</Menu.Item>
												<Menu.Item as='a'>3</Menu.Item>
												<Menu.Item as='a'>4</Menu.Item>
												<Menu.Item as='a' icon>
													<Icon name='chevron right' />
												</Menu.Item>
											</Menu>
										</Table.HeaderCell>
									</Table.Row>
								</Table.Footer>
							</Table>
						</Segment>
					</Sidebar.Pusher>
				</Sidebar.Pushable>
			</div>
		);
	}
}

export default HomePage