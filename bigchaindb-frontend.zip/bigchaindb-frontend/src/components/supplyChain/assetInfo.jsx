import React from 'react';
import { Form, Button } from 'semantic-ui-react';

class FormInfo extends React.Component {
	constructor(props) {
		super(props);
	}

	addMoreItem = () => {
		
	}

	render() {
		return (
			<Form>
				<Form.Group unstackable widths={2}>
					<Form.Input label='Origin Name' placeholder='Origin Name' />
					<Form.Input label='Pork Feed' placeholder='Pork Feed' />
				</Form.Group>
				<Form.Group widths={2}>
					<Form.Input label='Farm Name' placeholder='Farm Name' />
					<Form.Input label='Farm Address' placeholder='Farm Address' />
				</Form.Group>
                <Form.Group widths={2}>
					<Form.Input label='Gross Weight' placeholder='Gross Weight' />
					<Form.Input label='Health Status' placeholder='Health Status' />
				</Form.Group>
                <Form.Group widths={2}>
					<Form.Input label='Quantity' placeholder='Quantity' />
					<Form.Input label='Date Out' placeholder='Date Out' />
				</Form.Group>
				<Button type='submit' color='blue'>Save</Button>
				<Button type='button'>Cancel</Button>
			</Form>
		);
	}
}

export default FormInfo;