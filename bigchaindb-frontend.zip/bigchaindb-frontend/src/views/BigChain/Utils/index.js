export function formatDate(dateStr) {
    const date = new Date(dateStr);
    const minutes = date.getMinutes();
    const day = date.getDate();
    const month = date.getMonth();
    return `${day > 9 ? day : '0' + day}/
    ${month > 9 ? month + 1 : '0' + (month + 1)}/
    ${date.getFullYear()} ${date.getHours()}:
    ${minutes > 9 ? minutes : '0' + minutes}`;
}