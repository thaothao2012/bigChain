export function formatDate(dateStr) {
    const date = new Date(dateStr);
    const minutes = date.getMinutes();
    const day = date.getDate();
    const month = date.getMonth();
    return `${day > 9 ? day : '0' + day}/${month > 9 ? month + 1 : '0' + (month + 1)}/${date.getFullYear()} ${date.getHours()}:${minutes > 9 ? minutes : '0' + minutes}`;
}

export function formatName(str) {
  const formatedStr = str.replace(/_/g, ' ');
  return formatedStr.split(' ').map((word) => {
    const temp = word.charAt(0).toUpperCase() + word.slice(1);
    return temp.split(/(?=[A-Z])/).join(' ');
  }).join(' ');
}
