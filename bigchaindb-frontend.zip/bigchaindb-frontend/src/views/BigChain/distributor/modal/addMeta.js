import React from 'react';
import callApiBigChain from '../../../../callApi/apiCallBigChain';
import {
  Col,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormGroup,
  Input, Label
} from 'reactstrap';
import {formatDate} from '../../Utils';

let inputs = [];

class AssetInfo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dynamicData: [],
      addMetaModal: false,
      metaData: {
        metaName: '',
        metaSupplierType: 'Producer',
        noteAction: ''
      }
    }
  }

  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  handleChange = e => {
    const { metaData } = this.state;
    const { name, value } = e.target;
    this.setState({
      metaData: { ...metaData, [name]: value }
    })
  }

  handleSubmitMetaData = () => {
    const output = this.props.output;
    const { metaData } = this.state;
    const day = new Date();
    const data =[
      {"txId": output.transaction_id },
      {"outputIndex": output.output_index },
      {"amount": output.amount },
      {"currentIdentity" : {"privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
                            "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
                            }
      },
      {"updateContent": { "supplierType": metaData.metaSupplierType,
                          "name": metaData.metaName,
                          "noteAction": metaData.noteAction,
                          "detail" : {
                            "timestamp" : formatDate(day),
                            ...this.formatDynamicData()
                          }
      }},
      {"amountToSend": output.amount}
    ]
    callApiBigChain('updateAssetMetaWithOutputSC', 'POST', data).then(res => {
      if (res) {
        console.log(res);
        alert("Add metadata thanh cong!");
        this.props.reload();
        this.props.toggleMeta();
      }
    })
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  handleOnAddField = () => {
    const generateId = this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    const input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Col sm={6}>
          <Input
            type="text"
            id={key}
            name={key}
            placeholder="key"
            valueDefault=""
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm={5}>
          <Input
            type="text"
            id={valueField}
            name={valueField}
            autoComplete="dataPlus"
            placeholder="value"
            valueDefault=""
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <i className="fa fa-align-justify" onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
        </Col>
      </FormGroup>)
    };
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }


  render() {
    const { metaData } = this.state;
    const { toggleMeta } = this.props;
    return (
      <div>
        <FormGroup row>
          <Label for="name" sm='4'>Note Action:</Label>
          <Col sm={8}>
            <Input
              color="red"
              type="text"
              id="note"
              name="noteAction"
              autoComplete="noteAction"
              value={metaData.noteAction}
              onChange={this.handleChange}
            />
          </Col>
        </FormGroup>
        <Card>
          <CardHeader>
            Content
            <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
          </CardHeader>
          <CardBody>
            {this.formatRender()}
          </CardBody>
        </Card>
        <FormGroup className="float-right">
            <Button color="primary"
                    onClick={this.handleSubmitMetaData}
                    >Add</Button>{' '}
            <Button color="secondary"
                    onClick={toggleMeta}
                    >Cancel</Button>
          </FormGroup>
      </div>
    );
  }
}

export default AssetInfo;
