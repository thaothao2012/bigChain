import React, { Component } from 'react';
import {
  Card, CardBody, CardHeader, CardFooter, Col, Row, Button, InputGroup,
  FormGroup, Modal, ModalHeader, ModalBody, ModalFooter, Label, Input
} from 'reactstrap';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
// import AddMeta from '../producer/addMeta';
// import TransactionModal from '../Modal/transactionModal';
// import History from '../farmer/historyForm';
import AddMeta from './modal/addMeta';
import TransactionModal from './modal/transactionModal';
import History from './modal/historyForm';
//import { formatName } from '../Utils';
import Table from '../Modal/table';
import Pagination from '../Pagination';
import CallApiTest from '../../../callApi/apiCallTest';

let inputs = [];
const ColoredLine = ({ color }) => (
  <hr
    style={{
      color: color,
      backgroundColor: color,
      height: 2
    }}
  />
);

class Distributor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isOpenDivideModal: false,
      isOpenMetaModal: false,
      isOpenTransModal: false,
      isOpenHistoryModal: false,
      custom: [false, true],
      spentData: [],
      unSpentData: [],
      updateContent: {
        supplierType: 'Producer',
        name: '',
        note: '',
        detail: {}
      },
      amountToSend: {
        canned: 0,
        sausage: 0,
        meat: 0
      },
      transaction_tmp: {},
      reloadPage: 0,
      dynamicData: [],
      currentIdentity: {
        "privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
        "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
      },
      amountToTrans: 0,
      currentPage: 1,
      currentUnspentPage: 1,
      pageSize: 10,
      searchKey: {
        searchIdent: '',
        searchDes: '',
        searchQuantity: '',
        searchDate: '',
        searchUnit: '',
        searchStatus: ''
      }
    }
  }

  componentDidMount = () => {
    this.loadInitData();
  }

  loadInitData = () => {
    CallApiBigChain('getListOutputsSC?publicKey=HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q', 'GET', null).then(res => {
      if (res) {
        const totalSpent = res.data[0].length;
        const totalUnSpent = res.data[1].length;
        this.setState({
          spentData: res.data[0],
          unSpentData: res.data[1],
          totalSpent,
          totalUnSpent
        });
      }
    })
  }

  handleSwitchPage = (pageNumber, keyPagination) => {
    if (keyPagination === "spent") {
      this.setState({
        currentPage: pageNumber
      });
    }
    else {
      this.setState({
        currentUnspentPage: pageNumber
      });
    }
    this.loadInitData();
  }

  toggleCustom = (isAssetDetail, index) => {
    if (isAssetDetail) {
      this.setState({
        ['openAssetColapse_' + index]: !this.state['openAssetColapse_' + index]
      });
    } else {
      this.setState({
        ['openMetaColapse_' + index]: !this.state['openMetaColapse_' + index]
      });
    }
  }

  handleOnChange = (e) => {
    const { updateContent, amountToSend } = this.state;
    const { name, value } = e.target;
    this.setState({
      updateContent: {
        ...updateContent, [name]: value
      },
      amountToSend: {
        ...amountToSend, [name]: value
      }
    });
  }

  handleOnChangeTrans = e => {
    const { name, value } = e.target;
    this.setState({
      [name]: value
    });
  }

  generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }

  handleOnAddField = () => {
    const generateId = this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    const input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Row>
          <Col sm='6'>
            <Input
              type="text"
              id={key}
              name={key}
              autoComplete="dataPlus"
              placeholder="key"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='5'>
            <Input
              type="text"
              id={valueField}
              name={valueField}
              autoComplete="dataPlus"
              placeholder="value"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='1'>
            <i className="fa fa-align-justify" style={{ float: "left" }}
              onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
          </Col>
        </Row>
      </FormGroup>)
    };
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  handleAddDivisible = () => {
    const { transaction, updateContent, amountToSend } = this.state;
    const data = [
      { "txId": transaction.transaction_id },
      { "outputIndex": transaction.output_index },

      {
        "currentIdentity": {
          "privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
          "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
        }
      },
      {
        "updateContent": {
          "supplierType": updateContent.supplierType,
          "name": updateContent.name,
          "noteAction": updateContent.note,
          "detail": {
            ...this.formatDynamicData()
          }
        }
      },
      { "amountToSend1": Number(amountToSend.canned) },
      { "amountToSend2": Number(amountToSend.sausage) },
      { "amountToSend3": Number(amountToSend.meat) }
    ];
    //console.log(data);
    CallApiBigChain('divideTokensWithOutputSC', 'POST', data).then(res => {
      if (res) {
        alert("add divide data thanh cong!");
        this.loadInitData();
        this.setState(prevState => ({
          modal: !prevState.modal
        }));
      }
    })
  }

  toggle = (transaction, index) => {
    if (index === 1) {
      this.setState(prevState => ({
        transaction_tmp: transaction,
        isOpenDivideModal: !prevState.isOpenDivideModal
      }));
    }
    if (index === 2) {
      this.setState(prevState => ({
        transaction_tmp: transaction || this.state.transaction_tmp,
        reloadPage: 1,
        isPassData: true,
        isOpenMetaModal: !this.state.isOpenMetaModal
      }));
    }
    if (index === 3) {
      this.setState(prevState => ({
        transaction_tmp: transaction || prevState.transaction_tmp,
        reloadPage: 1,
        isOpenTransModal: !prevState.isOpenTransModal
      }));
    }
    if (index === 4) {
      CallApiTest('getHistoricalAssetByTransIdSC', 'GET', null
        // {
        //   currentTransId: transaction.transaction_id,
        //   asset_id: transaction.assetId
        // }
      ).then(res => {
        if (res) {
          debugger;
          this.setState({
            history: res.data,
            transaction_tmp: transaction,
            isOpenHistoryModal: !this.state.isOpenHistoryModal
          });
        }
      })
    }
  }

  onClose = (index) => {
    const { isOpenDivideModal, isOpenMetaModal, isOpenTransModal, isOpenHistoryModal } = this.state;
    if (index === 1) {
      this.setState({
        isOpenDivideModal: !isOpenDivideModal
      });
    }
    if (index === 2) {
      this.setState({
        isOpenMetaModal: !isOpenMetaModal
      });
    }
    if (index === 3) {
      this.setState({
        isOpenTransModal: !isOpenTransModal
      });
    }
    if (index === 4) {
      this.setState({
        isOpenHistoryModal: !isOpenHistoryModal
      });
    }
  }

  render() {
    const { spentData, unSpentData, updateContent, amountToSend, transaction_tmp,
      totalSpent, totalUnSpent, pageSize, currentPage, currentUnspentPage } = this.state;

    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardHeader color="bg-secondary" style={{ textAlign: "center" }}><h3><b>Supply Chain Traceability System</b></h3></CardHeader>
              <CardBody>
                {/* search */}

                <Row>
                  <Col sm="2">
                    <FormGroup>
                      <Label>Product identification</Label>
                      <Input type="text" name="searchIdent" value="" onChange={this.handleOnChangeTrans}></Input>
                    </FormGroup>
                  </Col>
                  <Col sm="2">
                    <FormGroup>
                      <Label>Product description</Label> <br />
                      <Input type="text"  name="searchDes" value="" onChange={this.handleOnChangeTrans}></Input>
                    </FormGroup>
                  </Col>
                  <Col sm="2">
                    <FormGroup>
                      <Label>Quantity number</Label><br />
                      <Input type="number" name="searchQuantity" value="" onChange={this.handleOnChangeTrans}></Input>
                    </FormGroup>
                  </Col>
                  <Col sm="2">
                    <FormGroup>
                      <Label>Unit Number</Label><br />
                      <Input type="number" name="searchUnit" value="" onChange={this.handleOnChangeTrans}></Input>
                    </FormGroup>
                  </Col>
                  <Col sm="2">
                    <FormGroup>
                      <Label>Create date</Label><br />
                      <Input type="date" name="searchDate" value="" onChange={this.handleOnChangeTrans}></Input>
                    </FormGroup>
                  </Col>
                  <Col sm="1">
                    <FormGroup>
                      <Label>IsUnspent</Label>
                      <Input type="select" name="searchStatus" value="" onChange={this.handleOnChangeTrans}>
                        <option> </option>
                        <option>True</option>
                        <option>False</option>
                      </Input>
                    </FormGroup>
                  </Col>
                  <Col sm="1">
                    <FormGroup>
                      <Button style={{ marginTop: "25px" }} color="primary">Go</Button>
                    </FormGroup>
                  </Col>
                </Row>
                <ColoredLine color="#d1d3d6" />
                <Row>

                  <Col>

                    <Button>Add new product</Button>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Card>
                      <CardHeader>
                        <i className="fa fa-align-justify"></i> List of created/owned products of this supplier<br />
                      </CardHeader>
                      <CardBody>
                        <Label><b>Items: </b></Label>
                        <Table data={unSpentData} tableKey='unspent' transaction_tmp={transaction_tmp} toggle={this.toggle}
                          currentPage={currentUnspentPage} />
                        {/* <Pagination
                          total={totalUnSpent ? totalUnSpent : 0}
                          keyPagination="unSpent"
                          pageSize={pageSize}
                          switchPage={this.handleSwitchPage}
                          currentPage={currentUnspentPage}
                        />
                          <Input
                          type="select"
                          id="pageSize"
                          name="pageSize"
                          className=''
                          value={pageSize}
                          onChange={this.handleOnChangePageSize}
                        // onClick={this.loadData}
                        >
                          <option defaultValue='' disabled value='' hidden></option>
                          <option value='5'>5</option>
                          <option value='10'>10</option>
                          <option value='15'>15</option>
                        </Input> */}
                      </CardBody>
                      <CardFooter>
                        <Row>
                          <Col>
                            <Pagination
                              total={totalUnSpent ? totalUnSpent : 0}
                              keyPagination="unSpent"
                              pageSize={pageSize}
                              switchPage={this.handleSwitchPage}
                              currentPage={currentUnspentPage}
                            />
                          </Col>
                          <Col>
                            <InputGroup>
                              <Label>Page size:</Label>
                              <Input
                                type="select"
                                id="pageSize"
                                name="pageSize"
                                className=''
                                value={pageSize}
                                onChange={this.handleOnChangePageSize}
                              // onClick={this.loadData}
                              >
                                <option defaultValue='' disabled value='' hidden></option>
                                <option value='5'>5</option>
                                <option value='10'>10</option>
                                <option value='15'>15</option>
                              </Input>
                            </InputGroup>

                          </Col>
                        </Row>


                      </CardFooter>
                    </Card>

                  </Col>
                </Row>
              </CardBody>
            </Card>
          </Col>
        </Row>

        {/* divide modal */}
        <Modal isOpen={this.state.isOpenDivideModal} toggle={() => this.onClose(1)} className={this.props.className}>
          <ModalHeader toggle={() => this.onClose(1)}>Amount:</ModalHeader>
          {/* <ModalHeader toggle={() => this.toggle(null, 1)}>Amount: {transaction_tmp.amount || ''}</ModalHeader> */}
          <ModalBody>
            <Card>
              <CardHeader>
                Divide
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
              </CardHeader>
              <CardBody>
                {this.formatRender()}
              </CardBody>
            </Card>
            <Card className="height-100">
              <CardBody>
                <FormGroup row>
                  <Col sm={12}>
                    <Card>
                      <CardHeader>
                        Content
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
                      </CardHeader>
                      <CardBody>
                        {this.formatRender()}
                      </CardBody>
                    </Card>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="note" sm='6'>Note Action</Label>
                  <Col sm={6}>
                    <Input
                      type="text"
                      id="note"
                      name="note"
                      autoComplete="note"
                      value={updateContent.note}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
              </CardBody>
            </Card>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleAddDivisible}>Divide</Button>{' '}
            <Button color="secondary" onClick={() => this.onClose(1)}>Cancel</Button>
          </ModalFooter>
        </Modal>

        {/* addMeta modal */}
        <Modal isOpen={this.state.isOpenMetaModal} toggle={() => this.onClose(2)} className={this.props.className}>
          <ModalHeader>Amount: {transaction_tmp.amount || ''} </ModalHeader>
          {/* <ModalHeader>Amount:  </ModalHeader> */}
          <ModalBody>
            <AddMeta output={this.state.transaction_tmp}
              isPassData={this.state.isPassData}
              reload={this.loadInitData}
              toggleMeta={() => this.onClose(2)}
              isOpenMetaForm={this.state.isOpenMetaModal}
            />
          </ModalBody>
        </Modal>

        {/* transfer modal */}
        <TransactionModal
          transactionId={this.state.transaction_tmp.transaction_id}
          amount={this.state.transaction_tmp.amount}
          toggle={() => this.toggle()}
          onClose={() => this.onClose()}
          isOpenModal={this.state.isOpenTransModal}
          currentIdentity={this.state.currentIdentity}
          handleOnChangeTrans={this.handleOnChangeTrans}
          reload={this.loadInitData}
          personIdentity={'Producer'}
          outputIndex={this.state.transaction_tmp.output_index}
        />

        {/* history modal */}
        <Modal isOpen={this.state.isOpenHistoryModal} toggle={() => this.onClose(4)} className={this.props.className}>
          <ModalHeader>History View</ModalHeader>
          <ModalBody>
            <History
              historyData={this.state.history}
            />
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={() => this.onClose(4)}>Ok</Button>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}

export default Distributor;
