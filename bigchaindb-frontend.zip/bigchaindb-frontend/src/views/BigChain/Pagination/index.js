import React from 'react';
import { Pagination, PaginationItem, PaginationLink } from 'reactstrap';

class CustomPagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
			currentPage: 1,
			pages: 1
		};
	}
	
	moveBack = () => {
		const {currentPage} = this.props;
		this.props.switchPage(currentPage - 1);
	}

	moveNext = (e) => {
		const {currentPage} = this.props;
		this.props.switchPage(currentPage + 1);
	}

	switchPage = (e) => {
		this.props.switchPage(Number(e.target.textContent));
	}
  
  render() {
		const { currentPage, total, pageSize } = this.props;
		const pages = (total%pageSize) !== 0 ? Math.floor(total/pageSize + 1) : Math.floor(total/pageSize);
		const data = [];

		for(let i = 1; i <= pages; i++) {
			const temp = <PaginationItem active={currentPage === i} key={i}>
				<PaginationLink tag="button" onClick={this.switchPage} >{i}</PaginationLink>
			</PaginationItem>;
			data.push(temp);
		}
    return (
			<Pagination>
				<PaginationItem disabled={currentPage === 1}><PaginationLink previous tag="button" onClick={this.moveBack}>Prev</PaginationLink></PaginationItem>
				{
					data.map(item => item)
				}
				<PaginationItem disabled={currentPage === pages || pages === 1}><PaginationLink next tag="button"  onClick={this.moveNext}>Next</PaginationLink></PaginationItem>
			</Pagination>
    );
  }
}

export default CustomPagination;
