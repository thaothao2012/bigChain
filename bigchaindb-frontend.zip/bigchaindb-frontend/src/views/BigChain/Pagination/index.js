import React from 'react';
import { Pagination, PaginationItem, PaginationLink } from 'reactstrap';

class CustomPagination extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentPage: 1
		};
		const paginate = {
			total: 27,
			pageSize: 10,
			currentPage: 1,
			pages: 3
		};
	}
	componentDidMount() {
		const { pageSize, total } = this.props;
		this.setState({
			pages: Math.floor(total/pageSize) + 1
		});
	}
	
	moveBack = (e) => {
		this.setState({
			currentPage: this.state.currentPage - 1
		})
	}

	moveNext = (e) => {
		this.setState({
			currentPage: this.state.currentPage + 1
		})
	}

	switchPage = (e) => {
		const value = Number(e.target.textContent);
		this.setState({
			currentPage: value
		})
	}
  
  
  render() {
		const { pages, currentPage } = this.state;
		const data = [];
		for(let i = 1; i <= pages; i++) {
			const temp = <PaginationItem active={currentPage === i} key={i}>
				<PaginationLink tag="button" onClick={this.switchPage} >{i}</PaginationLink>
			</PaginationItem>;
			data.push(temp);
		}
    return (
			<Pagination>
				<PaginationItem disabled={currentPage === 1}><PaginationLink previous tag="button" onClick={this.moveBack}>Prev</PaginationLink></PaginationItem>
				{
					data.map(item => item)
				}
				<PaginationItem disabled={currentPage === pages}><PaginationLink next tag="button"  onClick={this.moveNext}>Next</PaginationLink></PaginationItem>
			</Pagination>
    );
  }
}

export default CustomPagination;
