import React, { Component } from 'react';
import { ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Card, CardBody, CardHeader, Row, Col } from 'reactstrap';
import { formatDate, formatName } from '../Utils';

class HistoryModal extends Component {

  formatShowData = (obj) => {
    const keys = Object.keys(obj.content);
    return (<ListGroupItemText>
      {
        keys.map((key, idx) => {
          if (key === 'timeStamp') {
            return <React.Fragment key={idx}><label>{formatName(key)}:</label> {formatDate(obj.content[key])} <br /></React.Fragment>;
          }
          return <React.Fragment key={idx}>
            <Row>
              <Col sm="4"><label><b>{formatName(key)}:</b></label></Col>
              <Col sm="8">{obj.content[key]} <br /></Col>
            </Row> </React.Fragment>;
        })
      }
    </ListGroupItemText>);
  }
  render() {
    const { historyData } = this.props;
    const dataTmp = historyData[0];
    // const historyList = historyData && historyData.map((item, index) => {
    //   return (
    //     <React.Fragment key={index}>
    //       <ListGroupItem active className='header-meta-info'>
    //         <ListGroupItemHeading>Provider name: {item.content.providerName} - Time Stamp: {item.timeStamp}</ListGroupItemHeading>
    //       </ListGroupItem>
    //       <ListGroupItem className='header-meta-info' style={{ marginBottom: '10px' }}>

    //       </ListGroupItem>
    //     </React.Fragment>)
    // });
    return (
      <Card>
        <CardHeader>
          Provider name: {dataTmp.content.providerName} - Time Stamp: {dataTmp.timeStamp}
        </CardHeader>
        <CardBody style={{ overflowY: 'auto' }}>
          {/* <ListGroup style={{ height: '465px' }}> */}
          <ListGroup>
            {this.formatShowData(dataTmp)}
          </ListGroup>
        </CardBody>
      </Card>
    );
  }
}

export default HistoryModal;
