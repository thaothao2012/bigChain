import React, { Component } from 'react';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  Form,
  FormGroup,
  Input,
  Label
} from 'reactstrap';
import TransactionModal from '../Modal/transactionModal';

class AssetInfo extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: '',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      itemEditing: initModel,
      isOpenTransactionModal: false
    };
  }

  handleCreateAsset = () => {
    this.props.handleCreateAsset();
  }

  handleAddAsset = (e) => {
    e.preventDefault();
    this.props.handleOnAddAsset(e);
  }

  toCamelCase(str){
    return str.split(' ').map((word, index) => {
      if(index === 0){
        return word.toLowerCase();
      }
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join('');
  }

  toggleTransaction = () => {
    this.setState(prevState => ({
      isOpenTransactionModal: !prevState.isOpenTransactionModal
    }));
  }

  render() {
    const { handleOnChange } = this.props;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;

    return (
      <Card>
        <CardHeader>
          Asset Info
				</CardHeader>
        <CardBody >
          <Row>
            <Col xs='12' sm='10'>
              <Form id="asset-info" sm={8}>
                <FormGroup row>
                  <Label for="Id" sm='4'>Id:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      value={itemEditing.asset_id || ''}
                      disabled
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="name" sm='4'>Name:</Label>
                  <Col sm={8}>
                    <Input
                      color="red"
                      type="text"
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={itemEditing.name || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="supplierType" sm='4'>Supplier Type:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="supplierType"
                      name="supplierType"
                      value={itemEditing.supplierType || ''}
                      onChange={handleOnChange}>
                      <option defaultValue='' disabled value='' hidden></option>
                      <option value='Farmer'>Farmer</option>
                      <option value='Producer'>Producer</option>
                      <option value='Distributor'>Distributor</option>
                      <option value='Retailer'>Retailer</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailName" sm='4'>Retail Name:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailName"
                      name="retailName"
                      onChange={handleOnChange}
                      value={itemEditing.retailName || ''} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailAddress" sm='4'>Retail Address:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailAddress"
                      name="retailAddress"
                      onChange={handleOnChange}
                      value={itemEditing.retailAddress || ''} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quality" sm='4'>Quality:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="quality"
                      name="quality"
                      value={itemEditing.quality || ''} onChange={handleOnChange}>
                      <option defaultValue='' disabled value='' hidden></option>
                      <option value='Good'>Good</option>
                      <option value='Medium'>Medium</option>
                      <option value='Bad'>Bad</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="grossWeight" sm='4'>Weight:</Label>
                  <Col sm={8}>
                    <Input
                      type="number"
                      id="grossWeight"
                      name="grossWeight"
                      value={itemEditing.grossWeight || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quarantineNum" sm='4'>Quarantine Num:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="quarantineNum"
                      name="quarantineNum"
                      value={itemEditing.quarantineNum || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="normalPrice" sm='4'>Normal Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="normalPrice"
                      name="normalPrice"
                      value={itemEditing.normalPrice || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="promotionPrice" sm='4'>Promotion Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="promotionPrice"
                      name="promotionPrice"
                      value={itemEditing.promotionPrice || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup className="form-actions">
                  <Button
                    type="submit"
                    size="sm"
                    color="success"
                    disabled={itemEditing.status}
                    style={{ marginRight: 10 }}
                    onClick={this.handleAddAsset}>
                    {itemEditing.assetId ? 'Update' : 'Save'}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    color="light"

                    onClick={this.props.handleOnReset}>Reset</Button>
                  <Button
                    type="button"
                    size="sm"
                    color="primary"
                    disabled={itemEditing.status === "C" || !itemEditing.assetId || itemEditing.isExistMetaData}
                    style={{ float: 'right' }}
                    onClick={() => this.props.toggle(false)}>Additional Data</Button>
                </FormGroup>
              </Form>
            </Col >
            <Col xs='12' sm='2'>
              <div style={{ marginTop: "100%" }} sm={4}>
                <Button
                  type="button"
                  color="primary"
                  onClick={this.handleCreateAsset}
                  disabled = {!itemEditing.id || itemEditing.status === 'C' || itemEditing.status === 'T' || itemEditing.status === 'A'}
                >
                  Create Asset
                </Button><br />
                <Button
                  type="button"
                  color="warning"
                  style={{ marginTop: "7px" }}
                  onClick={() => this.props.toggle(false, true)}
                  disabled={!itemEditing.id || itemEditing.status === 'A' || itemEditing.status === 'T'}
                >
                  Add Meta
                </Button><br />
                <Button
                  type="button"
                  color="danger"
                  style={{ marginTop: "7px" }}
                  disabled = {!itemEditing.id || itemEditing.status === 'C' || itemEditing.status === 'T'}
                  onClick={this.toggleTransaction}
                >
                  Transfer Asset
                </Button>
              </div>
            </Col>
          </Row>
          <TransactionModal 
            toggle={this.toggleTransaction}
            isOpenModal={this.state.isOpenTransactionModal}
            transactionId={itemEditing.transactionId}
            transactionAssetId={itemEditing.transactionAssetId}
            amount={itemEditing.grossWeight}
            bcId={itemEditing.id}
            loadDataTable={this.props.handleReloadDataTable}
            loadHistoryOfAsset={this.props.handleReloadDataTable}
          />
        </CardBody>
      </Card>
    );
  }
}

export default AssetInfo;
