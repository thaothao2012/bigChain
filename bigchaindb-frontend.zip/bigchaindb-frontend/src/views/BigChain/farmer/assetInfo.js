import React, { Component } from 'react';
import CallApi from '../../../callApi/apiCall';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  Form,
  FormGroup,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText, Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';

class AssetInfo extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: '',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      modal: false,
      itemEditing: initModel
    };
  }

  toggle = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  handleAddAsset = (e) => {
    e.preventDefault();
    const itemEditing_id = this.props.itemEditing.id;
    this.props.handleOnAddAsset(e,itemEditing_id);
  }


  render() {
    const { handleOnChange } = this.props;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;
    return (
      <Card>
        <CardHeader>
          Asset Info
				</CardHeader>
        <CardBody >
          <Row>
            <Col xs='12' sm='10'>
              <Form id="asset-info" sm={8}>
                <FormGroup row>
                  <Label for="name" sm='4'>Name:</Label>
                  <Col sm={8}>
                    <Input
                      color="red"
                      type="text"
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={itemEditing.name}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="supplierType" sm='4'>Supplier Type:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="supplierType"
                      name="supplierType"
                      autoComplete="supplierType"
                      onChange={handleOnChange}
                      value={itemEditing.supplierType} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailName" sm='4'>Retail Name:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailName"
                      name="retailName"
                      onChange={handleOnChange}
                      value={itemEditing.retailName} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailAddress" sm='4'>Retail Address:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailAddress"
                      name="retailAddress"
                      onChange={handleOnChange}
                      value={itemEditing.retailAddress} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quality" sm='4'>Quality:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="quality"
                      name="quality"
                      value={itemEditing.quality} onChange={handleOnChange}>
                      <option>good</option>
                      <option>medium</option>
                      <option>bad</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="grossWeight" sm='4'>Weight:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="grossWeight"
                      name="grossWeight"
                      value={itemEditing.grossWeight}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quarantineNum" sm='4'>Quarantine Num:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="quarantineNum"
                      name="quarantineNum"
                      value={itemEditing.quarantineNum}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="normalPrice" sm='4'>Normal Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="normalPrice"
                      name="normalPrice"
                      value={itemEditing.normalPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="promotionPrice" sm='4'>Promotion Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="promotionPrice"
                      name="promotionPrice"
                      value={itemEditing.promotionPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup className="form-actions">
                  <Button
                    type="submit"
                    size="sm"
                    color="success"
                    style={{ marginRight: 10 }}
                    onClick={this.handleAddAsset}>
                    {itemEditing.id ? 'Update' : 'Save'}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    color="light"
                    onClick={ this.props.handleOnReset}>Reset</Button>
                  <Button
                    type="button"
                    size="sm"
                    color="primary"
                    style={{ float: 'right' }}
                    onClick={this.toggle}>Additional Data</Button>
                </FormGroup>
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
                  <ModalHeader toggle={this.toggle}>Metadata of pork</ModalHeader>
                  <ModalBody>
                    <FormGroup>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText><i className="fa fa-asterisk"></i></InputGroupText>
                        </InputGroupAddon>
                        <Input
                          type="text"
                          id="nameMeta"
                          name="nameMeta"
                          placeholder="Name Metadata"
                          autoComplete="name" />
                      </InputGroup>
                    </FormGroup>
                    <FormGroup>
                      <InputGroup>
                        <InputGroupAddon addonType="prepend">
                          <InputGroupText><i className="fa fa-asterisk"></i></InputGroupText>
                        </InputGroupAddon>
                        <Input
                          type="textarea"
                          id="data"
                          name="data"
                          placeholder="Data"
                          autoComplete="name" />
                      </InputGroup>
                    </FormGroup>

                  </ModalBody>
                  <ModalFooter>
                    <Button color="primary" onClick={this.toggle}>Add</Button>{' '}
                    <Button color="secondary" onClick={this.toggle}>Cancel</Button>
                  </ModalFooter>
                </Modal>
              </Form>

            </Col >
            <Col xs='12' sm='2'>
              <div style={{ marginTop: "100%" }} sm={4}>
                <button type="button" className="btn-primary">Create Asset</button><br />
                <button type="button" className="btn-warning" style={{ marginTop: "7px" }}>Add Meta</button><br />
                <button type="button" className="btn-danger" style={{ marginTop: "7px" }}>Transfer Asset</button>
              </div>
            </Col>
          </Row>

        </CardBody>
      </Card>
    );
  }
}

export default AssetInfo;
