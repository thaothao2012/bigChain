import React, { Component } from 'react';
import CallApi from '../../../callApi/apiCall';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  Form,
  FormGroup,
  Input,
  Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';
import { forEachChild } from 'typescript';

let inputs = [];

class AssetInfo extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: '',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      modal: false,
      itemEditing: initModel,
      reloadPage: 0,
      dynamicData: [],
      metaData: {
        metaName: '',
        supplierType: '',
        note: '',
        detail :{
          key : '',
          value : ''
        }
      }
    };
  }

  handleCreateAsset = () => {
    this.props.handleCreateAsset();
  }
  handleAddMetaBlockChain = () => {
    this.props.handleAddMetaBlockChain();
  }
  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  handleChange = e => {
    const { metaData } = this.state;
    const { name, value } = e.target;
    this.setState({
      metaData: { ...metaData.detail, [name]: value }
    })
  }

  toggle = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  handleAddAsset = (e) => {
    e.preventDefault();
    this.props.handleOnAddAsset(e);
  }

  handleSubmitMetaData = () => {
    const bcId = this.props.itemEditing.bcId;
    const { metaData } = this.state;
    const dataTranfer = {
      bcId: bcId,
      metaName: metaData.metaName,
      amoutToSend: metaData.amoutToSend,
      note: metaData.note,
      ...this.formatDynamicData()
    }
    //console.log(dataTranfer);
    CallApi('metadata', 'POST', dataTranfer).then( res =>{
      if(res){
        //console.log(res);
        alert("Add metadata thanh cong!");
      }
    })

  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  handleOnAddField = () => {
    const generateId = this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    const input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Col sm='3'>
          <Input
            type="text"
            id={key}
            name={key}
            placeholder="key"
            valueDefault=""
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <Label>:</Label>
        </Col>
        <Col sm='7'>
          <Input
            type="text"
            id={valueField}
            name={valueField}
            autoComplete="dataPlus"
            placeholder="value"
            valueDefault=""
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <i className="fa fa-align-justify" onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
        </Col>
      </FormGroup>)
    };
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  S4 = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  generateId = () => {
    return this.S4();
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }

  render() {
    console.log(this.state.metaData);
    const { handleOnChange } = this.props;
    const { metaData } = this.state;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;
    const status = false;
    return (
      <Card>
        <CardHeader>
          Asset Info
				</CardHeader>
        <CardBody >
          <Row>
            <Col xs='12' sm='10'>
              <Form id="asset-info" sm={8}>
                <FormGroup row>
                  <Label for="name" sm='4'>Name:</Label>
                  <Col sm={8}>
                    <Input
                      color="red"
                      type="text"
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={itemEditing.name}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="supplierType" sm='4'>Supplier Type:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="supplierType"
                      name="supplierType"
                      autoComplete="supplierType"
                      onChange={handleOnChange}
                      value={itemEditing.supplierType} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailName" sm='4'>Retail Name:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailName"
                      name="retailName"
                      onChange={handleOnChange}
                      value={itemEditing.retailName} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailAddress" sm='4'>Retail Address:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailAddress"
                      name="retailAddress"
                      onChange={handleOnChange}
                      value={itemEditing.retailAddress} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quality" sm='4'>Quality:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="quality"
                      name="quality"
                      value={itemEditing.quality} onChange={handleOnChange}>
                      <option>Good</option>
                      <option>Medium</option>
                      <option>Bad</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="grossWeight" sm='4'>Weight:</Label>
                  <Col sm={8}>
                    <Input
                      type="number"
                      id="grossWeight"
                      name="grossWeight"
                      value={itemEditing.grossWeight}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quarantineNum" sm='4'>Quarantine Num:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="quarantineNum"
                      name="quarantineNum"
                      value={itemEditing.quarantineNum}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="normalPrice" sm='4'>Normal Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="normalPrice"
                      name="normalPrice"
                      value={itemEditing.normalPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="promotionPrice" sm='4'>Promotion Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="promotionPrice"
                      name="promotionPrice"
                      value={itemEditing.promotionPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup className="form-actions">
                  <Button
                    type="submit"
                    size="sm"
                    color="success"
                    disabled={itemEditing.status === "C" ? true : false}
                    style={{ marginRight: 10 }}
                    onClick={this.handleAddAsset}>
                    {itemEditing.bcId ? 'Update' : 'Save'}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    color="light"

                    onClick={this.props.handleOnReset}>Reset</Button>
                  <Button
                    type="button"
                    size="sm"
                    color="primary"
                    disabled={(itemEditing.status === "C" || !itemEditing.bcId) ? true : false}
                    style={{ float: 'right' }}
                    onClick={this.toggle}>Additional Data</Button>
                </FormGroup>
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
                  <ModalHeader toggle={this.toggle}>Metadata of pork</ModalHeader>
                  <ModalBody>
                    <FormGroup row>
                      <Label for="name" sm='4'>Meta Name:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="metaName"
                          name="metaName"
                          autoComplete="metaName"
                          value={metaData.metaName}
                          onChange={this.handleChange}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='4'>Supplier Type:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="supplierType"
                          name="supplierType"
                          autoComplete="supplierType"
                          value={metaData.amoutToSend}
                          onChange={this.handleChange}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='4'>Note Action:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="note"
                          name="note"
                          autoComplete="note"
                          value={metaData.note}
                          onChange={this.handleChange}
                        />
                      </Col>
                    </FormGroup>
                    <Card>
                      <CardHeader>
                        Detail
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
                      </CardHeader>
                      <CardBody>
                        {this.formatRender()}
                      </CardBody>
                    </Card>
                  </ModalBody>
                  <ModalFooter>
                    <Button color="primary" onClick={this.handleSubmitMetaData}>Add</Button>{' '}
                    <Button color="secondary" onClick={this.toggle}>Cancel</Button>
                  </ModalFooter>
                </Modal>
              </Form>
            </Col >
            <Col xs='12' sm='2'>
              <div style={{ marginTop: "100%" }} sm={4}>
                <button type="button" className="btn-primary"
                        onClick={this.handleCreateAsset}
                        disabled = {(!itemEditing._id || itemEditing.status === "C") ? true : false}>
                  Create Asset
                </button><br />
                <button type="button" className="btn-warning" style={{ marginTop: "7px" }}
                        onClick={this.handleAddMetaBlockChain}
                        // disabled = {(!itemEditing.id || itemEditing.status === "N" || itemEditing.status === "C-T" || itemEditing.status === "C-A") ? true : false}
                        disabled={itemEditing.status === "C" ? false : true}>
                  Add Meta
                </button><br />
                <button type="button" className="btn-danger" style={{ marginTop: "7px" }}
                        disabled = {(itemEditing.status === "C" || itemEditing.status === "C-A") ? false : true}>
                  Transfer Asset
                </button>
              </div>
            </Col>
          </Row>

        </CardBody>
      </Card>
    );
  }
}

export default AssetInfo;
