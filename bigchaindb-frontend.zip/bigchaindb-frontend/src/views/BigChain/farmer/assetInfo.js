import React, { Component } from 'react';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  CardFooter,
  Form,
  FormGroup,
  Input,
  Label,
  FormText
} from 'reactstrap';
import TransactionModal from '../Modal/transactionModal';

class AssetInfo extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: 'Farmer',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      itemEditing: initModel,
      isOpenTransactionModal: false,
      currentIdentity: {
        "privateKey": "AMudkHmEX8obNZzSiqHo3y6P7w3oDZs79Y6Bopv9whti",
        "publicKey": "A6yF47Ud5GMmRi5yii77ce3xeY7ppvCNUbxubbKyuvD3"
      }
    };
  }

  handleCreateAsset = () => {
    this.props.handleCreateAsset();
  }

  handleAddAsset = (e) => {
    e.preventDefault();
    this.props.handleOnAddAsset(e);
  }

  toCamelCase(str) {
    return str.split(' ').map((word, index) => {
      if (index === 0) {
        return word.toLowerCase();
      }
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join('');
  }

  toggleTransaction = () => {
    this.setState(prevState => ({
      isOpenTransactionModal: !prevState.isOpenTransactionModal
    }));
  }

  render() {
    const { handleOnChange, isError, assetInforValidate } = this.props;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;
    return (
      <Card>
        <CardHeader>
          Asset Info
				</CardHeader>
        <CardBody >
          <Row>
            <Col xs='12' sm='10'>
              <Form id="asset-info" sm={8} >
                <FormGroup row>
                  <Label for="Id" sm='4'>Id:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      value={itemEditing.asset_id || ''}
                      disabled
                    />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="name" sm='4'>Origin:</Label>
                  <Col sm={8}>
                    <Input
                      color="red"
                      type="text"
                      invalid={(isError && assetInforValidate.name === '') ? true : false}
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={itemEditing.name || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="supplierType" sm='4'>Supplier Type:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="supplierType"
                      name="supplierType"
                      value={itemEditing.supplierType || 'Farmer'}
                      onChange={handleOnChange}>
                      <option disabled value='' hidden></option>
                      <option value='Farmer'>Farmer</option>
                      <option value='Producer'>Producer</option>
                      <option value='Distributor'>Distributor</option>
                      <option value='Retailer'>Retailer</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="farmerName" sm='4'>Farmer Name: </Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      invalid={(isError && assetInforValidate.farmerName === '') ? true : false}
                      id="farmerName"
                      name="farmerName"
                      onChange={handleOnChange}
                      value={itemEditing.farmerName || ''} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="farmerAddress" sm='4'>Farmer Address: </Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      invalid={(isError && assetInforValidate.farmerAddress === '') ? true : false}
                      id="farmerAddress"
                      name="farmerAddress"
                      onChange={handleOnChange}
                      value={itemEditing.farmerAddress || ''} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quality" sm='4'>Health Status:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      invalid={(isError && assetInforValidate.healthStatus === '') ? true : false}
                      id="healthStatus"
                      name="healthStatus"
                      value={itemEditing.healthStatus || ''} onChange={handleOnChange}>
                      <option disabled value='' hidden></option>
                      <option value='Good'>Good</option>
                      <option value='Medium'>Medium</option>
                      <option value='Bad'>Bad</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="grossWeight" sm='4'>Weight(g):</Label>
                  <Col sm={8}>
                    <Input
                      type="number"
                      invalid={(isError && assetInforValidate.grossWeight === '') ? true : false}
                      id="grossWeight"
                      name="grossWeight"
                      value={itemEditing.grossWeight || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="porkFeed" sm='4'>Pork Feed:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      invalid={(isError && assetInforValidate.porkFeed === '') ? true : false}
                      id="porkFeed"
                      name="porkFeed"
                      value={itemEditing.porkFeed || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="porkFeed" sm='4'>Date Out:</Label>
                  <Col sm={8}>
                    <Input
                      type="date"
                      invalid={(isError && assetInforValidate.dateOut === '') ? true : false}
                      id="dateOut"
                      name="dateOut"
                      value={itemEditing.dateOut || ''}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
              </Form>
            </Col >
            <Col xs='12' sm='2' className='container-group-btn'>

              <div className='group-btn'>
                <Label color="" style={{ textAlign: "center", marginBottom: "20px" }}><b>Supply Chain Network</b></Label>
                <Button
                  type="button"
                  onClick={this.handleCreateAsset}
                  disabled={!itemEditing.id || itemEditing.status === 'C' || itemEditing.status === 'T' || itemEditing.status === 'A' || itemEditing.isExistMetaData === false}
                >
                  Create Asset
                </Button><br />
                <Button
                  type="button"
                  style={{ marginTop: "7px" }}
                  onClick={() => this.props.toggle(false, true)}
                  disabled={!itemEditing.id || itemEditing.status === 'T' || itemEditing.status === 'N'}
                >
                  Add MetaData
                </Button><br />
                <Button
                  type="button"
                  style={{ marginTop: "7px" }}
                  disabled={!itemEditing.id || itemEditing.status === 'T' || itemEditing.status === 'N'}
                  onClick={this.toggleTransaction}
                >
                  Transfer Asset
                </Button>
              </div>
            </Col>
          </Row>
          <TransactionModal
            toggle={this.toggleTransaction}
            isOpenModal={this.state.isOpenTransactionModal}
            transactionId={itemEditing.transactionId}
            transactionAssetId={itemEditing.transactionAssetId}
            amount={itemEditing.grossWeight}
            bcId={itemEditing.id}
            loadDataTable={this.props.handleReloadDataTable}
            loadHistoryOfAsset={this.props.loadHistoryOfAsset}
            reloadStatusOfAsset={this.props.reloadStatusOfAsset}
            currentIdentity={this.state.currentIdentity}
            personIdentity={'Farmer'}
          />
        </CardBody>
        <CardFooter>
          <Button
            type="submit"
            size="sm"
            disabled={itemEditing.status && itemEditing.status !== 'N'}
            onClick={this.handleAddAsset}
            style={{ width: '100px' }}
            className='btn-action btn-primary'>
            {itemEditing.assetId ? 'Update' : 'Save'}
          </Button>
          <Button
            type="button"
            size="sm"
            className='btn-action'
            onClick={this.props.handleOnReset}>Add New</Button>
          <Button
            type="button"
            size="sm"
            disabled={itemEditing.status === "C" || !itemEditing.assetId || itemEditing.isExistMetaData}
            style={{ float: 'right' }}
            className='btn-action btn-primary'
            onClick={() => this.props.toggle(false)}>Additional Data</Button>
          {/* <FormText style={{float:"right"}}>Example help text that remains unchanged.</FormText> */}
        </CardFooter>
      </Card>
    );
  }
}

export default AssetInfo;
