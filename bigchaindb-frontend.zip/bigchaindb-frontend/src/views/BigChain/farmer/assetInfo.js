import React, { Component } from 'react';
import CallApi from '../../../callApi/apiCall';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  Form,
  FormGroup,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText, Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';
import { forEachChild } from 'typescript';

const inputs = [];

class AssetInfo extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: '',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      modal: false,
      itemEditing: initModel,
      reloadPage: 0,
      dynamicData: [],
      metaData : {
        metaName : '',
        amoutToSend : '',
        note : '',
        // key : '',
        // value : ''
      }
    };
  }

  handleChangeModal = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = {[name] : value};
    const existObj = dynamicData.filter(item => Object.keys(item) === name)[0];
    const index = dynamicData.indexOf(existObj);
    if (index !== -1) {
      dynamicData.slice(index, -1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  toggle = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }));
  }

  handleAddAsset = (e) => {
    e.preventDefault();
    this.props.handleOnAddAsset(e);
  }

  handleAddMeta = () => {
    const bcId = this.props.itemEditing.bcId;
    const { metaData } = this.state;
    const dataTranfer = {
      bcId : bcId,
      metaName : metaData.name,
      amoutToSend : metaData.amoutToSend,
      note : metaData.note,
      ...this.formatDynamicData()
    }

    console.log(dataTranfer);
    // CallApi('metadata', 'POST', dataTranfer).then( res =>{
    //   if(res){
    //     console.log(res);

    //   }
    // })
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};
    keyArr.forEach((item, idx) => {
      const temp = {[Object.values(item)[0]]: Object.values(valueArr[idx])[0]};
      resObj = Object.assign({}, ...resObj, ...temp);
    })
    return resObj;
  }

  handleOnAddField = () => {
    const key = `dynamic-key-${this.generateId()}`;
    const valueField = `dynamic-value-${this.generateId()}`;
    const input = (<FormGroup row>
                    <Col sm='3'>
                      <Input
                        type="text"
                        id={key}
                        name={key}
                        placeholder="key"
                        valueDefault=""
                        onChange={this.handleChangeModal}
                        />
                    </Col>
                    <Col sm='1'>
                      <Label>:</Label>
                    </Col>
                    <Col sm='7'>
                      <Input
                        type="text"
                        id={valueField}
                        name={valueField}
                        autoComplete="dataPlus"
                        placeholder="value"
                        valueDefault=""
                        onChange={this.handleChangeModal}
                      />
                    </Col>
                  </FormGroup>);
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
    console.log('metadata', this.state.metaData);
  }
  S4 = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }
  generateId = () => {
    return this.S4();
  }

  render() {
    const { handleOnChange } = this.props;
    const { metaData } = this.state;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;
    return (
      <Card>
        <CardHeader>
          Asset Info
				</CardHeader>
        <CardBody >
          <Row>
            <Col xs='12' sm='10'>
              <Form id="asset-info" sm={8}>
                <FormGroup row>
                  <Label for="name" sm='4'>Name:</Label>
                  <Col sm={8}>
                    <Input
                      color="red"
                      type="text"
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={itemEditing.name}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="supplierType" sm='4'>Supplier Type:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="supplierType"
                      name="supplierType"
                      autoComplete="supplierType"
                      onChange={handleOnChange}
                      value={itemEditing.supplierType} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailName" sm='4'>Retail Name:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailName"
                      name="retailName"
                      onChange={handleOnChange}
                      value={itemEditing.retailName} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="retailAddress" sm='4'>Retail Address:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="retailAddress"
                      name="retailAddress"
                      onChange={handleOnChange}
                      value={itemEditing.retailAddress} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quality" sm='4'>Quality:</Label>
                  <Col sm={8}>
                    <Input
                      type="select"
                      id="quality"
                      name="quality"
                      value={itemEditing.quality} onChange={handleOnChange}>
                      <option>good</option>
                      <option>medium</option>
                      <option>bad</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="grossWeight" sm='4'>Weight:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="grossWeight"
                      name="grossWeight"
                      value={itemEditing.grossWeight}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="quarantineNum" sm='4'>Quarantine Num:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="quarantineNum"
                      name="quarantineNum"
                      value={itemEditing.quarantineNum}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="normalPrice" sm='4'>Normal Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="normalPrice"
                      name="normalPrice"
                      value={itemEditing.normalPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="promotionPrice" sm='4'>Promotion Price:</Label>
                  <Col sm={8}>
                    <Input
                      type="text"
                      id="promotionPrice"
                      name="promotionPrice"
                      value={itemEditing.promotionPrice}
                      onChange={handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup className="form-actions">
                  <Button
                    type="submit"
                    size="sm"
                    color="success"
                    style={{ marginRight: 10 }}
                    onClick={this.handleAddAsset}>
                    {itemEditing.id ? 'Update' : 'Save'}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    color="light"
                    onClick={this.props.handleOnReset}>Reset</Button>
                  <Button
                    type="button"
                    size="sm"
                    color="primary"
                    disabled = {(itemEditing.id) ? false : true}
                    style={{ float: 'right' }}
                    onClick={this.toggle}>Additional Data</Button>
                </FormGroup>
                <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
                  <ModalHeader toggle={this.toggle}>Metadata of pork</ModalHeader>
                  <ModalBody>
                    <FormGroup row>
                      <Label for="name" sm='4'>Meta Name:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="metaName"
                          name="metaName"
                          autoComplete="metaName"
                          value={metaData.metaName}
                          onChange={this.handleChangeModal}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='4'>Amout to send:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="amoutToSend"
                          name="amoutToSend"
                          autoComplete="amoutToSend"
                          value={metaData.amoutToSend}
                          onChange={this.handleChangeModal}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='4'>Note:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          id="note"
                          name="note"
                          autoComplete="note"
                          value={metaData.note}
                          onChange={this.handleChangeModal}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="dataMeta" sm='4'>Detail:</Label>
                      <Col sm={8}>
                        <Form
                        // style={{backgroundColor : "#d9d9d9"}}
                        >
                          <FormGroup row>
                            {/* <Col sm='3'> */}
                              <Button color="primary" onClick={this.handleOnAddField}>Add field</Button>
                            {/* </Col> */}
                          </FormGroup>
                          {inputs}
                        </Form>
                      </Col>
                    </FormGroup>
                  </ModalBody>
                  <ModalFooter>
                    <Button color="primary" onClick={this.handleAddMeta}>Add</Button>{' '}
                    <Button color="secondary" onClick={this.toggle}>Cancel</Button>
                  </ModalFooter>
                </Modal>
              </Form>
            </Col >
            <Col xs='12' sm='2'>
              <div style={{ marginTop: "100%" }} sm={4}>
                <button type="button" className="btn-primary" disabled>
                  Create Asset
                </button><br />
                <button type="button" className="btn-warning" style={{ marginTop: "7px" }} disabled>
                  Add Meta
                </button><br />
                <button type="button" className="btn-danger" style={{ marginTop: "7px" }} disabled>
                  Transfer Asset
                </button>
              </div>
            </Col>
          </Row>

        </CardBody>
      </Card>
    );
  }
}

export default AssetInfo;
