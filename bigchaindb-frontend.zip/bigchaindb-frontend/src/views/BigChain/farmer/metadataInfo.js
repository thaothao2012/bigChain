import React, { Component } from 'react';
import { ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Card, CardBody, CardHeader } from 'reactstrap';
import { formatDate, formatName } from '../Utils';

class MetadataInfo extends Component {

  formatShowData = (obj) => {
    const keys = Object.keys(obj.detail);
    return (<ListGroupItemText>
      {
        keys.map((key, idx) => {
          if (key === 'timeStamp') {
            return <React.Fragment key={idx}><label>{formatName(key)}:</label> { formatDate(obj.detail[key]) } <br /></React.Fragment>;
          }
          return <React.Fragment key={idx}><label>{formatName(key)}:</label> { obj.detail[key] } <br /></React.Fragment>;
        })
      }
    </ListGroupItemText>);
  }
  render() {
    const { historyData } = this.props;
    const historyList = historyData && historyData.map((item, index) => {
      return (
        <React.Fragment key={index}>
          <ListGroupItem active className='header-meta-info'>
            <ListGroupItemHeading>Supplier Type: {item.supplierType} - Add: {item.name}</ListGroupItemHeading>
          </ListGroupItem>
          <ListGroupItem className='header-meta-info' style={{ marginBottom: '10px' }}>
            {this.formatShowData(item)}
          </ListGroupItem>
        </React.Fragment>)
    });
    return (
      <Card>
        <CardHeader>
          History of item
        </CardHeader>
        <CardBody style={{ overflowY: 'auto' }}>
          <ListGroup style={{ height: '465px' }}>
            {historyList}
          </ListGroup>
        </CardBody>
      </Card>
    );
  }
}

export default MetadataInfo;
