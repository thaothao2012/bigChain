import React, { Component } from 'react';
import { ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Card, CardBody, CardHeader } from 'reactstrap';
import { formatDate } from '../Utils';

class MetadataInfo extends Component {
  formatName(str) {
    return str.split(' ').map((word) => {
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join(' ');
  }

  formatShowData = (obj) => {
    const keys = Object.keys(obj.detail);
    return (<ListGroupItemText>
      {
        keys.map(key => {
          if (key === 'timeStamp') {
            return <React.Fragment>{`${this.formatName(key)}: ${formatDate(obj.detail[key])}`} <br /></React.Fragment>;
          }
          return <React.Fragment>{`${this.formatName(key)}: ${obj.detail[key]}`} <br /></React.Fragment>;
        })
      }
    </ListGroupItemText>);
  }
  render() {
    const { historyData } = this.props;
    const historyList = historyData && historyData.map((item, index) => {
      return (
      <ListGroupItem key={index}>
        <ListGroupItemHeading>{item.supplierType}</ListGroupItemHeading>
        {this.formatShowData(item)}
      </ListGroupItem>)
    });
    return (
      <Card>
        <CardHeader>
          History of item
        </CardHeader>
        <CardBody>
          <ListGroup style={{ overflow: "scroll", height: "450px" }}>
            {historyList}
          </ListGroup>
        </CardBody>
      </Card>
    );
  }
}

export default MetadataInfo;
