import React, { Component } from 'react';
import { ListGroup, ListGroupItem, ListGroupItemHeading, ListGroupItemText, Card, CardBody, CardHeader,
         ButtonGroup, Button
      } from 'reactstrap';

const dataTest = [{
  farmInfo: {
    "date": "20/11/2019",
    "content": "pork version 1"
  }
},
{
  distributorInfo: {
    "date": "03/04/2019",
    "content": "pork version 2"
  }
},
{
  producerInfo: {
    "date": "01/10/2019",
    "content": "pork version 3"
  }
},
{
  producerInfo: {
    "date": "01/10/2019",
    "content": "pork version 3"
  }
},
{
  producerInfo: {
    "date": "01/10/2019",
    "content": "pork version 3"
  }
},
{
  producerInfo: {
    "date": "01/10/2019",
    "content": "pork version 3"
  }
},
]

class MetadataInfo extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }
  render() {
    const historyList = dataTest.map((item, index) => {
      let result = "";
      const valuesItem = Object.values(item);
      valuesItem.map((value) => {
        //console.log(value.date + "-" + value.content)
        result = <ListGroupItem key={index}>
          <ListGroupItemHeading>{Object.keys(item)}</ListGroupItemHeading>
          <ListGroupItemText>
            Date : {value.date}
            <br />
            Content : {value.content}
          </ListGroupItemText>
        </ListGroupItem>
      })
      return result;
    })
    return (
      <Card>
        <CardHeader>
          History of item
        </CardHeader>
        <CardBody>
          <ListGroup style={{ overflow: "scroll", height: "450px" }}>
            {historyList}
          </ListGroup>
          {/* <div style={{marginTop : "5px", textAlign: "center"}}>
            <ButtonGroup>
              <button type="button" className="btn-primary"><i className="fa fa-plus-circle"></i> Create Asset</button>
              <button type="button" className="btn-warning" style={{marginLeft : "5px"}}><i className="fa fa-plus-square"></i> Add Meta</button>
              <button type="button" className="btn-danger" style={{marginLeft : "5px"}}><i className="fa fa-truck"></i> Transfer Asset</button>

            </ButtonGroup>
          </div> */}
        </CardBody>
      </Card>
    );
  }
}

export default MetadataInfo;
