import React from 'react';
import { Col, Row, Dropdown, DropdownMenu, DropdownToggle, Input, DropdownItem, Button, InputGroup, InputGroupAddon } from 'reactstrap';
import AssetInfo from './assetInfo';
import MetaDataInfo from './metadataInfo';
import Pagination from '../Pagination';
import SemanticTableGrid from '../Table';
import CallApi from '../../../callApi/apiCall';

class FarmerHome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      dropdownOpen: new Array(6).fill(false),
      itemEditing: null,
      filtered: [],
      assetInfo : {
        name: '',
        supplierType: '',
        retailName: '',
        retailAddress: '',
        quality: '',
        grossWeight: '',
        quarantineNum: '',
        normalPrice: '',
        promotionPrice: ''
      }
    };
  }

  componentDidMount() {
    this.loadInitData();
  }

  loadInitData = () => {
    CallApi('asset', 'GET', null).then(res => {
      if (res !== undefined) {
        this.formatDataTable(res.data);
        this.setState({
          data: this.formatDataTable(res.data),
          filtered: this.formatDataTable(res.data)
        });
      }
    })
  }

  handleOnUpdate = id => {
    let { data } = this.state;
    let index = this.findIndex(id, data);
    if (index !== -1) {
      this.setState({
        itemEditing: data[index]
      });
    }
  }

  handleOnAddAsset = (e, id) =>{
    e.preventDefault();
    const {assetInfo,itemEditing} = this.state;
    const data = {
      name: assetInfo.name,
      supplierType: assetInfo.supplierType,
      retailName: assetInfo.retailName,
      retailAddress: assetInfo.retailAddress,
      quality: assetInfo.quality,
      grossWeight: assetInfo.grossWeight,
      quarantineNum: assetInfo.quarantineNum,
      normalPrice: assetInfo.normalPrice,
      promotionPrice: assetInfo.promotionPrice
    };
    if(!itemEditing.id){
      CallApi('asset', 'POST', data).then(res => {
        if(res){
          alert('Add thanh cong!');
          this.loadInitData();
        }
      });
    } else {
      this.setState({
        ...itemEditing, data
      });
      CallApi('asset/'+`${id}`, 'PUT', data).then(res => {
        if(res){
          alert('Update thanh cong!');
          this.loadInitData();
        }
      })
    }
  }

  handleOnChange = (e) => {
    const {assetInfo} = this.state;
    const target = e.target;
    const name = target.name;
    const value = target.value;
    const { itemEditing } = this.state;
    const updateItem = { ...itemEditing, [e.target.name]: e.target.value };
    this.setState({
      itemEditing: updateItem,
      assetInfo : {
        ...assetInfo, [name]: value
      }
    })
  }


  handleSearch = e => {
    let currentList = [];
    let newList = [];
    if (e.target.value !== "") {
      currentList = this.state.data;
      newList = currentList.filter(item => {
        if (item.name) {
          const lc = item.name.toLowerCase();
          const filter = e.target.value.toLowerCase();
          return lc.includes(filter);
        }
      });
    } else {
      newList = this.state.data;
    }
    this.setState({
      filtered: newList
    });
  }

  handleOnReset =() =>{
    this.setState({
      itemEditing : null
    });
  }

  findIndex = (id, arr) => {
    let result = -1;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].id === id) {
        result = i;
      }
    }
    return result;
  }

  formatDataTable = (data) => {
    const formatedData = [];
    data.forEach((item, idx) => {
      //const { asset } = item;
      //console.log(item)
      const temp = {
        no: idx + 1,
        name: item.name,
        ...item,
        actions: (
          <div>
            {/* <Button color="primary" className="btn-pill btn-table-action" onClick={() => this.handleOnUpdate(item.id)}>
              <i className="fa fa-lightbulb-o"></i>&nbsp;Edit
            </Button> */}
            <Button color="danger" className="btn-pill btn-table-action">
              <i className="fa fa-lightbulb-o"></i>&nbsp;Delete
            </Button>
          </div>
        ),
      };
      formatedData.push(temp);
    });
    return formatedData;
  }

  toggle(i) {

    const newArray = this.state.dropdownOpen.map((element, index) => {
      return (index === i ? !element : false);
    });
    this.setState({
      dropdownOpen: newArray,
    });
  }



  render() {
    const { filtered, itemEditing } = this.state;
    //console.log(itemEditing)
    const ToolBar = (
      <InputGroup>
        <Dropdown isOpen={this.state.dropdownOpen[4]} toggle={() => { this.toggle(4); }}>
          <DropdownToggle caret>
            Add filter
          </DropdownToggle>
          <DropdownMenu>
            <DropdownItem>Name</DropdownItem>
            <DropdownItem>Status</DropdownItem>
          </DropdownMenu>
        </Dropdown>
        <Input
          type="text"
          id="input1-group2"
          name="input1-group2"
          placeholder="Search..."
          onChange={this.handleSearch}
        />
        <InputGroupAddon addonType="prepend">
          <Button
            type="button"
            color="primary"
          >
            <i className="fa fa-search"></i> Search</Button>
        </InputGroupAddon>
      </InputGroup>);
    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs='12' sm='7'>
            <AssetInfo
                itemEditing={itemEditing}
                handleOnChange={this.handleOnChange}
                handleOnReset={this.handleOnReset}
                handleOnAddAsset={this.handleOnAddAsset}/>
          </Col>
          <Col xs='12' sm='5'>
            <MetaDataInfo />
          </Col>
        </Row>
        <Row>
          <Col>
            <SemanticTableGrid
              isLoading={false}
              tblClass='tbl-standard'
              elements={filtered}
              rowClassKey={'class'}
              columns={[
                { key: 'no', name: 'No', sortable: true },
                { key: 'name', name: 'Name', sortable: true },
                { key: 'supplierType', name: 'Supplier Type', sortable: true },
                { key: 'retailName', name: 'Retail Name', sortable: true },
                { key: 'retailAddress', name: 'Retail Address', sortable: true },
                { key: 'quality', name: 'Quality', sortable: true },
                { key: 'grossWeight', name: 'Gross Weight', sortable: true },
                // { key: 'quarantineNum', name: 'Quarantine Num', sortable: true },
                // { key: 'normalPrice', name: 'Normal Price', sortable: true },
                // { key: 'promotionPrice', name: 'Promotion Price', sortable: true },
                { key: 'status', name: 'Status', sortable: true },
                { key: 'actions', name: 'Actions', sortable: false }
              ]}
              canSort={{
                active: true,
                onSort: (key, order) => {

                }
              }}
              canPaginate={{
                active: true,
                render: (
                  <Pagination total={27} pageSize={10} />
                )
              }}
              canAction={{
                active: true,
                actions: [ToolBar]
              }}
              hiddenHeaderIfEmpty
              emptyResults={<div>No results!</div>}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

export default FarmerHome;
