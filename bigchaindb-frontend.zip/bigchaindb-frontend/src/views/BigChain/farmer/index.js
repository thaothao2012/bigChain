import React from 'react';
import {
  Col,
  Row,
  Button,
  InputGroup, InputGroupAddon,
  Input, Label
} from 'reactstrap';
import AssetInfo from './assetInfo';
import MetaDataInfo from './historyForm';
import Pagination from '../Pagination';
import SemanticTableGrid from '../Table';
import CallApi from '../../../callApi/apiCall';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
import MetaModal from '../Modal/metaDataModal';
import ProductModal from '../Modal/productModal';

class FarmerHome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      itemEditing: { id: null },
      //itemEditing: null,
      filtered: [],
      assetInfo: {
        name: '',
        supplierType: 'Farmer',
        farmerName: '',
        farmerAddress: '',
        healthStatus: '',
        grossWeight: '',
        dateOut: '',
        porkFeed: ''
      },
      currentPage: 1,
      fieldName: '',
      searchStr: '',
      pageSize: 5,
      isOpenModal: false,
      isOpenTransactionModal: false,
      itemMetadataEditing: null,
      isLoadHistory: false,
      errors: {}
    };
  }

  componentDidMount() {
    this.loadData();
  }

  loadData = (sortField, sortOrder, pageSize) => {
    const { fieldName, searchStr, currentPage } = this.state;
    const pagingData = {
      pageSize: pageSize || this.state.pageSize,
      pageIndex: currentPage - 1,
      fieldName,
      searchStr
    }
    if (sortField && sortOrder) {
      pagingData.sortField = sortField;
      pagingData.sortOrder = sortOrder;
    }
    CallApi('transaction', 'GET', pagingData).then(res => {
      if (res) {
        const transactions = res.data.data;
        const metaDatas = [];
        transactions.forEach(item => {
          metaDatas.push(item.metaData);
        })
        const formatedTransactions = this.formatDataTable(transactions);
        this.setState({
          data: formatedTransactions,
          metaDatas,
          pageInfo: res.data.pageInfo
        });
      }
    })
  }

  handleOnUpdate = (element, indexActive) => {
    const id = element.id;
    let { data } = this.state;
    let obj = data.find(item => item.id === id);

    if (obj) {
      const formatAssetInfo = {
        name: obj.name,
        supplierType: obj.supplierType,
        farmerName: obj.farmerName,
        farmerAddress: obj.farmerAddress,
        healthStatus: obj.healthStatus,
        grossWeight: obj.grossWeight,
        dateOut: obj.dateOut,
        porkFeed: obj.porkFeed
      };

      this.setState({
        itemEditing: obj,
        assetInfo: formatAssetInfo,
        idxActiveRow: indexActive
      });
      this.loadHistoryOfAsset(obj.transactionId, obj.transactionAssetId);
    }
  }

  handleOnDelete = (id) => {
    CallApi('transaction/' + `${id}`, 'DELETE', null).then(res => {
      if (res) {
        alert("delete thanh cong!");
        this.loadData();
      }
    })
  }

  showMetaData = (id) => {
    const metaData = this.state.metaDatas.find(item => item.id === id);
    if (metaData && metaData.detail) {
      delete metaData.detail.bcId;
      delete metaData.detail.timeStamp;
      delete metaData.detail.noteAction
    }
    this.setState({
      itemMetadataEditing: metaData
    }, this.toggle);
  }

  handleOnAddAsset = (e) => {
    e.preventDefault();
    const { assetInfo, itemEditing } = this.state;
    const assetId = itemEditing.assetId;
    if (this.handleValidate() === true) {
      const dataTranfer = {
        asset_id: `PRK${Math.random().toString().substring(7)}`,
        name: assetInfo.name,
        supplierType: assetInfo.supplierType,
        farmerName: assetInfo.farmerName,
        farmerAddress: assetInfo.farmerAddress,
        healthStatus: assetInfo.healthStatus,
        grossWeight: assetInfo.grossWeight,
        dateOut: assetInfo.dateOut,
        porkFeed: assetInfo.porkFeed
      };

      if (!assetId) {
        //add assetInfo
        CallApi('asset', 'POST', dataTranfer).then(res => {
          if (res) {
            alert('Add thanh cong!');
            this.setState({
              isError: false
            });
            this.loadData();
            this.handleOnReset();
          }
        });
      } else {
        //update assetInfo
        const dataForEdit = {
          name: assetInfo.name,
          supplierType: assetInfo.supplierType,
          farmerName: assetInfo.farmerName,
          farmerAddress: assetInfo.farmerAddress,
          healthStatus: assetInfo.healthStatus,
          grossWeight: assetInfo.grossWeight,
          dateOut: assetInfo.dateOut,
          porkFeed: assetInfo.porkFeed
        }

        CallApi('asset/' + `${assetId}`, 'PUT', dataForEdit).then(res => {
          if (res) {
            alert('Update thanh cong!');
            this.loadData();
          }
        })
      }
    }
    else {
      this.setState({
        isError: true
      });
      alert("please enter enough field!");
    }

  }

  handleValidate = () => {
    let { assetInfo } = this.state;
    let errors = {};
    let formIsValid = true;
    //Name
    if (!assetInfo["name"]) {
      formIsValid = false;
      errors["name"] = "Cannot be empty";
    }
    //supplierType
    if (!assetInfo["supplierType"]) {
      formIsValid = false;
      errors["supplierType"] = "Cannot be empty";
    }
    //farmerAddress
    if (!assetInfo["farmerAddress"]) {
      formIsValid = false;
      errors["farmerAddress"] = "Cannot be empty";
    }
    //farmerName
    if (!assetInfo["farmerName"]) {
      formIsValid = false;
      errors["farmerName"] = "Cannot be empty";
    }
    //healthStatus
    if (!assetInfo["healthStatus"]) {
      formIsValid = false;
      errors["healthStatus"] = "Cannot be empty";
    }
    //grossWeight
    if (!assetInfo["grossWeight"]) {
      formIsValid = false;
      errors["grossWeight"] = "Cannot be empty";
    }
    //dateOut
    if (!assetInfo["dateOut"]) {
      formIsValid = false;
      errors["dateOut"] = "Cannot be empty";
    }
    //porkFeed
    if (!assetInfo["porkFeed"]) {
      formIsValid = false;
      errors["porkFeed"] = "Cannot be empty";
    }
    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  handleOnChange = (e) => {
    const { assetInfo } = this.state;
    const target = e.target;
    const name = target.name;
    const value = target.value;
    const { itemEditing } = this.state;
    const updateItem = { ...itemEditing, [e.target.name]: e.target.value };
    this.setState({
      itemEditing: updateItem,
      assetInfo: {
        ...assetInfo,
        [name]: value
      }
    })
  }

  handleOnChangePageSize = (e) => {
    const { name, value } = e.target;
    this.loadData(null, null, value);
    this.setState({
      [name]: value
    });
  }

  handleOnReset = () => {
    this.setState({
      itemEditing: { id: null },
      //: null,
      historyData: null,
      assetInfo: {
        name: '',
        supplierType: 'Farmer',
        farmerName: '',
        farmerAddress: '',
        healthStatus: '',
        grossWeight: '',
        dateOut: '',
        porkFeed: ''
      }
    });
  }

  loadHistoryOfAsset = (id, asset_id) => {
    const dataGet = {
      currentTransId: id,
      asset_id: !asset_id ? id : asset_id
    }
    if (id && dataGet.asset_id) {
      CallApiBigChain('getHistoricalAssetByTransIdSC', 'GET', dataGet).then(res3 => {
        if (res3) {
          this.setState({
            historyData: res3.data
          });
        }
      });
    } else {
      this.setState({
        historyData: null
      });
    }
  }

  handleCreateAsset = () => {
    const { itemEditing } = this.state;
    if (itemEditing) {
      CallApi('transaction/' + itemEditing.id, 'GET', {}).then(res => {
        if (res) {
          const { data } = res;
          delete data.assetData.id;
          delete data.assetData.detail.bcId;
          delete data.metaData.id;
          if (data.metaData.detail) {
            delete data.metaData.detail.bcId;
          }
          delete data.id;
          delete data.status;

          const formatedData = [
            { currentIdentity: data.currentIdentify },
            { assetData: data.assetData },
            { metaData: data.metaData },
            { nTokens: Number(data.assetData.detail.grossWeight) }
          ];
          CallApiBigChain('createTransactionSC', 'POST', formatedData).then(res1 => {
            if (res1) {
              // console.log(res1);
              CallApi('transaction/' + itemEditing.id, 'PUT', { status: 'C', transactionId: res1.data.id }).then(res2 => {
                if (res2) {
                  alert("Create asset thanh cong!");
                  this.loadData();
                  this.reloadStatusOfAsset({ status: 'C', transactionId: res1.data.id })
                }
              });
              CallApi('asset/' + itemEditing.assetId, 'PUT', { transactionAssetId: res1.data.id }).then(res3 => {
                if (res3) {
                  console.log('Update asset done', res3.data);
                }
              });
              this.loadHistoryOfAsset(res1.data.id);
            }

          });
        }
      })
    }
  }

  reloadStatusOfAsset = (data) => {
    const { itemEditing } = this.state;
    this.setState({
      itemEditing: { ...itemEditing, ...data }
    })
  }

  formatDataTable = (data) => {
    const formatedData = [];
    const { currentPage, pageSize } = this.state;
    data.forEach((item, idx) => {
      const temp = {
        no: (currentPage - 1) * pageSize + idx + 1,
        id: item.id,
        supplierType: item.assetData.supplierType,
        transactionId: item.transactionId,
        transactionAssetId: item.assetData.transactionAssetId,
        assetId: item.assetData.id,
        productionId: item.assetData.detail.asset_id,
        name: item.assetData.name,
        farmerInfo: `${item.assetData.detail.farmerName} ${item.assetData.detail.farmerAddress}`,
        isExistMetaData: Object.keys(item.metaData).length > 0,
        ...item.assetData.detail,
        status: item.status,
        actions: (
          <div>
            <Button color="danger" onClick={() => this.handleOnDelete(item.id)}
              disabled={item.status !== 'N'}>
              Delete
            </Button>
          </div>
        ),
        metaData: (
          <div>
            <Button
              className='btn-primary'
              disabled={item.status !== 'N' || Object.keys(item.metaData).length === 0}
              onClick={() => this.showMetaData(item.metaData.id)}
            >
              Meta Data
          </Button>
          </div>
        )
      };
      delete temp.bcId;
      formatedData.push(temp);
    });
    return formatedData;
  }

  handleSwitchPage = (pageIdx) => {
    this.setState({
      currentPage: pageIdx
    }, () => this.loadData(null, null, this.state.pageSize));
  }

  handleSearch = () => this.loadData()

  toggle = () => {
    this.setState(prevState => ({
      isOpenModal: !prevState.isOpenModal,
    }));
  }


  render() {
    const { data, itemEditing, pageInfo, fieldName, currentPage, pageSize } = this.state;

    const ToolBar = (
      <React.Fragment key={'fragment'}>
        <Label>List of Farmer's Assets</Label>
        <InputGroup key='toolbar'>
          <Input
            type="select"
            id="quality"
            name="quality"
            className='filter-field'
            style={{ marginRight: '10px' }}
            value={fieldName}
            onChange={(e) => this.setState({ fieldName: e.target.value })}
          >
            <option defaultValue='' disabled value='' hidden></option>
            <option value='name'>Origin</option>
            <option value='supplierType'>Supplier Type</option>
            <option value='status'>Status</option>
            <option value='healthStatus'>Health Status</option>
          </Input>

          {(fieldName === 'Health Status') ? <Input
            type="select"
            id="healthStatus"
            name="healthStatus"
          // value={itemEditing.healthStatus || ''} onChange={handleOnChange}
          >
            <option disabled value='' hidden></option>
            <option value='Good'>Good</option>
            <option value='Medium'>Medium</option>
            <option value='Bad'>Bad</option>
          </Input> : <Input
              type="text"
              id="input1-group2"
              name="searchStr"
              placeholder="Search..."
              onChange={(e) => this.setState({ searchStr: e.target.value })}
            />}

          <InputGroupAddon addonType="prepend">
            <Button
              type="button"
              className='btn-primary'
              onClick={this.handleSearch}
            >
              <i className="fa fa-search"></i> Search</Button>
          </InputGroupAddon>
        </InputGroup>
      </React.Fragment>);

    return (
      <div className="animated fadeIn">
        <Row>
          {/* <Col xs='12' sm='7'>
            <AssetInfo
              isError={this.state.isError}
              assetInforValidate={this.state.assetInfo}
              itemEditing={itemEditing}
              toggle={this.toggle}
              handleOnChange={this.handleOnChange}
              handleOnReset={this.handleOnReset}
              handleOnAddAsset={this.handleOnAddAsset}
              handleCreateAsset={this.handleCreateAsset}
              handleReloadDataTable={this.loadData}
              loadHistoryOfAsset={this.loadHistoryOfAsset}
              reloadStatusOfAsset={this.reloadStatusOfAsset}
            />
          </Col>
          <Col xs='12' sm='5'>
            <MetaDataInfo historyData={this.state.historyData} />
          </Col> */}
          <Col>
            <Button color="primary" onClick={this.toggle}>Add product</Button>
          </Col>
        </Row>
        <Row>

          <Col>
            <SemanticTableGrid
              isLoading={false}
              tblClass='tbl-standard'
              elements={data}
              rowClassKey={'class'}
              activeRow={this.state.idxActiveRow}
              columns={[
                { key: 'no', name: 'No', sortable: false },
                { key: 'productionId', name: 'Id', sortable: true },
                { key: 'name', name: 'Origin', sortable: true },
                { key: 'farmerInfo', name: 'Farmer Name & Address', sortable: true },
                { key: 'healthStatus', name: 'Health Status', sortable: true },
                { key: 'grossWeight', name: 'Weight', sortable: true },
                { key: 'porkFeed', name: 'Pork Feed', sortable: true },
                { key: 'dateOut', name: 'Date Out', sortable: true },
                { key: 'metaData', name: 'More Infor', sortable: false },
                { key: 'status', name: 'Status in SCN', sortable: true },
                { key: 'actions', name: 'Actions', sortable: false }
              ]}
              canUpdate={{
                active: true,
                onUpdate: this.handleOnUpdate
              }}
              canSort={{
                active: true,
                onSort: (key, order) => this.loadData(key, order)
              }}
              canPaginate={{
                active: true,
                render: (
                  <React.Fragment>
                    <Row>
                      <Col>
                        <Pagination total={pageInfo ? pageInfo.total : 0}
                          pageSize={pageSize}
                          switchPage={this.handleSwitchPage}
                          currentPage={currentPage} />
                      </Col>
                      <Col sm='2'>
                        <Label style={{float: "right"}}>Page size:</Label>
                      </Col>
                      <Col>
                        <Input
                          type="select"
                          id="pageSize"
                          name="pageSize"
                          className=''
                          value={pageSize}
                          onChange={this.handleOnChangePageSize}
                        // onClick={this.loadData}
                        >
                          <option defaultValue='' disabled value='' hidden></option>
                          <option value='5'>5</option>
                          <option value='10'>10</option>
                          <option value='15'>15</option>
                        </Input>
                      </Col>
                    </Row>
                  </React.Fragment>
                )
              }}
              canAction={{
                active: true,
                actions: [ToolBar],
              }}
              hiddenHeaderIfEmpty
              emptyResults={<div>No results!</div>}
            />
          </Col>
        </Row>
        {/* <MetaModal
          toggle={this.toggle}
          isOpenModal={this.state.isOpenModal}
          itemMetadataEditing={this.state.itemMetadataEditing}
          bcId={itemEditing.id}
          transactionId={itemEditing.transactionId}
          amount={itemEditing.grossWeight}
          handleReloadDataTable={this.loadData}
          isAddMetaTransaction={this.state.isAddMetaTransaction}
          loadHistoryOfAsset={this.loadHistoryOfAsset}
          loadDataTable={this.loadData}
          reloadStatusOfAsset={this.reloadStatusOfAsset}
        /> */}

        <ProductModal isOpenModal={this.state.isOpenModal}
          toggle={this.toggle} />
      </div>
    );
  }
}

export default FarmerHome;
