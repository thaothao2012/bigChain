import React from 'react';
import { Col, Row, Dropdown, DropdownMenu, DropdownToggle, Input, DropdownItem, Button, InputGroup, InputGroupAddon } from 'reactstrap';
import AssetInfo from './assetInfo';
import MetaDataInfo from './metadataInfo';
import Pagination from '../Pagination';
import SemanticTableGrid from '../Table';
import CallApi from '../../../callApi/apiCall';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
import { tsThisType } from '@babel/types';

//const assetDone = [];
class FarmerHome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      dropdownOpen: new Array(6).fill(false),
      itemEditing: null,
      filtered: [],
      assetInfo: {
        name: '',
        supplierType: '',
        retailName: '',
        retailAddress: '',
        quality: '',
        grossWeight: '',
        quarantineNum: '',
        normalPrice: '',
        promotionPrice: ''
      },
      currentPage: 1,
      fieldName: '',
      searchStr: '',
      pageSize: 10
    };
  }

  componentDidMount() {
    this.loadInitData();
  }

  loadInitData = () => {
    const { pageSize, fieldName, searchStr } = this.state;
    const pagingData = {
      pageSize,
      pageIndex: 0,
      fieldName,
      searchStr
    }
    CallApi('blockChain', 'GET', pagingData).then(res => {
      if (res) {
        const blockChains = res.data.data;

        const formatedBlockChains = this.formatDataTable(blockChains);
        this.setState({
          data: formatedBlockChains,
          filtered: formatedBlockChains,
          pageInfo: res.data.pageInfo,
          originData: blockChains
        });
      }
    })
  }

  handleOnUpdate = element => {
    const id = element._id;
    let { data } = this.state;
    let obj = data.find(item => item._id === id);
    if (obj) {
      this.setState({
        itemEditing: obj
      });
    }
  }

  handleOnDelete = (id) => {
    CallApi('blockChain/' + `${id}`, 'DELETE', null).then(res => {
      if (res) {
        alert("delete thanh cong!");
        this.loadInitData();
      }
    })
  }

  showMetaData = (metaId, bcId) => {

  }

  handleOnAddAsset = (e) => {
    e.preventDefault();
    const { assetInfo, itemEditing, data } = this.state;
    //debugger;
    const id = itemEditing._id;
    const dataTranfer = {
      name: assetInfo.name,
      supplierType: assetInfo.supplierType,
      retailName: assetInfo.retailName,
      retailAddress: assetInfo.retailAddress,
      quality: assetInfo.quality,
      grossWeight: assetInfo.grossWeight,
      quarantineNum: assetInfo.quarantineNum,
      normalPrice: assetInfo.normalPrice,
      promotionPrice: assetInfo.promotionPrice
    };
    if (!id) {
      //add assetInfo
      CallApi('asset', 'POST', dataTranfer).then(res => {
        if (res) {
          alert('Add thanh cong!');
          this.loadInitData();
          this.handleOnReset();
        }
      });
    } else {
      //update assetInfo
      const dataForEdit = {
        name: itemEditing.name,
        supplierType: itemEditing.supplierType,
        retailName: itemEditing.retailName,
        retailAddress: itemEditing.retailAddress,
        quality: itemEditing.quality,
        grossWeight: itemEditing.grossWeight,
        quarantineNum: itemEditing.quarantineNum,
        normalPrice: itemEditing.normalPrice,
        promotionPrice: itemEditing.promotionPrice
      }
      CallApi('asset/' + `${id}`, 'PUT', dataForEdit).then(res => {
        if (res) {
          alert('Update thanh cong!');
          this.loadInitData();
        }
      })
    }
  }

  handleOnChange = (e) => {
    const { assetInfo } = this.state;
    const target = e.target;
    const name = target.name;
    const value = target.value;
    const { itemEditing } = this.state;
    const updateItem = { ...itemEditing, [e.target.name]: e.target.value };
    this.setState({
      itemEditing: updateItem,
      assetInfo: {
        ...assetInfo, [name]: value
      }
    })
  }

  handleOnReset = () => {
    this.setState({
      itemEditing: null
    });
  }

  handleCreateAsset = () => {
    const { itemEditing, originData } = this.state;
    if (itemEditing) {
      const bcId = itemEditing.bcId;
      const blockChain = originData.find(item => item._id === bcId);
      //console.log( ...blockChain.metaData);
      const nTokens = Number(blockChain.assetData.grossWeight);
      const metaData = {
        "supplierType": "farmer",
        "name": "vaccination",
        "detail":
        {
          "vacc1": "4/2/2019",
          "vacc2": "6/2/2019",
          "timestamp": "8/2/2019"
        },
        "noteAction": "Create asset from farmer"
      };
      const createAsset = [
        { "currentIdentity": blockChain.currentIdentify },
        { "assetData": blockChain.assetData },
        { "metaData": metaData },
        { "nTokens": nTokens }];
      CallApiBigChain('createTransactionSC', 'POST', createAsset).then(res => {
        if (res) {
          alert("Create asset thanh cong!")
        }
      });
    }

  }
  handleAddMetaBlockChain = () => {

  }
  findIndex = (id, arr) => {
    let result = -1;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i].bcId === id) {
        result = i;
      }
    }
    return result;
  }

  formatDataTable = (data) => {
    const formatedData = [];
    data.forEach((item, idx) => {
      const temp = {
        no: idx + 1,
        name: item.assetData.name,
        ...item.assetData,
        status: item.status,
        actions: (
          <div>
            <Button color="danger" onClick={() => this.handleOnDelete(item._id)}
              disabled={item.status === "C" ? true : false}>
              Delete
            </Button>
          </div>
        ),
        metaDatas: (
          <div>
            <Button color="primary"
              disabled={item.status === "C" ? true : false}
            // onClick={() => this.showMetaData(item.id,item.bcId)}
            >
              Meta Data
          </Button>
          </div>
        )
      };
      formatedData.push(temp);
    });
    return formatedData;
  }

  toggle(i) {
    const newArray = this.state.dropdownOpen.map((element, index) => {
      return (index === i ? !element : false);
    });
    this.setState({
      dropdownOpen: newArray,
    });
  }

  handleSwitchPage = (pageIdx) => {
    const pagingData = {
      pageSize: 1,
      pageIndex: pageIdx - 1
    };
    CallApi('blockChain', 'GET', pagingData).then(res => {
      if (res) {
        const blockChains = res.data.data;
        const formatedBlockChains = this.formatDataTable(blockChains);
        this.setState({
          data: formatedBlockChains,
          filtered: formatedBlockChains
        });
      }
    })
    this.setState({
      currentPage: pageIdx
    });
  }

  handleSearch = () => this.loadInitData()

  render() {
    const { filtered, itemEditing, pageInfo, fieldName, currentPage, pageSize } = this.state;
    const ToolBar = (
      <InputGroup>
        <Input
          type="select"
          id="quality"
          name="quality"
          className='filter-field'
          style={{ marginRight: '10px' }}
          value={fieldName}
          onChange={(e) => this.setState({ fieldName: e.target.value })}
        >
          <option value='name'>Name</option>
          <option value='supplierType'>Supplier Type</option>
          <option value='status'>Status</option>
        </Input>
        <Input
          type="text"
          id="input1-group2"
          name="searchStr"
          placeholder="Search..."
          onChange={(e) => this.setState({ searchStr: e.target.value })}
        />
        <InputGroupAddon addonType="prepend">
          <Button
            type="button"
            color="primary"
            onClick={this.handleSearch}
          >
            <i className="fa fa-search"></i> Search</Button>
        </InputGroupAddon>
      </InputGroup>);
    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs='12' sm='7'>
            <AssetInfo
              itemEditing={itemEditing}
              handleOnChange={this.handleOnChange}
              handleOnReset={this.handleOnReset}
              handleOnAddAsset={this.handleOnAddAsset}
              handleCreateAsset={this.handleCreateAsset} />
          </Col>
          <Col xs='12' sm='5'>
            <MetaDataInfo />
          </Col>
        </Row>
        <Row>
          <Col>
            <SemanticTableGrid
              isLoading={false}
              tblClass='tbl-standard'
              elements={filtered}
              rowClassKey={'class'}
              columns={[
                { key: 'no', name: 'No', sortable: true },
                { key: 'name', name: 'Name', sortable: true },
                { key: 'supplierType', name: 'Supplier Type', sortable: true },
                { key: 'retailName', name: 'Retail Name', sortable: true },
                { key: 'retailAddress', name: 'Retail Address', sortable: true },
                { key: 'quality', name: 'Quality', sortable: true },
                { key: 'grossWeight', name: 'Gross Weight', sortable: true },
                // { key: 'quarantineNum', name: 'Quarantine Num', sortable: true },
                // { key: 'normalPrice', name: 'Normal Price', sortable: true },
                { key: 'metaDatas', name: 'More Infor', sortable: false },
                { key: 'status', name: 'Status', sortable: true },
                { key: 'actions', name: 'Actions', sortable: false }
              ]}
              canUpdate={{
                active: true,
                onUpdate: this.handleOnUpdate
              }}
              canSort={{
                active: true,
                onSort: (key, order) => {

                }
              }}
              canPaginate={{
                active: true,
                render: (
                  <Pagination total={pageInfo ? pageInfo.total : 0} pageSize={pageSize} switchPage={this.handleSwitchPage} currentPage={currentPage} />
                )
              }}
              canAction={{
                active: true,
                actions: [ToolBar],
              }}
              hiddenHeaderIfEmpty
              emptyResults={<div>No results!</div>}
            />
          </Col>
        </Row>
      </div>
    );
  }
}

export default FarmerHome;
