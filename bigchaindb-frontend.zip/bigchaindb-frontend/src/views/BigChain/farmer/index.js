import React from 'react';
import {
  Col,
  Row,
  Button,
  InputGroup, InputGroupAddon,
  Input, Label
} from 'reactstrap';
import AssetInfo from './assetInfo';
import MetaDataInfo from './metadataInfo';
import Pagination from '../Pagination';
import SemanticTableGrid from '../Table';
import CallApi from '../../../callApi/apiCall';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
import MetaModal from '../Modal/metaDataModal';

class FarmerHome extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      itemEditing: { id: null },
      filtered: [],
      assetInfo: {
        name: '',
        supplierType: 'Farmer',
        farmerName: '',
        farmerAddress: '',
        healthStatus: '',
        grossWeight: '',
        dateOut: '',
        porkFeed: ''
      },
      currentPage: 1,
      fieldName: '',
      searchStr: '',
      pageSize: 5,
      isOpenModal: false,
      isOpenTransactionModal: false,
      itemMetadataEditing: null,
      isLoadHistory: false
    };
  }

  componentDidMount() {
    this.loadData();
  }

  loadData = (sortField, sortOrder) => {
    const { pageSize, fieldName, searchStr } = this.state;
    const pagingData = {
      pageSize,
      pageIndex: 0,
      fieldName,
      searchStr
    }
    if (sortField && sortOrder) {
      pagingData.sortField = sortField;
      pagingData.sortOrder = sortOrder;
    }
    CallApi('transaction', 'GET', pagingData).then(res => {
      if (res) {
        const transactions = res.data.data;
        const metaDatas = [];
        transactions.forEach(item => {
          metaDatas.push(item.metaData);
        })
        const formatedTransactions = this.formatDataTable(transactions);
        this.setState({
          data: formatedTransactions,
          metaDatas,
          pageInfo: res.data.pageInfo
        });
      }
    })
  }

  handleOnUpdate = (element, indexActive) => {
    const id = element.id;
    let { data } = this.state;
    let obj = data.find(item => item.id === id);

    if (obj) {
      const formatAssetInfo = {
        name: obj.name,
        supplierType: obj.supplierType,
        farmerName: obj.farmerName,
        farmerAddress: obj.farmerAddress,
        healthStatus: obj.healthStatus,
        grossWeight: obj.grossWeight,
        dateOut: obj.dateOut,
        porkFeed: obj.porkFeed
      };

      this.setState({
        itemEditing: obj,
        assetInfo: formatAssetInfo,
        idxActiveRow: indexActive
      });
      this.loadHistoryOfAsset(obj.transactionId, obj.transactionAssetId);
    }
  }

  handleOnDelete = (id) => {
    CallApi('transaction/' + `${id}`, 'DELETE', null).then(res => {
      if (res) {
        alert("delete thanh cong!");
        this.loadData();
      }
    })
  }

  showMetaData = (id) => {
    const metaData = this.state.metaDatas.find(item => item.id === id);
    if (metaData && metaData.detail) {
      delete metaData.detail.bcId;
      delete metaData.detail.timeStamp;
      delete metaData.detail.noteAction
    }
    this.setState({
      itemMetadataEditing: metaData
    }, this.toggle);
  }

  handleOnAddAsset = (e) => {
    e.preventDefault();
    const { assetInfo, itemEditing } = this.state;
    const assetId = itemEditing.assetId;
    const dataTranfer = {
      asset_id: `PRK${Math.random().toString().substring(7)}`,
      name: assetInfo.name,
      supplierType: assetInfo.supplierType,
      farmerName: assetInfo.farmerName,
      farmerAddress: assetInfo.farmerAddress,
      healthStatus: assetInfo.healthStatus,
      grossWeight: assetInfo.grossWeight,
      dateOut: assetInfo.dateOut,
      porkFeed: assetInfo.porkFeed
    };

    if (!assetId) {
      //add assetInfo
      CallApi('asset', 'POST', dataTranfer).then(res => {
        if (res) {
          alert('Add thanh cong!');
          this.loadData();
          this.handleOnReset();
        }
      });
    } else {
      //update assetInfo
      const dataForEdit = {
        name: assetInfo.name,
        supplierType: assetInfo.supplierType,
        farmerName: assetInfo.farmerName,
        farmerAddress: assetInfo.farmerAddress,
        healthStatus: assetInfo.healthStatus,
        grossWeight: assetInfo.grossWeight,
        dateOut: assetInfo.dateOut,
        porkFeed: assetInfo.porkFeed
      }

      CallApi('asset/' + `${assetId}`, 'PUT', dataForEdit).then(res => {
        if (res) {
          alert('Update thanh cong!');
          this.loadData();
        }
      })
    }
  }

  handleOnChange = (e) => {
    const { assetInfo } = this.state;
    const target = e.target;
    const name = target.name;
    const value = target.value;
    const { itemEditing } = this.state;
    const updateItem = { ...itemEditing, [e.target.name]: e.target.value };

    this.setState({
      itemEditing: updateItem,
      assetInfo: {
        ...assetInfo,
        [name]: value
      }
    })
  }

  handleOnReset = () => {
    this.setState({
      itemEditing: { id: null },
      historyData: null
    });
  }

  loadHistoryOfAsset = (id, asset_id) => {
    const dataGet = {
      currentTransId: id,
      asset_id: !asset_id ? id : asset_id
    }
    if(id && dataGet.asset_id) {
      CallApiBigChain('getHistoricalAssetByTransIdSC', 'GET',  dataGet).then(res3 => {
        this.setState({
          historyData: res3.data
        });
      });
    } else {
      this.setState({
        historyData: null
      });
    }
  }

  handleCreateAsset = () => {
    const { itemEditing } = this.state;
    if (itemEditing) {
      CallApi('transaction/' + itemEditing.id, 'GET', {}).then(res => {
        if (res) {
          const { data } = res;
          delete data.assetData.id;
          delete data.assetData.detail.bcId;
          delete data.metaData.id;
          if (data.metaData.detail) {
            delete data.metaData.detail.bcId;
          }
          delete data.id;
          delete data.status;

          const formatedData = [
            { currentIdentity: data.currentIdentify },
            { assetData: data.assetData },
            { metaData: data.metaData },
            { nTokens: Number(data.assetData.detail.grossWeight) }
          ];
          CallApiBigChain('createTransactionSC', 'POST', formatedData).then(res1 => {
            CallApi('transaction/' + itemEditing.id, 'PUT', { status: 'C', transactionId: res1.data.id }).then(res2 => {
              if (res2) {
                alert("Create asset thanh cong!");
                this.loadData();
                this.reloadStatusOfAsset({ status: 'C', transactionId: res1.data.id })
              }
            });
            CallApi('asset/' + itemEditing.assetId, 'PUT', { transactionAssetId: res1.data.id }).then(res3 => {
              console.log('Update asset done', res3.data);
            });
            this.loadHistoryOfAsset(res1.data.id);
          });
        }
      })
    }
  }

  reloadStatusOfAsset = (data) => {
    const { itemEditing } = this.state;
    this.setState({
      itemEditing: { ...itemEditing, ...data }
    })
  }

  formatDataTable = (data) => {
    const formatedData = [];
    const { currentPage, pageSize } = this.state;
    data.forEach((item, idx) => {
      const temp = {
        no: (currentPage - 1) * pageSize + idx + 1,
        id: item.id,
        supplierType: item.assetData.supplierType,
        transactionId: item.transactionId,
        transactionAssetId: item.assetData.transactionAssetId,
        assetId: item.assetData.id,
        productionId: item.assetData.detail.asset_id,
        name: item.assetData.name,
        farmerInfo: `${item.assetData.detail.farmerName} ${item.assetData.detail.farmerAddress}`,
        isExistMetaData: Object.keys(item.metaData).length > 0,
        ...item.assetData.detail,
        status: item.status,
        actions: (
          <div>
            <Button color="danger" onClick={() => this.handleOnDelete(item.id)}
              disabled={item.status !== 'N'}>
              Delete
            </Button>
          </div>
        ),
        metaData: (
          <div>
            <Button
              className='btn-primary'
              disabled={item.status !== 'N' || Object.keys(item.metaData).length === 0}
              onClick={() => this.showMetaData(item.metaData.id)}
            >
              Meta Data
          </Button>
          </div>
        )
      };
      delete temp.bcId;
      formatedData.push(temp);
    });
    return formatedData;
  }

  handleSwitchPage = (pageIdx) => {
    const pagingData = {
      pageSize: 5,
      pageIndex: pageIdx - 1
    };
    CallApi('transaction', 'GET', pagingData).then(res => {
      if (res) {
        const transactions = res.data.data;
        const formatedTransactions = this.formatDataTable(transactions);
        this.setState({
          data: formatedTransactions
        });
      }
    })
    this.setState({
      currentPage: pageIdx
    });
  }

  handleSearch = () => this.loadData()

  toggle = (isResetForm, isAddMetaTransaction) => {
    this.setState(prevState => ({
      isOpenModal: !prevState.isOpenModal,
      itemMetadataEditing: !isResetForm ? prevState.itemMetadataEditing : null,
      isAddMetaTransaction
    }));
  }

  render() {
    const { data, itemEditing, pageInfo, fieldName, currentPage, pageSize } = this.state;

    const ToolBar = (
      <React.Fragment key={'fragment'}>
        <Label>List of Farmer's Assets</Label>
        <InputGroup key='toolbar'>
          <Input
            type="select"
            id="quality"
            name="quality"
            className='filter-field'
            style={{ marginRight: '10px' }}
            value={fieldName}
            onChange={(e) => this.setState({ fieldName: e.target.value })}
          >
            <option defaultValue='' disabled value='' hidden></option>
            <option value='name'>Origin</option>
            <option value='supplierType'>Supplier Type</option>
            <option value='status'>Status</option>
          </Input>
          <Input
            type="text"
            id="input1-group2"
            name="searchStr"
            placeholder="Search..."
            onChange={(e) => this.setState({ searchStr: e.target.value })}
          />
          <InputGroupAddon addonType="prepend">
            <Button
              type="button"
              className='btn-primary'
              onClick={this.handleSearch}
            >
              <i className="fa fa-search"></i> Search</Button>
          </InputGroupAddon>
        </InputGroup>
      </React.Fragment>);

    return (
      <div className="animated fadeIn">
        <Row>
          <Col xs='12' sm='7'>
            <AssetInfo
              itemEditing={itemEditing}
              toggle={this.toggle}
              handleOnChange={this.handleOnChange}
              handleOnReset={this.handleOnReset}
              handleOnAddAsset={this.handleOnAddAsset}
              handleCreateAsset={this.handleCreateAsset}
              handleReloadDataTable={this.loadData}
              loadHistoryOfAsset={this.loadHistoryOfAsset}
              reloadStatusOfAsset={this.reloadStatusOfAsset}
            />
          </Col>
          <Col xs='12' sm='5'>
            <MetaDataInfo historyData={this.state.historyData} />
          </Col>
        </Row>
        <Row>

          <Col>
            <SemanticTableGrid
              isLoading={false}
              tblClass='tbl-standard'
              elements={data}
              rowClassKey={'class'}
              activeRow={this.state.idxActiveRow}
              columns={[
                { key: 'no', name: 'No', sortable: false },
                { key: 'productionId', name: 'Id', sortable: true },
                { key: 'name', name: 'Origin', sortable: true },
                { key: 'farmerInfo', name: 'Farmer Name & Address', sortable: true },
                { key: 'healthStatus', name: 'Health Status', sortable: true },
                { key: 'grossWeight', name: 'Weight', sortable: true },
                { key: 'porkFeed', name: 'Pork Feed', sortable: true },
                { key: 'dateOut', name: 'Date Out', sortable: true },
                { key: 'metaData', name: 'More Infor', sortable: false },
                { key: 'status', name: 'Status in SCN', sortable: true },
                { key: 'actions', name: 'Actions', sortable: false }
              ]}
              canUpdate={{
                active: true,
                onUpdate: this.handleOnUpdate
              }}
              canSort={{
                active: true,
                onSort: (key, order) => this.loadData(key, order)
              }}
              canPaginate={{
                active: true,
                render: (
                  <Pagination total={pageInfo ? pageInfo.total : 0} pageSize={pageSize} switchPage={this.handleSwitchPage} currentPage={currentPage} />
                )
              }}
              canAction={{
                active: true,
                actions: [ToolBar],
              }}
              hiddenHeaderIfEmpty
              emptyResults={<div>No results!</div>}
            />
          </Col>
        </Row>
        <MetaModal
          toggle={this.toggle}
          isOpenModal={this.state.isOpenModal}
          itemMetadataEditing={this.state.itemMetadataEditing}
          bcId={itemEditing.id}
          transactionId={itemEditing.transactionId}
          amount={itemEditing.grossWeight}
          handleReloadDataTable={this.loadData}
          isAddMetaTransaction={this.state.isAddMetaTransaction}
          loadHistoryOfAsset={this.loadHistoryOfAsset}
          loadDataTable={this.loadData}
          reloadStatusOfAsset={this.reloadStatusOfAsset}
        />
      </div>
    );
  }
}

export default FarmerHome;
