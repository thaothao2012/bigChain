import React, { Component } from 'react';
import {
  Col, Row, Button, Card, CardBody, CardHeader, CardFooter, Form,
  FormGroup, Input, Label, Modal, ModalHeader, ModalFooter, ModalBody
} from 'reactstrap';
import CallApi from '../../../callApi/apiCall';

class Product extends Component {
  constructor(props) {
    super(props);
    const initModel = {
      name: '',
      supplierType: 'Farmer',
      retailName: '',
      retailAddress: '',
      quality: '',
      grossWeight: '',
      quarantineNum: '',
      normalPrice: '',
      promotionPrice: ''
    }
    this.state = {
      assetInfo: {
        name: '',
        supplierType: 'Farmer',
        farmerName: '',
        farmerAddress: '',
        healthStatus: '',
        grossWeight: '',
        dateOut: '',
        porkFeed: ''
      },
      itemEditing: initModel,
      isOpenTransactionModal: false,
      currentIdentity: {
        "privateKey": "AMudkHmEX8obNZzSiqHo3y6P7w3oDZs79Y6Bopv9whti",
        "publicKey": "A6yF47Ud5GMmRi5yii77ce3xeY7ppvCNUbxubbKyuvD3"
      }
    };
  }

  handleOnChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value
    });
  }

  handleCreateAsset = () => {
    this.props.handleCreateAsset();
  }

  handleSubmitProduct = (e) => {
    e.preventDefault();
    const { assetInfo } = this.state;
    const dataTranfer = {
      asset_id: `PRK${Math.random().toString().substring(7)}`,
      name: assetInfo.name,
      supplierType: assetInfo.supplierType,
      farmerName: assetInfo.farmerName,
      farmerAddress: assetInfo.farmerAddress,
      healthStatus: assetInfo.healthStatus,
      grossWeight: assetInfo.grossWeight,
      dateOut: assetInfo.dateOut,
      porkFeed: assetInfo.porkFeed
    };
    //add product
    CallApi('asset', 'POST', dataTranfer).then(res => {
      if (res) {
        console.log("res", res);
        alert('Add  product thanh cong!');
        // this.setState({
        //   isError: false
        // });
        // this.loadData();
        // this.handleOnReset();
      }
    });
  }

  toCamelCase(str) {
    return str.split(' ').map((word, index) => {
      if (index === 0) {
        return word.toLowerCase();
      }
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    }).join('');
  }

  toggleTransaction = () => {
    this.setState(prevState => ({
      isOpenTransactionModal: !prevState.isOpenTransactionModal
    }));
  }

  render() {
    //const { handleOnChange, isError, assetInforValidate } = this.props;
    const itemEditing = this.props.itemEditing || this.state.itemEditing;

    const { isOpenModal, toggle, className } = this.props;
    const {
      // name,
      // supplierType,
      // farmerName,
      // farmerAddress,
      // healthStatus,
      // grossWeight,
      // dateOut,
      // porkFeed,
      assetInfo } = this.state;
    return (
      <Modal isOpen={isOpenModal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}></ModalHeader>
        <ModalBody>
          <Card>
            <CardHeader>
              Asset Info
			    	</CardHeader>
            <CardBody >
              <Row>
                <Col xs='12' sm='10'>
                  <Form id="asset-info" sm={8} >
                    <FormGroup row>
                      <Label for="Id" sm='4'>Id:</Label>
                      <Col sm={8}>
                        <Input
                          type="text"
                          // /value={assetInfo.id}
                          disabled
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='4'>Origin:</Label>
                      <Col sm={8}>
                        <Input
                          color="red"
                          type="text"
                          required
                          // invalid={(isError && assetInforValidate.name === '') ? true : false}
                          id="name"
                          name="name"
                          autoComplete="name"
                          value={assetInfo.name}
                          onChange={this.handleOnChange}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="supplierType" sm='4'>Supplier Type:</Label>
                      <Col sm={8}>
                        <Input
                          type="select"
                          id="supplierType"
                          name="supplierType"
                          value={assetInfo.supplierType}
                          onChange={this.handleOnChange}
                        >
                          <option disabled value='' hidden></option>
                          <option value='Farmer'>Farmer</option>
                          <option value='Producer'>Producer</option>
                          <option value='Distributor'>Distributor</option>
                          <option value='Retailer'>Retailer</option>
                        </Input>
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="farmerName" sm='4'>Farmer Name: </Label>
                      <Col sm={8}>
                        <Input
                          type="text"
                          // invalid={(isError && assetInforValidate.farmerName === '') ? true : false}
                          id="farmerName"
                          name="farmerName"
                          onChange={this.handleOnChange}
                          value={assetInfo.farmerName} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="farmerAddress" sm='4'>Farmer Address: </Label>
                      <Col sm={8}>
                        <Input
                          type="text"
                          // invalid={(isError && assetInforValidate.farmerAddress === '') ? true : false}
                          id="farmerAddress"
                          name="farmerAddress"
                          onChange={this.handleOnChange}
                          value={assetInfo.farmerAddress} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="quality" sm='4'>Health Status:</Label>
                      <Col sm={8}>
                        <Input
                          type="select"
                          //={(isError && assetInforValidate.healthStatus === '') ? true : false}
                          id="healthStatus"
                          name="healthStatus"
                          value={assetInfo.healthStatus} onChange={this.handleOnChange}
                        >
                          <option disabled value='' hidden></option>
                          <option value='Good'>Good</option>
                          <option value='Medium'>Medium</option>
                          <option value='Bad'>Bad</option>
                        </Input>
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="grossWeight" sm='4'>Weight(g):</Label>
                      <Col sm={8}>
                        <Input
                          type="number"
                          //invalid={(isError && assetInforValidate.grossWeight === '') ? true : false}
                          id="grossWeight"
                          name="grossWeight"
                          value={assetInfo.grossWeight}
                          onChange={this.handleOnChange}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="porkFeed" sm='4'>Pork Feed:</Label>
                      <Col sm={8}>
                        <Input
                          type="text"
                          //invalid={(isError && assetInforValidate.porkFeed === '') ? true : false}
                          id="porkFeed"
                          name="porkFeed"
                          value={assetInfo.porkFeed}
                          onChange={this.handleOnChange}
                        />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="porkFeed" sm='4'>Date Out:</Label>
                      <Col sm={8}>
                        <Input
                          type="date"
                          //invalid={(isError && assetInforValidate.dateOut === '') ? true : false}
                          id="dateOut"
                          name="dateOut"
                          value={assetInfo.dateOut}
                          onChange={this.handleOnChange}
                        />
                      </Col>
                    </FormGroup>
                  </Form>
                </Col >
                <Col xs='12' sm='2' className='container-group-btn'>

                  <div className='group-btn'>
                    <Label color="" style={{ textAlign: "center", marginBottom: "20px" }}><b>Supply Chain Network</b></Label>
                    <Button
                      type="button"
                      onClick={this.handleCreateAsset}
                      disabled={!itemEditing.id || itemEditing.status === 'C' || itemEditing.status === 'T' || itemEditing.status === 'A' || itemEditing.isExistMetaData === false}
                    >
                      Create Asset
                </Button><br />
                    <Button
                      type="button"
                      style={{ marginTop: "7px" }}
                      onClick={() => this.props.toggle(false, true)}
                      disabled={!itemEditing.id || itemEditing.status === 'T' || itemEditing.status === 'N'}
                    >
                      Add MetaData
                </Button><br />
                    <Button
                      type="button"
                      style={{ marginTop: "7px" }}
                      disabled={!itemEditing.id || itemEditing.status === 'T' || itemEditing.status === 'N'}
                      onClick={this.toggleTransaction}
                    >
                      Transfer Asset
                </Button>
                  </div>
                </Col>
              </Row>
              {/* <TransactionModal
                toggle={this.toggleTransaction}
                isOpenModal={this.state.isOpenTransactionModal}
                transactionId={itemEditing.transactionId}
                transactionAssetId={itemEditing.transactionAssetId}
                amount={itemEditing.grossWeight}
                bcId={itemEditing.id}
                loadDataTable={this.props.handleReloadDataTable}
                loadHistoryOfAsset={this.props.loadHistoryOfAsset}
                reloadStatusOfAsset={this.props.reloadStatusOfAsset}
                currentIdentity={this.state.currentIdentity}
                personIdentity={'Farmer'}
              /> */}
            </CardBody>
            <CardFooter>
              <Button
                type="submit"
                size="sm"
                disabled={itemEditing.status && itemEditing.status !== 'N'}
                onClick={this.handleAddAsset}
                style={{ width: '100px' }}
                className='btn-action btn-primary'>
                {itemEditing.assetId ? 'Update' : 'Save'}
              </Button>
              <Button
                type="button"
                size="sm"
                className='btn-action'
                onClick={this.props.handleOnReset}>Add New</Button>
              <Button
                type="button"
                size="sm"
                disabled={itemEditing.status === "C" || !itemEditing.assetId || itemEditing.isExistMetaData}
                style={{ float: 'right' }}
                className='btn-action btn-primary'
                onClick={() => this.props.toggle(false)}>Additional Data</Button>
              {/* <FormText style={{float:"right"}}>Example help text that remains unchanged.</FormText> */}
            </CardFooter>
          </Card>
        </ModalBody>
        {/* <ModalFooter>
          <Button color="primary" onClick={this.handleSubmitMetaData}>Add</Button>{' '}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter> */}
      </Modal>
    );
  }
}

export default Product;
