import React, { Component } from 'react';
import {
	Col,
	Button,
	Card,
	CardBody,
	CardHeader,
	FormGroup,
	Input,
	Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';
import CallApi from '../../../callApi/apiCall';
import callApiBigChain from '../../../callApi/apiCallBigChain';

let inputs = [];
class MetaModal extends Component {
	constructor(props) {
		super(props);
		this.state = {
			dynamicData: [],
			btnSubmit: 'Add',
			metaData: {
        metaName: '',
        metaSupplierType: '',
        noteAction: ''
      }
		}
	}

	componentWillReceiveProps(nextProps) {
		this.handleLoadDataInit();
		if(!nextProps.isOpenModal) {
			inputs = [];
			const metaData = {
        metaName: '',
        metaSupplierType: '',
        noteAction: ''
      };
			this.setState({
				dynamicData: [],
				metaData,
				btnSubmit: 'Add'
			})
		}
	}

	handleLoadDataInit = () => {
		const {itemMetadataEditing} = this.props;
		if(itemMetadataEditing) {
			const metaData = {
				metaName: itemMetadataEditing.name,
        metaSupplierType: itemMetadataEditing.supplierType,
        noteAction: itemMetadataEditing.noteAction
			}
			const { detail } = itemMetadataEditing;
			let dynamicData = [];
			if(detail) {
				const keys = Object.keys(detail);
				keys.forEach(item => {
					const generateId = this.generateId();
					const objKey = { [`dynamic-key-${generateId}`]: item };
					const objValue = { [`dynamic-value-${generateId}`]: detail[item] };
					dynamicData = dynamicData.concat([objKey, objValue]);

					this.handleOnAddField(item, detail[item], generateId)
				});
			}
			this.setState({
				metaData,
				dynamicData,
				btnSubmit: 'Update'
			});
		}
	}

	handleChange = e => {
    const { metaData } = this.state;
    const { name, value } = e.target;
    this.setState({
      metaData: { ...metaData, [name]: value }
    })
  }

	formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
	}

	handleSubmitMetaData = () => {
    const { bcId, toggle, handleReloadDataTable, itemMetadataEditing, isAddMetaTransaction, transactionId } = this.props;
		const { metaData } = this.state;
    const dataTranfer = {
      bcId,
      name: metaData.metaName,
      supplierType: metaData.metaSupplierType,
      noteAction: metaData.noteAction,
      ...this.formatDynamicData()
		}
		if(itemMetadataEditing && !isAddMetaTransaction) {
			CallApi(`metadata/${itemMetadataEditing.id}`, 'PUT', dataTranfer).then(res => {
				if(res){
					alert(`Update metadata thanh cong!`);
					toggle();
					handleReloadDataTable();
				}
			})
		} else if(isAddMetaTransaction) {
			const data = [
				{ "txId": transactionId },
				{
					"currentIdentity": {
						"privateKey": "AMudkHmEX8obNZzSiqHo3y6P7w3oDZs79Y6Bopv9whti",
						"publicKey": "A6yF47Ud5GMmRi5yii77ce3xeY7ppvCNUbxubbKyuvD3"
					}
				},
				{
					"updateContent": {
						"supplierType": metaData.metaSupplierType,
						"name": metaData.metaName,
						"noteAction": metaData.noteAction,
						"detail": {
							...this.formatDynamicData(),
							timeStamp: new Date()
						}
					}
				},
				{ "amountToSend": Number(this.props.amount) }
			];
			callApiBigChain('updateTransactionSC', 'POST', data).then(res => {
				if (res) {
					alert("Add metadata transaction thanh cong!");
					CallApi('transaction/' + bcId, 'PUT', { status: 'A', transactionId: res.data.id }).then(res1 => {
						if (res1) {
							this.props.loadDataTable();
							toggle();
							this.props.reloadStatusOfAsset({ status: 'A', transactionId: res.data.id });
						}
					});
					this.props.loadHistoryOfAsset(res.data.id, res.data.asset.id);
				}
			})
		} else {
			CallApi('metadata', 'POST', dataTranfer).then(res =>{
				if(res) {
					alert(`Add metadata thanh cong!`);
					toggle();
					handleReloadDataTable();
				}
			})
		}
	}

	generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
	}
	
	handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }
	
	handleOnAddField = (dynamicKey = '', dynamicValue = '', itemId = '') => {
    const generateId = itemId || this.generateId();
    const key = `dynamic-key-${generateId}`;
		const valueField = `dynamic-value-${generateId}`;
    let input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Col sm='3'>
          <Input
            type="text"
            id={key}
						name={key}
						defaultValue={dynamicKey || ''}
            placeholder="key"
						onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <Label>:</Label>
        </Col>
        <Col sm='7'>
          <Input
            type="text"
            id={valueField}
            name={valueField}
						autoComplete="dataPlus"
						defaultValue={dynamicValue}
            placeholder="value"
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <i className="fa fa-align-justify" onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
        </Col>
      </FormGroup>)
		};

		inputs.push(input);
    this.setState({
      reloadPage: 1
    });
	}

	formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }
	
	handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

	render() {
		const { toggle, isOpenModal, className } = this.props;
		const { metaData, btnSubmit } = this.state;
		return (
			<Modal isOpen={isOpenModal} toggle={toggle} className={className}>
				<ModalHeader toggle={toggle}>Metadata of pork</ModalHeader>
				<ModalBody>
					<FormGroup row>
						<Label for="name" sm='4'>Meta Name:</Label>
						<Col sm={8}>
							<Input
								color="red"
								type="text"
								id="metaName"
								name="metaName"
								autoComplete="name"
								value={metaData.metaName}
								onChange={this.handleChange}
							/>
						</Col>
					</FormGroup>
					<FormGroup row>
						<Label for="name" sm='4'>Supplier Type:</Label>
						<Col sm={8}>
							<Input
								type="select"
								id="metaSupplierType"
								name="metaSupplierType"
								value={metaData.metaSupplierType}
								onChange={this.handleChange}>
								<option defaultValue='' disabled value='' hidden></option>
								<option value='Farmer'>Farmer</option>
								<option value='Producer'>Producer</option>
								<option value='Distributor'>Distributor</option>
								<option value='Retailer'>Retailer</option>
							</Input>
						</Col>
					</FormGroup>
					<FormGroup row>
						<Label for="name" sm='4'>Note Action:</Label>
						<Col sm={8}>
							<Input
								color="red"
								type="text"
								id="note"
								name="noteAction"
								autoComplete="noteAction"
								value={metaData.noteAction}
								onChange={this.handleChange}
							/>
						</Col>
					</FormGroup>
					<Card>
						<CardHeader>
							Detail
              <Button color="primary" style={{ float: 'right' }} onClick={() => this.handleOnAddField()}>Add field</Button>
						</CardHeader>
						<CardBody>
							{this.formatRender()}
						</CardBody>
					</Card>
				</ModalBody>
				<ModalFooter>
					<Button color="primary" onClick={this.handleSubmitMetaData}>{btnSubmit}</Button>{' '}
					<Button color="secondary" onClick={toggle}>Cancel</Button>
				</ModalFooter>
			</Modal>
		);
	}
}

export default MetaModal;
