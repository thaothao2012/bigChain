import React, { Component } from 'react';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormGroup,
  Input,
  Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';
import CallApi from '../../../callApi/apiCall';
import callApiBigChain from '../../../callApi/apiCallBigChain';

let inputs = [];
class TransactionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }
}


handleOnAddField = (dynamicKey = '', dynamicValue = '', itemId = '') => {
  const generateId = itemId || this.generateId();
  const key = `dynamic-key-${generateId}`;
  const valueField = `dynamic-value-${generateId}`;
  let input = {
    id: generateId,
    render: (<FormGroup row key={key}>
      <Col sm='6'>
        <Input
          type="text"
          id={key}
          name={key}
          defaultValue={dynamicKey || ''}
          placeholder="key"
          onChange={this.handleChangeDynamicField}
        />
      </Col>
      <Col sm='5'>
        <Input
          type="text"
          id={valueField}
          name={valueField}
          autoComplete="dataPlus"
          defaultValue={dynamicValue}
          placeholder="value"
          onChange={this.handleChangeDynamicField}
        />
      </Col>
      <Col sm='1'>
        <i className="fa fa-align-justify" onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
      </Col>
    </FormGroup>)
  };

  inputs.push(input);
  this.setState({
    reloadPage: 1
  });
}

formatDynamicData = () => {
  const { dynamicData } = this.state;
  const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
  const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
  let resObj = {};

  keyArr.forEach((item, idx) => {
    const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
    resObj = { ...resObj, ...temp };
  })
  return resObj;
}

handleChangeDynamicField = e => {
  const { dynamicData } = this.state;
  const { name, value } = e.target;
  const obj = { [name]: value };

  const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
  if (index !== -1) {
    dynamicData.splice(index, 1);
  }
  dynamicData.push(obj);

  this.setState({
    dynamicData
  });
}

toggleAndClearDataForm = () => {
  this.props.toggle();
}

render() {
  const { toggle, onClose, isOpenModal, className, amount } = this.props;
  const { metaData, btnSubmit } = this.state;
  return (
    <Modal isOpen={this.state.isOpenDivideModal} toggle={() => this.onClose(1)} className={this.props.className}>
      <ModalHeader toggle={() => this.onClose(1)}>Amount:</ModalHeader>
      {/* <ModalHeader toggle={() => this.toggle(null, 1)}>Amount: {transaction_tmp.amount || ''}</ModalHeader> */}
      <ModalBody>
        {/* <Card className="height-100">
          <CardHeader>
            <Label className="float-left">Divisible name</Label>
            <Label className="float-right" style={{ width: "50%" }}>Amount to send</Label>
          </CardHeader>
          <CardBody>
            <FormGroup row>
              <Label for="canned" sm='5'>Canned</Label>
              <Col sm={7}>
                <Input
                  type="text"
                  id="canned"
                  name="canned"
                  autoComplete="canned"
                  value={amountToSend.canned}
                  onChange={this.handleOnChange} />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="sausage" sm='5'>Sausage</Label>
              <Col sm={7}>
                <Input
                  type="text"
                  id="sausage"
                  name="sausage"
                  autoComplete="sausage"
                  value={amountToSend.sausage}
                  onChange={this.handleOnChange} />
              </Col>
            </FormGroup>
            <FormGroup row>
              <Label for="meat" sm='5'>Meat</Label>
              <Col sm={7}>
                <Input
                  type="text"
                  id="meat"
                  name="meat"
                  autoComplete="meat"
                  value={amountToSend.meat}
                  onChange={this.handleOnChange} />
              </Col>
            </FormGroup>
          </CardBody>
        </Card>
         */}
        <Card>
          <CardHeader>
            Divide
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
          </CardHeader>
          <CardBody>
            {this.formatRender()}
          </CardBody>
        </Card>
        <Card className="height-100">
          <CardHeader>
            Content
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
          </CardHeader>
          <CardBody>
            {this.formatRender()}
            <FormGroup row>
              <Label for="note" sm='6'>Note Action</Label>
              <Col sm={6}>
                <Input
                  type="text"
                  id="note"
                  name="note"
                  autoComplete="note"
                  value={updateContent.note}
                  onChange={this.handleOnChange} />
              </Col>
            </FormGroup>
          </CardBody>
        </Card>
      </ModalBody>
      <ModalFooter>
        <Button color="primary" onClick={this.handleAddDivisible}>Divide</Button>{' '}
        <Button color="secondary" onClick={() => this.onClose(1)}>Cancel</Button>
      </ModalFooter>
    </Modal>
  );
}
}

export default TransactionModal;
