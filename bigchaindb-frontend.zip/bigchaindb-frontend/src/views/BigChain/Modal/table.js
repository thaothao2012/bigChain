import React, { Component } from 'react';
import {
  ListGroup, ListGroupItem, Button, Collapse,
  FormGroup, Label, Table
} from 'reactstrap';
import { formatName } from '../Utils';
//let inputs = [];
class CustomTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      custom: [false, true],
      pageSize: 10
    }
  }

  toggle = (transaction, index) => {
    this.props.toggle(transaction, index);
  }

  toggleCustom = (isAssetDetail, index) => {
    if (isAssetDetail) {
      this.setState({
        ['openAssetColapse_' + index]: !this.state['openAssetColapse_' + index]
      });
    } else {
      this.setState({
        ['openMetaColapse_' + index]: !this.state['openMetaColapse_' + index]
      });
    }
  }

  render() {
    const { data, tableKey, transaction_tmp, currentPage } = this.props;
    const { pageSize } = this.state;
    const isDisable = tableKey === 'spent';
    let dataPaging = data.slice(pageSize * (currentPage - 1), pageSize*currentPage);

    const TransactionList = (dataPaging ? dataPaging.map((transaction, index) => {
      const metaDetail = transaction.metaData.detail;
      const assetDetail = transaction.assetData.detail;
      const trans_id = transaction.transaction_id + transaction.output_index;
      const transaction_tmp_id = transaction_tmp.transaction_id + transaction_tmp.output_index;
      return <tr key={tableKey + index}
        className={(trans_id === transaction_tmp_id) ? "active row" : "row"}>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Transaction Id:</Label> {transaction.transaction_id}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Output Index:</Label> {transaction.output_index}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Amount:</Label> {transaction.amount}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Input Transaction Id:</Label> {transaction.inputTxId}
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-3'>
          <ListGroup>
            <ListGroupItem>
              <Label>Supplier Type:</Label> {transaction.metaData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {transaction.metaData.name}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Note Action:</Label> {transaction.metaData.noteAction}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(false, index)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail
          </Button>
              <Collapse isOpen={this.state['openMetaColapse_' + index]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(metaDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + 2}>
                      <ListGroupItem className="padding-5">
                        <label key={index + 1}>{formatName(keyItem)}:</label>&nbsp;
                    <span key={index}>{metaDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Asset Id:</Label> {transaction.assetId}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Supplier Type:</Label> {transaction.assetData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {transaction.assetData.name}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(true, index)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail
          </Button>
              <Collapse isOpen={this.state['openAssetColapse_' + index]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(assetDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + 2} >
                      <ListGroupItem className="padding-5">
                        <label key={index + 1}>{formatName(keyItem)}:</label>&nbsp;
                    <span key={index}>{assetDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td style={{ textAlign: "center" }} className='col-sm-1'>
          <Button color="primary" className="width-70"
            disabled={isDisable}
            onClick={() => this.toggle(transaction, 1)}>Divide asset
      </Button><br />
          <Button color="primary"
            disabled={isDisable}
            className="margin-top width-70"
            onClick={() => this.toggle(transaction, 2)}>Add Meta
      </Button><br />
          <Button color="primary" className="margin-top width-70"
            disabled={isDisable}
            onClick={() => this.toggle(transaction, 3)}>Transfer asset
      </Button><br />
          <Button color="primary" className="margin-top width-70"
            onClick={() => this.toggle(transaction, 4)}>View history
      </Button>
        </td>
      </tr>

    }) : null);



    return (
      <Table responsive bordered>
        <thead>
          <tr className='row'>
            <th className='col-sm-4'>No.</th>
             <th className='col-sm-3'>No.</th>
              <th className='col-sm-4'>No.</th>
               <th className='col-sm-1'>No.</th>
            {/* <th >No.</th>
            <th >Product identification</th>
            <th >Transaction code</th>
            <th >Product line</th>
            <th >Product description</th>
            <th >Quantity</th>
            <th >Units</th>
            <th >Amount</th>
            <th >Created date</th>
            <th >Unspent</th>
            <th >Actions</th> */}
          </tr>
        </thead>
        <tbody style={{ overflow: "scroll", height: "600px" }}>
          {TransactionList}
        </tbody>
      </Table>
    );
  }
}

export default CustomTable;
