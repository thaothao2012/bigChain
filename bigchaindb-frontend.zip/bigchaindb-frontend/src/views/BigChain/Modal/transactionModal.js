import React, { Component } from 'react';
import {
  Col,
  Row,
  Button,
  Card,
  CardBody,
  CardHeader,
  FormGroup,
  Input,
  Modal, ModalHeader, ModalBody, ModalFooter, Label
} from 'reactstrap';
import CallApi from '../../../callApi/apiCall';
import callApiBigChain from '../../../callApi/apiCallBigChain';

let inputs = [];
class TransactionModal extends Component {
  constructor(props) {
    super(props);
    const listTransferUser = [
      {
        name: 'farmer1',
        privateKey: 'AMudkHmEX8obNZzSiqHo3y6P7w3oDZs79Y6Bopv9whti',
        publicKey: 'A6yF47Ud5GMmRi5yii77ce3xeY7ppvCNUbxubbKyuvD3'
      },
      {
        name: 'farmer2',
        privateKey: 'C3D47ks5n6xn2Nc3dzEtQXC9ZCb13vYYMzgJYgWnabiG',
        publicKey: '7F81vi6jF56ocf3goQfeQqNZQqduapxB58du5L85j3s'
      },
      {
        name: 'producer1',
        privateKey: 'Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq',
        publicKey: 'HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q'
      },
      {
        name: 'producer2',
        privateKey: '6GZuCGqG9kgbhpQ2YV9WxEAuXd5Rm6HWNzJpm9Yn6VmC',
        publicKey: '8RPVPUFhi3U42xj4pqTVFmEQG1h86WbvQy5yXtj1Zjm3'
      },
      {
        name: 'distributor1',
        privateKey: 'C18iERpX64giGSk3UeM4ADaQL3jLfC2nX4fhcFVGaxz8',
        publicKey: 'Aji4dH6K8hsLt11ZPko9tGhVjAMKcqUwgwZYJAG4YY4S'
      },
      {
        name: 'distributor2',
        privateKey: '5gPeCHeuiUfgjwhz2E6a9yk2ycP4SHtoRvd7hL7PUvWP',
        publicKey: '4PdJDqPCR2wqx66PJJQFbg5VDA24N3sYMx6JPJyxnsV7'
      },
      {
        name: 'retailer1',
        privateKey: 'GzpgiK2isqEs35kRzQo3p6SGDWmbEJreJvhh2ZUpE28i',
        publicKey: '3VgGBGJ9qTiUz9dbmH4iGwTJVnSEvchDJTXao3rM7Ms6'
      },
      {
        name: 'retailer2',
        privateKey: 'BqoweBu2jYJ4TzxTvSy2oTGKYyH7VFUVq1cuwb3uHWjW',
        publicKey: '4QHtaUUshKbhpZWPP6qGwUaYqdQ23xLFfqrto9521T2V'
      }
    ]
    this.state = {
      dynamicData: [],
      listTransferUser,
      btnSubmit: 'Add',
      transferIdentity: {},
      metaData: {
        metaName: '',
        metaSupplierType: 'Producer',
        noteAction: '',
        amount: '',
      }
    }
  }

  componentWillReceiveProps(nextProps) {
    this.handleLoadDataInit();
    if (!nextProps.isOpenModal) {
      inputs = [];
      const metaData = {
        metaName: '',
        metaSupplierType: '',
        noteAction: '',
        amount: '',
      };
      this.setState({
        dynamicData: [],
        metaData,
        btnSubmit: 'Transfer',
        transferName: ''
      })
    }
  }

  handleLoadDataInit = () => {
    const { itemMetadataEditing } = this.props;
    if (itemMetadataEditing) {
      const metaData = {
        metaName: itemMetadataEditing.name,
        metaSupplierType: itemMetadataEditing.supplierType,
        noteAction: itemMetadataEditing.noteAction,
        amount: itemMetadataEditing.amount
      }
      const { detail } = itemMetadataEditing;
      let dynamicData = [];
      if (detail) {
        const keys = Object.keys(detail);
        keys.forEach(item => {
          const generateId = this.generateId();
          const objKey = { [`dynamic-key-${generateId}`]: item };
          const objValue = { [`dynamic-value-${generateId}`]: detail[item] };
          dynamicData = dynamicData.concat([objKey, objValue]);

          this.handleOnAddField(item, detail[item], generateId)
        });
      }
      this.setState({
        metaData,
        dynamicData,
        btnSubmit: 'Update'
      });
    }
  }

  handleChange = e => {
    const { metaData } = this.state;
    const { name, value } = e.target;
    this.setState({
      metaData: { ...metaData, [name]: value }
    })
  }

  handleOnChangeTrans = e => {
    this.props.handleOnChangeTrans(e);
  }
  handleTransferIdentity = e => {
    const { listTransferUser } = this.state;
    const { value } = e.target;
    const cloneArray = listTransferUser.slice(0);
    const obj = cloneArray.find(item => item.name === value);
    if (obj) {
      delete obj.name
    }
    this.setState({
      transferIdentity: obj,
      transferName: value
    })
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }

  handleTransferAssetData = () => {
    const { transferIdentity, metaData } = this.state;
    const { amount, transactionId, bcId, currentIdentity, outputIndex} = this.props;

    if (!transferIdentity) {
      alert('Please select the tranfer Name');
    } else {
      const transferData = [
        {
          txId: transactionId
        },
        {
          outputIndex: outputIndex || 0
        },
        {
          currentIdentity: currentIdentity
        },
        {
          receiverPublicKey: transferIdentity.publicKey
        },
        {
          transferContent: {
            supplierType: metaData.metaSupplierType || this.props.personIdentity,
            name: metaData.metaName,
            detail: {
              ...this.formatDynamicData(),
              timeStamp: new Date()
            },
            noteAction: metaData.noteAction
          }
        },
        { amountToSend: Number(amount) }
      ];
      console.log('transferData', transferData);
      callApiBigChain('transferTransactionSC', 'POST', transferData).then(res => {
        if (res) {
          alert("Transfer transaction thanh cong!");
          if (this.props.personIdentity === 'Farmer') {
            this.props.loadHistoryOfAsset(res.data.id, res.data.asset.id);
            this.props.reloadStatusOfAsset({ status: 'T', transactionId: res.data.id });
            CallApi('transaction/' + bcId, 'PUT', { status: 'T', transactionId: res.data.id }).then(res1 => {
              if (res1) {
                this.props.loadDataTable();
                this.props.toggle();
              }
            });
          } else {
            this.props.reload();
            this.props.toggle();
          }
        }
      })
    }
  }

  generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  handleOnAddField = (dynamicKey = '', dynamicValue = '', itemId = '') => {
    const generateId = itemId || this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    let input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Col sm='6'>
          <Input
            type="text"
            id={key}
            name={key}
            defaultValue={dynamicKey || ''}
            placeholder="key"
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='5'>
          <Input
            type="text"
            id={valueField}
            name={valueField}
            autoComplete="dataPlus"
            defaultValue={dynamicValue}
            placeholder="value"
            onChange={this.handleChangeDynamicField}
          />
        </Col>
        <Col sm='1'>
          <i className="fa fa-align-justify" onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
        </Col>
      </FormGroup>)
    };

    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  toggleAndClearDataForm = () => {
    this.props.toggle();
  }

  render() {
    const { toggle, isOpenModal, className, amount } = this.props;
    const { metaData, btnSubmit } = this.state;
    return (
      <Modal isOpen={isOpenModal} toggle={toggle} className={className}>
        <ModalHeader toggle={toggle}>Transfer Asset</ModalHeader>
        <ModalBody>
          <Row>
            <Col sm='12'>
              <FormGroup>
                <Label for="name">Transfer Name:</Label>
                <Input
                  type="select"
                  id="transferName"
                  name="transferName"
                  value={this.state.transferName || ''}
                  onChange={this.handleTransferIdentity}>
                  <option disabled value='' hidden></option>
                  <option value='farmer1'>Farmer1</option>
                  <option value='farmer2'>Farmer2</option>
                  <option value='producer1'>Producer1</option>
                  <option value='producer2'>Producer2</option>
                  <option value='distributor1'>Distributor1</option>
                  <option value='distributor2'>Distributor2</option>
                  <option value='retailer1'>Retailer1</option>
                  <option value='retailer2'>Retailer2</option>
                </Input>
              </FormGroup>
              <FormGroup>
                <Label for="amount">Amount to Send:</Label>
                <Input
                  type="text"
                  id="amount"
                  name="amount"
                  autoComplete="amount"
                  value={metaData.amount || amount}
                  onChange={this.handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="name">Meta Name:</Label>
                <Input
                  type="text"
                  id="metaName"
                  name="metaName"
                  autoComplete="name"
                  value={metaData.metaName}
                  onChange={this.handleChange}
                />
              </FormGroup>
              <FormGroup>
                <Label for="name">Supplier Type:</Label>
                <Input
                  type="select"
                  id="metaSupplierType"
                  name="metaSupplierType"
                  value={metaData.metaSupplierType || this.props.personIdentity}
                  onChange={this.handleChange}>
                  <option disabled value='' hidden></option>
                  <option value='Farmer'>Farmer</option>
                  <option value='Producer'>Producer</option>
                  <option value='Distributor'>Distributor</option>
                  <option value='Retailer'>Retailer</option>
                </Input>
              </FormGroup>
              <Card>
                <CardHeader>
                  Detail
              <Button color="primary" style={{ float: 'right' }} onClick={() => this.handleOnAddField()}>Add field</Button>
                </CardHeader>
                <CardBody>
                  {this.formatRender()}
                </CardBody>
              </Card>
              <FormGroup>
                <Label for="name">Note Action:</Label>
                <Input
                  color="red"
                  type="text"
                  id="note"
                  name="noteAction"
                  autoComplete="noteAction"
                  value={metaData.noteAction}
                  onChange={this.handleChange}
                />
              </FormGroup>

            </Col>
          </Row>
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={this.handleTransferAssetData}>{btnSubmit}</Button>{' '}
          <Button color="secondary" onClick={toggle}>Cancel</Button>
        </ModalFooter>
      </Modal>
    );
  }
}

export default TransactionModal;
