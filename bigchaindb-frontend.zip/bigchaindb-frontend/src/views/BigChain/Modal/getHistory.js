import React, { Component } from 'react';
import {
  ListGroup, ListGroupItem,
  ListGroupItemHeading, ListGroupItemText,
  Card, CardBody, CardHeader,
  Modal, ModalBody, ModalHeader, ModalFooter
} from 'reactstrap';
import { formatDate } from '../Utils';
import { Button } from 'semantic-ui-react';

class History extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    const { historyData } = this.props;
    const historyList = historyData && historyData.map((item, index) => (<ListGroupItem key={index}>
      <ListGroupItemHeading>{item.supplierType}</ListGroupItemHeading>
      <ListGroupItemText>
        Date : {formatDate(item.detail.timeStamp)}
        <br />
        Content : {item.noteAction}
      </ListGroupItemText>
    </ListGroupItem>));

    const { toggle, isOpenModal, className } = this.props;
   // const { metaData, btnSubmit } = this.state;
    return (
      <Modal isOpen={isOpenModal} toggle={!isOpenModal} className={className}>
        <ModalHeader>History</ModalHeader>
        <ModalBody>
          <Card>
            <CardHeader>
              History of product
        </CardHeader>
            <CardBody>
              <ListGroup style={{ overflow: "scroll", height: "450px" }}>
                {historyList}
              </ListGroup>
            </CardBody>
          </Card>
        </ModalBody>
        <ModalFooter>
          <Button onClick={!isOpenModal}>OK</Button>
        </ModalFooter>
      </Modal>

    );
  }
}

export default History;
