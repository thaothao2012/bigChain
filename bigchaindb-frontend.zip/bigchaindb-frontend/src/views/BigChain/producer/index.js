import React, { Component } from 'react';
import {
  Badge, Card, CardBody, CardHeader, Col, Pagination,
  PaginationItem, PaginationLink, Row, Table,
  ListGroup, ListGroupItem, Button, Collapse,
  FormGroup, Modal, ModalHeader, ModalBody, ModalFooter, Label, Input
} from 'reactstrap';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
import AddMeta from './addMeta';
import TransactionModal from '../Modal/transactionModal';
import History from '../Modal/getHistory';

let inputs = [];
class Producer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      addMetaModal: false,
      isOpenTrans: false,
      isOpenHistory: false,
      custom: [true, false],
      spentData: [],
      unSpentData: [],
      updateContent: {
        supplierType: '',
        name: '',
        note: '',
        detail: {}
      },
      amountToSend: {
        canned: 0,
        sausage: 0,
        meat: 0
      },
      outputState: {},
      reloadPage: 0,
      dynamicData: []
    }
  }

  componentDidMount = () => {
    this.loadInitData();
  }

  loadInitData = () => {
    CallApiBigChain('getListOutputsSC?publicKey=HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q', 'GET', null).then(res => {
      if (res) {
        this.setState({
          spentData: res.data[0],
          unSpentData: res.data[1]
        });
      }
    })
  }



  toggleCustom(tab) {
    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);
    this.setState({
      custom: state,
    });
  }

  handleOnChange = (e) => {
    const { updateContent, amountToSend } = this.state;
    const { name, value } = e.target;
    this.setState({
      updateContent: {
        ...updateContent, [name]: value
      },
      amountToSend: {
        ...amountToSend, [name]: value
      }
    });
  }
  generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }

  handleOnAddField = () => {
    const generateId = this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    const input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Row>
          <Col sm='4'>
            <Input
              type="text"
              id={key}
              name={key}
              autoComplete="dataPlus"
              placeholder="key"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='6'>
            <Input
              type="text"
              id={valueField}
              name={valueField}
              autoComplete="dataPlus"
              placeholder="value"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='1'>
            <i className="fa fa-align-justify" style={{ float: "left" }}
              onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
          </Col>
        </Row>
      </FormGroup>)
    };
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  handleAddDivisible = () => {
    const { outputState, updateContent, amountToSend } = this.state;
    const data = [
      { "txId": outputState.transaction_id },
      { "outputIndex": outputState.output_index },

      {
        "currentIdentity": {
          "privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
          "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
        }
      },
      {
        "updateContent": {
          "supplierType": updateContent.supplierType,
          "name": updateContent.name,
          "noteAction": updateContent.note,
          "detail": {
            ...this.formatDynamicData()
          }
        }
      },
      { "amountToSend1": Number(amountToSend.canned) },
      { "amountToSend2": Number(amountToSend.sausage) },
      { "amountToSend3": Number(amountToSend.meat) }
    ];
    //console.log(data);
    CallApiBigChain('divideTokensWithOutputSC', 'POST', data).then(res => {
      if (res) {
        alert("add divide data thanh cong!");
        this.loadInitData();
      }
    })
  }

  toggle = (output) => {
    this.setState(prevState => ({
      modal: !prevState.modal,
      outputState: output
      //amount: output.amount
    }));
  }
  componentDidUpdate() {
    // debugger;
  }

  toggleAddMeta = (output) => {
    this.setState({
      outputState: output,
      reloadPage: 1,
      isPassData: true,
      addMetaModal: !this.state.addMetaModal
    });
  }

  toggleTransaction = (output) => {
    this.setState(prevState => ({
      outputState: output,
      reloadPage: 1,
      // isPassData: true,
      isOpenTrans: !prevState.isOpenTrans
    }));
  }

  toggleLoadHistoryOfAsset = (output) => {
    CallApiBigChain('getHistoricalAssetByTransIdSC', 'GET', {
      currentTransId: output.transaction_id,
      asset_id: output.assetId
    }).then(res => {
      if (res) {
        this.setState({
          history: res.data,
          isOpenHistory: !this.state.isOpenHistory
        });
      }
    })
  }

  render() {
    const { spentData, unSpentData, updateContent, amountToSend, outputState } = this.state;
    const spentDataList = spentData.map((output, index) => {
      const metaDetail = output.metaData.detail;
      const assetDetail = output.assetData.detail;
      return <tr key={index}>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              transactions_id: {output.transaction_id}
            </ListGroupItem>
            <ListGroupItem>
              output index: {output.output_index}
            </ListGroupItem>
            <ListGroupItem>
              amount: {output.amount}
            </ListGroupItem>
            <ListGroupItem>
              inputTxId: {output.inputTxId}
            </ListGroupItem>
          </ListGroup>
        </td>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              supplierType: {output.metaData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              name: {output.metaData.name}
            </ListGroupItem>
            <ListGroupItem>
              noteAction: {output.metaData.noteAction}
            </ListGroupItem>
            <ListGroupItem>
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(0)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail +
              </Button>
              <Collapse isOpen={this.state.custom[0]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(metaDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5">
                      <ListGroupItem className="padding-5">
                        <p key={index}>-{keyItem}:</p>
                        <p key={index}>{metaDetail[keyItem]}</p>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              assetId: {output.assetId}
            </ListGroupItem>
            <ListGroupItem>
              supplierType: {output.assetData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              name: {output.assetData.name}
            </ListGroupItem>
            <ListGroupItem>
              <Button className="m-0 p-0" color="link"
                onClick={() => this.toggleCustom(0)}
                aria-expanded={this.state.custom[0]}
                aria-controls="exampleAccordion1">
                Detail +
              </Button>
              <Collapse isOpen={this.state.custom[0]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(assetDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5">
                      <ListGroupItem className="padding-5">
                        <p key={index}>-{keyItem}:</p>
                        <p key={index}>{metaDetail[keyItem]}</p>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td style={{ textAlign: "center" }}>
          <Button color="success"
            className="width-70 margin-top-50"
            onClick={() => this.toggleLoadHistoryOfAsset(output)}
          >View history</Button>
        </td>
      </tr>
    });
    const unSpentDataList = unSpentData.map((output, index) => {
      const metaDetail = output.metaData.detail;
      const assetDetail = output.assetData.detail;
      return <tr key={'spent' - index}>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              transactions_id: {output.transaction_id}
            </ListGroupItem>
            <ListGroupItem>
              output index: {output.output_index}
            </ListGroupItem>
            <ListGroupItem>
              amount: {output.amount}
            </ListGroupItem>
            <ListGroupItem>
              inputTxId: {output.inputTxId}
            </ListGroupItem>
          </ListGroup>
        </td>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              supplierType: {output.metaData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              name: {output.metaData.name}
            </ListGroupItem>
            <ListGroupItem>
              noteAction: {output.metaData.noteAction}
            </ListGroupItem>
            <ListGroupItem>
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(0)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail +
              </Button>
              <Collapse isOpen={this.state.custom[0]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(metaDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5">
                      <ListGroupItem className="padding-5">
                        <p key={index}>-{keyItem}:</p>
                        <p key={index}>{metaDetail[keyItem]}</p>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td>
          <ListGroup style={{ overflow: "scroll", height: "200px" }}>
            <ListGroupItem>
              assetId: {output.assetId}
            </ListGroupItem>
            <ListGroupItem>
              supplierType: {output.assetData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              name: {output.assetData.name}
            </ListGroupItem>
            <ListGroupItem>
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(0)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail +
              </Button>
              <Collapse isOpen={this.state.custom[0]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(assetDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5">
                      <ListGroupItem className="padding-5">
                        <p key={index}>-{keyItem}:</p>
                        <p key={index}>{assetDetail[keyItem]}</p>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td style={{ textAlign: "center" }}>
          <Button color="primary" className="width-70"
            onClick={() => this.toggle(output)}>Divide asset
          </Button><br />
          <Button color="success"
            className="margin-top width-70"
            onClick={() => this.toggleAddMeta(output)}>Add Meta
          </Button><br />
          <Button color="primary" className="margin-top width-70"
            onClick={() => this.toggleTransaction(output)}>Transfer asset
          </Button><br />
          <Button color="success" className="margin-top width-70"
            onClick={() => this.toggleLoadHistoryOfAsset(output)}>View history
          </Button>
        </td>
      </tr>
    });

    return (
      <div className="animated fadeIn">
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Unspent output
              </CardHeader>
              <CardBody>
                <Table responsive bordered className="fixed_header">
                  <thead>
                    <tr>
                      <th>Common information</th>
                      <th>Current meta data</th>
                      <th>Asset data</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody style={{ overflow: "scroll", height: "600px" }}>
                    {unSpentDataList}
                  </tbody>
                </Table>
                <Pagination>
                  <PaginationItem><PaginationLink previous tag="button">Prev</PaginationLink></PaginationItem>
                  <PaginationItem active>
                    <PaginationLink tag="button">1</PaginationLink>
                  </PaginationItem>
                  <PaginationItem className="page-item"><PaginationLink tag="button">2</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">3</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">4</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink next tag="button">Next</PaginationLink></PaginationItem>
                </Pagination>
              </CardBody>
            </Card>
          </Col>
        </Row>

        <Row>
          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Spent output
              </CardHeader>
              <CardBody>
                <Table responsive bordered style={{ width: "900px", tableLayout: "fixed", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th>Common information</th>
                      <th>Current meta data</th>
                      <th>Asset data</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody style={{ overflow: "scroll", height: "600px" }}>
                    {spentDataList}
                  </tbody>
                </Table>
                <Pagination>
                  <PaginationItem><PaginationLink previous tag="button">Prev</PaginationLink></PaginationItem>
                  <PaginationItem active>
                    <PaginationLink tag="button">1</PaginationLink>
                  </PaginationItem>
                  <PaginationItem className="page-item"><PaginationLink tag="button">2</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">3</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink tag="button">4</PaginationLink></PaginationItem>
                  <PaginationItem><PaginationLink next tag="button">Next</PaginationLink></PaginationItem>
                </Pagination>
              </CardBody>
            </Card>
          </Col>

        </Row>

        <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
          <ModalHeader toggle={this.toggle}>Amount: {outputState.amount || ''}</ModalHeader>
          <ModalBody>
            <Row>
              <Col sm={6}>
                <Card className="height-100">
                  <CardHeader>
                    <Label className="float-left">Divisible name</Label>
                    <Label className="float-right">Amount to send</Label>
                  </CardHeader>
                  <CardBody>
                    <FormGroup row>
                      <Label for="canned" sm='5'>canned</Label>
                      <Col sm={7}>
                        <Input
                          type="text"
                          id="canned"
                          name="canned"
                          autoComplete="canned"
                          value={amountToSend.canned}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="sausage" sm='5'>sausage</Label>
                      <Col sm={7}>
                        <Input
                          type="text"
                          id="sausage"
                          name="sausage"
                          autoComplete="sausage"
                          value={amountToSend.sausage}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="meat" sm='5'>meat</Label>
                      <Col sm={7}>
                        <Input
                          type="text"
                          id="meat"
                          name="meat"
                          autoComplete="meat"
                          value={amountToSend.meat}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                  </CardBody>
                </Card>
              </Col>
              <Col sm={6}>
                <Card className="height-100">
                  <CardHeader>
                    <Label className="float-left">Divisible content</Label>
                  </CardHeader>
                  <CardBody>
                    <FormGroup row>
                      <Label forsupplierType sm='6'>supplierType</Label>
                      <Col sm={6}>
                        <Input
                          type="text"
                          id="supplierType"
                          name="supplierType"
                          autoComplete="supplierType"
                          value={updateContent.supplierType}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="name" sm='6'>name</Label>
                      <Col sm={6}>
                        <Input
                          type="text"
                          id="name"
                          name="name"
                          autoComplete="name"
                          value={updateContent.name}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                    <FormGroup row>

                      <Col sm={12}>
                        <Card>
                          <CardHeader>
                            Detail
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>+</Button>
                          </CardHeader>
                          <CardBody>
                            {this.formatRender()}
                          </CardBody>
                        </Card>
                      </Col>
                    </FormGroup>
                    <FormGroup row>
                      <Label for="note" sm='6'>note</Label>
                      <Col sm={6}>
                        <Input
                          type="text"
                          id="note"
                          name="note"
                          autoComplete="note"
                          value={updateContent.note}
                          onChange={this.handleOnChange} />
                      </Col>
                    </FormGroup>
                  </CardBody>
                </Card>

              </Col>
            </Row>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleAddDivisible}>Ok</Button>{' '}
            <Button color="secondary" onClick={this.toggle}>Cancel</Button>
          </ModalFooter>
        </Modal>

        <Modal isOpen={this.state.addMetaModal} toggle={this.toggleAddMeta} className={this.props.className}>
          <ModalHeader>Amount: {outputState.amount || ''} </ModalHeader>
          <ModalBody>
            <AddMeta output={this.state.outputState}
              isPassData={this.state.isPassData}
              reload={this.loadInitData}
              toggle={this.toggleAddMeta} />
          </ModalBody>
        </Modal>
        <TransactionModal
          output={this.state.outputState}
          toggle={this.toggleTransaction}
          isOpenModal={this.state.isOpenTrans} />
        <History
          historyData={this.state.history}
          // toggle={this.toggleLoadHistoryOfAsset}
          isOpenModal={this.state.isOpenHistory} />
      </div>
    );
  }
}

export default Producer;
