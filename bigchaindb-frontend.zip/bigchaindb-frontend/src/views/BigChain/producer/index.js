import React, { Component } from 'react';
import {
  Card, CardBody, CardHeader, Col, Row, Table,
  ListGroup, ListGroupItem, Button, Collapse,
  FormGroup, Modal, ModalHeader, ModalBody, ModalFooter, Label, Input
} from 'reactstrap';
import CallApiBigChain from '../../../callApi/apiCallBigChain';
import AddMeta from './addMeta';
import TransactionModal from '../Modal/transactionModal';
import History from '../farmer/metadataInfo';
import { formatName } from '../Utils';

let inputs = [];
class Producer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      modal: false,
      addMetaModal: false,
      isOpenTrans: false,
      isOpenHistory: false,
      custom: [false, true],
      spentData: [],
      unSpentData: [],
      updateContent: {
        supplierType: 'Producer',
        name: '',
        note: '',
        detail: {}
      },
      amountToSend: {
        canned: 0,
        sausage: 0,
        meat: 0
      },
      outputState: {},
      reloadPage: 0,
      dynamicData: [],
      currentIdentity: {
        "privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
        "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
      },
      amountToTrans: 0
    }
  }

  componentDidMount = () => {
    this.loadInitData();
  }

  loadInitData = () => {
    CallApiBigChain('getListOutputsSC?publicKey=HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q', 'GET', null).then(res => {
      if (res) {
        this.setState({
          spentData: res.data[0],
          unSpentData: res.data[1]
        });
      }
    })
  }

  toggleCustom = (isAssetDetail, index) => {
    if (isAssetDetail) {
      this.setState({
        ['openAssetColapse_' + index]: !this.state['openAssetColapse_' + index]
      });
    } else {
      this.setState({
        ['openMetaColapse_' + index]: !this.state['openMetaColapse_' + index]
      });
    }
  }

  handleOnChange = (e) => {
    const { updateContent, amountToSend } = this.state;
    const { name, value } = e.target;
    this.setState({
      updateContent: {
        ...updateContent, [name]: value
      },
      amountToSend: {
        ...amountToSend, [name]: value
      }
    });
  }

  handleOnChangeTrans = e => {
    const { name, value } = e.target;
    this.setState({
      [name]: value
    });
  }

  generateId = () => {
    return Math.floor((1 + Math.random()) * 0X10000).toString(16).substring(1);
  }

  handleChangeDynamicField = e => {
    const { dynamicData } = this.state;
    const { name, value } = e.target;
    const obj = { [name]: value };

    const index = dynamicData.findIndex(item => Object.keys(item)[0] === name);
    if (index !== -1) {
      dynamicData.splice(index, 1);
    }
    dynamicData.push(obj);

    this.setState({
      dynamicData
    });
  }

  handleOnDeleteField = (e, key, valueField, generateId) => {
    const { dynamicData } = this.state;
    // remove element in dom
    inputs = inputs.filter(item => {
      return item.id !== generateId;
    });

    // Remove data in state
    const listRemoveKey = dynamicData.filter(item => (Object.keys(item)[0] !== key));
    const listRemoveValue = listRemoveKey.filter(item => (Object.keys(item)[0] !== valueField));
    this.setState({
      dynamicData: listRemoveValue
    })
  }

  formatDynamicData = () => {
    const { dynamicData } = this.state;
    const keyArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-key-') !== -1);
    const valueArr = dynamicData.filter(item => Object.keys(item)[0].indexOf('dynamic-value-') !== -1);
    let resObj = {};

    keyArr.forEach((item, idx) => {
      const temp = { [Object.values(item)[0]]: Object.values(valueArr[idx])[0] };
      resObj = { ...resObj, ...temp };
    })
    return resObj;
  }

  formatRender = () => {
    const arrResponse = [];
    inputs.forEach(item => {
      arrResponse.push(item.render);
    })
    return arrResponse;
  }

  handleOnAddField = () => {
    const generateId = this.generateId();
    const key = `dynamic-key-${generateId}`;
    const valueField = `dynamic-value-${generateId}`;
    const input = {
      id: generateId,
      render: (<FormGroup row key={key}>
        <Row>
          <Col sm='6'>
            <Input
              type="text"
              id={key}
              name={key}
              autoComplete="dataPlus"
              placeholder="key"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='5'>
            <Input
              type="text"
              id={valueField}
              name={valueField}
              autoComplete="dataPlus"
              placeholder="value"
              valueDefault=""
              onChange={this.handleChangeDynamicField}
            />
          </Col>
          <Col sm='1'>
            <i className="fa fa-align-justify" style={{ float: "left" }}
              onClick={(e) => this.handleOnDeleteField(e, key, valueField, generateId)}></i>
          </Col>
        </Row>
      </FormGroup>)
    };
    inputs.push(input);
    this.setState({
      reloadPage: 1
    });
  }

  handleAddDivisible = () => {
    const { outputState, updateContent, amountToSend } = this.state;
    const data = [
      { "txId": outputState.transaction_id },
      { "outputIndex": outputState.output_index },

      {
        "currentIdentity": {
          "privateKey": "Bf9fnEusmYPrU3ZtSW6eqMojNQpvYC5aWQn9FcTrNGgq",
          "publicKey": "HWjX94TC91Vf6kPM3CuZvVauxf8HsXqXHaaFW3eesm7q"
        }
      },
      {
        "updateContent": {
          "supplierType": updateContent.supplierType,
          "name": updateContent.name,
          "noteAction": updateContent.note,
          "detail": {
            ...this.formatDynamicData()
          }
        }
      },
      { "amountToSend1": Number(amountToSend.canned) },
      { "amountToSend2": Number(amountToSend.sausage) },
      { "amountToSend3": Number(amountToSend.meat) }
    ];
    //console.log(data);
    CallApiBigChain('divideTokensWithOutputSC', 'POST', data).then(res => {
      if (res) {
        alert("add divide data thanh cong!");
        this.loadInitData();
        this.setState(prevState => ({
          modal: !prevState.modal
        }));
      }
    })
  }

  toggle = (output) => {
    this.setState(prevState => ({
      modal: !prevState.modal,
      outputState: output
    }));
  }

  toggleAddMeta = (output) => {
    this.setState({
      outputState: output || this.state.outputState,
      reloadPage: 1,
      isPassData: true,
      addMetaModal: !this.state.addMetaModal
    });
  }

  toggleTransaction = (output) => {
    this.setState(prevState => ({
      outputState: output || prevState.outputState,
      reloadPage: 1,
      isOpenTrans: !prevState.isOpenTrans
    }));
  }

  toggleLoadHistoryOfAsset = (output) => {
    CallApiBigChain('getHistoricalAssetByTransIdSC', 'GET', {
      currentTransId: output.transaction_id,
      asset_id: output.assetId
    }).then(res => {
      if (res) {
        this.setState({
          history: res.data,
          outputState: output,
          isOpenHistory: !this.state.isOpenHistory
        });
      }
    })
  }

  toggleHistory = () => {
    this.setState(prevState => ({
      isOpenHistory: !prevState.isOpenHistory
    }));
  }
  render() {
    const { spentData, unSpentData, updateContent, amountToSend, outputState } = this.state;
    //spent
    const spentDataList = spentData.map((output, index) => {
      const metaDetail = output.metaData.detail;
      const assetDetail = output.assetData.detail;
      const output_id = output.transaction_id + output.output_index;
      const outputState_id = outputState.transaction_id + outputState.output_index;
      return <tr key={index + 1}
        className={(output_id === outputState_id) ? "active row" : "row"}>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Transactions Id:</Label> {output.transaction_id}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Output Index:</Label> {output.output_index}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Amount:</Label> {output.amount}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Input Transaction Id:</Label> {output.inputTxId}
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-3'>
          <ListGroup>
            <ListGroupItem >
              <Label>Supplier Type:</Label> {output.metaData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {output.metaData.name}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Note Action:</Label> {output.metaData.noteAction}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(true, index)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail
              </Button>
              <Collapse isOpen={this.state['openAssetColapse_' + index]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(metaDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + 2}>
                      <ListGroupItem className="padding-5">
                        <Label key={index + 1}>{formatName(keyItem)}:</Label>&nbsp;
                        <span key={index}>{metaDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Asset Id:</Label> {output.assetId}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Supplier Type:</Label> {output.assetData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {output.assetData.name}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link"
                onClick={() => this.toggleCustom(0)}
                aria-expanded={this.state.custom[0]}
                aria-controls="exampleAccordion1">
                Detail
              </Button>
              <Collapse isOpen={this.state.custom[0]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(assetDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + index}>
                      <ListGroupItem className="padding-5">
                        <Label key={index + 1}>{formatName(keyItem)}:</Label>&nbsp;
                        <span key={index}>{metaDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td style={{ textAlign: "center" }} className='col-sm-1'>
          <Button color="primary"
            className="width-70 margin-top-50"
            onClick={() => this.toggleLoadHistoryOfAsset(output)}
          >View history</Button>
        </td>
      </tr>
    });
    //unSpent
    const unSpentDataList = unSpentData.map((output, index) => {
      const metaDetail = output.metaData.detail;
      const assetDetail = output.assetData.detail;
      const output_id = output.transaction_id + output.output_index;
      const outputState_id = outputState.transaction_id + outputState.output_index;
      return <tr key={'unspent'+index}
        className={(output_id === outputState_id) ? "active row" : "row"}>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Transaction Id:</Label> {output.transaction_id}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Output Index:</Label> {output.output_index}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Amount:</Label> {output.amount}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Input Transaction Id:</Label> {output.inputTxId}
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-3'>
          <ListGroup>
            <ListGroupItem>
              <Label>Supplier Type:</Label> {output.metaData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {output.metaData.name}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Note Action:</Label> {output.metaData.noteAction}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(false, index)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail
              </Button>
              <Collapse isOpen={this.state['openMetaColapse_' + index]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(metaDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + 2}>
                      <ListGroupItem className="padding-5">
                        <label key={index + 1}>{formatName(keyItem)}:</label>&nbsp;
                        <span key={index}>{metaDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td className='td-container col-sm-4'>
          <ListGroup>
            <ListGroupItem>
              <Label>Asset Id:</Label> {output.assetId}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Supplier Type:</Label> {output.assetData.supplierType}
            </ListGroupItem>
            <ListGroupItem>
              <Label>Name:</Label> {output.assetData.name}
            </ListGroupItem>
            <ListGroupItem className="padding-5">
              <Button className="m-0 p-0" color="link" onClick={() => this.toggleCustom(true, index)} aria-expanded={this.state.custom[0]} aria-controls="exampleAccordion1">
                Detail
              </Button>
              <Collapse isOpen={this.state['openAssetColapse_' + index]} data-parent="#exampleAccordion" id="exampleAccordion1">
                {Object.keys(assetDetail).map((keyItem, index) => {
                  return (
                    <ListGroup className="padding-5" key={index + 2} >
                      <ListGroupItem className="padding-5">
                        <label key={index + 1}>{formatName(keyItem)}:</label>&nbsp;
                        <span key={index}>{assetDetail[keyItem]}</span>
                      </ListGroupItem>
                    </ListGroup>
                  )
                })}
              </Collapse>
            </ListGroupItem>
          </ListGroup>
        </td>
        <td style={{ textAlign: "center" }} className='col-sm-1'>
          <Button color="primary" className="width-70"
            onClick={() => this.toggle(output)}>Divide asset
          </Button><br />
          <Button color="primary"
            className="margin-top width-70"
            onClick={() => this.toggleAddMeta(output)}>Add Meta
          </Button><br />
          <Button color="primary" className="margin-top width-70"
            onClick={() => this.toggleTransaction(output)}>Transfer asset
          </Button><br />
          <Button color="primary" className="margin-top width-70"
            onClick={() => this.toggleLoadHistoryOfAsset(output)}>View history
          </Button>
        </td>
      </tr>
    });

    return (
      <div className="animated fadeIn">
        {/* unspent table */}
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Unspent output
              </CardHeader>
              <CardBody>
                <Table responsive bordered>
                  <thead>
                    <tr className='row'>
                      <th className='col-sm-4'>Common information</th>
                      <th className='col-sm-3'>Current meta data</th>
                      <th className='col-sm-4'>Asset data</th>
                      <th className='col-sm-1'>Actions</th>
                    </tr>
                  </thead>
                  <tbody style={{ overflow: "scroll", height: "600px" }}>
                    {unSpentDataList}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>
        </Row>

        {/* spent table */}
        <Row>
          <Col>
            <Card>
              <CardHeader>
                <i className="fa fa-align-justify"></i> Spent output
              </CardHeader>
              <CardBody>
                <Table responsive bordered>
                  <thead>
                    <tr className='row'>
                      <th className='col-sm-4'>Common information</th>
                      <th className='col-sm-3'>Current meta data</th>
                      <th className='col-sm-4'>Asset data</th>
                      <th className='col-sm-1'>Actions</th>
                    </tr>
                  </thead>
                  <tbody style={{ overflow: "scroll", height: "600px" }} key='body-2'>
                    {spentDataList}
                  </tbody>
                </Table>
              </CardBody>
            </Card>
          </Col>

        </Row>

        {/* divide modal */}
        <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className}>
          <ModalHeader toggle={this.toggle}>Amount: {outputState.amount || ''}</ModalHeader>
          <ModalBody>
            <Card className="height-100">
              <CardHeader>
                <Label className="float-left">Divisible name</Label>
                <Label className="float-right" style={{ width: "50%" }}>Amount to send</Label>
              </CardHeader>
              <CardBody>
                <FormGroup row>
                  <Label for="canned" sm='5'>Canned</Label>
                  <Col sm={7}>
                    <Input
                      type="text"
                      id="canned"
                      name="canned"
                      autoComplete="canned"
                      value={amountToSend.canned}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="sausage" sm='5'>Sausage</Label>
                  <Col sm={7}>
                    <Input
                      type="text"
                      id="sausage"
                      name="sausage"
                      autoComplete="sausage"
                      value={amountToSend.sausage}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="meat" sm='5'>Meat</Label>
                  <Col sm={7}>
                    <Input
                      type="text"
                      id="meat"
                      name="meat"
                      autoComplete="meat"
                      value={amountToSend.meat}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
              </CardBody>
            </Card>
            <Card className="height-100">
              <CardHeader>
                <Label className="float-left">Divisible content</Label>
              </CardHeader>
              <CardBody>
                <FormGroup row>
                  <Label for="supplierType" sm='6'>Supplier Type:</Label>
                  <Col sm={6}>
                    <Input
                      type="select"
                      id="supplierType"
                      name="supplierType"
                      value={updateContent.supplierType}
                      onChange={this.handleOnChange}>
                      <option value='Producer'>Producer</option>
                      <option value='Farmer'>Farmer</option>
                      <option value='Distributor'>Distributor</option>
                      <option value='Retailer'>Retailer</option>
                    </Input>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="name" sm='6'>Name</Label>
                  <Col sm={6}>
                    <Input
                      type="text"
                      id="name"
                      name="name"
                      autoComplete="name"
                      value={updateContent.name}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
                <FormGroup row>

                  <Col sm={12}>
                    <Card>
                      <CardHeader>
                        Detail
                        <Button color="primary" style={{ float: 'right' }} onClick={this.handleOnAddField}>Add field</Button>
                      </CardHeader>
                      <CardBody>
                        {this.formatRender()}
                      </CardBody>
                    </Card>
                  </Col>
                </FormGroup>
                <FormGroup row>
                  <Label for="note" sm='6'>Note Action</Label>
                  <Col sm={6}>
                    <Input
                      type="text"
                      id="note"
                      name="note"
                      autoComplete="note"
                      value={updateContent.note}
                      onChange={this.handleOnChange} />
                  </Col>
                </FormGroup>
              </CardBody>
            </Card>
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.handleAddDivisible}>Divide</Button>{' '}
            <Button color="secondary" onClick={this.toggle}>Cancel</Button>
          </ModalFooter>
        </Modal>

        {/* addMeta modal */}
        <Modal isOpen={this.state.addMetaModal} toggle={this.toggleAddMeta} className={this.props.className}>
          <ModalHeader>Amount: {outputState.amount || ''} </ModalHeader>
          <ModalBody>
            <AddMeta output={this.state.outputState}
              isPassData={this.state.isPassData}
              reload={this.loadInitData}
              toggleMeta={this.toggleAddMeta}
              isOpenMetaForm={this.state.addMetaModal}
            />
          </ModalBody>
        </Modal>

        {/* transfer modal */}
        <TransactionModal
          transactionId={this.state.outputState.transaction_id}
          amount={this.state.outputState.amount}
          toggle={this.toggleTransaction}
          isOpenModal={this.state.isOpenTrans}
          currentIdentity={this.state.currentIdentity}
          handleOnChangeTrans={this.handleOnChangeTrans}
          reload={this.loadInitData}
          personIdentity={'Producer'}
          outputIndex={this.state.outputState.output_index}
        />

        {/* history modal */}
        <Modal isOpen={this.state.isOpenHistory} toggle={this.toggleHistory} className={this.props.className}>
          <ModalHeader>History View</ModalHeader>
          <ModalBody>
            <History
              historyData={this.state.history}
            />
          </ModalBody>
          <ModalFooter>
            <Button color="primary" onClick={this.toggleHistory}>Ok</Button>
          </ModalFooter>
        </Modal>
      </div>
    );
  }
}

export default Producer;
