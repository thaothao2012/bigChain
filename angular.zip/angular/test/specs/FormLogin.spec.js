// import FormLogin from '../BaseTest/FormLogin.page';
// import chai from 'chai';
//
// describe('Test Login', function () {
//
//     beforeEach(() => {
//         FormLogin.open();
//         // FormLogin.waitForLandingPageToLoad();
//     })
//
//      it('should login error', function () {
//          FormLogin.setUsername("username")
//          FormLogin.setPassword("password")
//          FormLogin.submitForm();
//          // FormLogin.debugBrowser();
//          FormLogin.getAlertText().should.to.equal('Your username or password is invalid. Please try again.');
//      });
//
//
//        it('should username not fill input ', function () {
//            FormLogin.setUsername("")
//            FormLogin.setPassword("password")
//            FormLogin.submitForm();
//            FormLogin.getAlertText().should.to.equal('Email is required. Please enter Email.');
//        });
//
//
//     it('should pass and then redirect user', function () {
//         FormLogin.setUsername("yec14882@nbzmr.com");
//         FormLogin.setPassword("yec14882@nbzmr.com");
//         FormLogin.submitForm();
//         FormLogin.waitForSidebarPageToLoad();
//         // FormLogin.getUrl().should.to.equal('/users');
//         FormLogin.debugBrowser();
//         // FormLogin.browserBack();
//         // FormLogin.getValueImages().should.to.have.lengthOf(2);
//     });
//
//
//
// });