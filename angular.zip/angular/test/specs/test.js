var webdriverio = require('webdriverio');
var options = {
    desiredCapabilities: {
        browserName: 'chrome'
    }
};

describe('Test google', function () {

    beforeEach(() => {
        browser.url("https://www.google.com.vn");
    })

    it('should render without errors', function () {
        browser.debug()
    });

});
