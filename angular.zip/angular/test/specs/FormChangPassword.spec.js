// import FormChangePassword from '../BaseTest/FormChangePassword.page';
//
// describe('Test change password', function () {
//
//     beforeEach(() => {
//         // FormLogin.waitForLandingPageToLoad();
//     })
//
//     it('should change password success', function () {
//         FormChangePassword.open();
//         FormChangePassword.ChangePasswordFormSuccess('yec14882@nbzmr.com','yec14882@nbzmr.com','12345678x@X');
//         FormChangePassword.waitForForm('#password')
//         FormChangePassword.LoginFormSuccess('yec14882@nbzmr.com','12345678x@X');
//         FormChangePassword.waitSubtitlePageToLoad()
//         FormChangePassword.open();
//         FormChangePassword.ChangePasswordFormSuccess('yec14882@nbzmr.com','12345678x@X','123456789x@X');
//         FormChangePassword.open();
//         FormChangePassword.ChangePasswordFormSuccess('yec14882@nbzmr.com','123456789x@X','12345678910x@X');
//         FormChangePassword.open();
//         FormChangePassword.ChangePasswordFormSuccess('yec14882@nbzmr.com','12345678910x@X','yec14882@nbzmr.com');
//     });
//
//     it('should Confirmed password and password are not matched. is required.', function () {
//         FormChangePassword.open();
//         FormChangePassword.setCurrentPassword("yec14882@nbzmr.com");
//         FormChangePassword.setNewPassword("passNoMatch");
//         FormChangePassword.setConfirmPassword("pass");
//         FormChangePassword.submitForm();
//         FormChangePassword.getAlertTextError().should.to.equal('Confirmed password and password are not matched. is required. Please enter Confirmed password and password are not matched..');
//     });
//
//     it('should Password is required.', function () {
//         FormChangePassword.open();
//         FormChangePassword.setNewPassword("passNoMatch");
//         FormChangePassword.setConfirmPassword("pass");
//         FormChangePassword.submitForm();
//         FormChangePassword.getAlertTextError().should.to.equal('Password is required. Please enter Password.');
//     });
// });
