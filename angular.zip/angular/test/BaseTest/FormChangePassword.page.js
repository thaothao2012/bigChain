import Page from './Page';

class FormChangePassword extends Page {

    get subtitle() {
        return browser.element('.subtitle');
    }

    open = () => {
        browser.url("/change-password")
    }

    waitSubtitlePageToLoad = () => {
        if (!this.subtitle.isVisible()) {
            this.subtitle.waitForText(2000);
        }
    }


    setCurrentPassword = (value) => {
        $('#currentPassword').setValue(value);
    }

    setUsername = (value) => {
        $('#userName').setValue(value);
    }

    setNewPassword = (value) => {
        $('#newPassword').setValue(value);
    }

    setConfirmPassword = (value) => {
        $('#confirmPassword').setValue(value);
    }
    // ====form login
    setUsername = (value) => {
        $('#userName').setValue(value);
    }

    setPassword = (value) => {
        $('#password').setValue(value);
    }

    submitFormLogin = () => {
        $('[name="login"]').click();
    }
    // ====form login

    submitForm = () => {
        $('#btnChangePassword').click();
    }

    LoginFormSuccess = (username, password) => {
        super.open('/signin');
        this.setUsername(username);
        this.setPassword(password);
        $('[name="login"]').click();
    }

    ChangePasswordFormSuccess = (username, currentPassword, newPassword) => {
        this.setUsername(username);
        this.setCurrentPassword(currentPassword);
        this.setNewPassword(newPassword);
        this.setConfirmPassword(newPassword);
        this.submitForm();
        this.waitForForm('.alert-info')
        this.getAlertTextInfo().should.to.equal('You have changed your password successfully. You need to log out and login again by the new password.');
    }

}

export default new FormChangePassword();
