import Page from './Page';

class FormLogin extends Page {

    get loaderWrapper() {
        return browser.element('.authentication');
    }

    get sidebar() {
        return browser.element('.sidebar');
    }

    open = () => {
        super.open('/signin');
    }

    waitForLandingPageToLoad = () => {
        if (!this.loaderWrapper.isVisible()) {
            this.loaderWrapper.waitForVisible(2000);
        }
    }

    waitForSidebarPageToLoad = () => {
        if (!this.sidebar.isVisible()) {
            this.sidebar.waitForVisible(2000);
        }
    }

    getAlertText = () => {
        return browser.getText('.alert-danger');
    }

    setUsername = (value) => {
        $('#userName').setValue(value);
    }

    setPassword = (value) => {
        $('#password').setValue(value);
    }

    submitForm = () => {
        $('[name="login"]').click();
    }

    debugBrowser = () => {
        return browser.debug();
    }
    browserBack = () => {
        return browser.back();
    }

}

export default new FormLogin();
