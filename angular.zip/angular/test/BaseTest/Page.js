export default class Page {
    open(path) {
        browser.url(path)
    }

    waitForForm = (name, time) => {
        if (!browser.element(name).isVisible()) {
            browser.element(name).waitForVisible(time);
        }
    }

    isExisting = (name) => {
        return browser.isExisting(name);
    }

    clickBack = () => {
        browser.element('.NavigationBar-back img').click();
    }

    clickNext = () => {
        browser.element('.right-img-frame img').click();
    }

    debugBrowser = () => {
        return browser.debug();
    }

    browserBack = () => {
        return browser.back();
    }

    getUrl = () => {
        var url = browser.getUrl();
        return url;
    }

    getAlertTextInfo = () => {
        return browser.getText('.alert-info');
    }

    getAlertTextError = () => {
        return browser.getText('.alert-danger');
    }

}