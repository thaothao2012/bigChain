import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {PayeeComponent} from './component/payee.component';
import {PayeesComponent} from './component/payees.component';
import {PayerComponent} from './component/payer.component';
import {PayersComponent} from './component/payers.component';
import {SetupModuleComponent} from './setup.module.component';
import { BanksComponent } from './component/banks.component';
import { BankComponent } from './component/bank.component';
import { PaymentAccount } from './model/PaymentAccount';
import { PaymentAccountsComponent } from './component/payment-accounts';

const setupRoutes: Routes = [
  {
    path: '',
    component: SetupModuleComponent,
    children: [
      { path: 'payer/search', component: PayersComponent },
      { path: 'payer/add', component: PayerComponent },
      { path: 'payer/:id', component: PayerComponent },
      { path: 'payee/search', component: PayeesComponent },
      { path: 'payee/add', component: PayeeComponent },
      { path: 'payee/:id', component: PayeeComponent },
      { path: 'payee/:id', component: PayeeComponent },
      { path: 'bank/search', component: BanksComponent },
      { path: 'bank/add', component: BankComponent },
      { path: 'bank/:id', component: BankComponent },
      { path: 'paymentAccount/search', component: PaymentAccountsComponent },
      // { path: 'paymentAccount/add', component: BankComponent },
      // { path: 'paymentAccount/:id', component: BankComponent }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(setupRoutes)
  ],
  declarations: [

  ],
  exports: [
    RouterModule,
  ]
})

export class SetupRoutingModule {
}
