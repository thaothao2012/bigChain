import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchComponent } from '../../core';
import { PaymentAccount } from '../model/PaymentAccount';
import { PaymentAccountSM } from '../search-model/PaymentAccountSM';
import { PaymentAccountServiceImpl } from '../service/impl/PaymentAccountServiceImpl';

@Component({
  selector: 'app-paymentAccount-list',
  templateUrl: '../view/paymentAccounts.html',
  providers: [PaymentAccountServiceImpl]
})
export class PaymentAccountsComponent extends SearchComponent<PaymentAccount, PaymentAccountSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, paymentAccountService: PaymentAccountServiceImpl) {
    super(viewContainerRef, router, route, paymentAccountService);
    this.checkedCtrl = [];
  }
  protected ctrlStatuslist = [
    {
      value: 'P',
      text: 'Pending',
    },
    {
      value: 'A',
      text: 'Approved',
    },
    {
      value: 'R',
      text: 'Rejected',
    }
  ];
  checkedCtrl: string[] = [];

  updateChecked(value, event, field, checkedList, model) {
    if (model[field] !== null && model[field] !== undefined) {
      checkedList = model[field];
    }
    if (event.target.checked) {
      checkedList.push(value);
    } else {
      for (let i = 0; i < checkedList.length; i++) {
        if (checkedList[i] === value) {
          checkedList.splice(i, 1);
        }
      }
    }
    model[field] = checkedList;
    console.log(field + 'Checked', model[field]);
  }
  isChecked(checkedList, value): boolean {
    if (checkedList === null || checkedList === undefined) {
      return false;
    }
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i] === value) {
        return true;
      }
    }
    return false;
  }
  formatResults(results: any[]) {
    for (const result of results ) {
      if (result.ctrlStatus) {
        const v = result.ctrlStatus;
        if (v === 'A') {
          result.ctrlStatusName = 'Approved';
        } else if (v === 'R') {
          result.ctrlStatusName = 'Rejected';
        } else if (v === 'P') {
          result.ctrlStatusName = 'Pending';
        }
      }
      if (result.actionStatus) {
        const v = result.actionStatus;
        if (v === 'C') {
          result.actionStatus = 'Created';
        } else if (v === 'U') {
          result.actionStatus = 'Updated';
        } else {
          result.actionStatus = 'Deleted';
        }
      }
    }
  }

  formatSearchModel(obj) {
    const objs = Object.keys(obj);
    for (const o of objs) {
      obj[o] = null;
    }
    obj.entityType = 'E';
    super.formatSearchModel(obj);
  }

  viewPaymentAccount(id) {
    this.navigate('setup/paymentAccount', [id]);
  }

  addPaymentAccount() {
    this.navigate('setup/paymentAccount/add');
  }
}
