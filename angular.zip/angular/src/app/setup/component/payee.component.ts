import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {EditComponent, ReflectionUtil, StringUtil} from '../../core';
import {Payee} from '../model/Payee';
import {Payer} from '../model/Payer';
import {PayeeServiceImpl} from '../service/impl/PayeeServiceImpl';
import {PayerServiceImpl} from '../service/impl/payerServiceImpl';

@Component({
  selector: 'app-payee-detail',
  templateUrl: '../view/payee.html',
  providers: [PayeeServiceImpl]
})
export class PayeeComponent extends EditComponent<Payee> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, payeeServiceImpl: PayeeServiceImpl) {
    super(viewContainerRef, router, route, payeeServiceImpl);
  }

  protected payee: Payee;
  public getModel(): Payee {
    this.payee.maxAtmPtrn = Number(this.formatNumber(this.payee.maxAtmPtrn));
    const obj = ReflectionUtil.clone(this.payee);
    // this.jsonEntity(obj);
    return obj;
  }

  formatNumber(v: any) {
    const c = v.replace(',', '');
    return c;
  }

  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }
  onChangRadio(event) {
    if (event.target.checked) {
      this.payee.businessType = event.target.value;
    }
  }
  public setModel(obj: Payee) {
    obj.mobilePhone = StringUtil.formatPhone(obj.mobilePhone);
    obj.faxNo = StringUtil.formatFax(obj.faxNo);
    obj.contactNo = StringUtil.formatPhone(obj.contactNo);
    obj.maxAtmPtrn = StringUtil.formatCurrency(obj.maxAtmPtrn);
    this.payee = obj;
    if (this.isNewMode()) {
      this.payee.entityType = 'E';
    }
  }
  onChangEntityType(event) {
    if (event.target.checked) {
      this.payee.entityType = 'R';
    } else {
      this.payee.entityType = 'E';
    }
  }
}
