import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {EditComponent, ReflectionUtil, StringUtil} from '../../core';
import { BankServiceImpl } from '../service/impl/BankServiceImpl';
import { Bank } from '../model/Bank';
import { BranchServiceImpl } from '../service/impl/BranchServiceImpl';

@Component({
  selector: 'app-bank-detail',
  templateUrl: '../view/bank.html',
  providers: [BankServiceImpl, BranchServiceImpl]
})
export class BankComponent extends EditComponent<Bank> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, bankServiceImpl: BankServiceImpl, private branchServiceImpl: BranchServiceImpl) {
    super(viewContainerRef, router, route, bankServiceImpl);
  }
  protected branches: any = [];

  protected initData(){
    this.branchServiceImpl.getAll().subscribe(result => {
      this.branches = result;
      super.initData();
    });
  }

  protected bank: Bank;

  public getModel(): Bank {
    const obj = ReflectionUtil.clone(this.bank);
    // this.jsonEntity(obj);
    return obj;
  }
  public setModel(obj: Bank) {
    obj.faxNo = StringUtil.formatFax(obj.faxNo);
    obj.contactNo = StringUtil.formatPhone(obj.contactNo);
    this.bank = obj;
  }

  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }
}
