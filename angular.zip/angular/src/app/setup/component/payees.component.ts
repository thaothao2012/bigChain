import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchComponent } from '../../core';
import {Payee} from '../model/Payee';
import {Payer} from '../model/Payer';
import {PayeeSM} from '../search-model/PayeeSM';
import {PayerSM} from '../search-model/PayerSM';
import {PayeeServiceImpl} from '../service/impl/PayeeServiceImpl';
import {PayerServiceImpl} from '../service/impl/payerServiceImpl';

@Component({
  selector: 'app-payer-list',
  templateUrl: '../view/payees.html',
  providers: [PayerServiceImpl]
})
export class PayeesComponent extends SearchComponent<Payee, PayeeSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, payeeService: PayeeServiceImpl) {
    super(viewContainerRef, router, route, payeeService);
    this.checkedCtrl = [];
  }
  protected ctrlStatuslist = [
    {
      value: 'P',
      text: 'Pending',
    },
    {
      value: 'A',
      text: 'Approved',
    },
    {
      value: 'R',
      text: 'Rejected',
    }
  ];
  checkedCtrl: string[] = [];

  updateChecked(value, event, field, checkedList, model) {
    if (model[field] !== null && model[field] !== undefined) {
      checkedList = model[field];
    }
    if (event.target.checked) {
      checkedList.push(value);
    } else {
      for (let i = 0; i < checkedList.length; i++) {
        if (checkedList[i] === value) {
          checkedList.splice(i, 1);
        }
      }
    }
    model[field] = checkedList;
    console.log(field + 'Checked', model[field]);
  }
  isChecked(checkedList, value): boolean {
    if (checkedList === null || checkedList === undefined) {
      return false;
    }
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i] === value) {
        return true;
      }
    }
    return false;
  }
  formatResults(results: any[]) {
    for (const result of results ) {
      if (result.ctrlStatus) {
        const v = result.ctrlStatus;
        if (v === 'A') {
          result.ctrlStatusName = 'Approved';
        } else if (v === 'R') {
          result.ctrlStatusName = 'Rejected';
        } else if (v === 'P') {
          result.ctrlStatusName = 'Pending';
        }
      }
      if (result.actionStatus) {
        const v = result.actionStatus;
        if (v === 'C') {
          result.actionStatus = 'Created';
        } else if (v === 'U') {
          result.actionStatus = 'Updated';
        } else {
          result.actionStatus = 'Deleted';
        }
      }
    }
  }

  formatSearchModel(obj) {
    const objs = Object.keys(obj);
    for (const o of objs) {
      obj[o] = null;
    }
    obj.entityType = 'E';
    super.formatSearchModel(obj);
  }

  viewUser(id) {
    this.navigate('setup/payee', [id]);
  }

  addUser() {
    this.navigate('setup/payee/add');
  }
}
