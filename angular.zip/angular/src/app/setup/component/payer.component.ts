import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {EditComponent, ReflectionUtil, StringUtil} from '../../core';
import {Payer} from '../model/Payer';
import {PayerServiceImpl} from '../service/impl/payerServiceImpl';

@Component({
  selector: 'app-payer-detail',
  templateUrl: '../view/payer.html',
  providers: [PayerServiceImpl]
})
export class PayerComponent extends EditComponent<Payer> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, payerServiceImpl: PayerServiceImpl) {
    super(viewContainerRef, router, route, payerServiceImpl);
  }

  protected payer: Payer;
  public getModel(): Payer {
    const obj = ReflectionUtil.clone(this.payer);
    // this.jsonEntity(obj);
    return obj;
  }


  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: Payer) {
    obj.mobilePhone = StringUtil.formatPhone(obj.mobilePhone);
    obj.faxNo = StringUtil.formatFax(obj.faxNo);
    obj.contactNo = StringUtil.formatPhone(obj.contactNo);
    obj.maxAtmPtrn = StringUtil.formatCurrency(obj.maxAtmPtrn);
    this.payer = obj;
    if (this.isNewMode()) {
      this.payer.entityType = 'R';
      this.payer.pymtAccCtl = false;
    }
  }
  onChangRadio(event) {
    if (event.target.checked) {
      this.payer.paymentConfirm = event.target.value;
    }
  }
  onChangePymtAccCtl(event) {
    if (event.target.checked) {
      this.payer.pymtAccCtl = true;
    } else {
      this.payer.pymtAccCtl = false;
    }
  }
  onChangEntityType(event) {
    if (event.target.checked) {
      this.payer.entityType = 'E';
    } else {
      this.payer.entityType = 'R';
    }
  }
}
