import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchComponent } from '../../core';
import { BankServiceImpl } from '../service/impl/BankServiceImpl';
import { Bank } from '../model/Bank';
import { BankSM } from '../search-model/BankSM';

@Component({
  selector: 'app-bank-list',
  templateUrl: '../view/banks.html',
  providers: [BankServiceImpl]
})
export class BanksComponent extends SearchComponent<Bank, BankSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, bankService: BankServiceImpl) {
    super(viewContainerRef, router, route, bankService);
  }

  viewBank(id) {
    this.navigate('setup/bank', [id]);
  }

  addBank() {
    this.navigate('setup/bank/add');
  }
}
