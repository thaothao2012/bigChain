import { GenericSearchService } from '../../common/service/GenericSearchService';
import {Payee} from '../model/Payee';
import {PayeeSM} from '../search-model/PayeeSM';

export interface PayeeService extends GenericSearchService<Payee, PayeeSM> {
}
