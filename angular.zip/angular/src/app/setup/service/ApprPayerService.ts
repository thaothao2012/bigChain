import { Observable } from 'rxjs';
import { ViewSearchService } from '../../core';
import { Payer } from '../model/Payer';
import { PayerSM } from '../search-model/PayerSM';

export interface ApprPayerService extends ViewSearchService<Payer, PayerSM> {
  getByKeyWords(keyWords: string): Observable<Payer[]>;
}

