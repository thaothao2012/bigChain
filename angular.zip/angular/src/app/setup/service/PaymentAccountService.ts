import { GenericSearchService } from '../../common/service/GenericSearchService';
import { PaymentAccount } from '../model/PaymentAccount';
import { PaymentAccountSM } from '../search-model/PaymentAccountSM';

export interface PaymentAccountService extends GenericSearchService<PaymentAccount, PaymentAccountSM> {
}
