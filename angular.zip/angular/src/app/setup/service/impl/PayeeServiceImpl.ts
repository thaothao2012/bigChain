import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import {payeeModel} from '../../metadata/PayeeModel';
import {Payee} from '../../model/Payee';
import {PayeeSM} from '../../search-model/PayeeSM';
import {PayeeService} from '../payeeService';

@Injectable()
export class PayeeServiceImpl extends GenericSearchWebService<Payee, PayeeSM> implements PayeeService {
  constructor(http: HttpClient) {
    super(http, config.setupPayeeUrl, payeeModel);
  }
}
