import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import { PaymentAccount } from '../../model/PaymentAccount';
import { PaymentAccountSM } from '../../search-model/PaymentAccountSM';
import { PaymentAccountService } from '../PaymentAccountService';
import { paymentAccountModel } from '../../metadata/PaymentAccountModel';

@Injectable()
export class PaymentAccountServiceImpl extends GenericSearchWebService<PaymentAccount, PaymentAccountSM> implements PaymentAccountService {
  constructor(http: HttpClient) {
    super(http, config.setupPaymentAccountUrl, paymentAccountModel);
  }
}
