import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import config from '../../../../config';
import {GenericSearchWebService} from '../../../core';
import { WebClientUtil } from '../../../core';
import { payerModel } from '../../metadata/PayerModel';
import { Payer } from '../../model/Payer';
import { PayerSM } from '../../search-model/PayerSM';
import { ApprPayerService } from '../ApprPayerService';

@Injectable()
export class ApprPayerServiceImpl extends GenericSearchWebService<Payer, PayerSM> implements ApprPayerService {
  constructor(http: HttpClient) {
    super(http, config.backOfficeUrl + 'common/resources/profile/payers', payerModel);
  }

  getByKeyWords(keyWords: string): Observable<Payer[]> {
    const url = this.serviceUrl + '/' + keyWords;
    // @ts-ignore
    return WebClientUtil.get(url)
      .pipe(map((res: any) => this.formatObjects(res)));
  }
}
