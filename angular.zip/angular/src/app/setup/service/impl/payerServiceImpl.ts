import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import {payerModel} from '../../metadata/PayerModel';
import {Payer} from '../../model/Payer';
import {PayerSM} from '../../search-model/PayerSM';
import {PayerService} from '../payerService';

@Injectable()
export class PayerServiceImpl extends GenericSearchWebService<Payer, PayerSM> implements PayerService {
  constructor(http: HttpClient) {
    super(http, config.setupPayerUrl, payerModel);
  }
}
