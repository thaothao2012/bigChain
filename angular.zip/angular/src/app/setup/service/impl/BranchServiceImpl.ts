import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import { Branch } from '../../model/Branch';
import { BranchSM } from '../../search-model/BranchSM';
import { BranchService } from '../BranchService';
import { branchModel } from '../../metadata/BranchModel';

@Injectable()
export class BranchServiceImpl extends GenericSearchWebService<Branch, BranchSM> implements BranchService {
  constructor(http: HttpClient) {
    super(http, config.setupBranchUrl, branchModel);
  }
}
