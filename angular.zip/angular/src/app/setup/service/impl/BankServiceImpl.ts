import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import { Bank } from '../../model/Bank';
import { BankSM } from '../../search-model/BankSM';
import { BankService } from '../bankService';
import { bankModel } from '../../metadata/BankModel';

@Injectable()
export class BankServiceImpl extends GenericSearchWebService<Bank, BankSM> implements BankService {
  constructor(http: HttpClient) {
    super(http, config.setupBankUrl, bankModel);
  }
}
