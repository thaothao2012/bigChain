import { GenericSearchService } from '../../common/service/GenericSearchService';
import { Bank } from '../model/Bank';
import { BankSM } from '../search-model/BankSM';

export interface BankService extends GenericSearchService<Bank, BankSM> {
}
