import { GenericSearchService } from '../../common/service/GenericSearchService';
import {Branch} from '../model/Branch';
import {BranchSM} from '../search-model/BranchSM';

export interface BranchService extends GenericSearchService<Branch, BranchSM> {
}
