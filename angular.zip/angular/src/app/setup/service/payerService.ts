import { GenericSearchService } from '../../common/service/GenericSearchService';
import {Payer} from '../model/Payer';
import {PayerSM} from '../search-model/PayerSM';

export interface PayerService extends GenericSearchService<Payer, PayerSM> {
}
