import {ControlSearchModel} from './ControlSearchModel';

export interface BranchSM extends ControlSearchModel {
  branchId: string;
}
