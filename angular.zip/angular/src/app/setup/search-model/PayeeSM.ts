import {ControlSearchModel} from './ControlSearchModel';

export interface PayeeSM extends ControlSearchModel {
  entityType: string;
  entityName: string;
}
