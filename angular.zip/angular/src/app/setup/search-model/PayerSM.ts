import {ControlSearchModel} from './ControlSearchModel';

export interface PayerSM extends ControlSearchModel {
  entityType: string;
  entityName: string;
}
