import {SearchModel} from '../../core';

export interface BankSM extends SearchModel {
  bankName: string;
  bankShortName: string;
}
