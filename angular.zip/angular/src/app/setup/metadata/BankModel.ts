import {DataType, Model} from '../../core';

export const bankModel: Model = {
  name: 'bank',
  attributes: {
    bankId: {
      type: DataType.String,
      primaryKey: true
    }
  }
};
