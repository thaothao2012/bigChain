import {DataType, Model} from '../../core';

export const branchModel: Model = {
  name: 'branch',
  attributes: {
    branchId: {
      type: DataType.String,
      length: 45,
      primaryKey: true
    },
    clZoneNo: {
      type: DataType.String,
      length: 45,
    },
    brZoneNo: {
      type: DataType.String,
      length: 45,
    },
    brNameEng: {
      type: DataType.String ,
      length: 45
    },
    brNameTh: {
      type: DataType.String,
      length: 45
    },
  }
};
