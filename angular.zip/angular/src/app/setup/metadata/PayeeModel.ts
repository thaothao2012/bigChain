import {DataType, Model} from '../../core';

export const payeeModel: Model = {
  name: 'payee',
  attributes: {
    entityId: {
      type: DataType.String,
      primaryKey: true
    },
    entityType: {
      type: DataType.String,
      length: 255,
      nullable: true
    },
    entityName: {
      type: DataType.String,
      length: 255
    },
    shortName: {
      type: DataType.String,
      length: 12
    },
    add1: {
      type: DataType.String,
    },
    add2: {
      type: DataType.String
    },
    add3: {
      type: DataType.String,
      length: 255
    },
    postalCode: {
      type: DataType.String,
      length: 20
    },
    stateName: {
      type: DataType.String,
      length: 20
    },
    countryCode: {
      type: DataType.String,
      length: 20
    },
    contactName: {
      type: DataType.String,
      length: 20
    },
    contactNo: {
      type: DataType.String,
      length: 20
    },
    faxNo: {
      type: DataType.String,
      length: 20
    },
    mobilePhone: {
      type: DataType.String,
      length: 20
    },
    emailAdd: {
      type: DataType.String,
      length: 20
    },
    authMethod: {
      type: DataType.String,
      length: 1
    },
    businessType: {
      type: DataType.String,
      length: 4
    },
    maxAtmPtrn: {
      type: DataType.Integer,
      length: 15
    },
    webConfirmation: {
      type: DataType.Integer
    },
    ctrlStatus: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    actionStatus: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    actedBy: {
      type: DataType.String,
      length: 50,
      nullable: true
    }
  }
};
