import {DataType, Model} from '../../core';

export const paymentAccountModel: Model = {
  name: 'paymentAccount',
  attributes: {
    bankId: {
      type: DataType.String,
      length: 50,
      primaryKey: true
    },
    entityId: {
      type: DataType.String,
      length: 50,
      primaryKey: true
    },
    accNo: {
      type: DataType.String,
      length: 50,
      primaryKey: true
    },
    profile: {
      type: DataType.Object,
      length: 25
    },
    bank: {
      type: DataType.Object,
    },
    accountCurrency: {
      type: DataType.String,
      length: 255
    },
    accountName: {
      type: DataType.String,
      length: 255
    },
    defaultAccount: {
      type: DataType.Bool,
      length: 20
    },
    nightMode: {
      type: DataType.String,
      length: 1
    }
  }
};
