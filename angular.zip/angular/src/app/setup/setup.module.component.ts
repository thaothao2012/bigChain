import {Component} from '@angular/core';

@Component({
  selector: 'app-setup-module',
  template: '<router-outlet></router-outlet>'
})

export class SetupModuleComponent {
  constructor() {
  }
}
