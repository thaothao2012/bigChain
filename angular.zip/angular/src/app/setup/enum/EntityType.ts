export enum EntityType {
  Bank= 'B',
  Payee = 'E',
  Payer = 'R',
  DynamicForm = 'dynamicForm'
}
