export enum AccType {
  Receivable = 'R',
  Payable = 'O'
}
