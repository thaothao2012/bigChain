import {CtrlStatus} from '../enum/CtrlStatus';

export class ControlModel {
  actedBy: string;
  actionStatus: string;
  ctrlStatus?: CtrlStatus;
  actionDate: Date;
}
