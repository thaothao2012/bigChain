import {ControlModel} from './ControlModel';

export class Branch extends ControlModel {
  branchId: string;
  clZoneNo: string;
  brZoneNo: string;
  brNameEng: string;
  brNameTh: string;
}
