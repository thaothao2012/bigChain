import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BsDatepickerModule} from 'ngx-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import {TimepickerModule } from 'ngx-bootstrap/timepicker';
import {PayeeComponent} from './component/payee.component';
import {PayeesComponent} from './component/payees.component';
import {PayerComponent} from './component/payer.component';
import {PayersComponent} from './component/payers.component';
import {PayeeServiceImpl} from './service/impl/PayeeServiceImpl';
import {PayerServiceImpl} from './service/impl/payerServiceImpl';
import {SetupRoutingModule} from './setup-routing.module';
import {SetupModuleComponent} from './setup.module.component';
import { BanksComponent } from './component/banks.component';
import { BankServiceImpl } from './service/impl/BankServiceImpl';
import { BankComponent } from './component/bank.component';
import { PaymentAccountsComponent } from './component/payment-accounts';
import { PaymentAccountServiceImpl } from './service/impl/PaymentAccountServiceImpl';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SetupRoutingModule,
    ReactiveFormsModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot()
  ],
  declarations: [
    SetupModuleComponent,
    PayersComponent,
    PayerComponent,
    PayeesComponent,
    PayeeComponent,
    BanksComponent,
    BankComponent,
    PaymentAccountsComponent
  ],
  entryComponents: [

  ],
  providers: [
    PayerServiceImpl,
    PayeeServiceImpl,
    BankServiceImpl,
    PaymentAccountServiceImpl
  ]
})

export class SetupModule {
}
