import {EventEmitter, Injectable} from '@angular/core';
import {BsModalRef, BsModalService, ComponentLoaderFactory, PositioningService} from 'ngx-bootstrap';

@Injectable()
export class PopupComponentService {
  bsModalRef: BsModalRef;

  constructor (
    private bsModalService: BsModalService,
  ) {
  }

  show(conponent: any, item: any) {
    const initialState = { data: Object.assign({}, item)};
    return this.bsModalService.show(conponent, {
      initialState,
      class: 'modal-dialog-centered modal-dialog-log'
    });
  }
}

export const DependenciesServiceProviders = [PopupComponentService, BsModalService, ComponentLoaderFactory, PositioningService];
