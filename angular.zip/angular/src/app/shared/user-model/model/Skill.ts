export class Skill {
  skill: string;
  hirable: boolean;
}
