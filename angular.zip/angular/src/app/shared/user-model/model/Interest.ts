export class Interest {
  subject: string;
  status: string;
}
