export class Achievement {
  subject: string;
  description: string;
  highlight: boolean;
  status: string;
}
