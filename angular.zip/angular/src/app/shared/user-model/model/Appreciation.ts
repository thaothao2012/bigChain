export class Appreciation {
  appreciator: string;
  appreciatedTime: Date;
  subject: string;
  description: string;
  status: string;
}
