export enum UserStatus {
  Registered = 'R',
  Activated = 'A',
  Deactivated = 'D',
  Blocked = 'B'
}
