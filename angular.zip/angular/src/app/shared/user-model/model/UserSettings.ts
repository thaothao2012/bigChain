export class UserSettings {
  constructor(
    public userId?: string,
    public defaultLanguage?: string,
    public dateFormat?: string,
    public dateTimeFormat?: string,
    public timeFormat?: string,
    public notification = false,
    public searchEnginesLinksToMyProfile = false,
    public emailFeedUpdates = false,
    public notifyFeedUpdates = false,
    public emailPostMentions = false,
    public notifyPostMentions = false,
    public emailCommentsOfYourPosts = false,
    public notifyCommentsOfYourPosts = false,
    public emailEventInvitations = false,
    public notifyEventInvitations = false,
    public emailWhenNewEventsAround = false,
    public notifyWhenNewEventsAround = false,
  ) {}
}
