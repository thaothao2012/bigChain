import {DataType, Model} from '../../../core';

export const userModel: Model = {
  name: 'user',
  attributes: {
    userId: {
      type: DataType.String,
      primaryKey: true
    },
    userName: {
      type: DataType.String,
      length: 255,
      nullable: true
    },
    firstName: {
      type: DataType.String ,
      length: 255
    },
    lastName: {
      type: DataType.String,
      length: 255
    },
    gender: {
      type: DataType.String,
      length: 1
    },
    dateOfBirth: {
      type: DataType.DateTime
    },
    email: {
      type: DataType.String,
      length: 255
    },
    phone: {
      type: DataType.String,
      length: 20
    },
    createdDate: {
      type: DataType.DateTime,
      updatable: false
    },
    modifiedDate: {
      type: DataType.DateTime
    }
  }
};
