import {Observable} from 'rxjs';

export interface SignoutService {
  signout(userName: string): Observable<boolean>;
}
