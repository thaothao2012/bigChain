import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import config from '../../../../../config';
import {storage, WebClientUtil} from '../../../../core';
import {SignoutService} from '../SignoutService';

export class SignoutServiceImpl implements SignoutService {
  constructor(private http: HttpClient) {
  }

  signout(userName: string): Observable<boolean> {
    const url = config.authenticationServiceUrl + '/authentication/signout/' + userName;
    return WebClientUtil.get(this.http, url).pipe(map((success: any) => {
      if (success) {
        sessionStorage.setItem('authService', null);
        sessionStorage.clear();
        storage.setUser(null);
      }
      return success;
    }));
  }
}
