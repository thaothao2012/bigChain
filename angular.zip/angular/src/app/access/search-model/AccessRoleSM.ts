import {ControlSearchModel} from './ControlSearchModel';

export interface AccessRoleSM extends ControlSearchModel {
  userType: string;
  role_name: string;
}
