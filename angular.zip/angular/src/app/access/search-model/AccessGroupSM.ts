import { ControlSearchModel } from './ControlSearchModel';

export interface AccessGroupSM extends ControlSearchModel {
  entityType: string;
  groupId: string;
}
