import {DataType, Model} from '../../core';
import {AccessModule1} from '../model/AccessModule';
import { BankAdmin } from '../model/BankAdmin';

export const accessRoleModel: Model = {
  name: 'accessRole',
  attributes: {
    roleId: {
      type: DataType.String,
      primaryKey: true
    },
    cId: {
      type: DataType.String,
      primaryKey: true
    },
    roleDesc: {
      type: DataType.String,
      length: 255,
      nullable: true
    },
    role_name: {
      type: DataType.String ,
      length: 255
    },
    userType: {
      type: DataType.String,
      length: 2
    },
    evUserReg: {
      type: DataType.String,
      length: 1
    },
    evUserRegBank: {
      type: DataType.String,
      length: 1
    },
    evResetPwdBank: {
      type: DataType.String,
      length: 1
    },
    evResetPwdNonBank: {
      type: DataType.String,
      length: 1
    },
    evActivate: {
      type: DataType.String,
      length: 1
    },
    actedBy: {
      type: DataType.String,
      length: 50
    },
    ctrlStatus: {
      type: DataType.String,
      length: 255
    },
    actionStatus: {
      type: DataType.String,
      length: 1
    },
    assignedBy: {
      type: DataType.String,
      length: 50
    },
    assignedCtrlStatus: {
      type: DataType.String,
      length: 255
    },
    assignedStatus: {
      type: DataType.String,
      length: 1
    },
    modules: {
      type: DataType.Array,
      typeOf: AccessModule1
    },
    users: {
      type: DataType.Array,
      typeOf: BankAdmin
    }
  }
};

