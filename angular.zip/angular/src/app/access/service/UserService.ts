﻿import {GenericSearchService, SearchModel} from '../../core';
import {User} from '../../shared/user-model';

export interface UserService extends GenericSearchService<User, SearchModel> {

}
