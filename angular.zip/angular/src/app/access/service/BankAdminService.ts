import {GenericSearchService, SearchModel} from '../../core';
import {BankAdmin} from '../model/BankAdmin';

export interface BankAdminService extends GenericSearchService<BankAdmin, SearchModel> {

}
