import { GenericSearchService } from '../../common/service/GenericSearchService';
import {ViewSearchService} from '../../common/service/ViewSearchService';
import {AccessRole} from '../model/AccessRole';
import {AccessRoleSM} from '../search-model/AccessRoleSM';

export interface ApprAccessRoleAssignmentService extends ViewSearchService<AccessRole, AccessRoleSM> {
}
