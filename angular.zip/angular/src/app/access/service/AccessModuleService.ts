import {ViewWebService} from '../../core';
import {AccessModule1} from '../model/AccessModule';

export interface AccessModuleService extends ViewWebService<AccessModule1> {

}
