import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import { accessGroupModel } from '../../metadata/AccessGroupModel';
import { AccessGroup } from '../../model/AccessGroup';
import { AccessGroupSM } from '../../search-model/AccessGroupSM';
import { AccessGroupService } from '../AccessGroupService';

@Injectable()
export class AccessGroupServiceImpl extends GenericSearchWebService<AccessGroup, AccessGroupSM> implements AccessGroupService {
  constructor(http: HttpClient) {
    super(http, config.accessGroupServiceUrl, accessGroupModel);
  }
}
