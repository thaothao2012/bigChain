import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import { GenericSearchWebService } from '../../../core';
import { accessGroupModel } from '../../metadata/AccessGroupModel';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import { AccessGroup } from '../../model/AccessGroup';
import {AccessRole} from '../../model/AccessRole';
import { AccessGroupSM } from '../../search-model/AccessGroupSM';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import { AccessGroupService } from '../AccessGroupService';
import {AccessRoleAssignmentService} from '../AccessRoleAssignmentService';

@Injectable()
export class AccessRoleAssignmentServiceImpl extends GenericSearchWebService<AccessRole, AccessRoleSM> implements AccessRoleAssignmentService {
  constructor(http: HttpClient) {
    super(http, config.accessRoleServiceUrl, accessRoleModel);
  }
}
