import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import config from '../../../../config';
import {GenericSearchWebService, SearchModel} from '../../../core';
import {userModel} from '../../../shared/user-metadata';
import {User} from '../../../shared/user-model';
import {UserService} from '../UserService';

@Injectable()
export class UserServiceImpl extends GenericSearchWebService<User, SearchModel> implements UserService {
  constructor(http: HttpClient) {
    super(http, config.userServiceUrl, userModel);
  }
}
