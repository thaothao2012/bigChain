import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import config from '../../../../config';
import {GenericSearchWebService} from '../../../core';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import { AccessRoleService } from '../AccessRoleService';

@Injectable()
export class AccessRoleServiceImpl extends GenericSearchWebService<AccessRole, AccessRoleSM> implements AccessRoleService {
  constructor(http: HttpClient) {
    super(http, config.backOfficeUrl + 'accessRoleDefinition', accessRoleModel);
  }
  protected formatObject(obj): AccessRole {
    const role: AccessRole = super.formatObject(obj);
    if (role.modules) {
      role.modules.forEach(module => {
          module.showName = module.parentId ? module.parentId + '->' + module.moduleName : module.moduleName;
      });
    }
    return role;
  }
}
