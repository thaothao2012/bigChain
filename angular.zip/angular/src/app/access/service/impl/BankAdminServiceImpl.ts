import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import config from '../../../../config';
import {GenericSearchWebService, SearchModel} from '../../../core';
import {bankAdminModel} from '../../metadata/BankAdminModel';
import {BankAdmin} from '../../model/BankAdmin';
import {BankAdminService} from '../BankAdminService';

@Injectable()
export class BankAdminServiceImpl extends GenericSearchWebService<BankAdmin, SearchModel> implements BankAdminService {
  constructor(http: HttpClient) {
    super(http, config.backOfficeUrl + 'bankAdmin', bankAdminModel);
  }
}
