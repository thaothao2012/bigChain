import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import config from '../../../../config';
import {ViewSearchWebService} from '../../../core';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import {ApprAccessRoleAssignmentService} from '../ApprAccessRoleAssignmentService';

@Injectable()
export class ApprAccessRoleAssignmentServiceImpl extends ViewSearchWebService<AccessRole, AccessRoleSM> implements ApprAccessRoleAssignmentService {
  constructor(http: HttpClient) {
    super(http, config.appAccessRoleServiceUrl, accessRoleModel);
  }
}
