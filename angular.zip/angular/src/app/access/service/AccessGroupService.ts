import { GenericSearchService } from '../../common/service/GenericSearchService';
import { AccessGroup } from '../model/AccessGroup';
import { AccessGroupSM } from '../search-model/AccessGroupSM';

export interface AccessGroupService extends GenericSearchService<AccessGroup, AccessGroupSM> {

}
