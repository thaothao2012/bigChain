// import { AccessModule } from 'src/app/access/access.module';
import { CtrlStatus } from '../enum/CtrlStatus';
import { AccessModule1 } from './AccessModule';
import { BankAdmin } from './BankAdmin';
import {ControlModel} from './ControlModel';

export class AccessRole extends ControlModel {
  roleId: string;
  cId: string;
  roleDesc: string;
  roleName: string;
  userType: string;
  evUserReg: string;
  evUserRegBank: string;
  evResetPwdBank: string;
  evResetPwdNonBank: string;
  evActivate: string;
  modules: AccessModule1[];
  users: BankAdmin[];
  assignedBy: string;
  assignedStatus: string;
  assignedCtrlStatus: CtrlStatus;
  assignedDate: Date;
}
