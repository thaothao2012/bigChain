import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccessModuleComponent } from './access.module.component';
import { AccessgroupComponent } from './component/accessgroup.component';
import { AccessgroupsComponent } from './component/accessgroups.component';
import { AccessRoleComponent } from './component/accessRole.components';
import {AccessRoleAssignmentComponent} from './component/accessRoleAssignment.component';
import {AccessRoleAssignmentsComponent} from './component/accessRoleAssignments.component';
import { AccessRolesComponent } from './component/accessRoles.components';
import {BankAdminComponent} from './component/bankAdmin.component';
import {BankAdminsComponent} from './component/bankAdmins.component';
import { UserComponent } from './component/user.component';
import { UsersComponent } from './component/users.component';
const accessRoutes: Routes = [
  {
    path: '',
    component: AccessModuleComponent,
    children: [
      { path: 'users', component: UsersComponent },
      { path: 'users/:id', component: UserComponent },
      { path: 'accessGroup/search', component: AccessgroupsComponent },
      { path: 'accessGroup/add', component: AccessgroupComponent },
      { path: 'accessGroup/:groupId/:cId', component: AccessgroupComponent },
      { path: 'accessRole/search', component: AccessRoleAssignmentsComponent },
      { path: 'accessRole/add', component: AccessRoleAssignmentComponent },
      { path: 'accessRole/:roleId/:cId', component: AccessRoleAssignmentComponent },
      {path: 'accessRoleDefinition', component: AccessRolesComponent},
      {path: 'accessRoleDefinition/:roleId/:cId', component: AccessRoleComponent},
      {path: 'accessRoleDefinition/add', component:  AccessRoleComponent},
      {path: 'bank-admin', component: BankAdminsComponent},
      {path: 'bank-admin/:id', component: BankAdminComponent}
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(accessRoutes)
  ],
  declarations: [

  ],
  exports: [
    RouterModule,
  ]
})

export class AccessRoutingModule {
}
