﻿import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {EditComponent, ReflectionUtil} from '../../core';
import {User} from '../../shared/user-model';
import {UserServiceImpl} from '../service/impl/UserServiceImpl';

@Component({
  selector: 'app-user-detail',
  templateUrl: '../views/user.html',
  providers: [UserServiceImpl]
})
export class UserComponent extends EditComponent<User> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, userService: UserServiceImpl) {
    super(viewContainerRef, router, route, userService);
  }

  private user: any = {};

  public getModel(): User {
    const obj = ReflectionUtil.clone(this.user);
    // this.jsonEntity(obj);
    return obj;
  }


  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: User) {
    this.user = obj;
  }
}
