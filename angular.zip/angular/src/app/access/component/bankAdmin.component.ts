import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { zip } from 'rxjs';
import { MasterDataServiceImpl } from 'src/app/shared/master-data/service/impl/MasterDataServiceImpl';
import { MasterDataService } from 'src/app/shared/master-data/service/MasterDataService';
import {EditComponent, ReflectionUtil} from '../../core';
import {BankAdmin} from '../model/BankAdmin';
import {BankAdminServiceImpl} from '../service/impl/BankAdminServiceImpl';

@Component({
  selector: 'app-bank-admin-editor',
  templateUrl: '../views/bank-admin-form.html',
  providers: [BankAdminServiceImpl]
})
export class BankAdminComponent extends EditComponent<BankAdmin> {
  private readonly masterDataService: MasterDataService;
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, bankAdminService: BankAdminServiceImpl) {
    super(viewContainerRef, router, route, bankAdminService);
    this.bankAdminService = bankAdminService;
    this.masterDataService = new MasterDataServiceImpl();
    this.loadMasterData();

  }

  bankAdminService: BankAdminServiceImpl;
  public bankAdmin: any = {};
  public titleList: any = [];
  public positionList: any = [];

  loadMasterData() {
    zip(
      this.masterDataService.getTitles(),
      this.masterDataService.getPositions(),
      this.masterDataService.getGenders()
    ).subscribe(([titleList, positionList]) => {
      this.titleList = titleList;
      this.positionList = positionList;
    });
  }

  public getModel(): BankAdmin {
    const obj = ReflectionUtil.clone(this.bankAdmin);
    console.log('obj: ', obj);
    // this.jsonEntity(obj);

    return obj;
  }


  public saveBankAdmin() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: BankAdmin) {
    this.bankAdmin = obj;
  }
}
