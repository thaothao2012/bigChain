import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {DateUtil, SearchComponent} from '../../core';
import { AccessGroup } from '../model/AccessGroup';
import {AccessRole} from '../model/AccessRole';
import { AccessGroupSM } from '../search-model/AccessGroupSM';
import {AccessRoleSM} from '../search-model/AccessRoleSM';
import { AccessGroupServiceImpl } from '../service/impl/AccessGroupServiceImpl';
import {AccessRoleAssignmentServiceImpl} from '../service/impl/AccessRoleAssignmentServiceImpl';

@Component({
  selector: 'app-accessrolesassignment-list',
  templateUrl: '../view/accessRolesAssignment.html',
  providers: [AccessRoleAssignmentServiceImpl]
})
export class AccessRoleAssignmentsComponent extends SearchComponent<AccessRole, AccessRoleSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessRoleAssignmentService: AccessRoleAssignmentServiceImpl) {
    super(viewContainerRef, router, route, accessRoleAssignmentService);
  }
  protected ctrlStatuslist = [
    {
      value: 'P',
      text: 'Pending',
    },
    {
      value: 'A',
      text: 'Approved',
    },
    {
      value: 'R',
      text: 'Rejected',
    }
  ];
  protected userTypes = [
    {
      value: 'BA',
      text: 'Bank Admin',
    }
  ];
  checkedCtrl: string[] = [];
  checkedUserType: string[] = [];
  updateChecked(value, event, field, checkedList, se) {
    if (this.se[field] !== null && this.se[field] !== undefined) {
      checkedList = this.se[field];
    }
    if (event.target.checked) {
      checkedList.push(value);
    } else {
      for (let i = 0; i < checkedList.length; i++) {
        if (checkedList[i] === value) {
          checkedList.splice(i, 1);
        }
      }
    }
    se[field] = checkedList;
    console.log(field + 'Checked', se[field]);
  }
  isChecked(checkedList, value): boolean {
    if (checkedList === null || checkedList === undefined) {
      return false;
    }
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i] === value) {
        return true;
      }
    }
    return false;
  }
  viewUser(groupId, cId) {
    console.log('Edit', groupId, cId);
    this.navigate('access/accessRole', [groupId, cId]);
  }

  addUser() {
    this.navigate('access/accessRole/add');
  }
  formatResults(results: any[]) {
    for (const result of results ) {
      if (result.assignedCtrlStatus) {
        const v = result.assignedCtrlStatus;
        if (v === 'A') {
          result.assignedCtrlStatusName = 'Approved';
        } else if (v === 'R') {
          result.assignedCtrlStatusName = 'Rejected';
        } else if (v === 'P') {
          result.assignedCtrlStatusName = 'Pending';
        }
      }

      if (result.assignedStatus) {
        const v = result.assignedStatus;
        if (v === 'C') {
          result.assignedStatus = 'Created';
        } else if (v === 'U') {
          result.assignedStatus = 'Updated';
        } else {
          result.assignedStatus = 'Deleted';
        }
      }
      if (result.assignedDate) {
        result.assignedDate = DateUtil.formatDate(result.assignedDate, 'DD.MM.YYYY hh:mm:ss');
      }
    }
  }
  formatSearchModel(obj) {
    const objs = Object.keys(obj);
    for (const o of objs) {
      obj[o] = null;
    }
    super.formatSearchModel(obj);
  }
}
