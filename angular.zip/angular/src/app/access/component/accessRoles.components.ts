import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { zip } from 'rxjs';
import { MasterDataService } from 'src/app/shared/master-data/service/MasterDataService';
import {SearchComponent} from '../../core';
import {AccessRole} from '../model/AccessRole';
import { AccessRoleSM } from '../search-model/AccessRoleSM';
import {AccessRoleServiceImpl} from '../service/impl/AccessRoleServiceImpl';

@Component({
  selector: 'app-access-role-list',
  templateUrl: '../view/accessRoles.html',
  providers: [AccessRoleServiceImpl]
})
export class AccessRolesComponent extends SearchComponent<AccessRole, AccessRoleSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessRoleService: AccessRoleServiceImpl) {
    super(viewContainerRef, router, route, accessRoleService);
  }

  masterDataService: MasterDataService;
  public accessRole: any = {};
  public userTypeList = [
    {
      value: 'BA',
      text: 'Bank Admin',
    }
  ];
  public ctrlStatusList = [
    {
      value: 'P',
      text: 'Pending',
    },
    {
      value: 'A',
      text: 'Approved',
    },
    {
      value: 'R',
      text: 'Rejected',
    }
  ];

  viewAccessRole(roleId, cId) {
    this.navigate('access/accessRoleDefinition', [roleId, cId]);
  }
  addUser() {
    this.navigate('access/accessRoleDefinition/add');
  }
}
