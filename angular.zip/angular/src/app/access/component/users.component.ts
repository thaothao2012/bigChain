﻿import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {SearchComponent, SearchModel} from '../../core';
import {User} from '../../shared/user-model';
import {UserServiceImpl} from '../service/impl/UserServiceImpl';

@Component({
  selector: 'app-user-list',
  templateUrl: '../views/users.html',
  providers: [UserServiceImpl]
})
export class UsersComponent extends SearchComponent<User, SearchModel> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, userService: UserServiceImpl) {
    super(viewContainerRef, router, route, userService);
  }

  viewUser(userId) {
    this.navigate('access/users', userId);
  }
}
