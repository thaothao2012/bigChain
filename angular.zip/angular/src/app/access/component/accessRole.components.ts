import { HttpClient } from '@angular/common/http';
import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { zip } from 'rxjs';
import {EditComponent, ReflectionUtil, UIUtil} from '../../core';
import { AccessRole } from '../model/AccessRole';
import {AccessModuleServiceImpl} from '../service/impl/AccessModuleServiceImpl';
import {AccessRoleServiceImpl} from '../service/impl/AccessRoleServiceImpl';
import { BankAdminServiceImpl } from '../service/impl/BankAdminServiceImpl';

@Component({
  selector: 'app-access-role-detail',
  templateUrl: '../view/accessRole.html',
  providers: [AccessRoleServiceImpl]
})
export class AccessRoleComponent extends EditComponent<AccessRole> {
  constructor(http: HttpClient, viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessRoleService: AccessRoleServiceImpl) {
    super(viewContainerRef, router, route, accessRoleService);
    this.accessModuleService = new AccessModuleServiceImpl(http);
    this.bankAdminService = new BankAdminServiceImpl(http);
    this.renderForm();
  }
  accessModuleService: AccessModuleServiceImpl;
  bankAdminService: BankAdminServiceImpl;
  public accessRole: any = {};
  public moduleList: any = [];
  public availableModules: any = [];
  public userList: any = [];
  checkedAll: false;
  protected userTypeList = [
    {
      value: 'BA',
      text: 'Bank Admin',
    }
  ];

  renderForm() {
    zip(
      this.accessModuleService.getAll(),
      this.bankAdminService.getAll()
    ).subscribe(([moduleList, userList]) => {
      this.moduleList = moduleList;
      console.log('moduleList: ', moduleList);
      this.userList = userList;
    });
  }
  showModel(model: AccessRole) {
    const promise = new Promise((resolve, reject) => {
      this.saveModelToState(model);
      resolve('Success!');
    });
    promise.then(() => {
      const accessRole = this.accessRole;
      const availableModules = this.availableModules;
      const lenAv = availableModules.reduce((len, modules) =>
        len += modules.children.length, 0);
      // tslint:disable-next-line:no-unused-expression
      accessRole.modules.length === lenAv ? ({checkedAll: true}) : ({checkedAll: false});
    });
  }
  handleCheck(event) {
    const accessRole = this.accessRole;
    const availableModules = this.availableModules;
    if (event.target.value === 'on') {
      const parent = availableModules.find(item =>
        item.moduleId === event.target.id);
      if (accessRole.modules.filter(item =>
        item.parentId === event.target.id).length === parent.children.length) {
        accessRole.modules = accessRole.modules.filter(item =>
          item.parentId !== event.target.id);
      } else {
        accessRole.modules = accessRole.modules.filter(item =>
          item.parentId !== event.target.id);
        accessRole.modules = accessRole.modules.concat(parent.children);
      }
    } else if (event.target.value === 'all') {
      accessRole.modules = [];
      if (event.target.value) {
        accessRole.modules = availableModules.reduce((resultArray, currentArray) =>
          resultArray = resultArray.concat(currentArray.children), []
        );
      }
    } else {
      let checked = true;
      const parent = availableModules.find(item =>
        item.moduleId === event.target.value);
      const child = parent.children.
        find(value =>
          value.moduleId === event.target.id);
      if (accessRole.modules !== []) {
        checked = !!accessRole.modules.find(item =>
          item.moduleId === event.target.id);
      } else {
        checked = false;
      }
      if (!checked) {
        accessRole.modules.push(child);
      } else {
        accessRole.modules = accessRole.modules = accessRole.modules.filter(item =>
          item.moduleId !== event.target.id);
      }
    }
    return this.isCheckedAll(event);
  }

  isCheckedAll(event) {
    const availableModules = this.availableModules;
    const form = event.target.form;
    const controls = UIUtil.getControlsFromForm(form, availableModules.reduce((acc, current) =>
      acc = acc.concat(current.moduleId), []
    ));
    const checkedAll = controls.every(i => i.checked === true);
    return checkedAll;
  }

  public getModel(): AccessRole {
    const obj = ReflectionUtil.clone(this.accessRole);
    return obj;
  }


  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: AccessRole) {
    this.accessRole = obj;
  }
}
