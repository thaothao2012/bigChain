import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SearchComponent } from '../../core';
import { AccessGroup } from '../model/AccessGroup';
import { AccessGroupSM } from '../search-model/AccessGroupSM';
import { AccessGroupServiceImpl } from '../service/impl/AccessGroupServiceImpl';

@Component({
  selector: 'app-accessgroup-list',
  templateUrl: '../view/accessgroups.html',
  providers: [AccessGroupServiceImpl]
})
export class AccessgroupsComponent extends SearchComponent<AccessGroup, AccessGroupSM> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessGroupService: AccessGroupServiceImpl) {
    super(viewContainerRef, router, route, accessGroupService);
    this.checkedCtrl = [];
    this.checkedEntity = [];
  }

  protected ctrlStatuslist = [
    {
      value: 'P',
      text: 'Pending',
    },
    {
      value: 'A',
      text: 'Approved',
    },
    {
      value: 'R',
      text: 'Rejected',
    }
  ];
  protected entityTypeList = [
    {
      value: 'E',
      text: 'Payee',
    },
    {
      value: 'B',
      text: 'Bank',
    },
    {
      value: 'R',
      text: 'Payer',
    }
  ];
  checkedCtrl: string[] = [];
  checkedEntity: string[] = [];

  formatSearchModel(obj) {
    const objs = Object.keys(obj);
    for (const o of objs) {
      obj[o] = null;
    }
    super.formatSearchModel(obj);
  }

  updateChecked(value, event, field, checkedList, model) {
    if (model[field] !== null && model[field] !== undefined) {
      checkedList = model[field];
    }
    if (event.target.checked) {
      checkedList.push(value);
    } else {
      for (let i = 0; i < checkedList.length; i++) {
        if (checkedList[i] === value) {
          checkedList.splice(i, 1);
        }
      }
    }
    model[field] = checkedList;
    console.log(field + 'Checked', model[field]);
  }
  isChecked(checkedList, value): boolean {
    if (checkedList === null || checkedList === undefined) {
      return false;
    }
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i] === value) {
        return true;
      }
    }
    return false;
  }
  formatResults(results: any[]) {
    for (const result of results ) {
      if (result.ctrlStatus) {
        const v = result.ctrlStatus;
        if (v === 'A') {
          result.ctrlStatusName = 'Approved';
        } else if (v === 'R') {
          result.ctrlStatusName = 'Rejected';
        } else if (v === 'P') {
          result.ctrlStatusName = 'Pending';
        }
      }
      if (result.actionStatus) {
        const v = result.actionStatus;
        if (v === 'C') {
          result.actionStatus = 'Created';
        } else if (v === 'U') {
          result.actionStatus = 'Updated';
        } else {
          result.actionStatus = 'Deleted';
        }
      }
    }
  }

  viewUser(groupId, cId) {
    console.log('Edit', groupId, cId);
    this.navigate('access/accessGroup', [groupId, cId]);
  }

  addUser() {
    this.navigate('access/accessGroup/add');
  }
}
