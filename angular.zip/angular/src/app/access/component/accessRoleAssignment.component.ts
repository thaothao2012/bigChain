import {Component, Input, ViewContainerRef} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'underscore';
import { EditComponent, ReflectionUtil } from '../../core';
import {AccessRole} from '../model/AccessRole';
import {AccessRoleAssignmentServiceImpl} from '../service/impl/AccessRoleAssignmentServiceImpl';
import {ApprAccessRoleAssignmentServiceImpl} from '../service/impl/ApprAccessRoleAssignmentServiceImpl';

@Component({
  selector: 'app-accessroleassignment-detail',
  templateUrl: '../view/accessRoleAssignment.html',
  providers: [AccessRoleAssignmentServiceImpl, ApprAccessRoleAssignmentServiceImpl]
})
export class AccessRoleAssignmentComponent extends EditComponent<AccessRole> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessRoleAssignmentService: AccessRoleAssignmentServiceImpl, private apprAccessRoleAssignmentService: ApprAccessRoleAssignmentServiceImpl) {
    super(viewContainerRef, router, route, accessRoleAssignmentService);
  }
  protected accessRole: any = {};
  protected accessRoleUser: any = {};
  protected roles: any = [];
  protected textSearch = '';
  protected isShowCheckbox = false;
  protected checkBoxList: any[] = [];
  protected userTypes = [
    {
      value: 'BA',
      text: 'Bank Admin',
    }
  ];

  protected initData() {
    this.apprAccessRoleAssignmentService.getAll().subscribe(result => {
      this.roles = result;
      super.initData();
    });
  }
  updateChecked(value, event, checkedList) {
    if (event.target.checked) {
      checkedList.push(value);
    } else {
      for (let i = 0; i < checkedList.length; i++) {
        if (checkedList[i].userId === value.userId) {
          checkedList.splice(i, 1);
        }
      }
    }
  }
  isChecked(checkedList, value): boolean {
    if (checkedList === null || checkedList === undefined) {
      return false;
    }
    for (let i = 0; i < checkedList.length; i++) {
      if (checkedList[i].userId === value.userId) {
        return true;
      }
    }
    return false;
  }
  handleGroupdIdChange(event) {
    for (const item of this.roles) {
      const uType = this.accessRole.userType;
      const users = this.accessRole.users;
      if (item.roleId === event.target.value) {
        this.accessRole = {...item, userType: uType };
      } else if (event.target.value === '') {
        this.accessRole = {userType: uType };
      }
    }
    this.accessRoleUser = this.accessRole.users;
  }
  onSearch(event) {
    if (this.accessRole.users) {
      const result = this.accessRole.users.filter((value) => {
        return value['userId'].includes(event.target.value);
      });

      this.accessRoleUser = result;
    }
  }
  onShowCheckBox () {
    if (this.isShowCheckbox === false) {
      this.isShowCheckbox = true;
    } else {
      this.isShowCheckbox = false;
    }
  }
  onCheckAll() {
    if (this.checkBoxList) {
      this.checkBoxList = [];
    }
    if (this.accessRole.users) {
      for ( const user of this.accessRole.users) {
        this.checkBoxList.push(user);
      }
    }
  }
  onUnCheckAll() {
    this.checkBoxList = [];
  }
  onDeleteCheckBox() {
    if (confirm('Delete ?') === true) {
      console.log('delete');
      const arr = [];
      this.accessRole.users.map((value) => {
        const result = this.checkBoxList.find((v) => {
          if (v) {
            return v.userId === value.userId;
          }
        });
        if (result === undefined) {
          arr.push(value);
        }
      });
      this.accessRoleUser = arr;
      this.accessRole.users = arr;
      this.checkBoxList = [];
      this.isShowCheckbox = false;
    }
  }
  public getModel(): AccessRole {
    const obj = ReflectionUtil.clone(this.accessRole);
    // this.jsonEntity(obj);
    return obj;
  }
  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: AccessRole) {
    this.accessRole = obj;
    this.accessRoleUser = obj.users;
  }
}
