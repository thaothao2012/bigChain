import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EditComponent, ReflectionUtil } from '../../core';
import { AccessGroup } from '../model/AccessGroup';
import { AccessGroupServiceImpl } from '../service/impl/AccessGroupServiceImpl';

@Component({
  selector: 'app-accessgroup-detail',
  templateUrl: '../view/accessgroup.html',
  providers: [AccessGroupServiceImpl]
})
export class AccessgroupComponent extends EditComponent<AccessGroup> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, accessGroupService: AccessGroupServiceImpl) {
    super(viewContainerRef, router, route, accessGroupService);
  }

  protected accessGroup: any = {};
  protected entityTypeList = [
    {
      value: 'E',
      text: 'Payee',
    },
    {
      value: 'B',
      text: 'Bank',
    },
    {
      value: 'R',
      text: 'Payer',
    }
  ];

  public getModel(): AccessGroup {
    const obj = ReflectionUtil.clone(this.accessGroup);
    // this.jsonEntity(obj);
    return obj;
  }


  public saveUser() {
    this.confirm('Are you sure save?', () => {
      this.saveOnClick();
    }, () => {

    });
  }

  public setModel(obj: AccessGroup) {
    this.accessGroup = obj;
  }
}
