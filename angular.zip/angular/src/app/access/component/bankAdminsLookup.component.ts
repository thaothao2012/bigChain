import {Component, Input, ViewChild, ViewChildren, ViewContainerRef} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {SearchComponent, SearchModel} from '../../core';
import {BankAdmin} from '../model/BankAdmin';
import {BankAdminServiceImpl} from '../service/impl/BankAdminServiceImpl';
import {AccessRoleAssignmentComponent} from './accessRoleAssignment.component';

@Component({
  selector: 'app-banklook-list',
  templateUrl: '../view/bankAdminsLookup.html',
  providers: [BankAdminServiceImpl]
})
export class BankAdminsLookupComponent extends SearchComponent<BankAdmin, SearchModel> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, bankAdminService: BankAdminServiceImpl) {
    super(viewContainerRef, router, route, bankAdminService);
  }
  protected bankAdmin: any[] = [];
  onCheckUser(event) {
    if (event.target.checked) {
      const result = this.getList().find((value) => value.userId === event.target.value);
      this.bankAdmin.push(result);
    } else {
      for (let i = 0; i < this.bankAdmin.length; i++) {
        if (this.bankAdmin[i].userId === event.target.value) {
          this.bankAdmin.splice(i, 1);
        }
      }
    }
  }
  onModelSave() {
    console.log('OOOOOOO');
  }
  onSearch(event) {
    if (this.getList()) {
      const result = this.getList().filter((value) => {
        return value['userId'].includes(event.target.value);
      });
      this.setList(result);
    }
  }
}
