import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { zip } from 'rxjs';
import { MasterDataServiceImpl } from 'src/app/shared/master-data/service/impl/MasterDataServiceImpl';
import { MasterDataService } from 'src/app/shared/master-data/service/MasterDataService';
import {SearchComponent, SearchModel} from '../../core';
import {BankAdmin} from '../model/BankAdmin';
import {BankAdminServiceImpl} from '../service/impl/BankAdminServiceImpl';

@Component({
  selector: 'app-bank-admin-list',
  templateUrl: '../views/bank-admins-form.html',
  providers: [BankAdminServiceImpl]
})

export class BankAdminsComponent extends SearchComponent<BankAdmin, SearchModel> {
  private readonly masterDataService: MasterDataService;
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, bankAdminService: BankAdminServiceImpl) {
    super(viewContainerRef, router, route, bankAdminService);
    this.masterDataService = new MasterDataServiceImpl();
    this.loadMasterData();
  }

  public activationStatusList: any = [];
  public ctrlStatusList: any = [];

  loadMasterData() {
    zip(
      this.masterDataService.getStatus(),
      this.masterDataService.getCtrlStatus(),
    ).subscribe(([activationStatusList, ctrlStatusList]) => {
      this.activationStatusList = activationStatusList;
      this.ctrlStatusList = ctrlStatusList;
    });
  }

  viewBankAdmin(bankAdminId: string) {
    this.navigate('access/bank-admin', bankAdminId);
  }
}
