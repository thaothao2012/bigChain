import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {BsDatepickerModule, DatepickerModule, ModalModule} from 'ngx-bootstrap';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import {TimepickerModule } from 'ngx-bootstrap/timepicker';
import {ModalComponent} from '../common/modal/ModalComponent';
import { AccessRoutingModule } from './access-routing.module';
import { AccessModuleComponent } from './access.module.component';
import { AccessgroupComponent } from './component/accessgroup.component';
import { AccessgroupsComponent } from './component/accessgroups.component';
import { AccessRoleComponent } from './component/accessRole.components';
import {AccessRoleAssignmentComponent} from './component/accessRoleAssignment.component';
import {AccessRoleAssignmentsComponent} from './component/accessRoleAssignments.component';
import { AccessRolesComponent } from './component/accessRoles.components';
import {BankAdminComponent} from './component/bankAdmin.component';
import {BankAdminsComponent} from './component/bankAdmins.component';
import {BankAdminsLookupComponent} from './component/bankAdminsLookup.component';
import {ExampleModalComponent} from './component/exampleModal.component';
import { UserComponent } from './component/user.component';
import { UsersComponent } from './component/users.component';
import { AccessGroupServiceImpl } from './service/impl/AccessGroupServiceImpl';
import {AccessRoleAssignmentServiceImpl} from './service/impl/AccessRoleAssignmentServiceImpl';
import { AccessRoleServiceImpl } from './service/impl/AccessRoleServiceImpl';
import {BankAdminServiceImpl} from './service/impl/BankAdminServiceImpl';
import { UserServiceImpl } from './service/impl/UserServiceImpl';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AccessRoutingModule,
    ReactiveFormsModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot()
  ],
  declarations: [
    AccessModuleComponent,
    UsersComponent,
    UserComponent,
    AccessRoleComponent,
    AccessRolesComponent,
    AccessgroupsComponent,
    AccessgroupComponent,
    BankAdminsComponent,
    BankAdminComponent,
    AccessRoleAssignmentComponent,
    AccessRoleAssignmentsComponent,
    BankAdminsLookupComponent,
    ExampleModalComponent
  ],
  entryComponents: [

  ],
  providers: [
    UserServiceImpl,
    AccessGroupServiceImpl,
    BankAdminServiceImpl,
    AccessRoleServiceImpl,
    AccessRoleAssignmentServiceImpl
  ]
})

export class AccessModule {
}
