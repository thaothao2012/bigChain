import {Component} from '@angular/core';

@Component({
  selector: 'app-access-module',
  template: '<router-outlet></router-outlet>'
})

export class AccessModuleComponent {
  constructor() {
  }
}
