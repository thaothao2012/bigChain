export enum CtrlStatus {
  Pending= 'P',
  Approved = 'A',
  Rejected = 'R'
}
