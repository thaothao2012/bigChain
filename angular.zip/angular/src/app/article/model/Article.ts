export class Article {
  articleId: string;
  title: string;
  description: string;
  body: string;
  keywords: string[];
  status: string;
}

