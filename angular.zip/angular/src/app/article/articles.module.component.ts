import {Component} from '@angular/core';

@Component({
  selector: 'app-articles-module',
  template: '<router-outlet></router-outlet>'
})

export class ArticlesModuleComponent {
  constructor() {
  }
}
