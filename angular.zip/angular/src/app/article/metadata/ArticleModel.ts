import {DataType, Model} from '../../core';

export const articleModel: Model = {
  name: 'article',
  sourceName: 'article',
  attributes: {
    articleId: {
      field: 'articleId',
      type: DataType.String,
      primaryKey: true
    },
    name: {
      field: 'name',
      type: DataType.String,
      length: 255,
      allowNull: true
    },
    description: {
      field: 'description',
      type: DataType.String ,
      length: 255
    },
    body: {
      field: 'body',
      type: DataType.String,
      length: 255
    },
    // keywords: {
    //   field: 'keywords',
    //   type: DataType.Array,
    //   typeOf: DataType.String
    // },
    status: {
      field: 'status',
      type: DataType.DateTime
    }
  }
};
