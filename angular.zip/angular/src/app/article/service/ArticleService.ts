import {GenericSearchService, SearchModel} from '../../core';
import {Article} from '../model/Article';

export interface ArticleService extends GenericSearchService<Article, SearchModel> {

}
