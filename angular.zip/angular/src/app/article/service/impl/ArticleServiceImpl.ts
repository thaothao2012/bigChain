import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import config from '../../../../config';
import {GenericSearchWebService, SearchModel} from '../../../core';
import {articleModel} from '../../metadata/ArticleModel';
import {Article} from '../../model/Article';
import {ArticleService} from '../ArticleService';

@Injectable()
export class ArticleServiceImpl extends GenericSearchWebService<Article, SearchModel> implements ArticleService {
  constructor(http: HttpClient) {
    super(http, config.articleServiceUrl, articleModel);
  }
}
