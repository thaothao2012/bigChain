import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {UserServiceImpl} from '../../access/service/impl/UserServiceImpl';
import {EditComponent, ModalService, ReflectionUtil, UIUtil} from '../../core';
import {Article} from '../model/Article';
import {ArticleServiceImpl} from '../service/impl/ArticleServiceImpl';

@Component({
  selector: 'app-article-editor',
  templateUrl: '../views/article.html',
  providers: [UserServiceImpl]
})
export class ArticleComponent extends EditComponent<Article> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, modalService: ModalService, articleService: ArticleServiceImpl) {
    super(viewContainerRef, router, route, articleService);
    this.articleService = articleService;
  }
  articleService: ArticleServiceImpl;
  public article: any = {};

  public getModel(): Article {
    const obj = ReflectionUtil.clone(this.article);
    return obj;
  }

  public setModel(obj: Article) {
    this.article = obj;
  }

  public editorChange(textEditor: string) {
    this.article.body = textEditor;
  }
}

