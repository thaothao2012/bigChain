import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {SearchComponent, SearchModel} from '../../core';
import {Article} from '../model/Article';
import {ArticleServiceImpl} from '../service/impl/ArticleServiceImpl';

@Component({
  selector: 'app-article-list',
  templateUrl: '../views/articles.html',
  providers: [ArticleServiceImpl]
})

export class ArticlesComponent extends SearchComponent<Article, SearchModel> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, articleService: ArticleServiceImpl) {
    super(viewContainerRef, router, route, articleService);
  }

  viewArticle(articleId: string) {
    this.navigate('articles', articleId);
  }
}
