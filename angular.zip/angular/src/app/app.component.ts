import {Component, OnInit} from '@angular/core';
import {NavigationEnd, Router} from '@angular/router';
import {storage} from './core';

/*
@Component({
  // tslint:disable-next-line
  selector: 'body',
  template: '<router-outlet></router-outlet>'
})
*/
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  constructor(private router: Router) { }

  ngOnInit() {
    if (location.href.startsWith(storage.getRedirectUrl())) {
      window.location.href = location.origin + '/connect/oAuth2' + location.search;
    }

    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }
}
