import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {FeeDetailReportComponent} from './component/feeDetailReport.component';
import {FeeDetailReportModuleComponent} from './fee-detail-report.module.component';

const feeDetailReportRoutes: Routes = [
  {
    path: '',
    component: FeeDetailReportModuleComponent,
    children: [
      {path: 'fee-detail-report', component: FeeDetailReportComponent},
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(feeDetailReportRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class FeeDetailReportRoutingModule {
}
