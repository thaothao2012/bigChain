import {DataType, Model} from '../../core';

export const feeDetailReportModel: Model = {
  name: 'feeDetailReport',
  attributes: {
    payerName: {
      type: DataType.String,
    },
    transactionDate: {
      type: DataType.DateTime
    },
    transactionNo: {
      type: DataType.String
    },
    internalReference: {
      type: DataType.String ,
    },
    transactionStatus: {
      type: DataType.String ,
    },
    transactionAmount: {
      type: DataType.String,
    },
    feeAmount: {
      type: DataType.String
    },
    feeTransactionNo: {
      type: DataType.String,
    },
    feeEffectiveDate: {
      type: DataType.DateTime
    },
    feePositingType: {
      type: DataType.String,
    },
    feeDebitAccount: {
      type: DataType.String,
    }
  }
};

