import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule, MatInputModule, MatRippleModule} from '@angular/material';
import {MatAutocompleteModule} from '@angular/material';
import {MatChipsModule} from '@angular/material/chips';
import {BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import {BsDropdownModule} from 'ngx-bootstrap/dropdown';
import {PaginationModule} from 'ngx-bootstrap/pagination';
import {TimepickerModule } from 'ngx-bootstrap/timepicker';
import {FeeDetailReportComponent} from './component/feeDetailReport.component';
import {FeeDetailReportRoutingModule} from './fee-detail-report-routing.module';
import {FeeDetailReportModuleComponent} from './fee-detail-report.module.component';
import {FeeDetailReportServiceImpl} from './service/impl/FeeDetailReportServiceImpl';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FeeDetailReportRoutingModule,
    ReactiveFormsModule,
    BsDropdownModule,
    PaginationModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    BsDatepickerModule.forRoot(),
    TimepickerModule.forRoot(),
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations: [
    FeeDetailReportModuleComponent,
    FeeDetailReportComponent,
  ],
  entryComponents: [

  ],
  providers: [
    FeeDetailReportServiceImpl
  ]
})

export class FeeDetailReportModule {
}
