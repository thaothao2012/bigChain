import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { HttpClient } from '@angular/common/http';
// tslint:disable-next-line:ordered-imports
import { Component, ElementRef, ViewChild, ViewContainerRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent, MatChipInputEvent } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { Payer } from 'src/app/setup/model/Payer';
import { ApprPayerServiceImpl } from 'src/app/setup/service/impl/ApprPayerServiceImpl';
import { MasterDataServiceImpl } from 'src/app/shared/master-data/service/impl/MasterDataServiceImpl';
import { MasterDataService } from 'src/app/shared/master-data/service/MasterDataService';
import { SearchComponent } from '../../core';
import { FeeDetailReport } from '../model/FeeDetailReport';
import { FeeDetailReportSM } from '../search-model/FeeDetailReportSM';
import { FeeDetailReportServiceImpl } from '../service/impl/FeeDetailReportServiceImpl';


export interface Fruit {
  name: string;
}

@Component({
  selector: 'app-fee-detail-report-list',
  templateUrl: '../views/fee-detail-report-form.html',
  styleUrls: ['../test.css'],
  providers: [FeeDetailReportServiceImpl]
})

export class FeeDetailReportComponent extends SearchComponent<FeeDetailReport, FeeDetailReportSM> {
  private readonly masterDataService: MasterDataService;
  constructor(http: HttpClient, viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, feeDetailReportService: FeeDetailReportServiceImpl) {
    super(viewContainerRef, router, route, feeDetailReportService);
    this.apprPayerServiceImpl = new ApprPayerServiceImpl(http);
    this.masterDataService = new MasterDataServiceImpl();
    this.load();
  }

  apprPayerServiceImpl: ApprPayerServiceImpl;
  payers: Payer[];
  allPayers: string[];
  selectedPayer: string[] = [];
  payerCtrl = new FormControl();
  filteredPayers: Observable<string[]>;
  payersList: string[] = [];
  public feeStatusList: any = [];
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];

  @ViewChild('payerInput') payerInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  load() {

    this.masterDataService.getFeeStatus().subscribe(feeStatusList => {
      this.feeStatusList = feeStatusList;
    });

    this.apprPayerServiceImpl.getAll().subscribe(payers => {
      const promise = new Promise((resolve, reject) => {
        this.payers = payers;
        resolve('Success!');
      });
      promise.then(() => {
        const arrs = [];
        this.payers.forEach(function (value) {
          if (value.entityName) {
            arrs.push(value.entityName);
          }
        });
        this.allPayers = arrs;
        this.filteredPayers = this.payerCtrl.valueChanges.pipe(
          startWith(null),
          map((payer: string | null) => payer ? this._filterPayer(payer) : this.allPayers.slice()));
      });
    });
  }

  addPayer(event: MatChipInputEvent): void {
    // Add fruit only when MatAutocomplete is not open
    // To make sure this does not conflict with OptionSelected Event
    if (!this.matAutocomplete.isOpen) {
      const input = event.input;
      const value = event.value;

      // Add our fruit
      if ((value || '').trim()) {
        this.selectedPayer.push(value.trim());
      }

      // Reset the input value
      if (input) {
        input.value = '';
      }

      this.payerCtrl.setValue(null);
    }
  }

  removePayer(payer: string): void {
    const index = this.selectedPayer.indexOf(payer);

    if (index >= 0) {
      this.selectedPayer.splice(index, 1);
    }
  }

  selectedPayerFunc(event: MatAutocompleteSelectedEvent): void {
    this.selectedPayer.push(event.option.viewValue);
    const x = this.payers.find(v => v.entityName === event.option.viewValue);
    this.payersList.push(x.entityId);
    this.payerInput.nativeElement.value = '';
    this.payerCtrl.setValue(null);
    this.se.payersList = this.payersList;
  }

  private _filterPayer(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allPayers.filter(payer => payer.toLowerCase().indexOf(filterValue) === 0);
  }

}
