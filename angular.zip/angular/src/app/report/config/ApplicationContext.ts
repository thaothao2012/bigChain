import {HttpClient} from '@angular/common/http';
import {ApprPayerService} from '../../setup/service/ApprPayerService';
import {ApprPayerServiceImpl} from '../../setup/service/impl/ApprPayerServiceImpl';



export class ApplicationContext {
  private readonly apprPayerService: ApprPayerService;
  constructor(http: HttpClient) {
    this.apprPayerService = new ApprPayerServiceImpl(http);
  }

  getApprPayerService(): ApprPayerService {
    return this.apprPayerService;
  }
}

// const applicationContext = new ApplicationContext();
