import {GenericSearchService} from '../../core';
import {FeeDetailReport} from '../model/FeeDetailReport';
import {FeeDetailReportSM} from '../search-model/FeeDetailReportSM';

export interface FeeDetailReportService extends GenericSearchService<FeeDetailReport, FeeDetailReportSM> {
}
