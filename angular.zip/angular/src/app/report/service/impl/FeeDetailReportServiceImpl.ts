import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import config from '../../../../config';
import {GenericSearchWebService} from '../../../core';
import {feeDetailReportModel} from '../../metadata/FeeDetailReportModel';
import {FeeDetailReport} from '../../model/FeeDetailReport';
import {FeeDetailReportSM} from '../../search-model/FeeDetailReportSM';
import {FeeDetailReportService} from '../FeeDetailReportService';

@Injectable()
export class FeeDetailReportServiceImpl extends GenericSearchWebService<FeeDetailReport, FeeDetailReportSM> implements FeeDetailReportService {
  constructor(http: HttpClient) {
    super(http, config.backOfficeUrl + 'transactionFeeDetail', feeDetailReportModel);
  }
}
