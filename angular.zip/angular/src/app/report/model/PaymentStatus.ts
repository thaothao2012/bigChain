export enum PaymentStatus {
  Debited = 'D',
  Credited = 'C',
  Fail = 'F',
  Success = 'S',
}
