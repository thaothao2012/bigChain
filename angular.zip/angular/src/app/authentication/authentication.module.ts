import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AuthenticationModuleComponent} from './authentication.module.component';
import {AuthenticationRoutingModule} from './authentication-routing.module';
import {ChangePasswordComponent} from './component/change-password.component';
import {ConnectComponent} from './component/connect.component';
import {ConnectOAuth2Component} from './component/connect-OAuth2.component';
import {ForgotPasswordComponent} from './component/forgot-password.component';
import {ResetPasswordComponent} from './component/reset-password.component';
import {SigninComponent} from './component/signin.component';
import {SignupComponent} from './component/signup.component';
import {WelcomeComponent} from './component/welcome.component';
import {AuthenticationServiceImpl} from './service/impl/AuthenticationServiceImpl';
import {IntegrationConfigurationServiceImpl} from './service/impl/IntegrationConfigurationServiceImpl';
import {PasswordServiceImpl} from './service/impl/PasswordServiceImpl';
import {UserRegistrationServiceImpl} from './service/impl/UserRegistrationServiceImpl';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    AuthenticationRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [
    AuthenticationModuleComponent,
    WelcomeComponent,
    ConnectComponent,
    ConnectOAuth2Component,
    SignupComponent,
    SigninComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    ChangePasswordComponent
  ],
  entryComponents: [],
  providers: [
    UserRegistrationServiceImpl, AuthenticationServiceImpl, PasswordServiceImpl, IntegrationConfigurationServiceImpl
  ]
})

export class AuthenticationModule {
}
