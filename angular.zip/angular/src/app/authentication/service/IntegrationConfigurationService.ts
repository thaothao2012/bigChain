import {Observable} from 'rxjs';
import {IntegrationConfiguration} from '../model/IntegrationConfiguration';

export interface IntegrationConfigurationService {
  getAll(): Observable<IntegrationConfiguration[]>;
  getByType(type: string): Observable<IntegrationConfiguration>;
}
