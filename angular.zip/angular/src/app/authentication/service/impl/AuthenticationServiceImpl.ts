import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import config from '../../../../config';
import {WebClientUtil} from '../../../core';
import {SigninInfo} from '../../model/SigninInfo';
import {SigninResult} from '../../model/SigninResult';
import {AuthenticationService} from '../AuthenticationService';

@Injectable()
export class AuthenticationServiceImpl implements AuthenticationService {
  constructor(private http: HttpClient) {
  }

  authenticate(user: SigninInfo): Observable<SigninResult> {
    const url = config.authenticationServiceUrl + '/authentication/authenticate';
    return WebClientUtil.postObject<SigninResult>(this.http, url, user);
  }

  authenticateByOAuth2(user: SigninInfo): Observable<SigninResult> {
    const url = config.authenticationServiceUrl + '/oauth2/authenticate';
    return WebClientUtil.postObject<SigninResult>(this.http, url, user);
  }

}
