import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import config from '../../../../config';
import {WebClientUtil} from '../../../core';
import {IntegrationConfiguration} from '../../model/IntegrationConfiguration';
import {IntegrationConfigurationService} from '../IntegrationConfigurationService';

@Injectable()
export class IntegrationConfigurationServiceImpl implements IntegrationConfigurationService {
  private serviceUrl = config.authenticationServiceUrl + '/' + 'integrationConfigurations';

  constructor(private http: HttpClient) {

  }

  getAll(): Observable<IntegrationConfiguration[]> {
    const url = this.serviceUrl;
    const objectObservable: any = WebClientUtil.get(this.http, url);
    return objectObservable;
  }

  getByType(type: string): Observable<IntegrationConfiguration> {
    throw new Error('Method not implemented.'); // TODO
  }
}
