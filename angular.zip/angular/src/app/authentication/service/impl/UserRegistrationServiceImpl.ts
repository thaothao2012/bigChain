import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import config from '../../../../config';
import {WebClientUtil} from '../../../core';
import {UserRegistration} from '../../model/UserRegistration';
import {UserRegistrationResult} from '../../model/UserRegistrationResult';
import {UserRegistrationService} from '../UserRegistrationService';

@Injectable()
export class UserRegistrationServiceImpl implements UserRegistrationService {
  constructor(private http: HttpClient) {
  }

  registerUser(signupInfo: UserRegistration): Observable<UserRegistrationResult> {
    const url = config.userRegistrationServiceUrl + '/user-registration/register';
    return WebClientUtil.postObject<UserRegistrationResult>(this.http, url, signupInfo);
  }
}
