import {Observable} from 'rxjs';
import {PasswordChange} from '../model/PasswordChange';
import {PasswordReset} from '../model/PasswordReset';

export interface PasswordService {
  changePassword(pass: PasswordChange): Observable<boolean>;
  forgotPassword(email: string): Observable<boolean>;
  resetPassword(pass: PasswordReset): Observable<boolean>;
}
