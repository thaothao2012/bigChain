import {Observable} from 'rxjs';
import {UserRegistration} from '../model/UserRegistration';
import {UserRegistrationResult} from '../model/UserRegistrationResult';

export interface UserRegistrationService {
  registerUser(user: UserRegistration): Observable<UserRegistrationResult>;
}
