import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {AuthorizationRequiredService} from '../common/service/AuthorizationRequiredService';
import {AuthenticationModuleComponent} from './authentication.module.component';
import {ChangePasswordComponent} from './component/change-password.component';
import {ConnectComponent} from './component/connect.component';
import {ConnectOAuth2Component} from './component/connect-OAuth2.component';
import {ForgotPasswordComponent} from './component/forgot-password.component';
import {ResetPasswordComponent} from './component/reset-password.component';
import {SigninComponent} from './component/signin.component';
import {SignupComponent} from './component/signup.component';
import {WelcomeComponent} from './component/welcome.component';

const authenticationRoutes: Routes = [
  {
    path: '',
    component: AuthenticationModuleComponent,
    children: [
      {path: 'welcome', component: WelcomeComponent},
      {path: 'connect', component: ConnectComponent},
      {path: 'connect/oAuth2', component: ConnectOAuth2Component},
      {path: 'signup', component: SignupComponent},
      {path: 'signin', component: SigninComponent},
      {path: 'forgot-password', component: ForgotPasswordComponent},
      {path: 'reset-password', component: ResetPasswordComponent},
      {path: 'change-password', component: ChangePasswordComponent}
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(authenticationRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AuthenticationRoutingModule {
}
