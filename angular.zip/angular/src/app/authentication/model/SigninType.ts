export enum SigninType {
  UserName = 'Email',
  Facebook = 'Facebook',
  Google = 'Google',
  LinkedIn = 'LinkedIn'
}
