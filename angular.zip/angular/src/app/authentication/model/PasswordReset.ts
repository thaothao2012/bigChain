export interface PasswordReset {
  userName: string;
  passcode: string;
  newPassword: string;
}
