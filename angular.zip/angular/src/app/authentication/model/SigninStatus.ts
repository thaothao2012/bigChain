export enum SigninStatus {
  Success = '1', // 'S',
  Reactivate = '18',
  UserNotExisted = '13', // 'N'
  PasswordNotExisted = '15',
  WrongPassword = '16',
  Locked = 'L',
  Suspended = 'S',
  Blocked = 'B',
  PasswordExpired = '20',
  SuccessAndReactivated = '21',

  SecurityError = '-3', // 'R',
  BusinessLogicError = '6', // 'B',
  Error = '9', // 'E',

  ItemDeactivated = '14',
  SystemError = '17',

  EmailExisted = '19',

  Deactivated = 'D', // deleted

  WrongInvitationEmail = 'WIM',
  Fail = 'F'
}
