export interface PasswordChange {
  userName: string;
  currentPassword: string;
  newPassword: string;
}
