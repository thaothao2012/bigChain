import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {CookieService} from 'ngx-cookie-service';
import {DateUtil, ResourceManager, storage, UIUtil} from '../../core';
import {SigninInfo} from '../model/SigninInfo';
import {SigninResult} from '../model/SigninResult';
import {SigninStatus} from '../model/SigninStatus';
import {SigninType} from '../model/SigninType';
import {AuthenticationService} from '../service/AuthenticationService';
import {AuthenticationServiceImpl} from '../service/impl/AuthenticationServiceImpl';
import {BaseAuthenticationComponent} from './base-authentication.component';
import {LoadingUtil} from '../../common/util/LoadingUtil';

declare var Base64: any;

@Component({
  selector: 'app-signin',
  templateUrl: '../view/signin.html',
  providers: [AuthenticationServiceImpl, CookieService],
})
export class SigninComponent extends BaseAuthenticationComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute,
      cookieService: CookieService, authenticationService: AuthenticationServiceImpl) {
    super(viewContainerRef, router, route);
    this.authenticationService = authenticationService;
    this.cookieService = cookieService;
  }

  authenticationService: AuthenticationService;
  cookieService: CookieService;
  user: SigninInfo = {
    userName: '',
    password: ''
  };

  txtUserName: any;
  txtPassword: any;
  chkRemember: any;
  remember: boolean;

  initForm() {
    this.autoInitForm();
    this.txtUserName = UIUtil.getControlFromForm(this.form, 'userName');
    this.txtPassword = UIUtil.getControlFromForm(this.form, 'password');
    this.chkRemember = UIUtil.getControlFromForm(this.form, 'remember');
  }

  initData() {
    const str = this.cookieService.get('data');
    if (!!str && str.length > 0) {
      try {
        const tmp: any = JSON.parse(Base64.decode(str));
        this.user.userName = tmp.userName;
        this.user.password = tmp.password;
        this.remember = true;
      } catch (error) {
      }
    }
  }

  forgotPassword() {
    this.navigate('forgot-password');
  }

  signup() {
    this.navigate('signup');
  }

  signin() {
    let valid = true;
    if (UIUtil.isEmpty(this.txtUserName)) {
      valid = false;
      const message = ResourceManager.format('error_required', 'user_userName');
      this.showDanger(message);
    } else if (UIUtil.isEmpty(this.txtPassword)) {
      valid = false;
      const message = ResourceManager.format('error_required', 'user_password');
      this.showDanger(message);
    }
    if (valid === false) {
      return;
    }

    LoadingUtil.showLoading();

    this.authenticationService.authenticate(this.user).subscribe((result: SigninResult) => {
      LoadingUtil.hideLoading();
      const status = result.status;
      if (status === SigninStatus.Success || status === SigninStatus.Reactivate) {
        if (this.chkRemember.checked === true) {
          const data = {
            userName: this.txtUserName.value,
            password: this.txtPassword.value
          };
          const expiredDate = DateUtil.addDays(DateUtil.now(), 7);
          this.cookieService.set('data', Base64.encode(JSON.stringify(data)), expiredDate);
        } else {
          this.cookieService.delete('data');
        }
        const expiredDays = DateUtil.dayDiff(result.user.passwordExpiredTime, DateUtil.now()) ;
        if (expiredDays > 0) {
          const message2 = ResourceManager.getString('msg_password_expired_soon', expiredDays);
          this.showToast(message2);
        }
        if (status === SigninStatus.Success) {
          storage.setUser(result.user);
          this.navigateToHome();
        } else {
          const message3 = ResourceManager.getString('msg_account_reactivated');
          UIUtil.alertInfo(message3, null, function() {
            storage.setUser(result.user);
            this.navigateToHome();
          });
        }
      } else {
        storage.setUser(null);
        let msg: string;
        switch (status) {
          case SigninStatus.UserNotExisted:
            msg = ResourceManager.getString('fail_authentication');
            break;
          case SigninStatus.WrongPassword:
            msg = ResourceManager.getString('fail_wrong_password');
            break;
          case SigninStatus.PasswordExpired:
            msg = ResourceManager.getString('fail_password_expired');
            break;
          case SigninStatus.Suspended:
            msg = ResourceManager.getString('fail_suspended_account');
            break;
          case SigninStatus.Suspended:
            msg = ResourceManager.getString('fail_blocked_account');
            break;
          case SigninStatus.PasswordNotExisted:
            msg = ResourceManager.getString('fail_unexisted_password');
            break;
          default:
            msg = ResourceManager.getString('fail_authentication');
            break;
        }
        this.showDanger(msg);
      }
    }, err => {
      this.handleError(err);
    });
  }
}
