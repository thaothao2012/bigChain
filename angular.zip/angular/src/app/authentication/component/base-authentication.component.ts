import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BaseComponent} from '../../core';

export class BaseAuthenticationComponent extends BaseComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute) {
    super(viewContainerRef, router, route);
  }
}
