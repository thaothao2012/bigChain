import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BaseAuthenticationComponent} from './base-authentication.component';

@Component({
  selector: 'app-welcome',
  templateUrl: '../view/welcome.html',
})
export class WelcomeComponent extends BaseAuthenticationComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute) {
    super(viewContainerRef, router, route);
  }

  signup() {
    this.navigate('signup');
  }

  signin() {
    this.navigate('signin');
  }
}
