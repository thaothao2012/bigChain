import {Component, OnInit, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, storage, StringUtil} from '../../core';
import {IntegrationConfiguration} from '../model/IntegrationConfiguration';
import {SigninType} from '../model/SigninType';
import {AuthenticationServiceImpl} from '../service/impl/AuthenticationServiceImpl';
import {IntegrationConfigurationServiceImpl} from '../service/impl/IntegrationConfigurationServiceImpl';
import {BaseAuthenticationComponent} from './base-authentication.component';

@Component({
  selector: 'app-connect',
  templateUrl: '../view/connect.html',
})
export class ConnectComponent extends BaseAuthenticationComponent implements OnInit {
  constructor(
    viewContainerRef: ViewContainerRef,
    router: Router, route: ActivatedRoute,
    private integrationConfigurationServiceImpl: IntegrationConfigurationServiceImpl,
    private authenticationService: AuthenticationServiceImpl
  ) {
    super(viewContainerRef, router, route);
  }

  private integrationConfigurations: IntegrationConfiguration[] = [];

  ngOnInit(): void {
    this.running = true;
    this.integrationConfigurationServiceImpl.getAll().subscribe(integrationConfigurations => {
      this.integrationConfigurations = integrationConfigurations;
    }, error => {
      this.running = false;
      console.log(error);
    }, () => {
      this.running = false;
      super.ngOnInit();
    });
  }

  public connect(signInType: string) {
    if (!signInType) {
      return;
    }

    const integrationConfig = this.getIntegrationConfiguration(signInType);
    if (!integrationConfig) {
      this.message = StringUtil.format(ResourceManager.getString('msg_set_integration_information'), signInType);
      return;
    }

    let url;
    if (signInType === SigninType.Google) {
      url = 'https://accounts.google.com/o/oauth2/auth?client_id=' + integrationConfig.clientId + '&response_type=code&redirect_uri='
        + storage.getRedirectUrl()
        + '&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&include_granted_scopes=true';
    } else if (signInType === SigninType.LinkedIn) {
      url = 'https://www.linkedin.com/oauth/v2/authorization?client_id=' + integrationConfig.clientId + '&response_type=code&redirect_uri='
        + storage.getRedirectUrl()
        + '&state=Rkelw7xZWQlV7f8d&scope=r_basicprofile%20r_emailaddress';
    } else if (signInType === SigninType.Facebook) {
      url = 'https://www.facebook.com/v2.5/dialog/oauth?client_id=' + integrationConfig.clientId + '&redirect_uri='
        + storage.getRedirectUrl()
        + '&scope=public_profile%2cemail%2cuser_birthday';
    }

    const signInObj: any = {};
    signInObj.redirectUri = storage.getRedirectUrl();
    // signInObj.clientSecret = obj.clientSecret;
    // signInObj.clientId = obj.clientId;
    signInObj.signInType = signInType;
    (window as any).authenticationService = this.authenticationService;

    const left = screen.width / 2 - 300;
    const top = screen.height / 2 - 350;
    // window.signInType = signInType;
    const win = window.open(url, '', 'top=' + top + ',left=' + left + ', width=600, height=700');

    const interval = window.setInterval(function () {
      try {
        if (win == null || win.closed) {
          window.clearInterval(interval);
          let code = localStorage.getItem('code');
          if (!StringUtil.isEmpty(code)) {
            // $scope.showLoading();
            if (signInObj.signInType === SigninType.Google) {
              code = encodeURIComponent(code);
            }
            signInObj.code = code;
            /*// if wanna signin by meshwork admin
            if (searchObject && !StringUtil.isNullOrEmpty(searchObject.role) && searchObject.role.toLowerCase() == 'admin') {
              signInObj.isMeshworkAdmin = true;
            }*/
            // sessionStorage.setItem('signInType', $scope.type);
            console.log(signInObj);
            console.log(this);

            (window as any).authenticationService.authenticateByOAuth2(signInObj).subscribe(res => {
              //
              console.log(res);
            });
            // $scope.service.signin(signInObj, userSuccessCB, userErrorCB, true);
          } else {
            // $scope.hideLoading();
          }
        }
      } catch (e) {
        // $scope.hideLoading();
      }
    }, 1000);
  }

  private getIntegrationConfiguration(type: string): IntegrationConfiguration {
    for (const integrationConfiguration of this.integrationConfigurations) {
      if (integrationConfiguration.sourceType === type) {
        return integrationConfiguration;
      }
    }
    return null;
  }
}
