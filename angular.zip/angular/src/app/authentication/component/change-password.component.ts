import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, storage, UIUtil} from '../../core';
import {PasswordChange} from '../model/PasswordChange';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {PasswordService} from '../service/PasswordService';
import {BaseAuthenticationComponent} from './base-authentication.component';
import {LoadingUtil} from '../../common/util/LoadingUtil';

@Component({
  selector: 'app-change-password',
  templateUrl: '../view/change-password.html',
})
export class ChangePasswordComponent extends BaseAuthenticationComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, passwordService: PasswordServiceImpl) {
    super(viewContainerRef, router, route);
    this.passwordService = passwordService;
  }

  passwordService: PasswordService;
  user: PasswordChange = {
    userName: storage.getUserName(),
    currentPassword: '',
    newPassword: ''
  };

  txtCurrentPassword: any;
  txtNewPassword: any;
  txtConfirmPassword: any;

  initForm() {
    this.autoInitForm();
    this.txtCurrentPassword = UIUtil.getControlFromForm(this.form, 'currentPassword');
    this.txtNewPassword = UIUtil.getControlFromForm(this.form, 'newPassword');
    this.txtConfirmPassword = UIUtil.getControlFromForm(this.form, 'confirmPassword');
  }

  changePassword() {
    if (!storage.getUser()) {
      this.navigate('signin');
      return;
    }
    if (UIUtil.isEmpty(this.txtNewPassword)) {
      const msg = ResourceManager.format('error_required', 'user_password');
      this.showDanger(msg);
      return;
    } else {
      if (UIUtil.isEmpty(this.txtCurrentPassword)) {
        const msg = ResourceManager.format('error_required', 'user_password');
        this.showDanger(msg);
        return;
      }
      if (!UIUtil.equalsValue(this.txtNewPassword, this.txtConfirmPassword)) {
        const msg = ResourceManager.format('error_required', 'error_confirmed_password');
        this.showDanger(msg);
        return;
      }
    }
    LoadingUtil.showLoading();

    this.passwordService.changePassword(this.user).subscribe((success) => {
      LoadingUtil.hideLoading();
      if (success) {
        const msg = ResourceManager.getString('success_change_password');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_change_password');
        this.showDanger(msg);
      }
    });
  }

  signin() {
    this.navigate('signin');
  }
}
