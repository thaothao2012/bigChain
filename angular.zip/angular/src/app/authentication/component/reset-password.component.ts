import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, UIUtil} from '../../core';
import {PasswordReset} from '../model/PasswordReset';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {PasswordService} from '../service/PasswordService';
import {BaseAuthenticationComponent} from './base-authentication.component';
import {LoadingUtil} from '../../common/util/LoadingUtil';

@Component({
  selector: 'app-reset-password',
  templateUrl: '../view/reset-password.html',
})
export class ResetPasswordComponent extends BaseAuthenticationComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, passwordService: PasswordServiceImpl) {
    super(viewContainerRef, router, route);
    this.passwordService = passwordService;
  }

  passwordService: PasswordService;
  user: PasswordReset = {
    userName: '',
    passcode: '',
    newPassword: ''
  };

  txtUserName: any;
  txtPasscode: any;
  txtNewPassword: any;
  txtConfirmPassword: any;

  initForm() {
    this.autoInitForm();
    this.txtUserName = UIUtil.getControlFromForm(this.form, 'userName');
    this.txtPasscode = UIUtil.getControlFromForm(this.form, 'passcode');
    this.txtNewPassword = UIUtil.getControlFromForm(this.form, 'newPassword');
    this.txtConfirmPassword = UIUtil.getControlFromForm(this.form, 'confirmPassword');
  }

  resetPassword() {
    let valid = true;
    if (UIUtil.isEmpty(this.txtUserName)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'user_userName');
      this.showDanger(msg);
    } else if (UIUtil.isEmpty(this.txtPasscode)) {
      valid = false;
      const msg =  ResourceManager.getString('error_required_passcode');
      this.showDanger(msg);
    } else if (UIUtil.isEmpty(this.txtNewPassword)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'user_newPassword');
      this.showDanger(msg);
    } else if (!UIUtil.equalsValue(this.txtNewPassword, this.txtConfirmPassword)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'error_confirmed_password');
      this.showDanger(msg);
    }
    if (!valid) {
      return;
    }
    LoadingUtil.showLoading();
    this.passwordService.resetPassword(this.user).subscribe((result) => {
      LoadingUtil.hideLoading();
      if (result) {
        const msg = ResourceManager.getString('success_reset_password');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_reset_password');
        this.showDanger(msg);
      }
    }, err => {
      this.handleError(err);
    });
  }

  public isEmpty(ctrl) {
    if (!ctrl) { return true; }
    const str = ctrl.trim();
    return (!str || str === '');
  }

  signin() {
    this.navigate('signin');
  }
}
