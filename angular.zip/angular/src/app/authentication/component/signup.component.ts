import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, StringUtil, UIUtil} from '../../core';
import {UserRegistration} from '../model/UserRegistration';
import {UserRegistrationServiceImpl} from '../service/impl/UserRegistrationServiceImpl';
import {UserRegistrationService} from '../service/UserRegistrationService';
import {BaseAuthenticationComponent} from './base-authentication.component';
import {LoadingUtil} from '../../common/util/LoadingUtil';

@Component({
  selector: 'app-signup',
  templateUrl: '../view/signup.html',
})
export class SignupComponent extends BaseAuthenticationComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, userRegistrationService: UserRegistrationServiceImpl) {
    super(viewContainerRef, router, route);
    this.userRegistrationService = userRegistrationService;
  }

  userRegistrationService: UserRegistrationService;
  user: UserRegistration = {
    userName: '',
    password: '',
    email: ''
  };

  txtEmail: any;
  txtUserName: any;
  txtPassword: any;
  chkRemember: any;

  initForm() {
    this.autoInitForm();
    this.txtUserName = UIUtil.getControlFromForm(this.form, 'userName');
    this.txtPassword = UIUtil.getControlFromForm(this.form, 'password');
    this.chkRemember = UIUtil.getControlFromForm(this.form, 'remember');
  }

  signup() {
  if (!StringUtil.isEmail(this.txtUserName.value)) {
    const msg = ResourceManager.format('error_required', 'error_email');
    this.showDanger(msg);
    return;
  }
  if (UIUtil.isEmpty(this.txtUserName)) {
    const msg = ResourceManager.format('error_required', 'user_email');
    this.showDanger(msg);
    return;
  } else {
    if (UIUtil.isEmpty(this.txtPassword)) {
    const msg = ResourceManager.format('error_required', 'user_password');
    this.showDanger(msg);
    return;
    }
  }
  LoadingUtil.showLoading();
  this.user.email = this.txtUserName.value;
  this.userRegistrationService.registerUser(this.user).subscribe((result) => {
    LoadingUtil.hideLoading();
    if (result.success) {
    const msg = ResourceManager.getString('success_sign_up');
    this.showInfo(msg);
    } else {
    let message = '';
    for (let i = 0; i < result.errors.length; i++) {
      message += result.errors[i].message;
    }
    this.showDanger(message);
    }
  });
  }

  signin() {
  this.navigate('signin');
  }
}
