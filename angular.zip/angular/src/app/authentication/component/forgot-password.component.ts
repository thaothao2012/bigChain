import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, UIUtil} from '../../core';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {PasswordService} from '../service/PasswordService';
import {BaseAuthenticationComponent} from './base-authentication.component';
import {LoadingUtil} from '../../common/util/LoadingUtil';

@Component({
  selector: 'app-forgot-password',
  templateUrl: '../view/forgot-password.html',
})
export class ForgotPasswordComponent extends BaseAuthenticationComponent {
  user: any = {};

  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, passwordService: PasswordServiceImpl) {
    super(viewContainerRef, router, route);
    this.passwordService = passwordService;
  }

  passwordService: PasswordService;
  txtEmail: any;

  initForm() {
    this.autoInitForm();
    this.txtEmail = UIUtil.getControlFromForm(this.form, 'email');
  }

  forgotPassword() {
    if (UIUtil.isEmpty(this.txtEmail)) {
      const msg = ResourceManager.format('error_required', 'user_email');
      this.showDanger(msg);
      return;
    }
    LoadingUtil.showLoading();
    this.passwordService.forgotPassword(this.txtEmail.value).subscribe((result) => {
      LoadingUtil.hideLoading();
      if (result) {
        const msg =  ResourceManager.getString('success_forgot_password');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_forgot_password');
        this.showDanger(msg);
      }
    });
  }

  signin() {
    this.navigate('signin');
  }

  resetPassword() {
    this.navigate('reset-password');
  }
}
