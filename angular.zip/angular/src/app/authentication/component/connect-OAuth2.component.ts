import {Component, OnInit, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {IntegrationConfigurationServiceImpl} from '../service/impl/IntegrationConfigurationServiceImpl';
import {BaseAuthenticationComponent} from './base-authentication.component';

@Component({
  selector: 'app-connect',
  templateUrl: '../view/connect-oAuth2.html'
})
export class ConnectOAuth2Component extends BaseAuthenticationComponent implements OnInit {
  constructor(viewContainerRef: ViewContainerRef, router: Router, activeRoute: ActivatedRoute, private integrationConfigurationServiceImpl: IntegrationConfigurationServiceImpl) {
    super(viewContainerRef, router, activeRoute);
  }

  ngOnInit(): void {
    this.activeRoute.queryParams.subscribe(queryParams => {
      if (queryParams.error === undefined) {
        localStorage.setItem('code', queryParams.code);
      }
      window.close();
    });
  }
}
