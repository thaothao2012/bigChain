import { Component, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import {SignoutService, SignoutServiceImpl} from '../shared/signout-service';
import config from '../../config';
import { BaseComponent, storage, WebClientUtil } from '../core';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'default-layout',
  templateUrl: './default-layout.html',
  // styleUrls: [
  //       '../css/angular-material-override.css',
  //       '../css/mine.css',
  //       '../css/custome-style.css',
  //       '../css/mine-mobile.css',
  //       '../css/theme-mobile.css'
  //       ]
  // providers: [SignoutServiceImpl],
})
export class DefaultLayoutComponent extends BaseComponent {
  public logInUser: any = { userId: 1 };
  public isShowSearchResult = false;

  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute) {
    super(viewContainerRef, router, route);
    // this.signoutService = signoutService;
  }

  // signoutService: SignoutService;
  se: any = {};
  pageSize = 10;
  pageSizes = [10, 20, 40, 60, 100, 200, 400, 10000];

  initData() {

  }

  searchOnClick() {
    alert('test');
  }

  signout() {
    /*
    this.signoutService.signout(GlobalApps.getUserName()).subscribe(success => {
      if (success === true) {
        this.navigate('signin');
      }
    }, err => {
      this.handleError(err);
    });
    */
    /*
     const url = config.authenticationServiceUrl + '/authentication/signout/' + GlobalApps.getUserName();
     WebClientUtil.get(this.http, url).subscribe(
       success => {
         if (success) {
           sessionStorage.setItem('authService', null);
           sessionStorage.clear();
           GlobalApps.setUser(null);
           this.navigate('signin');
         }
       },
       err => this.handleError(err)
     );
     */
    sessionStorage.setItem('authService', null);
    sessionStorage.clear();
    storage.setUser(null);
    this.navigate('signin');
  }

  routeIsActive(routePath: string, params: any) {
    //  let currentRoute = this.router.urlTree.firstChild(this.router.urlTree.root);
    //  // e.g. 'Login' or null if route is '/'
    //  let segment = !currentRoute ? '/' : currentRoute.segment;
    //  return  segment == routePath;
    return false;
  }

  activeWithPath(path) {
    return this.router.url === path ? 'active' : '';
  }

  gotoUserList() {
    this.navigate('users');
  }
  gotoAccessGroupList() {
    this.navigate('access/accessGroup/search');
  }
  gotoPayerList() {
    this.navigate('setup/payer/search');
  }
  gotoPayeeList() {
    this.navigate('setup/payee/search');
  }

  gotoBankList() {
    this.navigate('setup/bank/search');
  }

  gotoPaymentAccountList(){
    this.navigate('setup/paymentAccount/search');
  }

  gotoAccessRoleAssignmentList() {
    this.navigate('access/accessRole/search');
  }

  gotoCurrentUser() {
    this.navigate('user', this.logInUser.userId);
  }

  changeMyPassword() {
    this.navigate('mypassword');
  }

  viewMyProfile() {
    this.navigate('myprofile');
  }

  viewMySettings() {
    this.navigate('mysettings');
  }
}
