import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {DefaultLayoutComponent} from './container/default-layout.component';
import {AuthorizationRequiredService} from './core';
import {Error404Component} from './core/error404/error-404.component';

const routes: Routes = [
  {path: '', redirectTo: '/', pathMatch: 'full'},
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },
    canActivate: [AuthorizationRequiredService],
    children: [
      {
        path: 'access',
        loadChildren: './access/access.module#AccessModule'
      },
      {
        path: 'setup',
        loadChildren: './setup/setup.module#SetupModule'
      },
      {
        path: '',
        loadChildren: './myprofile/my-profile.module#MyProfileModule'
      },
      {
        path: 'articles',
        loadChildren: './article/article.module#ArticleModule'
      },
      {
        path: 'reporting-engine',
        loadChildren: './report/fee-detail-report.module#FeeDetailReportModule'
      },
    ]
  },
  // {path: '', component: TemplatesComponent},
  // {path: 'users', loadChildren: './user/UsersModule#UsersModule'},
  {path: '', loadChildren: './authentication/authentication.module#AuthenticationModule'},
  {path: '404', component: Error404Component},

  // otherwise redirect to 404
  {path: '**', redirectTo: '/' + '404'}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {
}
