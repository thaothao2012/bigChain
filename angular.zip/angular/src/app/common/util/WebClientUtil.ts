import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {storage} from '../storage';

export class WebClientUtil {
  private static getHttpOptions(): {
    headers?: HttpHeaders
  } {
    const token = storage.getToken();
    if (token === null) {
      return {
        headers: new HttpHeaders({'Content-Type': 'application/json'})
      };
    } else {
      return {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + token
        })
      };
    }
  }

  public static get(http: HttpClient, url: string): Observable<Object> {
    return http.get(url, this.getHttpOptions());
  }

  public static getObject<T>(http: HttpClient, url: string): Observable<T> {
    return http.get<T>(url, this.getHttpOptions());
  }

  public static postObject<T>(http: HttpClient, url: string, obj: any): Observable<T> {
    return http.post<T>(url, obj, this.getHttpOptions());
  }

  public static postRequest(http: HttpClient, url: string, obj: any): Observable<Object> {
    return http.post(url, obj, this.getHttpOptions());
  }

  public static putRequest(http: HttpClient, url: string, obj: any): Observable<Object> {
    return http.put(url, obj, this.getHttpOptions());
  }

  public static putObject<T>(http: HttpClient, url: string, obj: any): Observable<T> {
    return http.put<T>(url, obj, this.getHttpOptions());
  }
}
