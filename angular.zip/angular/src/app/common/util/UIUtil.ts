// import {DOM} from 'angular2/src/platform/dom/dom_adapter';
import {Locale} from '../locale/model/Locale';
import {ResourceManager} from '../ResourceManager';
import {DateUtil} from './DateUtil';
import {NumberUtil} from './NumberUtil';
import {StringUtil} from './StringUtil';

declare var sysToast: any;
declare var sysAlert: any;
declare var sysIcon: any;
declare var sysMessage: any;
declare var sysErrorDetail: any;
declare var sysErrorDetailText: any;
declare var sysNo: any;
declare var sysLoading: any;

declare var _fyesOnClick: any;
declare var _fnoOnClick: any;
declare var sysErrorDetailCaret: any;
declare var sysDatePicker: any;
declare var jQuery: any;
declare var $: any;

export enum AlertIconType {
  Error = 'Error',
  Warning = 'Warning',
  Success = 'Success',
  Info = 'Info'
}

export enum AlertType {
  Confirm = 'Confirm',
  Alert = 'Alert'
}

export class UIUtil {
  private static ENTER: '\r\n';
  private static _nreg = / |,|\$|\€|\£|\£|¥/g;
  private static _preg = / |,|%|\$|\€|\£|\£|¥/g;
  private static _creg = / |,|\$|\€|\£|\£|¥/g;
  public static validation_error_class = 'error-control';
  public static validation_valid_class = 'valid-control';
  private static _button = 'BUTTON';
  private static _reset = 'RESET';
  private static _submit = 'SUBMIT';

  public static getValue(ctrl, locale?: Locale, eventType?: string): { mustChange: any, value?: any } {
    if (ctrl.type === 'checkbox') {
      const ctrlOnValue = ctrl.getAttribute('data-on-value');
      const ctrlOffValue = ctrl.getAttribute('data-off-value');
      if (ctrlOnValue && ctrlOffValue) {
        const onValue = ctrlOnValue ? ctrlOnValue : true;
        const offValue = ctrlOffValue ? ctrlOffValue : false;
        return ctrl.checked === true ? { mustChange: true, value: onValue } : { mustChange: true, value: offValue };
      } else {
        return ctrl.checked === true ? { mustChange: true, value: true } : { mustChange: true, value: false };
      }
    } else {
      const datatype = ctrl.getAttribute('data-type');
      if (datatype === 'number' || datatype === 'int') {
        const v: any = ctrl.value.replace(this._nreg, '');
        return isNaN(v) ? { mustChange: false } : { mustChange: true, value: parseFloat(v) };
      } else if (datatype === 'currency' || datatype === 'string-currency') {
        const res: any = UIUtil.getStringCurrency(ctrl.value, datatype, locale, ctrl.getAttribute('maxlength'), eventType === 'blur');
        return res;
      } else {
        return { mustChange: true, value: ctrl.value };
      }
    }
  }

  private static getStringCurrency(value: string, datatype: string, locale: Locale, maxLength?: number, isOnBlur?: boolean): { mustChange: any, value?: string } {
    value = value.replace(this._creg, '');
    if (value === '') {
      return { mustChange: true, value: '' };
    }
    value = this.extractNumber(value);
    if (value.length === 0) {
      return { mustChange: false };
    } else if (value.length > 0 && value.charAt(0) === '0') {
      return { mustChange: true, value: value.substring(1) };
    }

    const currencyDecimalDigits = locale ? locale.currencyDecimalDigits : 2;
    const groupDigits = 3; // TODO in database locale don't have data
    const decimalSeparator = '.';
    const thousandsSeparator = ',';

    if (isOnBlur) {
      const number = Number(value.replace(/^0+/, ''));
      if (number === 0) {
        return { mustChange: true, value: '' };
      } else {
        value = number.toFixed(currencyDecimalDigits);
      }
    }

    const dotPosition = value.indexOf(decimalSeparator);
    // Format thousands
    let beforeDot = dotPosition > -1 ? value.substr(0, dotPosition) : value;
    if (datatype === 'string-currency' || isOnBlur) {
      beforeDot = beforeDot.replace(new RegExp('\\B(?=(\\d{' + groupDigits + '})+(?!\\d))', 'g'), thousandsSeparator);
    }

    // Cut after dot
    let afterDot;
    if (dotPosition > 0) {
      afterDot = value.substr(dotPosition + 1);
      if (afterDot.length > currencyDecimalDigits) {
        afterDot = afterDot.substr(0, currencyDecimalDigits);
      }
    }
    if (beforeDot.length > maxLength - (currencyDecimalDigits + 1)) {
      return { mustChange: false };
    }

    value = dotPosition > -1 ? beforeDot + decimalSeparator + afterDot : beforeDot;
    return maxLength && value.length > maxLength ? { mustChange: false } : { mustChange: true, value };
  }

  private static extractNumber(str: string): string {
    const arrs: string[] = [];
    let d = false;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charAt(i);  // get char
      if (ch >= '0' && ch <= '9') {
        arrs.push(ch);
      } else if (ch === '.') {
        if (d) {
          return arrs.join('');
        } else {
          d = true;
          arrs.push(ch);
        }
      } else {
        return arrs.join('');
      }
    }
    return arrs.join('');
  }

  public static getLabel(input) {
    if (!input || input.getAttribute('type') === 'hidden') {
      return '';
    }
    let label = input.getAttribute('label');
    if (label) {
      return label;
    } else if (!label || label.length === 0) {
      let key = input.getAttribute('key');
      if (!key || key.length === 0) {
        key = input.getAttribute('resource-key');
      }
      if (key !== null && key.length > 0) {
        label = ResourceManager.getString(key);
        input.setAttribute('label', label);
        return label;
      } else {
        return UIUtil.getLabelFromContainer(input);
      }
    } else {
      return UIUtil.getLabelFromContainer(input);
    }
  }

  private static getLabelFromContainer(input) {
    const parent = UIUtil.getControlContainer(input);
    if (parent && parent.nodeName === 'LABEL' && parent.childNodes.length > 0) {
      const first = parent.childNodes[0];
      if (first.nodeType === 3) {
        return first.nodeValue;
      }
    } else if (parent && parent.nodeName !== 'LABEL') {
      if (parent.classList.contains('form-group')) {
        const firstChild = parent.firstChild;
        if (firstChild.nodeName === 'LABEL') {
          return firstChild.innerHTML;
        } else {
          return '';
        }
      } else {
        const node = parent.parentElement;
        if (node && node.nodeName === 'LABEL' && node.childNodes.length > 0) {
          const first = node.childNodes[0];
          if (first.nodeType === 3) {
            return first.nodeValue;
          }
        }
      }
    }
    return '';
  }

  public static confirm(msg, yesCallback: Function = null, noCallback: Function = null) {
    this.showAlert(msg, null, AlertType.Confirm, AlertIconType.Warning, yesCallback, noCallback);
  }

  public static alertError(msg, detail: string = null, callback: Function = null) {
    this.showAlert(msg, detail, AlertType.Alert, AlertIconType.Error, callback, null);
  }

  public static alertWarning(msg, detail: string = null, callback: Function = null) {
    this.showAlert(msg, detail, AlertType.Alert, AlertIconType.Warning, callback, null);
  }

  public static alertInfo(msg, detail: string = null, callback: Function = null) {
    this.showAlert(msg, detail, AlertType.Alert, AlertIconType.Info, callback, null);
  }

  public static alertSuccess(msg, detail: string = null, callback: Function = null) {
    this.showAlert(msg, detail, AlertType.Alert, AlertIconType.Success, callback, null);
  }

  public static showDatePicker() {
    sysDatePicker.style.display = 'block';
  }

  public static showAlert(msg, detail?: string, type?: AlertType, iconType?: AlertIconType,
    yesCallback?: Function, noCallback?: Function) {
    if (type === AlertType.Confirm) {
      sysNo.style.display = 'inline-block';
    } else {
      sysNo.style.display = 'none';
    }
    if (!detail) {
      sysErrorDetailCaret.style.display = 'none';
      sysErrorDetail.style.display = 'none';
      sysErrorDetailText.innerHTML = '';
    } else {
      sysErrorDetailCaret.style.display = 'inline-block';
      sysErrorDetail.style.display = 'inline-block';
      sysErrorDetailText.innerHTML = StringUtil.encodeHtml(detail);
    }

    sysMessage.innerHTML = StringUtil.encodeHtml(msg);
    if (iconType === AlertIconType.Error) {
      sysIcon.classList.remove('sa-warning');
      sysIcon.classList.remove('sa-info');
      sysIcon.classList.remove('sa-success');
      sysIcon.classList.remove('animate');
      if (!sysIcon.classList.contains('sa-error')) {
        sysIcon.classList.add('sa-error');
      }
      sysIcon.innerHTML = '<span class="sa-x-mark"><span class="sa-line sa-left"></span><span class="sa-line sa-right"></span></span>';
    } else if (iconType === AlertIconType.Info) {
      sysIcon.classList.remove('sa-error');
      sysIcon.classList.remove('sa-warning');
      sysIcon.classList.remove('sa-success');
      sysIcon.classList.remove('animate');
      if (!sysIcon.classList.contains('sa-info')) {
        sysIcon.classList.add('sa-info');
      }
      sysIcon.innerHTML = '';
    } else if (iconType === AlertIconType.Warning) {
      sysIcon.classList.remove('sa-error');
      sysIcon.classList.remove('sa-info');
      sysIcon.classList.remove('sa-success');
      sysIcon.classList.remove('animate');
      if (!sysIcon.classList.contains('sa-warning')) {
        sysIcon.classList.add('sa-warning');
      }
      sysIcon.innerHTML = '<span class="sa-body"></span><span class="sa-dot"></span>';
    } else {
      sysIcon.classList.remove('sa-error');
      sysIcon.classList.remove('sa-warning');
      sysIcon.classList.remove('sa-info');
      if (!sysIcon.classList.contains('sa-success')) {
        sysIcon.classList.add('sa-success');
      }
      if (!sysIcon.classList.contains('animate')) {
        sysIcon.classList.add('animate');
      }
      sysIcon.innerHTML = '<span class="sa-line sa-tip animateSuccessTip"></span><span class="sa-line sa-long animateSuccessLong"></span><div class="sa-placeholder"></div><div class="sa-fix"></div>';
    }
    sysAlert.style.display = 'block';
    _fyesOnClick = yesCallback;
    _fnoOnClick = noCallback;
  }

  public static showToast(msg) {
    sysToast.innerHTML = msg;
    const ui = this;
    ui.fadeIn(sysToast);
    setTimeout(function () {
      ui.fadeOut(sysToast);
    }, 1340);
  }

  public static fadeOut(el) {
    el.style.opacity = 1;
    (function fade() {
      if ((el.style.opacity -= .1) < 0) {
        el.style.display = 'none';
      } else {
        requestAnimationFrame(fade);
      }
    })();
  }

  public static fadeIn(el, display = null) {
    el.style.opacity = 0;
    el.style.display = display || 'block';

    (function fade() {
      let val = parseFloat(el.style.opacity);
      if (!((val += .1) > 1)) {
        el.style.opacity = val;
        requestAnimationFrame(fade);
      }
    })();
  }

  public static formatObject(obj, form) {
    if (form != null && obj != null) {
      for (let i = 0; i < form.length; i++) {
        const ctrl = form[i];
        const name = ctrl.getAttribute('name');
        const collection = ctrl.getAttribute('collection');
        if (name != null && name !== '') {
          if (!collection) {
            const val: any = obj[name];
            const datatype = ctrl.getAttribute('datatype');
            if (val != null) {
              if (val instanceof Date && datatype === 'date') {
                let dateFormat = ctrl.getAttribute('date-format');
                if (!dateFormat || dateFormat.length === 0) {
                  dateFormat = ctrl.getAttribute('uib-datepicker-popup');
                }
                if (!dateFormat || dateFormat.length === 0) {
                  dateFormat = ctrl.getAttribute('datepicker-popup');
                }
                if (!!dateFormat && dateFormat.length > 0) {
                  obj[name] = DateUtil.formatDate(val, dateFormat);
                }
              } else if (typeof val === 'number') {
                if (datatype === 'currency') {
                  let symbol = form.currencySymbol;
                  let pattern = form.currencyPattern;
                  let scale = form.currencyDecimalDigits;
                  if (!symbol) {
                    symbol = '$';
                  }
                  if (!pattern) {
                    pattern = 0;
                  }
                  if (!scale) {
                    scale = 2;
                  }
                  const val2 = NumberUtil.formatNumber(val, scale);
                  switch (pattern) {
                    case 0:
                      obj[name] = symbol + val2;
                      break;
                    case 1:
                      obj[name] = '' + val2 + symbol;
                      break;
                    case 2:
                      obj[name] = symbol + ' ' + val2;
                      break;
                    case 3:
                      obj[name] = '' + val2 + ' ' + symbol;
                      break;
                    default:
                      obj[name] = symbol + val2;
                      break;
                  }
                } else {
                  const val2: any = this._formatNumber(ctrl, val);
                  if (datatype === 'number' || datatype === 'int') {
                    if (val !== val2) {
                      obj[name] = val2;
                    }
                  } else if (datatype === 'percent') {
                    obj[name] = '' + val2 + '%';
                  }
                }
              } else if (typeof val === 'boolean') {
                if (ctrl.getAttribute('type') === 'radio') {
                  if (val === true) {
                    obj[name] = 'true';
                  } else if (val === false) {
                    obj[name] = 'false';
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  private static _formatNumber(ctrl, val): any {
    const numFormat = ctrl.getAttribute('number-format');
    if (numFormat != null) {
      if (numFormat.indexOf('number') === 0) {
        const strNums = numFormat.split(':');
        if (strNums.length > 0 && NumberUtil.isNumber(strNums[1])) {
          const scale = parseInt(strNums[1], null);
          return NumberUtil.formatNumber(val, scale);
        } else {
          return val;
        }
      } else {
        return NumberUtil.format(val, numFormat);
      }
    } else {
      return val;
    }
  }

  public static jsonObject(obj, form) {
    if (form != null && obj != null) {
      for (let i = 0; i < form.length; i++) {
        const ctrl = form[i];
        const name = ctrl.getAttribute('name');
        const collection = ctrl.getAttribute('collection');
        if (!!name && name !== '') {
          if (!collection) {
            const v = obj[name];
            if (!!v && typeof v === 'string') {
              const datatype = ctrl.getAttribute('datatype');
              if (datatype === 'date') {
                let dateFormat = ctrl.getAttribute('date-format');
                if (!dateFormat || dateFormat.length === 0) {
                  dateFormat = ctrl.getAttribute('uib-datepicker-popup');
                }
                if (!dateFormat || dateFormat.length === 0) {
                  dateFormat = ctrl.getAttribute('datepicker-popup');
                }
                if (!v || v === '') {
                  obj[name] = null;
                } else {
                  if (DateUtil.isDate(ctrl.value, dateFormat)) {
                    obj[name] = DateUtil.parse(ctrl.value, dateFormat);
                  }
                }
              } else if (datatype === 'number' || datatype === 'int') {
                this._jsonNumber(obj, name, v, ctrl);
              } else if (datatype === 'currency') {
                let val2 = v.replace(this._creg, '');
                const symbol = form.currencySymbol;
                if (symbol != null) {
                  val2 = val2.replace(symbol, '');
                }
                this._jsonNumber(obj, name, val2, ctrl);
              } else if (datatype === 'percent') {
                const val2 = v.replace(this._preg, '');
                this._jsonNumber(obj, name, val2, ctrl);
              } else if (datatype === 'bool') {
                if (ctrl.getAttribute('type') === 'radio') {
                  if (v === 'false') {
                    obj[name] = false;
                  } else if (v === 'true') {
                    obj[name] = true;
                  } else {
                    obj[name] = null;
                  }
                }
              }
            }
          }
        }
      }
      return obj;
    }
  }

  private static _jsonNumber(obj, name, val, ctrl) {
    const numFormat = ctrl.getAttribute('number-format');
    if (numFormat != null) {
      if (numFormat.indexOf('number') === 0) {
        const strNums = numFormat.split(':');
        if (strNums.length > 0 && NumberUtil.isNumber(strNums[1])) {
          const scale = parseInt(strNums[1], null);
          obj[name] = NumberUtil.parseNumber(val, scale);
        }
      }
    } else {
      obj[name] = NumberUtil.parseNumber(val, 2);
    }
  }

  public static bindToForm(form, obj) {
    for (const f of form) {
      let ctrl = f;
      if (ctrl.name !== null && ctrl.name !== '') {
        let v = obj[ctrl.name];
        if (v === undefined || v === null) {
          v = null;
        }
        ctrl = v;
      }
    }
  }

  public static decodeFromForm(form): any {
    if (!form) {
      return null;
    }
    const obj = {};
    for (let i = 0; i < form.length; i++) {
      const ctrl = form[i];
      const name = ctrl.getAttribute('name');
      const id = ctrl.getAttribute('id');
      if (name != null && name.length > 0) {
        let nodeName = ctrl.nodeName;
        const type = ctrl.getAttribute('type');
        if (nodeName === 'INPUT' && type !== null) {
          nodeName = type.toUpperCase();
        }
        if (nodeName !== 'BUTTON'
          && nodeName !== 'RESET'
          && nodeName !== 'SUBMIT') {
          switch (type) {
            case 'checkbox':
              if (!!id && name !== id) {
                obj[name] = !obj[name] ? [] : obj[name];
                if (ctrl.checked) {
                  obj[name].push(ctrl.value);
                } else {
                  obj[name] = obj[name].filter(item =>
                    item !== ctrl.value);
                }
              } else {
                if (ctrl.checked === 'checked') {
                  obj[name] = true;
                }
              }
              break;
            case 'radio':
              if (ctrl.checked === 'checked') {
                obj[name] = ctrl.value;
              }
              break;
            default:
              obj[name] = ctrl.value;
          }
        }
      }
    }
    return obj;
  }
  public static setReadOnlyForm(form) {
    if (!form) {
      return;
    }
    for (let i = 0; i < form.length; i++) {
      const ctrl = form[i];
      const name = ctrl.getAttribute('name');
      if (name != null && name.length > 0 && name !== 'btnBack') {
        let nodeName = ctrl.nodeName;
        const type = ctrl.getAttribute('type');
        if (nodeName === 'INPUT' && type !== null) {
          nodeName = type.toUpperCase();
        }
        if (nodeName !== 'BUTTON'
          && nodeName !== 'RESET'
          && nodeName !== 'SUBMIT'
          && nodeName !== 'SELECT') {
          switch (type) {
            case 'checkbox':
              ctrl.disabled = true;
              break;
            case 'radio':
              ctrl.disabled = true;
              break;
            default:
              ctrl.readOnly = true;
          }
        } else {
          ctrl.disabled = true;
        }
      }
    }
  }
  public static equalsValue(ctrl1, ctrl2) {
    if (ctrl1 === ctrl2) {
      return true;
    } else {
      return false;
    }
  }

  public static isEmpty(ctrl) {
    if (!ctrl) {
      return true;
    }
    const str = this.trimText(ctrl.value);
    return (str === '');
  }

  public static trim(ctrl) {
    if (!ctrl) {
      return;
    }
    const str = ctrl.value;
    const str2 = this.trimText(ctrl.value);
    if (str !== str2) {
      ctrl.value = str2;
    }
  }

  public static showLoading(isFirstTime) {
    try {
      if ((window as any).sysLoading !== undefined) {
        (window as any).sysLoading.style.display = 'block';
        if (isFirstTime) {
          (window as any).sysLoading.classList.add('dark');
        } else {
          (window as any).sysLoading.classList.remove('dark');
        }
      }
    } catch (er) {
      console.log(er);
    }
  }

  public static hideLoading() {
    try {
      if (sysLoading !== undefined) { sysLoading.style.display = 'none'; }
    } catch (er) { }
  }

  public static focusFirstControl(form) {
    let i = 0;
    const len = form.length;
    for (i = 0; i < len; i++) {
      const ctrl = form[i];
      if (!(ctrl.readOnly || ctrl.disabled)) {
        let nodeName = ctrl.nodeName;
        const type = ctrl.getAttribute('type');
        if (nodeName === 'INPUT' && type !== null) {
          nodeName = type.toUpperCase();
        }
        if (nodeName !== 'BUTTON'
          && nodeName !== 'RESET'
          && nodeName !== 'SUBMIT'
          && nodeName !== 'CHECKBOX'
          && nodeName !== 'RADIO') {
          ctrl.focus();
          ctrl.scrollIntoView();
          try {
            ctrl.setSelectionRange(0, ctrl.value.length);
          } catch (error) {
          }
          return;
        }
      }
    }
  }

  public static focusErrorControl(form) {
    const len = form.length;
    for (let i = 0; i < len; i++) {
      const ctrl = form[i];
      const parent = ctrl.parentElement;
      if (ctrl.classList.contains('invalid')
        || ctrl.classList.contains('.ng-invalid')
        || parent.classList.contains('invalid')) {
        ctrl.focus();
        ctrl.scrollIntoView();
        return;
      }
    }
  }

  public static getControlContainer(control) {
    const p = control.parentElement;
    if (p.nodeName === 'LABEL' || p.classList.contains('form-group')) {
      return p;
    } else {
      const p1 = p.parentElement;
      if (p.nodeName === 'LABEL' || p1.classList.contains('form-group')) {
        return p1;
      } else {
        const p2 = p1.parentElement;
        if (p.nodeName === 'LABEL' || p2.classList.contains('form-group')) {
          return p2;
        } else {
          const p3 = p2.parentElement;
          if (p.nodeName === 'LABEL' || p3.classList.contains('form-group')) {
            return p3;
          } else {
            return null;
          }
        }
      }
    }
  }

  public static getControlFromForm(form, childName) {
    for (const f of form) {
      if (f.name === childName) {
        return f;
      }
    }
    return null;
  }

  public static getControlsFromForm(form, childNames: string[]): any[] {
    const outputs = [];
    for (const f of form) {
      if (!!childNames.find(v => v === f.name)) {
        outputs.push(f);
      }
    }
    return outputs;
  }

  public static getControlByName(ctrl, childName, ctrlType) {
    if (!ctrlType) {
      ctrlType = 'input';
    }
    const jctrl = $(ctrl);
    const selector = '' + ctrlType + '[name=\'' + childName + '\']';
    const sub = jctrl.find(selector);
    return sub[0];
  }

  public static getParentByClass(ctrl, className) {
    if (!ctrl) {
      return null;
    }
    let tmp = ctrl;
    while (true) {
      const parent = tmp.parentElement;
      if (!parent) {
        return null;
      }
      if (parent.classList.contains(className)) {
        return parent;
      } else {
        tmp = parent;
      }
      if (tmp.nodeName === 'BODY') {
        return null;
      }
    }
  }

  public static getParentByNodeNameOrDataField(ctrl, nodeName: string) {
    if (!ctrl) {
      return null;
    }
    let tmp = ctrl;
    while (true) {
      const parent = tmp.parentElement;
      if (!parent) {
        return null;
      }
      if (parent.nodeName === nodeName || parent.getAttribute('data-field') != null) {
        return parent;
      } else {
        tmp = parent;
      }
      if (tmp.nodeName === 'BODY') {
        return null;
      }
    }
  }

  public static getAllDataFields(form): any[] {
    let results = [];
    const attributeValue = form.getAttribute('data-field');
    if (attributeValue && attributeValue.length > 0) {
      results.push(form);
    }
    const childNodes = form.childNodes;
    if (childNodes.length > 0) {
      for (const childNode of childNodes) {
        if (childNode.nodeType === Node.ELEMENT_NODE) {
          results = results.concat(this.getAllDataFields(childNode));
        }
      }
    }
    return results;
  }

  private static trimText(s) {
    if (s === null || s === undefined) {
      return;
    }
    s = s.trim();
    let i = s.length - 1;
    while (i >= 0 && (s.charAt(i) === ' ' || s.charAt(i) === '\t' || s.charAt(i) === '\r' || s.charAt(i) === '\n')) {
      i--;
    }
    s = s.substring(0, i + 1);
    i = 0;
    while (i < s.length && (s.charAt(i) === ' ' || s.charAt(i) === '\t' || s.charAt(i) === '\r' || s.charAt(i) === '\n')) {
      i++;
    }
    return s.substring(i);
  }
}
