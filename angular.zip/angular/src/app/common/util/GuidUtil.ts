import uuidv4 from 'uuid/v4';

export class GuidUtil {
  static newGuid(): string {
    return uuidv4();
  }
}
