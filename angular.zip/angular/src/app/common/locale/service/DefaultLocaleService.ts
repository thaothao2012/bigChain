import LocaleResources from '../LocaleResources';
import {Locale} from '../model/Locale';
import ShortLocaleIdMap from '../ShortLocaleIdMap';
import {LocaleService} from './LocaleService';

export class DefaultLocaleService implements LocaleService {
  private _nreg = / |,|\$|\€|\£|\£|¥/g;

  getLocale(id: string): Locale {
    let locale = this.getLocaleFromResources(id);
    if (locale === null) {
      const newId = ShortLocaleIdMap.get(id);
      locale = this.getLocaleFromResources(newId);
    }
    return locale;
  }

  private getLocaleFromResources(id: string): Locale {
    for (const locale of LocaleResources) {
      if (id === locale.localeId) {
        return locale;
      }
    }
    return null;
  }

  getZeroCurrencyByLanguage(language: string) {
    return this.getZeroCurrency(this.getLocale(language));
  }

  getZeroCurrency(locale: Locale) {
    if (locale) {
      if (locale.currencyDecimalDigits <= 0) {
        return '0';
      } else {
        const start = '0' + locale.decimalSeparator;
        const padLength = start.length + locale.currencyDecimalDigits;
        return this.padRight(start, padLength, '0');
      }
    } else  {
      return '0.00';
    }
  }

  formatCurrency(value: any, locale: Locale): string {
    if (!value) {
      return '';
    }
    const scale = (locale && locale.currencyDecimalDigits && locale.currencyDecimalDigits >= 0 ? locale.currencyDecimalDigits : 2);
    if (typeof value === 'number') {
      value = value.toFixed(scale);
    } else {
      if (typeof value !== 'string') {
        value = value.toString();
      }
    }
    if (isNaN(value) && value.includes('.')) {
      return value;
    } else if (value.indexOf(',') === -1 && value.includes('.')) {
      const prefix = value.split('.')[0];
      if (prefix.length < 3) {
        return value;
      }
    }
    let amount = value.replace(this._nreg, '');
    const delimiter = ',';
    const a = amount.split('.', 2);
    let d = '';
    if (a[0].length === 0) {
      a[0] = '0';
    }
    if (a.length >= 2) {
      d = a[1];
    }
    a[0] = a[0].replace(delimiter, '');
    let i = 0;
    if (!isNaN(a[0])) {
      i = parseInt(a[0], null);
    }
    let minus = '';
    if (i < 0) {
      minus = '-';
    }
    i = Math.abs(i);
    let n = i + '';
    const b = [];

    while (n.length > 3) {
      const nn = n.substring(n.length - 3);
      b.unshift(nn);
      n = n.substring(0, n.length - 3);
    }
    if (n.length > 0) {
      b.unshift(n);
    }
    n = b.join(delimiter);
    if (d.length < 1) {
      amount = n;
    } else {
      amount = n + '.' + d;
    }
    amount = minus + amount;

    return amount;
  }

  private padRight(str, length, pad) {
    if (!str) {
      return str;
    }
    if (typeof str !== 'string') {
      str = '' + str;
    }
    if (str.length >= length) {
      return str;
    }
    let str2 = str;
    if (!pad) {
      pad = ' ';
    }
    while (str2.length < length) {
      str2 = str2 + pad;
    }
    return str2;
  }
}
