import {Locale} from '../model/Locale';

export interface LocaleService {
  getLocale(id: string): Locale;
  getZeroCurrencyByLanguage(language: string);
  getZeroCurrency(locale: Locale);
  formatCurrency(value: any, locale: Locale): string;
}
