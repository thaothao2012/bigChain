import {Module} from './Module';
import {UserAccount} from './UserAccount';

export class DefaultUserAccount implements UserAccount {
  userId: string;
  userName: string;
  email: string;
  displayName: string;
  imageURL?: string;
  passwordExpiredTime: Date;
  token: string;
  tokenExpiredDate: Date;
  newUser: boolean;
  language: string;
  privileges: string[];
  roleType: string;
  modules: Module[];
}
