import {ComponentConfig} from '../config/ComponentConfig';
import {AcceptType} from './AcceptType';

export interface FormConfig {
  name: string;
  acceptState?: string;
  acceptType?: AcceptType;
  components: ComponentConfig[];
}
