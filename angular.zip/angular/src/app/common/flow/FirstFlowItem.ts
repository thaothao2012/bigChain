import {FlowInitializer} from './FlowInitializer';
import {FlowService} from './FlowService';

export interface FirstFlowItem {
  isLoadedInitData(): boolean;
  isFlowInitialized(): boolean;
  getFlowInitializer(): FlowInitializer;
  getFlowService(): FlowService;
}
