export interface Storage {
  get<T>(key: string): T;
  put<T>(key: string, obj: T);
  delete(key: string);
}
