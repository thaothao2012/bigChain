import {Observable} from 'rxjs';

export interface FlowInitializer {
  initialize(): Observable<any>;
}
