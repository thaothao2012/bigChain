import {Language} from '../Language';
import {Locale} from '../locale/model/Locale';
import {Flow} from './Flow';
import {FormConfig} from './FormConfig';

export interface FlowItem {
  init();
  loadData();

  isDisableAccept(): boolean;
  accept(event);
  validateAndSave(event);
  save(event);

  back(event);
  cancel(event);

  getFlowId(): string;
  getFlow(): Flow;
  getFormConfig(): FormConfig;
  getAcceptState(): string;

  getEnv(): any;
  getLanguage(): Language;
  getLocale(): Locale;

  getFromStorage<K>(key: string): K;
  saveToStorage<K>(key: string, obj: K);
  removeFromStorage(key: string);
}
