export enum AcceptType {
  Next = 'next',
  Accept = 'accept'
}
