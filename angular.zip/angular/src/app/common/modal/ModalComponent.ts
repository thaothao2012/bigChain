import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {ModalService} from './ModalService';

@Component({
  selector: 'modal',
  template: `
<div class="modal fade" bsModal #modalComponent="bs-modal" [config]="{backdrop: 'static'}" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" aria-label="Close" id="closeButton">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title">{{title}}</h4>
      </div>
      <div class="modal-body">
        {{message}}
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" id="okButton" [class.hidden]="isHideOkButton()">{{okText}}</button>
        <button type="button" class="btn btn-default" id="cancelButton" [class.hidden]="isHideCancelButton()">{{cancelText}}</button>
      </div>
    </div>
  </div>
</div>
  `
})
export class ModalComponent implements OnInit {
  @ViewChild('modalComponent') public modalComponent: ModalDirective;

  private _defaults = {
    title: 'Title',
    message: 'Message',
    okText: 'OK',
    cancelText: 'Cancel'
  };
  title: string;
  message: string;
  okText: string;
  cancelText: string;
  okCallback: any;
  cancelCallback: any;

  private closeButton: any;
  private okButton: any;
  private cancelButton: any;

  constructor(modalService: ModalService) {
    modalService.activate = this.activate.bind(this);
  }

  setLabels(title = this._defaults.title, message = this._defaults.message, okText = this._defaults.okText, cancelText = null) {
    this.title = title;
    this.message = message;
    this.okText = okText;
    this.cancelText = cancelText;
  }

  setCallback(okCallback = null, cancelCallback = null) {
    this.okCallback = okCallback;
    this.cancelCallback = cancelCallback;
  }

  activate(title = this._defaults.title, message = this._defaults.message, okText = this._defaults.okText, cancelText = null, okCallback = null, cancelCallback = null) {
    this.setLabels(title, message, okText, cancelText);
    this.setCallback(okCallback, cancelCallback);

    const promise = new Promise<boolean>(resolve => {
      this.show(resolve);
    });
    return promise;
  }

  private show(resolve: (boolean) => any) {
    const negativeOnClick = (e: any) => resolve(false);
    const positiveOnClick = (e: any) => resolve(true);

    // if (!this._okButton) return;

    this.okButton.onclick = ((e: any) => {
      e.preventDefault();
      if (!positiveOnClick(e)) {
        this.okButtonClicked();
      }
    });

    this.cancelButton.onclick = ((e: any) => {
      e.preventDefault();
      if (!positiveOnClick(e)) {
        this.cancelButtonClicked();
      }
    });

    this.closeButton.onclick = ((e: any) => {
      e.preventDefault();
      if (!positiveOnClick(e)) {
        this.closeButtonClicked();
      }
    });

    this.showDialog();

  }
  public isHideOkButton() {
    return (this.okText === null);
  }

  public isHideCancelButton() {
    return (this.cancelText === null);
  }

  public okButtonClicked() {
    this.hideDialog();
    if (this.okCallback !== null) {
      this.okCallback();
    }
  }

  public cancelButtonClicked() {
    this.hideDialog();
    if (this.cancelCallback !== null) {
      this.cancelCallback();
    }
  }

  public closeButtonClicked() {
    this.hideDialog();
    if (this.cancelCallback !== null) {
      this.cancelCallback();
    }
  }

  public hideDialog() {
    this.modalComponent.hide();
  }
  public showDialog() {
    this.modalComponent.show();
  }

  ngOnInit(): any {
    this.closeButton = document.getElementById('closeButton');
    this.okButton = document.getElementById('okButton');
    this.cancelButton = document.getElementById('cancelButton');
  }
}
