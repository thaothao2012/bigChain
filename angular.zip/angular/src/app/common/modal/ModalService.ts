import {Injectable} from '@angular/core';

@Injectable()
export class ModalService {
  activate: (title?: string, message?: string, okText?: string, cancelText?: string, okCallback?: any, cancelCallback?: any) => Promise<boolean>;
}
