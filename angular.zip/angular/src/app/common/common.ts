interface Array<T> {
   remove(o: T): Array<T>;
   removeAt(index: number): T;
   contains(o: T);
}

Array.prototype.removeAt = function (index) {
	if (index != null && index >= 0)
		this.splice(index, 1);
	return this;
};
Array.prototype.contains = function(obj) {
    const length = this.length;
    for (let i = 0; i < length; i++) {
        if (obj === this[i])
            return true;
    }
    return false;
};

interface StringConstructor {
    format(): string;
    replaceAll (token:string, newToken:string, ignoreCase:boolean):string;
    bindObject(obj:any);
    contains(it:string):boolean;
    isLong():boolean;
    isULong():boolean;
    isNumber():boolean;
    isUNumber():boolean;
    isInteger():boolean;
    isUInteger():boolean;
    boolean():boolean;
    countWord():number;
    limitChar(charLimit:number):string;
    limitWord(wordLimit:number):string;
};

String.replaceAll = function (token, newToken, ignoreCase) {
    var _token;
    var str = this + '';
    var i = -1;

    if (typeof token === "string") {

        if (ignoreCase) {

            _token = token.toLowerCase();

            while ((
				i = str.toLowerCase().indexOf(
					token, i >= 0 ? i + newToken.length : 0
				)) !== -1
			) {
                str = str.substring(0, i) +
					newToken +
					str.substring(i + token.length);
            }

        } else {
            return this.split(token).join(newToken);
        }

    }
    return str;
};

String.bindObject = function (obj) {
    if (!obj) return this;
    var str = this;
    for (var key in obj) {
        var tem = '{' + key + '}';
        str = str.replaceAll(tem, obj[key]);
    }
    return str;
};
/*Check an string in a string*/
String.contains = function (it):boolean {
    return this.indexOf(it) != -1;
};
String.format = function () {
    var formatted = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        formatted = formatted.replace(regexp, arguments[i]);
    }
    return formatted;
};
String.isLong = function () {
    if (this.length == 0)
        return false;
    else if (this.indexOf('.') >= 0)
        return false;
    else if (isNaN(this))
        return false;
    else {
        return true;
    }
};
String.isULong = function () {
    if (this.length == 0)
        return false;
    else if (this.indexOf('.') >= 0)
        return false;
    else if (isNaN(this))
        return false;
    else {
        if (this >= 0)
            return true;
        else
            return false;
    }
};

String.isNumber = function () {
    if (this.length == 0)
        return false;
    else if (isNaN(this)) {
        return false;
    } else {
        return true;
    }
};

String.isUNumber = function () {
    if (this.length == 0)
        return false;
    else if (isNaN(this)) {
        return false;
    } else {
        if (this >= 0) {
            return true;
        } else {
            return false;
        }
    }
};

String.isInteger = function () {
    if (this.length == 0)
        return false;
    else if (this.indexOf('.') >= 0)
        return false;
    else if (isNaN(this))
        return false;
    else {
        return true;
    }
};

String.isUInteger = function () {
    if (this.length == 0)
        return false;
    else if (this.indexOf('.') >= 0)
        return false;
    else if (isNaN(this))
        return false;
    else {
        if (this >= 0)
            return true;
        else
            return false;
    }
};

String.countWord = function () {
    var text1 = this.toString().replace(/\s+/g, ' ');
    var text2 = text1.split(' ');
    return text2.length;
};

String.limitWord = function (wordLimit:number) {
    var finalText = '';
    var text2 = this.toString().replace(/\s+/g, ' ');
    var text3 = text2.split(' ');
    var numberOfWords = text3.length;
    var i = 0;
    if (numberOfWords > wordLimit) {
        for (i = 0; i < wordLimit; i++)
            finalText = finalText + ' ' + text3[i] + ' ';
        return finalText + '...';
    } else return this.toString();
};

String.limitChar = function (charLimit:number) {
    var finalText = '';
    var text = this.toString().replace(/\s+/g, ' ');
    var numberOfChars = text.length;
    var i = 0;
    if (numberOfChars > charLimit) {
        finalText = text.substring(0, charLimit);
        return finalText + ' ...';
    } else return this.toString();
};