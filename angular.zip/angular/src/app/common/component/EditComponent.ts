import {ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResultInfo} from '../model/ResultInfo';
import {StatusCode} from '../model/StatusCode';
import {ResourceManager} from '../ResourceManager';
import {GenericService} from '../service/GenericService';
import {storage} from '../storage';
import {UIUtil} from '../util/UIUtil';
import {ValidationUtil} from '../util/ValidationUtil';
import {ViewComponent} from './ViewComponent';
import {LoadingUtil} from '../util/LoadingUtil';

export class EditComponent<T> extends ViewComponent<T> {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, protected service: GenericService<T>) {
    super(viewContainerRef, router, route, service);
  }

  setBack = false;
  ignoreCurrentErrorsOfForm = true;
  updateChangedOnly = false;
  addable: boolean;
  editable: boolean;
  deletable: boolean;

  deleteHeader: string = ResourceManager.getString('msg_delete_header');
  deleteConfirm: string = ResourceManager.getString('msg_delete_confirm');
  deleteFailed: string = ResourceManager.getString('msg_delete_failed');

  insertSuccessMsg: string = ResourceManager.getString('msg_save_success');
  updateSuccessMsg: string = ResourceManager.getString('msg_save_success');
  saveSuccessMsg: string = ResourceManager.getString('msg_save_success');

  initPermission() {
    this.viewable = true;
    this.addable = true;
    this.editable = true;
    this.deletable = true;
  }

  loadData() {
    const id = this.getId();
    if (!!id && id !== '') {
      if (this.viewable !== true) {
        // const title = ResourceManager.getString('error_permission');
        const msg = ResourceManager.getString('error_permission_view');
        UIUtil.alertError(msg);
        const user = storage.getUser();
        if (user != null) {
          this.navigateToHome();
        } else {
          this.navigateToSignin();
        }
        return;
      } else {
        this.service.getById(id).subscribe((obj: T) => {
          this.showObject(obj);
        });
        /*
        this.service.getById(id, function (obj) {
          com.showObject(obj);
        }, function (response) {
          com.handleError(response);
        });
        */
      }
    } else {
      this.newOnClick();
    }
  }

  newOnClick() {
    const form = this.form;
    ValidationUtil.removeFormError(form);
    const obj = this.createModel();
    this.setNewMode(true);
    this.setModel(obj);
    setTimeout(function () {
      ValidationUtil.removeFormError(form);
    }, 100);
  }

  showObject(obj) {
    this.hideMessage();
    ValidationUtil.removeFormError(this.form);
    this.setNewMode(false);
    this.setModel(obj);
    this.running = false;
    LoadingUtil.hideLoading();
  }

  protected saveModelToState(model: T) {
    const props: any = this.route;
    if (props.props.setGlobalState) {
      this.orginalModelRedux = model;
      props.props.setGlobalState({[this.form.name]: model});
    } else {
      const modelName = this.getModelName();
      const objSet: any = {};
      objSet[modelName] = model;
      this.showObject(objSet);
      // throw new Error('Component must add setGlobalState: (data) => dispatch(updateGlobalState(data)) into props');
    }
  }

  saveOnClick() {
    if (this.isNewMode() === true && this.addable !== true) {
      // const title = ResourceManager.getString('error_permission');
      const msg = ResourceManager.getString('error_permission_add');
      UIUtil.alertError(msg);
      const user = storage.getUser();
      if (!!user) {
        this.navigateToHome();
      } else {
        this.navigateToSignin();
      }
      return;
    } else if (this.isNewMode() === false && this.editable !== true) {
      // const title = ResourceManager.getString('error_permission');
      const msg = ResourceManager.getString('error_permission_edit');
      UIUtil.alertError(msg);
      const user = storage.getUser();
      if (!!user) {
        this.navigateToHome();
      } else {
        this.navigateToSignin();
      }
      return;
    } else {
      if (this.running === true) {
        return;
      }
      let valid = true;
      if (this.ignoreCurrentErrorsOfForm === true) {
        ValidationUtil.removeFormError(this.form);
      } else {
        valid = ValidationUtil.isValidForm(this.form);
      }
      if (valid === true) {
        const com = this;
        const confirmMsg = ResourceManager.getString('msg_confirm_save');
          if (valid === true) {
            const obj = com.getModel();
            com.validate(obj, () => {
              UIUtil.confirm(confirmMsg, () => {
                console.log('save');
                com.save(obj);
              });
            });
          } else {
            UIUtil.alertWarning('Form invalid...');
          }
      }
    }
  }

  validate(obj, callback: Function) {
    const valid = ValidationUtil.validateForm(this.form);
    if (valid) {
      callback(obj);
    }
  }

  save(obj) {
    this.running = true;
    LoadingUtil.showLoading();
    const com = this;
    if (this.isNewMode() === false) {
      if (this.updateChangedOnly === true) {
        /*
        let obj2 = this.checkFieldChange(obj, this.originalEntity);
        let id = this.getId();
        this.service.updateWithPath(id, obj2, function (result) {
          com.afterUpdate(result);
        }, function (result) {
          com.updateError(result);
        });
        */
      } else {
        this.service.update(obj).subscribe((result: ResultInfo<T>) => {
          com.afterUpdate(result);
        }, err => {
          this.handleError(err);
        });
        /*
        this.service.update(obj, function (result: ResultInfo) {
          com.afterUpdate(result);
        }, function (response) {
          com.updateError(response);
        });
        */
      }
    } else {
      this.service.insert(obj).subscribe((result: ResultInfo<T>) => {
        com.afterInsert(result);
      }, err => {
        this.handleError(err);
      });
      /*
      this.service.insert(obj, function (result: ResultInfo) {
        com.afterInsert(result);
      }, function (response) {
        com.insertError(response);
      });
      */
    }
  }

  insertSuccess(result: ResultInfo<T>) {
    const obj2 = result.value;
    this.setNewMode(false);
    if (this.setBack === true) {
      this.setModel(obj2);
    } else {
      const obj = this.getModel();
      const obj3: any = obj;
      if (obj3.rowVersion != null) {
        obj3.rowVersion = obj3.rowVersion + 1;
      } else {
        obj3.rowVersion = 1;
      }
    }
    this.saveSuccessMsg = this.insertSuccessMsg;
    this.afterSaveSuccessfully(result);
  }

  insertError(response) {
    this.handleError(response);
  }

  updateSuccess(result: ResultInfo<T>) {
    const obj2 = result.value;
    this.setNewMode(false);
    if (this.setBack === true) {
      this.setModel(obj2);
    } else {
      const obj = this.getModel();
      const obj3: any = obj;
      if (obj3.rowVersion != null) {
        obj3.rowVersion = obj3.rowVersion + 1;
      } else {
        obj3.rowVersion = 1;
      }
    }
    this.saveSuccessMsg = this.updateSuccessMsg;
    this.afterSaveSuccessfully(result);
  }

  updateError(response) {
    this.handleError(response);
  }

  afterInsert(result: ResultInfo<T>) {
    this.running = false;
    LoadingUtil.hideLoading();
    if (result.status === StatusCode.Success) {
      // $scope.afterSaveSuccessfully(result);
      this.insertSuccess(result);
    } else if (result.status === StatusCode.Error) {
      this.afterSaveUnsuccessfully(result);
    } else if (result.status === StatusCode.ExceptionError) {
      result.message = ResourceManager.getString('msg_515');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.SessionExpired) {
      this.handleSessionExpired(result);
    } else if (result.status === StatusCode.PrimaryKeyMandatory) {
      this.handlePrimaryKeyMandatory(result);
    } else if (result.status === StatusCode.DuplicatePrimaryKey) {
      this.handleDuplicatePrimaryKeyException(result);
    } else if (result.status === StatusCode.DataIntegrity) {
      result.message = ResourceManager.getString('msg_006');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.SequenceError) {
      result.message = ResourceManager.getString('msg_474');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.SecurityError) {
      result.message = ResourceManager.getString('msg_017');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.DataCorrupt) {
      result.message = ResourceManager.getString('msg_007');
      this.showDanger(result.message);
    } else {
      result.status = StatusCode.Success;
      this.insertSuccess(result);
    }
  }

  afterUpdate(result: ResultInfo<T>) {
    this.running = false;
    LoadingUtil.hideLoading();
    if (result.status === StatusCode.SessionExpired) {
      this.handleSessionExpired(result);
    } else if (result.status === StatusCode.DataIntegrity) {
      result.message = ResourceManager.getString('msg_006');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.SecurityError) {
      result.message = ResourceManager.getString('msg_017');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.DataCorrupt) {
      result.message = ResourceManager.getString('msg_007');
      this.showDanger(result.message);
    } else if (result.status === StatusCode.Success) {
      this.updateSuccess(result);
    } else if (result.status === StatusCode.Error) {
      this.afterSaveUnsuccessfully(result);
    } else {
      result.status = StatusCode.Success;
      this.updateSuccess(result);
    }
  }

  handleSessionExpired(result) {
    const msg = ResourceManager.getString('msg_047');
    result.message = msg;
    this.showDanger(msg);
  }

  handleDuplicatePrimaryKeyException(result) {
    const msg = ResourceManager.getString('msg_426');
    result.message = msg;
    this.showDanger(msg);
  }

  handlePrimaryKeyMandatory(result) {
    const msg = ResourceManager.getString('msg_466');
    result.message = msg;
    this.showDanger(msg);
  }

  afterSaveSuccessfully(result: ResultInfo<T>) {
    const msg = ResourceManager.getString('msg_002');
    result.message = msg;
    UIUtil.showToast(msg);
    // this.showMessage(msg);
  }

  afterSaveUnsuccessfully(result: ResultInfo<T>) {
    const errors = result.errors;
    const unmappedErrors = ValidationUtil.showFormError(this.form, errors);
    UIUtil.focusErrorControl(this.form);
    if (!result.message) {
      if (!!errors && errors.length === 1) {
        result.message = errors[0].message;
      } else {
        result.message = ValidationUtil.buildErrorMessage(unmappedErrors);
      }
    }
    this.showDanger(result.message);
  }
}
