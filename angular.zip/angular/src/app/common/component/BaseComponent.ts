import { OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, ActivatedRouteSnapshot, Router, RouterStateSnapshot } from '@angular/router';
import { ResourceManager } from '../ResourceManager';
import { storage } from '../storage';
import { DateUtil } from '../util/DateUtil';
import { NumberUtil } from '../util/NumberUtil';
import { StringUtil } from '../util/StringUtil';
import { UIEventUtil } from '../util/UIEventUtil';
import { UIUtil } from '../util/UIUtil';
import {LoadingUtil} from '../util/LoadingUtil';

declare var initMaterial: any;
declare var handleFocus: any;
declare var handleBlur: any;

export class BaseComponent implements OnInit {
  resource: any = ResourceManager.getResource();
  com: any = this;
  dateFormat: String = 'MM/DD/YYYY';
  forms: Array<any>;
  _urlMode: string;
  form: any;
  running: boolean;
  message = '';
  alertClass = 'alert alert-success';
  _nreg: any = / |,|\$|\€|\£|\£|¥/g;
  _preg: any = / |,|%|\$|\€|\£|\£|¥/g;

  constructor(protected viewContainerRef: ViewContainerRef, protected router: Router, protected activeRoute: ActivatedRoute) {
    console.log(this.router.url);
    /*
    let session = this.getQueryParam(this.activeRoute, 's');
    if(session){
      window.sessionStorage.setItem('inboxSessionKey' , session);
    }
    */
  }

  protected getCurrentUserId(): string {
    return storage.getUserId();
  }

  ngOnInit() {
    this.initForm();
    this.initPermission();
    this.initData();
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const url: string = state.url;
    return this.checkSignin(url);
  }

  checkSignin(url: string): boolean {
    // this.router.navigate(['/signin']);
    return true;
  }

  getParam(route: ActivatedRoute, name: any): any {
    if (!route || !name) {
      return null;
    }
    const param: any = route.params;
    const obj = param._value;
    return obj;
  }

  getQueryParam(route: ActivatedRoute, name: any): any {
    if (!route || !name) {
      return null;
    }
    const queryParams: any = route.queryParams;
    const obj = queryParams.value;
    return obj[name];
  }
  navigate(stateTo, params = null) {
    const commands: any = [];
    commands.push(stateTo);
    if (params != null) {
      if (typeof params === 'object') {
        for (const param of params) {
          commands.push(param);
        }
        this.router.navigate(commands);
      }
      this.router.navigate(stateTo, params);
    } else {
      this.router.navigate([stateTo]);
    }
  }
  navigateBack() {
    window.history.back();
  }
  navigateToHome() {
    this.navigate('access/users');
  }
  navigateToSignin() {
    this.navigate('signin');
  }
  protected initForm() {
    this.autoInitForm();
  }
  autoInitForm() {
    const el = this.viewContainerRef.element.nativeElement;
    const forms = el.querySelectorAll('form');
    this.forms = forms;
    if (forms != null && forms.length > 0) {
      this.form = forms[0];
      setTimeout(function () {
        for (let i = 0; i < forms.length; i++) {
          const form = forms[i];
          UIEventUtil.initMaterial(form);
        }
        UIUtil.focusFirstControl(forms[0]);
      }, 100);
    }
  }
  protected initPermission() {

  }
  protected initData() {
    this.loadData();
  }

  loadData() {

  }

  refresh() {
    this.loadData();
  }

  showToast(msg) {
    UIUtil.showToast(msg);
  }
  alertError(msg) {
    UIUtil.alertError(msg);
  }

  // showError(msg) {}

  confirm(msg, yescallback, nocallback) {
    UIUtil.confirm(msg, yescallback, nocallback);
  }
  showMessage(msg) {
    this.alertClass = 'alert alert-success';
    this.message = msg;
  }
  showWarning(msg) {
    this.alertClass = 'alert alert-warning';
    this.message = msg;
  }
  showInfo(msg) {
    this.alertClass = 'alert alert-info';
    this.message = msg;
  }
  showDanger(msg) {
    this.alertClass = 'alert alert-danger';
    this.message = msg;
  }
  hideMessage() {
    this.message = '';
  }
  setUrlHash(params) { }

  handleError(response) {
    this.running = false;
    LoadingUtil.showLoading();

    let msg = ResourceManager.getString('error_unauthorized'); // ResourceManager.getString('error_network');

    let minutes = -1;
    const status = response.status;
    if (storage.lastSuccessTime != null) {
      const now = new Date();
      minutes = DateUtil.getMinutesBetween(now, storage.lastSuccessTime);
    }
    if (status === 401) {
      msg = ResourceManager.getString('error_unauthorized');
      minutes = parseFloat(minutes.toFixed(0));
      if (minutes > 0) {
        msg = StringUtil.format(ResourceManager.getString('error_timeout'), minutes);
      }
      storage.signinMessage = msg;
      this.navigateToSignin();
      return;
    } else if (status === 403) {
      msg = ResourceManager.getString('error_permission_forbidden');
    } else if (status === 500) {
      msg = ResourceManager.getString('error_internal');
    } else if (status === 503) {
      msg = ResourceManager.getString('error_service_unavailable');
    }
    UIUtil.alertError(msg, response);
  }

  getHashFromUrl() { }
  buildUrlParams() { }

  numberOnFocus(event) {
    UIEventUtil.numberOnFocus(event);
  }
  numberOnBlur(event) {
    UIEventUtil.numberOnBlur(event);
  }
  currencyOnBlur(event) {
    UIEventUtil.currencyOnBlur(event);
  }
  currencyOnFocus(event) {
    UIEventUtil.currencyOnFocus(event);
  }
  percentageOnFocus(event) {
    UIEventUtil.percentageOnFocus(event);
  }
  validateOnBlur(event) {
    UIEventUtil.validateOnBlur(event);
  }

  protected checkRequiredOnBlur(event) {
    UIEventUtil.checkRequiredOnBlur(event);
  }
}
