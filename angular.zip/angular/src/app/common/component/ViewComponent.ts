import { ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Model } from 'src/app/core';
import { ResourceManager } from '../ResourceManager';
import { ViewService } from '../service/ViewService';
import { storage } from '../storage';
import { ReflectionUtil } from '../util/ReflectionUtil';
import { UIUtil } from '../util/UIUtil';
import { ValidationUtil } from '../util/ValidationUtil';
import { BaseComponent } from './BaseComponent';
import { IdBuilder } from './IdBuilder';
import {LoadingUtil} from '../util/LoadingUtil';

export class ViewComponent<T> extends BaseComponent {
  private _id: any = null;
  newMode = true;
  private model: any;
  protected orginalModelRedux = null;
  protected metadata: Model;

  constructor(viewContainerRef: ViewContainerRef, router: Router, protected route: ActivatedRoute, private service0: ViewService<T>) {
    super(viewContainerRef, router, route);
    const id = this.getParam(route, 'id')['id'];
    if (!!id) {
      this.setId(id);
    }
  }

  protected viewable: boolean;

  initPermission() {
    this.viewable = true;
  }

  setId(id: any) {
    this._id = id;
  }

  getId(): any {
    if (this._id) {
      return this._id;
    } else {
      if (!this.service0.getMetaData()) {
        return null;
      } else {
        return IdBuilder.buildId(this.service0.getMetaData(), this.route);
      }
    }
  }

  protected getModelName() {
    return this.metadata.name;
  }

  setNewMode(_newMode: boolean) {
    this.newMode = _newMode;
  }
  isNewMode(): boolean {
    return this.newMode;
  }

  createModel(): T {
    const obj: any = {};
    obj.status = 'A';
    obj.rowVersion = 0;
    return obj;
  }

  setModel(obj: T) {
    this.formatModel(obj);
    this.model = obj;
  }
  getModel(): T {
    const obj = ReflectionUtil.clone(this.model);
    this.jsonModel(obj);
    return obj;
  }
  formatModel(obj) {
    return obj;
  }
  jsonModel(obj) {
    return obj;
  }

  loadData() {
    const id = this.getId();
    if (id != null && id !== '') {
      if (this.viewable !== true) {
        // const title = ResourceManager.getString('error_permission');
        const msg = ResourceManager.getString('error_permission_view');
        UIUtil.alertError(msg);
        const user = storage.getUser();
        if (!!user) {
          this.navigateToHome();
        } else {
          this.navigateToSignin();
        }
        return;
      } else {
        this.service0.getById(id).subscribe((obj: T) => {
          this.showObject(obj);
        }, err => {
          this.handleError(err);
        });
        /*
        this.service.getById(id, function (obj) {
          com.showObject(obj);
        }, function (response) {
          com.handleError(response);
        });
        */
      }
    } else {
      // this.newOnClick();
      // Show Error Message
    }
  }

  showObject(obj) {
    this.hideMessage();
    ValidationUtil.removeFormError(this.form);
    this.setNewMode(false);
    this.setModel(obj);
    this.running = false;
    LoadingUtil.hideLoading();
  }
}
