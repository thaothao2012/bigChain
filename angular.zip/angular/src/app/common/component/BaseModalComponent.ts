import {ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ModalService} from '../modal/ModalService';
import {BaseComponent} from './BaseComponent';

export class BaseModalComponent extends BaseComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, activeRoute: ActivatedRoute, protected modalService: ModalService) {
    super(viewContainerRef, router, activeRoute);
  }

  alertWithTitle(title: string, msg: string) {
    this.modalService.activate(title, msg);
  }

  confirmWithTitle(title: string, msg: string, yesCallback: any, noCallback: any) {
    const okText = 'Yes';
    const cancelText = 'No';
    this.modalService.activate(title, msg, okText, cancelText, yesCallback, noCallback);
  }
}
