import {ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {SearchModel} from '../model/SearchModel';
import {SearchResult} from '../model/SearchResult';
import {ResourceManager} from '../ResourceManager';
import {SearchService} from '../service/SearchService';
import {storage} from '../storage';
import {ReflectionUtil} from '../util/ReflectionUtil';
import {StringUtil} from '../util/StringUtil';
import {UIUtil} from '../util/UIUtil';
import {ValidationUtil} from '../util/ValidationUtil';
import {BaseComponent} from './BaseComponent';
import {LoadingUtil} from '../util/LoadingUtil';

declare var Masonry: any;
declare var initMaterial: any;

export class SearchComponent<T, S extends SearchModel> extends BaseComponent {
  constructor(viewContainerRef: ViewContainerRef,
        router: Router,
        activeRoute: ActivatedRoute,
        protected service: SearchService<T, S>) {
    super(viewContainerRef, router, activeRoute);
  }

  listForm: any;
  tagName: string;
  displayFields: any[];
  displayFieldNames: string;
  _autoSearch = true;
  _triggerSearch = false;
  showPaging = false;
  appendMode = false;
  appendable = false;
  index: number;
  pageMaxSize = 7;
  _tmpPageIndex: number;
  _bkpageIndex: number;
  pageIndex = 1;
  pageSize = 20;
  initPageSize = 20;
  pageSizes: number[] = [10, 20, 40, 60, 100, 200, 400, 10000];
  // pageSizes = ['10', '20', '40'];
  pageTotal: number;
  itemTotal: number;
  sortField: string;
  _currentSortField: string;
  sortType: string;
  _sortTarget: any;
  hideFilter: boolean;
  append = false;
  gotoFirst = false;
  gotoLast = false;
  resultView: string;
  result: any = null;
  _tmpSelected: any;
  lastSelected: any;
  _hasMasonry: boolean = null;
  _masonryView: any = null;
  masonry: any = null;
  chkAll: any = null;
  _lastSearchedTime: any = null;

  searchable = true;
  viewable: boolean;
  addable: boolean;
  editable: boolean;
  deletable: boolean;

  deleteHeader: string = ResourceManager.getString('msg_delete_header');
  deleteConfirm: string = ResourceManager.getString('msg_delete_confirm');
  deleteFailed: string = ResourceManager.getString('msg_delete_failed');

  protected se: S;
  private list: any[];

  initListForm(form) {
    let view = 'view2';
    const strView = form.getAttribute('result-view');
    if (strView === 'view3') {
      view = 'view3';
      if (!form.classList.contains('result3')) {
        form.classList.add('result3');
      }
      form.classList.remove('result1');
      form.classList.remove('result2');
    } else if (strView === 'view2') {
      view = 'view2';
      if (!form.classList.contains('result2')) {
        form.classList.add('result2');
      }
      form.classList.remove('result1');
      form.classList.remove('result3');
    } else {
      view = 'view1';
      if (!form.classList.contains('result1')) {
        form.classList.add('result1');
      }
      form.classList.remove('result2');
      form.classList.remove('result3');
    }
    if (view != null) {
      this.resultView = view;
    }
    let fieldNames = form.getAttribute('display-fields');
    let fields = [];
    if (fieldNames != null && fieldNames !== '') {
      fields = fieldNames.split(',');
      this.displayFieldNames = fieldNames;
      this.displayFields = fields;
    } else {
      const hiddenNames = form.getAttribute('hidden-fields');
      if (hiddenNames != null && hiddenNames !== '') {
        const hiddenFields = hiddenNames.split(',');
        for (let i = 0; i < hiddenFields.length; i++) {
          if (!hiddenFields.contains(hiddenFields[i])) {
            fields.push(hiddenFields[i]);
          }
        }
      }
      fieldNames = '';
      if (fields != null && fields.length > 0) {
        let str = fields[0];
        for (let i = 1; i < fields.length; i++) {
          str = str + ',' + fields[i];
        }
        this.displayFieldNames = str;
      }
      if (!!fields && fields.length > 0) {
        this.displayFields = fields;
      }
    }
  }
  initPermission() {
    this.searchable = true;
    this.viewable = true;
    this.addable = true;
    this.editable = true;
    this.deletable = true;
  }

  createSearchModel(): S {
    const obj: any = {};
    return obj;
  }
  setSearchModel(obj: S) {
    this.formatSearchModel(obj);
    this.se = obj;
  }
  getSearchModel(): S {
    const obj = this.populateSearchModel(this.se);
    return obj;
  }
  getOriginalSearchModel(): S {
    return this.se;
  }
  formatSearchModel(obj) {
    /*
    UIUtil.formatDateObj(obj, this.searchDateFields);
    UIUtil.formatNumberObj(obj, this.searchNumberFormats);
    UIUtil.formatStringBoolObj(obj, this.searchStrBoolFields);
    */
    // UIFormatterUtil.formatObject(obj, this.listForm);
  }
  jsonSearchModel(obj) {
    /*
    UIUtil.jsonDateObj(obj, this.searchDateFields);
    UIUtil.jsonNumberObj(obj, this.searchNumberFormats);
    UIUtil.jsonStringBool(obj, this.searchStrBoolFields);
    */
    // UIUtil.jsonObject(obj, this.listForm);
  }

  populateSearchModel(se: S = null): S {
    if (!se) {
      se = this.se;
    }
    if (this.tagName != null && this.tagName !== undefined) {
      se.tagName = this.tagName;
    }
    const obj = ReflectionUtil.clone(se);
    this.jsonSearchModel(obj);
    obj.fields = this.getDisplayFields();
    if (this.pageIndex != null && this.pageIndex >= 1) {
      obj.pageIndex = this.pageIndex;
    }
    obj.pageSize = this.pageSize;
    obj.initPageSize = this.initPageSize;
    obj.sortField = this.sortField;
    obj.sortType = this.sortType;
    se.pageSize = this.pageSize;
    return obj;
  }
  getDisplayFields(): any[] {
    return this.displayFields;
  }
  setList(results: T[]) {
    this.list = results;
  }
  getList(): any[] {
    return this.list;
  }
  getSelectedList(): any[] {
    const list = this.getList();
    const arrs = [];
    if (list != null && list !== undefined) {
      for (let i = 0; i < list.length; i++) {
        if (list[i].selected === true) {
          arrs.push(list[i]);
        }
      }
    }
    return arrs;
  }
  getUnselectedList(): any[] {
    const list = this.getList();
    const arrs = [];
    if (list != null && list !== undefined) {
      for (let i = 0; i < list.length; i++) {
        if (list[i].selected !== true) {
          arrs.push(list[i]);
        }
      }
    }
    return arrs;
  }
  isSelectedAll(): boolean {
    const list = this.getList();
    for (let i = 0; i < list.length; i++) {
      if (list[i].selected !== true) {
        return false;
      }
    }
    return true;
  }
  chkAllOnClick(event) {
    const target = event.currentTarget;
    const isChecked = target.checked;
    const list = this.getList();
    if (list !== undefined || list != null) {
      for (let i = 0; i < list.length; i++) {
        list[i].selected = isChecked;
      }
    }
    this.handleItemOnChecked(list);
  }
  itemOnClick(event) {
    if (this.chkAll != null) {
      this.chkAll.checked = this.isSelectedAll();
    }
    const list = this.getList();
    this.handleItemOnChecked(list);
  }
  handleItemOnChecked(list: any[]) {
  }

  autoInitForm() {
    const el = this.viewContainerRef.element.nativeElement;
    const result = el.querySelector('.result');
    this.result = result;

    const forms = el.querySelectorAll('form');
    this.forms = forms;
    if (forms != null && forms.length > 0) {
      this.listForm = forms[0];
      setTimeout(function() {
        if (initMaterial != null) {
          for (let i = 0; i < forms.length; i++) {
            const form = forms[i];
            initMaterial(form);
          }
        }
        UIUtil.focusFirstControl(forms[0]);
      }, 100);
      this.initListForm(this.listForm);
    }
  }
  initData() {
    this.initSearchModel();
    this.loadData();
  }

  initSearchModel() {
    let obj = null;
    const tmp = storage.tmpSearchModel;
    if (!!tmp && tmp.tagName === this.tagName) {
      obj = tmp;
    }

    if (!obj) {
      obj = this.createSearchModel();
    }
    if (!!obj.pageSize) {
      this.pageSize = obj.pageSize;
    }
    if (!obj.pageSize && !!this.pageSize) {
      obj.pageSize = this.pageSize;
    }
    if (!!obj.initPageSize) {
      this.initPageSize = obj.initPageSize;
    } else {
      this.initPageSize = this.pageSize;
    }
    if (!!obj.sortField) {
      this.sortField = obj.sortField;
    }
    this.setSearchModel(obj);
  }
  loadData() {
    const com = this;
    if (com._autoSearch) {
      setTimeout(function () {
        com._lastSearchedTime = new Date();
        com._bkpageIndex = com.pageIndex;
        com.doSearch();
      }, 100);
    }
  }
  resetSearchModel() {
    this.autoResetSearchModel(true);
  }
  autoResetSearchModel(bindToForm: boolean = null) {
    const str = this.getHashFromUrl();
    const obj = this.createSearchModel();
    const se = this.getOriginalSearchModel();
    obj.keyword = se.keyword;
    this.setSearchModel(obj);
    const com = this;
    setTimeout(function () {
      ValidationUtil.removeFormError(com.listForm);
      if (bindToForm) {
        UIUtil.bindToForm(com.listForm, obj);
      }
      com.searchOnClick();
    }, 100);
  }

  toggleFilter(event) {
    this.hideFilter = !this.hideFilter;
    // $scope.runMaterializeCript();
  }
  sort(event, field?: string, sortType?: string) {
    if (event != null && event.target != null) {
      let target = event.target;
      if (target.nodeName === 'I') {
        target = target.parentNode;
      }
      if (!field) {
        field = target.getAttribute('data-field');
        if (!field) {
          field = target.parentNode.getAttribute('data-field');
        }
        if (!field || field.length === 0) {
          return;
        }
      }
      let i = null;
      if (target.children.length === 0) {
        target.innerHTML = target.innerHTML + '<i class="fa fa-caret-up" aria-hidden="true"></i>';
      } else {
        i = target.children[0];
        if (i.classList.contains('fa-caret-up')) {
          i.classList.remove('fa-caret-up');
          i.classList.add('fa-caret-down');
        } else if (i.classList.contains('fa-caret-down')) {
          i.classList.remove('fa-caret-down');
          i.classList.add('fa-caret-up');
        }
      }
      if (!this.sortField || this.sortField === '') {
        this.sortField = field;
        this.sortType = 'ASC';
      } else if (this.sortField !== field) {
        this.sortField = field;
        this.sortType = (!sortType ? 'ASC' : sortType);
        if (this._sortTarget != null && this._sortTarget.children.length > 0) {
          this._sortTarget.removeChild(this._sortTarget.children[0]);
        }
      } else if (this.sortField === field) {
        if (!sortType) {
          if (!this.sortType || this.sortType === 'ASC') {
            this.sortType = 'DESC';
          } else {
            this.sortType = 'ASC';
          }
        } else {
          this.sortType = sortType;
        }
      }
      this._sortTarget = target;
    } else {
      this.sortField = field;
      if (!this.sortType || this._currentSortField !== this.sortField || this.sortType === 'DESC') {
        this.sortType = 'ASC';
      } else {
        this.sortType = 'DESC';
      }

      this._currentSortField = ReflectionUtil.clone(this.sortField);
    }
    this._lastSearchedTime = null;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.setList(null);
    if (this.appendMode === false) {
      this.doSearch();
    } else {
      this.searchOnClick();
    }
  }
  setPage(pageNo: number) {
    this.pageIndex = pageNo;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.doSearch();
  }

  pageChanged(event) {
    if (this._lastSearchedTime != null) {
      const now: any = new Date();
      const xbug = Math.abs(this._lastSearchedTime - now);
      console.log('xbug:' + xbug);
      if (xbug < 800) {
        this.pageIndex = this._bkpageIndex;
        return;
      }
    }
    this.pageIndex = event.page;
    this.pageSize = event.itemsPerPage;
    this.append = false;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.doSearch();
  }

  viewChanged(id, event) {
    /*
    if (this.running == true)
      return;
    if (!(id == 1 || id == 2 || id == 3))
      return;
    this.resultView = ('view' + id);
    let newClass = ('result' + id);
    this.jlistForm.addClass(newClass);
    if (id == 1) {
      this.hasMasonry = null;
      this.masonry = null;
      this.jlistForm.removeClass('result2');
      this.jlistForm.removeClass('result3');
      if (this.angular2 == false)
        this.result.find('.view2').empty();
      if (this.angular3 == false)
        this.result.find('.view3').empty();
    } else if (id == 2) {
      this.jlistForm.removeClass('result1');
      this.jlistForm.removeClass('result3');
      if (this.angular1 == false)
        this.result.find('tbody').empty();
      if (this.angular3 == false)
        this.result.find('.view3').empty();
    } else if (id == 3) {
      this.hasMasonry = null;
      this.masonry = null;
      this.jlistForm.removeClass('result1');
      this.jlistForm.removeClass('result2');
      if (this.angular1 == false)
        this.result.find('tbody').empty();
      if (this.angular2 == false)
        this.result.find('.view2').empty();
    }
    this.doSearch();
    */
  }

  buildUrlParams() {/*
    let se = this.getSearchEntity();
    let obj = {};
    const keys = Object.keys(se);

    for (let i = 0; i < keys.length; i++) {
      if (!('results' === keys[i]) && !('displayFields' === keys[i])) {
        const val = se[keys[i]];
        if (val != null)
          obj[keys[i]] = val;
      }
    }

    let jelement = this.jelement;
    if (jelement.hasClass("panel3"))
      obj["__view"] = "panel3";
    else if (jelement.hasClass("panel2"))
      obj["__view"] = "panel2";
    else if (jelement.hasClass("panel1"))
      obj["__view"] = "panel1";
    else if (jelement.hasClass("panel0"))
      obj["__view"] = "panel0";

    let params = StringUtil.param(obj);
    jelement.attr("url_params", params);
    return params;*/
  }
  changeUrlParams() {
    /*
    if (this.urlMode == '2') {
      let params = this.buildUrlParams();
      this.setUrlHash(params);
    }
    */
  }
  onPageSizeChanged(event) {
    const ctrl = event.currentTarget;
    this.pageSizeChanged(ctrl.value, event);
  }
  pageSizeChanged(size: number, event) {
    this._lastSearchedTime = new Date();
    this.initPageSize = size;
    this.pageSize = size;
    this._tmpPageIndex = 1;
    this.pageIndex = 1;
    this._bkpageIndex = this.pageIndex;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.doSearch();
  }
  getId(obj) {
    /*
    let ids = this.ids;
    if (!ids || ids.length == 0)
      return null;
    else if (ids.length == 1)
      return obj[ids[0]];
    else {
      let id = {};
      for (let i = 0; i < ids.length; i++) {
        id[ids[i]] = obj[ids[i]];
      }
      return id;
    }
    */
  }

  clearKeyworkOnClick = () => {
    this.se.keyword = '';
  }

  searchOnClick() {
    // UIUtil.showAlert("test");
    if (this.running === true) {
      this._triggerSearch = true;
      return;
    }
    if (this._sortTarget != null) {
      if (this._sortTarget.children.length > 0) {
        this._sortTarget.removeChild(this._sortTarget.children[0]);
      }
      this._sortTarget = null;
    }
    this._lastSearchedTime = null;
    this.sortField = null;
    this.append = false;
    this._tmpPageIndex = 1;
    this.pageIndex = 1;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.doSearch();
  }
  doSearch() {
    if (this.searchable !== true) {
      // const title = ResourceManager.getString('error_permission');
      const msg = ResourceManager.getString('error_permission_search');
      UIUtil.alertError(msg);
      const user = storage.getUser();
      if (user != null) {
        this.navigateToHome();
      } else {
        this.navigateToSignin();
      }
      return;
    } else {
      if (this.listForm != null) {
        ValidationUtil.removeFormError(this.listForm);
      }
      const se: SearchModel = this.getSearchModel();
      storage.tmpSearchModel = se; // sessionStorage.setItem('searchEntity', JSON.stringify(se));
      const com = this;
      this.validateSearch(se, function (se2) {
        if (com.running === true) {
          return;
        }
        com.running = true;
        LoadingUtil.showLoading();
        com.search(se);
      });
    }
  }
  showMore() {
    this.append = true;
    this._tmpPageIndex = this.pageIndex;
    this.pageIndex = this.pageIndex + 1;
    this.gotoFirst = false;
    this.gotoLast = false;
    this.doSearch();
  }
  /*
	$scope.getDisplayFields = function() {
		return this.displayFields;
	};
	$scope.getDisplayDateFields = function() {
		return this.displayDateFields;
	};
	$scope.getDisplayDateFields = function() {
		return this.dateFields;
	};
	$scope.getDefaultNumberFields = function() {
		return this.numberFields;
	};*/
  search(se: SearchModel) {
    const service = this.service;
    const com = this;
    this.service.search(se).subscribe((se2: SearchResult<T>) =>
      this.showResults(se, se2),
      err => this.handleError(err)
    );
    /*
    service.search(se, function (se: SearchModel) {
      com.showResults(se);
    }, function (response) {
      com.searchError(se);
    });
    */
  }
  validateSearch(se, callback: Function) {
    let valid = true;
    if (this.listForm != null) {
      valid = ValidationUtil.validateForm(this.listForm);
    }
    if (valid === true) {
      callback(se);
    }
  }
  showResults(s: SearchModel, sr: SearchResult<T>) {
    if (sr.itemTotal) {
      this.itemTotal = sr.itemTotal;
    }
    this.pageIndex = s.pageIndex;
    const results = sr.results;
    if (results != null && results.length > 0) {
      this.formatSearchResults(results);
      this.formatResults(results);
    }
    this.index = -1;
    this.lastSelected = null;
    if (this.appendMode === false) {
      this.setList(results);
      this.showSearchMessage(sr);
      this.showPages(sr);
    } else {
      if (s.pageSize === 0) {
        this.appendable = false;
      } else {
        let pageSize = s.pageSize;
        if (s.pageIndex <= 1) {
          pageSize = s.initPageSize;
        }
        if (sr.lastPage === true || results.length < pageSize) {
          this.appendable = false;
        } else {
          this.appendable = true;
        }
      }
      if (this.append === true && s.pageIndex > 1) {
        this.appendList(results);
      } else {
        this.setList(results);
      }
      if (results.length === 0) {
        this.appendable = false;
      }
    }
    this.changeUrlParams();
    this.running = false;
    LoadingUtil.hideLoading();
    if (this._triggerSearch === true) {
      this._triggerSearch = false;
      this.searchOnClick();
    }
  }

  searchError(response) {
    this.pageIndex = this._tmpPageIndex;
    this.handleError(response);
  }

  formatSearchResultObj(obj) {
  }

  formatSearchResults(results) {

  }

  formatResults(results: any[]) {

  }
  appendObject(obj) {
    const list = this.getList();
    list.push(obj);
  }
  insertIntoResults(index: number, obj) {
    const list = this.getList();
    list.splice(index, 0, obj);
  }
  appendList(results: any[]) {
    const list = this.getList();
    const length = results.length;
    for (let i = 0; i < length; i++) {
      list.push(results[i]);
    }
  }

  showSearchMessage(se: SearchResult<T>) {
    this._tmpPageIndex = this.pageIndex;
    this.itemTotal = se.itemTotal;
    const pageTotal = this.getPageTotal(this.itemTotal, this.pageSize);
    this.pageTotal = pageTotal;
    const results = se.results;
    if (!results || results.length === 0) {
      const msg = ResourceManager.getString('msg_008');
      UIUtil.showToast(msg);
    } else {
      const fromIndex = (this.pageIndex - 1) * this.pageSize + 1;
      const toIndex = fromIndex + results.length - 1;
      if (pageTotal > 1) {
        const msg2 = StringUtil.format(ResourceManager.getString('msg_010'), fromIndex, toIndex, this.itemTotal, this.pageIndex, this.pageTotal);
        UIUtil.showToast(msg2);
      } else {
        const msg3 = StringUtil.format(ResourceManager.getString('msg_009'), fromIndex, toIndex);
        UIUtil.showToast(msg3);
      }
    }
    // this.statusNavigation();
  }
  showPages(se: SearchResult<T>) {
    this.showPaging = (this.pageTotal <= 1 ? false : true);
  }
  renderResult(result, template) {

  }
  renderItem(obj, template) {
    return template.bindObject(obj);
  }
  layoutMasonry() {
    if (this.masonry != null) {
      this.masonry.layout();
    }
    this.result.visibility = 'visible'; // this.result.classList.remove('invisible');
  }
  showCompleted() {
    if (this.gotoFirst === true) {
      this.goto(0);
    } else if (this.gotoLast === true) {
      const list = this.getList();
      if (list != null && list.length > 0) {
        this.goto(list.length - 1);
      }
    }
    if (this.resultView === 'view2') {
      this.initMasonry();
    }
  }

  initMasonry() {
    if (!this._hasMasonry || this._hasMasonry === true) {
      let jv = null;
      if (!this._hasMasonry) {
        // let v = document.querySelector('.masonry');
        jv = this.result.querySelector('.masonry');
        if (!jv || jv.length === 0) {
          this._hasMasonry = false;
        } else {
          this._hasMasonry = true;
          const v = jv;
          this._masonryView = v;
          const masonry = new Masonry(this._masonryView, {
            isFitWidth: true,
            itemSelector: '.float-item',
            transitionDuration: 0
          });
          this.masonry = masonry;
          // $scope.masonry.layout();
          this.result.visibility = 'hidden'; // this.result.addClass('invisible');
          const com = this;
          setTimeout(function() {
            com.layoutMasonry();
          }, 80);
        }
      } else if (this.masonry != null) {
        this.masonry.reloadItems();
        // $scope.masonry.layout();
        const com = this;
        setTimeout(function() {
          com.layoutMasonry();
        }, 80);
      }
    }
  }

  getPageTotal(recordTotal: number, pageSize: number) {
    if (pageSize <= 0) {
      return 1;
    } else {
      if ((recordTotal % pageSize) === 0) {
        return Math.floor((recordTotal / pageSize));
      }
      return Math.floor((recordTotal / pageSize) + 1);
    }
  }

  goto(i) {
    /*
    let list = this.getList();
    if (!list || list.length == 0 || i >= list.length)
      return;
    this.getObject(list[i], i, null);
    */
  }
  /*
  first() {
    let list = this.getList();
    if (!list || list.length == 0)
      return;
    if (!this.index || this.index > 0)
      this.goto(0);
    else if (this.index == 0 && this.pageIndex > 1) {
      this.pageIndex = this.pageIndex - 1;
      this.gotoFirst = true;
      this.gotoLast = false;
      this.doSearch();
    }
  }
  last() {
    let list = this.getList();
    if (!list || list.length == 0)
      return;
    if (!this.index || this.index < (list.length - 1))
      this.goto(list.length - 1);
    else {
      this.pageIndex = this.pageIndex + 1;
      this.gotoFirst = false;
      this.gotoLast = true;
      this.doSearch();
    }
  }
  previous() {
    if (!this.index || this.index < 0)
      this.goto(0);
    else if (this.index > 0)
      this.goto(this.index - 1);
    else {
      this.pageIndex = this.pageIndex - 1;
      this.gotoFirst = false;
      this.gotoLast = true;
      this.doSearch();
    }
  }
  next() {
    let list = this.getList();
    if (!this.index || this.index < 0)
      this.goto(0);
    else if (this.index < list.length - 1)
      this.goto(this.index + 1);
    else {
      this.pageIndex = this.pageIndex + 1;
      this.gotoFirst = true;
      this.gotoLast = false;
      this.doSearch();
    }
  }
  previousPage() {
    if (this.pageTotal > 0 && this.pageIndex <= 1)
      return;
    this.pageIndex = this.pageIndex - 1;
    this.gotoFirst = false;
    this.gotoLast = true;
    this.doSearch();
  }
  nextPage() {
    if (this.pageTotal > 0 && this.pageIndex == this.pageTotal)
      return;
    this.pageIndex = this.pageIndex + 1;
    this.gotoFirst = true;
    this.gotoLast = false;
    this.doSearch();
  }
  */
  activateSelected(pctrl) {
    /*
    if (!pctrl || this.lastSelected == pctrl)
      return;
    let ctrl = pctrl;
    let jctrl = null;
    //if (pctrl instanceof JQLite) {
    if (pctrl.jquery) {
      jctrl = pctrl;
      ctrl = jctrl[0];
    }
    else {
      jctrl = angular.element(ctrl);
    }
    if (jctrl.hasClass('card-item-padding')) {
      let ja = jctrl.find('a');
      if (ja != null && ja.length > 0) {
        if (ja[0] == this.lastSelected)
          return;
      }
    }
    jctrl.addClass("active");
    if (this.lastSelected != null)
      angular.element(this.lastSelected).removeClass("active");
    this.lastSelected = ctrl;
    */
  }
  highlight(ctrl, index) {
    /*
    if (ctrl != null) {
      if (ctrl.nodeName == "TR") {
        this.activateSelected(ctrl);
      } else if (ctrl.nodeName == "A") {
        let parent = ctrl.parentNode;
        if (parent.nodeName == "TD") {
          let tmp = parent;
          while (true) {
            tmp = tmp.parentNode;
            if (!tmp || tmp.nodeName == "BODY") {
              break;
            } else if (tmp.nodeName == "TR") {
              this.activateSelected(tmp);
              break;
            }
          }
        } else {
          this.activateSelected(ctrl);
        }
      } else {
        let jctrl = $(ctrl);
        if (jctrl.hasClass("list-group-item")
          || jctrl.hasClass("card-item-padding")
          || jctrl.hasClass("card-item")) {
          if (jctrl.hasClass("card-item-padding"))
            this.activateSelected(jctrl.find('a'));
          else
            this.activateSelected(ctrl);
        } else {
          let tmp = ctrl;
          while (true) {
            tmp = tmp.parentNode;
            let jtmp = $(tmp);
            if (!tmp || tmp.nodeName == "BODY" || jtmp.hasClass("left-panel")) {
              break;
            } else if (tmp.nodeName == "TR" || tmp.nodeName == "A"
              || jtmp.hasClass("list-group-item")
              || jctrl.hasClass("card-item-padding")
              || jtmp.hasClass("card-item")) {
              if (jctrl.hasClass("card-item-padding"))
                this.activateSelected(jtmp.find('a'));
              else
                this.activateSelected(tmp);
              break;
            }
          }
        }
      }
    } else {
      if (this.resultView == 'view2') {
        let row2 = this.result.find('.view2').find('.card-item')[index];
        //let row2 = this.result.find('.list-group-item')[index];
        this.activateSelected(row2);
      } else if (this.resultView == 'view1') {
        //let row3 = this.result.find('.view1').find('tbody').find('tr')[index];
        let row3 = this.result.find('tbody').find('tr')[index];
        this.activateSelected(row3);
      } else if (this.resultView == 'view3') {
        let view3 = this.result.find('.view3');
        let rows = view3.find('.list-group-item');
        if (rows.length > 0) {
          const row = rows[index];
          this.activateSelected(row);
        } else {
          const row = view3.find('.card-item')[index];
          this.activateSelected(row);
        }
      } else {
        const row = this.result.find('.list-group').find('.list-group-item')[index];
        this.activateSelected(row);
      }
    }
    */
  }
  /*
  showDirect(item: T, index, ctrl, event) {
    this.setEntity(item);
    if (!ctrl) {
      ctrl = event.currentTarget;
    }
    this.activateSelected(ctrl);
    this.index = index;
  }

  getObject(item, index, ctrl, event) {
    const id = this.getId(item);
    this.getById(id, index, ctrl, event);
  }

  getById(id, index, ctrl, event) {
    if (this.running === true) {
      this.lastId = id;
      this.lastIndex = index;
      return;
    }
    this.lastId = null;
    this.lastIndex = null;
    this.running = true;
    LoadingUtil.showLoading();
    if (!ctrl && !!event) {
      ctrl = event.currentTarget;
    }
    this.oldId = this.id;
    this.id = id;
    const tmpSelected = this.lastSelected;
    if (index != null && index >= 0 && this.index != index) {
      this.highlight(ctrl, index);
    }
    this.clickIndex = index;
    const com = this;
    this.service.getById(id, function(obj) {
      com.showObject(obj);
    }, function(response) {
      this.activateSelected(this._tmpSelected);
      this.handleError(response);
    });
  }
  */
  showObject(obj) {
    /*
    this.hideMessage();
    const oldWidth = this.form.clientWidth;
    //if (this.singleview || oldWidth == 0)//if (window.outerWidth <= 448)
    if (oldWidth == 0)//if (window.outerWidth <= 448)
      this.scaleup(null);

    this.formatServerObj(obj);

    UIUtil.removeFormError(this.jform);
    this.setNewMode(false);
    this.setEntity(obj);

    this.index = this.clickIndex;
    this.clickIndex = null;
    this.statusNavigation();
    this.running = false;
    this.hideLoading();
    if (this.lastId != null) {
      this.getById(this.lastId, this.lastIndex, null, null);
    } else if (this.urlMode == "1") {
      let hash = this.getHashFromUrl();
      let i = hash.lastIndexOf("/");
      if (i > 0 && this.isNewMode() == false) {
        let entity = this.getEntity();
        if (entity != null) {
          let ids = this.ids;
          if (ids != null) {
            if (ids.length == 1) {
              let sub = hash.substring(0, i + 1);
              let newHash = sub + entity[ids[0]];
              //$scope.urlChanging = true;
              this.urlChanging = true;
              //setUrlHash(newHash);
            } else {
              let id = {};
              for (let j = 0; j < ids.length; j++) {
                obj[ids[j]] = entity[ids[j]];
              }
            }
          }
        }
      }
    } else {
      //$scope.changeUrlParams();
    }
    */
  }
}
