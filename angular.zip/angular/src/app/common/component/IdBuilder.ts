import { ActivatedRoute } from '@angular/router';
import {Model} from '../metadata/Model';
import {MetadataUtil} from '../metadata/util/MetadataUtil';

export class IdBuilder {
  static buildId(metadata: Model, route: ActivatedRoute): any {
    if (!route) {
      return null;
    }
    const param: any = route.params;
    const obj = param._value;
    const metaModel = MetadataUtil.getMetaModel(metadata);
    if (!metaModel.primaryKeys || metaModel.primaryKeys.length <= 0) {
      return null;
    } else {
      const id: any = {};
      for (const key of metaModel.primaryKeys) {
        const v = obj[key.name];
        if (!v) {
          return null;
        }
        id[key.name] = v;
      }
      return id;
    }
  }
}
