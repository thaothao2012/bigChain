import {Directive, EventEmitter, Input, OnInit, Output} from '@angular/core';
/* tslint:disable */
@Directive({ selector: '[isLast]' })
export class LastDirective implements OnInit {
  @Input() isLast: boolean;
  @Output() lastDone: EventEmitter<boolean> = new EventEmitter<boolean>();
  ngOnInit() {
    if (this.isLast) {
      this.lastDone.emit(true);
    }
  }
}
