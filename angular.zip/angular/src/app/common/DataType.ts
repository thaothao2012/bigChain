export enum DataType {
  ObjectId = 'ObjectId',
  DateTime = 'DateTime',
  Bool = 'Bool',
  String = 'String',
  Text = 'Text',
  Number = 'Number',
  Integer = 'Integer',

  Object = 'Object',
  Array = 'Array',
  Fields = 'Fields'
}
