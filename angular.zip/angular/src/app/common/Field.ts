export interface Field {
  name: string;
  resourceKey: string;
}
