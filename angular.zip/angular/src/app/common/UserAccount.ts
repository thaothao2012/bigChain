import {Module} from './Module';

export interface UserAccount {
  userId: string;
  userName: string;
  email: string;
  displayName: string;
  imageURL?: string;
  passwordExpiredTime: Date;
  token: string;
  tokenExpiredDate: Date;
  newUser: boolean;
  language: string;
  privileges: string[];
  roleType: string;
  modules: Module[];
}
