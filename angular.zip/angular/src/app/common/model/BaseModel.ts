export class BaseModel {

}
