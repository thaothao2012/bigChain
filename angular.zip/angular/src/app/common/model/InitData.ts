export class Info {
  actionType?: string;
  appKeyword?: string;
  appLogo?: string;
  consentDate?: string;
  consentFlag?: string;
  consentUxDate?: string;
  deepLinkUrl?: string;
  detail?: object;
  displayName?: string;
  formURL?: string;
  isCancelToken?: string;
  nextAction?: string;
  partnerId?: string;
  rgb?: string;
  subDisplayName?: string;
  timerCount?: string;
}

export class InitModel {
  mobileNo?: string;
  mobileOS?: string;
  os?: string;
  osVersion?: string;
  appVersion?: string;
  appId?: string;
  language?: string;
  email?: string;
  inboxSessionId?: string;
  feedId?: string;
  formId?: string;
  tokenId?: string;
  corrId?: string;
  info?: Info;
}
