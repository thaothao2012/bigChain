export enum AvailableStatus {
  Online = 'O',
  Offline = 'F',
  Idle = 'I'
}
