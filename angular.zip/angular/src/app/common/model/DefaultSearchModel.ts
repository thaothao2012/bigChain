import {SearchModel} from './SearchModel';

export class DefaultSearchModel implements SearchModel {
  keyword: string;
  sortField: string;
  sortType: string;
  pageIndex: number;
  pageSize: number;
  initPageSize: number;
  tagName: string;
}
