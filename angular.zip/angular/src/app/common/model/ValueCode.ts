export class ValueCode {
  value: string;
  code: string;
}
