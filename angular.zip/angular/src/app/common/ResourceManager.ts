import Resources from '../resource/Resources';

export class ResourceManager {
    private static data_resource_key = 'data-resource';
    private static _resource: any = Resources; // {};
    public static getResource() {
        return this._resource;
    }
    public static getString(key, param: any = null): string {
        if (!!this._resource) {
            const str = this._resource[key];
            if (!str || str.length === 0) {
                return str;
            }
            if (!param) {
                return str;
            } else {
                if (typeof param === 'string') {
                    let paramValue = this._resource[param];
                    if (!paramValue) {
                        paramValue = param;
                    }
                    return str.format(paramValue);
                }
            }
        } else {
            return '';
        }
    }
    public static format(key, keys: any) {
        const str = this.getString(key);
        if (Array.isArray(keys)) {
            const params = [];
            for (let i = 0; i < keys.length; i++) {
                const param = this.getString(keys[i]);
                params.push(param);
            }
            return this.formatString(str, params);
        } else {
            const param = this.getString(keys);
            return this.formatString(str, param);
        }
    }
    private static formatString(...args: any[]): string {
        let formatted = args[0];
        if (!formatted) {
            return '';
        }
        if (args.length > 1 && Array.isArray(args[1])) {
            const params = args[1];
            for (let i = 0; i < params.length; i++) {
                const regexp = new RegExp('\\{' + i + '\\}', 'gi');
                formatted = formatted.replace(regexp, params[i]);
            }
        } else {
            for (let i = 1; i < args.length; i++) {
                const regexp = new RegExp('\\{' + (i - 1) + '\\}', 'gi');
                formatted = formatted.replace(regexp, args[i]);
            }
        }
        return formatted;
    }
}
