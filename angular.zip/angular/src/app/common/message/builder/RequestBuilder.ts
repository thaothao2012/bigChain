import {InitModel} from '../../model/InitData';
import {GuidUtil} from '../../util/GuidUtil';
import {RequestHeader} from '../RequestHeader';

export interface RequestBuilder {
  buildRequestHeader(initModel: InitModel): RequestHeader;
}
