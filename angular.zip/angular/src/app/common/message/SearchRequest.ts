import {SearchModel} from '../model/SearchModel';
import {BaseRequest} from './BaseRequest';

export class SearchRequest extends BaseRequest<SearchModel> {

}
