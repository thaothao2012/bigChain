export enum ResponseStatus {
  Success = 'S',
  Fail = 'F'
}
