import {ErrorMessage} from '../model/ErrorMessage';
import {ResponseStatus} from './ResponseStatus';

export class ResponseHeader {
  status: ResponseStatus;
  responseCode: string;
  responseDesc: string;
  mobileNo: string;
  requestedUniqueId: string;
  requestedDateTime: Date;
  responseId: string;
  responseDateTime: Date;
  inboxSessionId: string;
  errors: ErrorMessage[];
  corrId: string;
}
