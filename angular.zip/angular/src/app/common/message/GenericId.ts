export class GenericId<Id> {
  id: Id;
}
