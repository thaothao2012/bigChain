import {Flow} from './flow/Flow';
import {InitModel} from './model/InitData';
import {UserAccount} from './UserAccount';

// tslint:disable-next-line:class-name
export class storage {
  private static _initData: InitModel;
  public static tmpSearchModel = null;
  public static signinMessage = null;
  public static lastSuccessTime = null;

  private static _user = null;
  public static _sessionStorageAllowed = true;
  private static _flows: any = {};
  public static getRedirectUrl() {
    return encodeURIComponent(location.origin + '/index.html?redirect=oAuth2');
  }

  public static setUser(user: UserAccount) {
    storage._user = user;
    if (storage._sessionStorageAllowed === true) {
      try {
        if (user != null) {
          sessionStorage.setItem('authService', JSON.stringify(user));
        } else {
          sessionStorage.removeItem('authService');
        }
      } catch (err) {
        storage._sessionStorageAllowed = false;
      }
    }
  }
  public static getUser(): UserAccount {
    let user = storage._user;
    if (!user) {
      if (storage._sessionStorageAllowed === true) {
        try {
          const authService = sessionStorage.getItem('authService');
          if (!!authService) {
            storage._user = JSON.parse(authService);
            user = storage._user;
          }
        } catch (err) {
          storage._sessionStorageAllowed = false;
        }
      }
    }
    return user;
  }
  public static getUserId(): any {
    const user = storage.getUser();
    if (!user) {
      return '';
    } else {
      return user.userId;
    }
  }
  public static getUserName(): any {
    const user = storage.getUser();
    if (!user) {
      return '';
    } else {
      return user.userName;
    }
  }
  public static getToken(): string {
    const user = storage.getUser();
    if (!user) {
      return null;
    } else {
      return user.token;
    }
  }
  public static getFlow(flowId: string): Flow {
    return this._flows[flowId];
  }
  public static setFlow(flowId: string, flow: Flow) {
    this._flows[flowId] = flow;
  }

  public static setInitModel(initData: InitModel) {
    this._initData = initData;
  }
  public static getInitModel() {
    return this._initData;
  }
}
