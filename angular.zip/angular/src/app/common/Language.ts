export enum Language {
  Thai = 'th',
  English = 'en'
}
