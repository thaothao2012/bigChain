import {SearchModel} from '../model/SearchModel';
import {SearchService} from './SearchService';
import {ViewService} from './ViewService';

export interface ViewSearchService<T, S extends SearchModel>
  extends ViewService<T>, SearchService<T, S> {
}
