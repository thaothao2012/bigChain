/* tslint:disable */
export interface BaseService {

}
