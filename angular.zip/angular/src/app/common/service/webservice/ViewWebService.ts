import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Model } from '../../metadata/Model';
import { MetadataUtil } from '../../metadata/util/MetadataUtil';
import { WebClientUtil } from '../../util/WebClientUtil';
import { ViewService } from '../ViewService';
import { BaseWebService } from './BaseWebService';

@Injectable()
export class ViewWebService<T> extends BaseWebService implements ViewService<T> {
  constructor(protected http: HttpClient, protected serviceUrl: string, protected model: Model) {
    super();
  }

  getMetaData(): Model {
    return this.model;
  }

  getAll(): Observable<Array<T>> {
    return WebClientUtil.get(this.http, this.serviceUrl)
      .pipe(map((res: any) => this.formatObjects(res)));
  }

  getById(id): Observable<T> {
    let url = this.serviceUrl + '/' + id;
    if (typeof id === 'object' && this.model) {
      const metaModel = MetadataUtil.getMetaModel(this.model);
      if (metaModel.primaryKeys && metaModel.primaryKeys.length > 0) {
        url = this.serviceUrl;
        for (const key of metaModel.primaryKeys) {
          url = url + '/' + id[key.name];
        }
      }
    }
    return WebClientUtil.get(this.http, url)
      .pipe(map((res: any) => this.formatObject(res)));
  }

  protected formatObjects(list: any[]): any[] {
    if (!list || list.length === 0 || !this.model) {
      return list;
    }
    const metadata = this.getMetaData();
    for (const obj of list) {
      MetadataUtil.json(obj, metadata);
    }
    return list;
  }

  protected formatObject(obj): any {
    return MetadataUtil.json(obj, this.getMetaData());
  }
}
