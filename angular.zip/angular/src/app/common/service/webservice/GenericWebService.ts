import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Model } from '../../metadata/Model';
import { MetadataUtil } from '../../metadata/util/MetadataUtil';
import { ResultInfo } from '../../model/ResultInfo';
import { ReflectionUtil } from '../../util/ReflectionUtil';
import { WebClientUtil } from '../../util/WebClientUtil';
import { GenericService } from '../GenericService';
import { ViewWebService } from './ViewWebService';

@Injectable()
export class GenericWebService<T> extends ViewWebService<T> implements GenericService<T> {
  constructor(http: HttpClient, serviceUrl: string, model: Model) {
    super(http, serviceUrl, model);
  }

  protected formatResultInfo(result: ResultInfo<T>): ResultInfo<T> {
    result.value = MetadataUtil.json(result.value, this.getMetaData());
    return result;
  }

  insert(obj: T): Observable<ResultInfo<T>> {
    const obj2 = ReflectionUtil.clone(obj);
    ReflectionUtil.dateToISO(obj2);
    return WebClientUtil.postRequest(this.http, this.serviceUrl, obj2)
      .pipe(map((res: any) => this.formatResultInfo(res)));
  }

  update(obj: T): Observable<ResultInfo<T>> {
    const obj2 = ReflectionUtil.clone(obj);
    ReflectionUtil.dateToISO(obj2);
    const metadata = MetadataUtil.getMetaModel(this.model);
    let url = this.serviceUrl;
    for (const item of metadata.primaryKeys) {
      url = url + '/' + obj2[item.name];
    }
    // const url = (metadata.primaryKeys.length !== 1 ? this.serviceUrl : this.serviceUrl + '/' + obj2[metadata.primaryKeys[0].name]);
    return WebClientUtil.putRequest(this.http, url, obj2)
      .pipe(map((res: any) => this.formatResultInfo(res)));
  }
}
