import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot} from '@angular/router';

import {storage} from '../storage';

@Injectable()
export class AuthorizationRequiredService implements CanActivate {
  constructor(public router: Router) {

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    const user = storage.getUser();
    if (!user) {
      this.router.navigate(['/signin']);
      return false;
    } else {
      return true;
    }
  }

  checkSignin(url: string): boolean {
    this.router.navigate(['/signin']);
    return false;
  }
}
