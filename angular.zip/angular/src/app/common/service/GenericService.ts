import {Observable} from 'rxjs';
import {ResultInfo} from '../model/ResultInfo';
import {ViewService} from './ViewService';

export interface GenericService<T> extends ViewService<T> {
  insert(obj: T): Observable<ResultInfo<T>>;
  update(obj: T): Observable<ResultInfo<T>>;
}
