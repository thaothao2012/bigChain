import {State} from './State';

export interface ComponentConfig {
  name: string;
  state: State;
}
