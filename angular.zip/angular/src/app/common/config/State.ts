export enum State {
  Normal = 'normal',
  Readonly = 'readonly',
  Hidden = 'hidden'
}
