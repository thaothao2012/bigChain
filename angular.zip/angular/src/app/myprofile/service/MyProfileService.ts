import {Observable} from 'rxjs';
import {User, UserSettings} from '../../shared/user-model';

export interface MyProfileService {
    getMyProfile(userId): Observable<User>;
    getMySettings(userId): Observable<UserSettings>;
    saveMySettings(userId: string, settings: UserSettings): Observable<boolean>;
    saveMyProfile(userId: string, user: User): Observable<boolean>;
}
