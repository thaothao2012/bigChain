import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import config from '../../../../config';
import {WebClientUtil} from '../../../core';
import {User, UserSettings} from '../../../shared/user-model';
import {MyProfileService} from '../MyProfileService';

@Injectable()
export class MyProfileServiceImpl implements MyProfileService {
  constructor(protected http: HttpClient) {
  }

  protected serviceUrl = config.myprofileServiceUrl;

  getMyProfile(userId): Observable<User> {
    const url = this.serviceUrl + '/myprofile/' + userId;
    return WebClientUtil.getObject<User>(this.http, url);
  }

  getMySettings(userId): Observable<UserSettings> {
    const url = this.serviceUrl + '/mysettings/' + userId;
    return WebClientUtil.getObject<UserSettings>(this.http, url);
  }

  saveMySettings(userId: string, settings: UserSettings): Observable<boolean> {
    const url = this.serviceUrl + '/mysettings/' + userId;
    return WebClientUtil.putObject(this.http, url, settings);
  }

  saveMyProfile(userId: string, user: User): Observable<boolean> {
    const url = this.serviceUrl + '/saveMyProfile/' + userId;
    return WebClientUtil.putObject(this.http, url, user);
  }
}
