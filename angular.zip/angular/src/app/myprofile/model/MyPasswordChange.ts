export interface MyPasswordChange {
  userName: string;
  currentPassword: string;
  newPassword: string;
}
