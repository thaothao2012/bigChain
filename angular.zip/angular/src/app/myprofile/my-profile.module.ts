import {CommonModule} from '@angular/common';
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BsModalService, ComponentLoaderFactory, ModalModule} from 'ngx-bootstrap';
import {StringToArrayPipe} from '../core';
import {DependenciesServiceProviders} from '../shared/service/popupService';
import {GeneralInfoComponent} from './component/general-info.component';
import {MyPasswordComponent} from './component/my-password.component';
import {MyProfileComponent} from './component/my-profile.component';
import {MySettingsComponent} from './component/my-settings.component';
import {MyProfileRoutingModule} from './my-profile-routing.module';
import {MyProfileModuleComponent} from './my-profile.module.component';
import {MyProfileServiceImpl} from './service/impl/MyProfileServiceImpl';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    MyProfileRoutingModule,
    ReactiveFormsModule,
    ModalModule,
    ModalModule.forRoot()
  ],
  declarations: [
    MyProfileModuleComponent,
    MyProfileComponent,
    MySettingsComponent,
    MyPasswordComponent,
    GeneralInfoComponent,
    StringToArrayPipe
  ],
  entryComponents: [
    GeneralInfoComponent
  ],
  providers: [
    MyProfileServiceImpl, DependenciesServiceProviders, BsModalService, ComponentLoaderFactory
  ]
})

export class MyProfileModule {
}
