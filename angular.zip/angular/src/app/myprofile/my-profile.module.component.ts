import {Component} from '@angular/core';

@Component({
  selector: 'app-my-profile-module',
  template: '<router-outlet></router-outlet>',
})

export class MyProfileModuleComponent {
  constructor() {
  }
}
