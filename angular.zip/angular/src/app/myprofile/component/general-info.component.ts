import {Component, EventEmitter, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BsModalRef} from 'ngx-bootstrap';
import {BaseComponent, storage} from '../../core';
import {PopupComponentService} from '../../shared/service/popupService';
import {User} from '../../shared/user-model';
import {MyProfileServiceImpl} from '../service/impl/MyProfileServiceImpl';
import {MyProfileService} from '../service/MyProfileService';

@Component({
  selector: 'app-general-info',
  templateUrl: '../view/general-info-popup.html',
  styleUrls: ['../view/general-info.scss'],
  providers: [PopupComponentService]
})
export class GeneralInfoComponent extends BaseComponent {
  profileService: MyProfileService;
  data: User;
  onClose: EventEmitter<any> = new EventEmitter();

  newSkill: string;
  newSkillHireable: boolean;
  newLookingFor: string;

  constructor(private bsModalRef: BsModalRef, viewContainerRef: ViewContainerRef, router: Router,
              route: ActivatedRoute, profileService: MyProfileServiceImpl) {
    super(viewContainerRef, router, route);
    this.profileService = profileService;
  }

  addSkill() {
    if (this.newSkill && this.newSkill.trim() !== '') {
      const skills = this.data.skills.slice(0);
      skills.push({
        hirable: this.newSkillHireable ? true : false,
        skill: this.newSkill
      });
      this.data.skills = skills;
      this.newSkill = '';
      this.newSkillHireable = false;
    }
  }


  removeSkill(skillContent: string) {
    const filters = this.data.skills.filter(item => item['skill'] !== skillContent);
    this.data.skills = filters;
  }



  save() {
    console.log('begin save user');
    this.profileService.saveMyProfile(storage.getUserId(), this.data).subscribe(successs => {
      let status = '';
      if (successs) {
        status = 'success';
      } else {
        status = 'fail';
      }
      const sendObject = {
        status: status,
        data: this.data
      };

      this.onClose.emit(sendObject);
      this.close();
    });
  }

  close() {
    this.bsModalRef.hide();
  }
}
