import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {BaseComponent, storage, StringUtil} from '../../core';

export class BaseMyProfileComponent extends BaseComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute) {
    super(viewContainerRef, router, route);
    const userId = storage.getUserId();
    if (StringUtil.isEmpty(userId)) {
      this.navigateToSignin();
    }
  }
}
