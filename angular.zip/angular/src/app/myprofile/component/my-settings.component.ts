import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ResourceManager, storage} from '../../core';
import {UserSettings} from '../../shared/user-model';
import {MyProfileServiceImpl} from '../service/impl/MyProfileServiceImpl';
import {MyProfileService} from '../service/MyProfileService';
import {BaseMyProfileComponent} from './base-my-profile.component';

@Component({
  selector: 'app-my-settings',
  templateUrl: '../view/mysettings.html',
  providers: [MyProfileServiceImpl]
})
export class MySettingsComponent extends BaseMyProfileComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute, profileService: MyProfileServiceImpl) {
    super(viewContainerRef, router, route);
    // @ts-ignore
    this.profileService = profileService;
  }

  profileService: MyProfileService;
  settings: UserSettings = new UserSettings();
  dateFormats = [
    'MM/dd/yyyy',
    'M/d/yyyy',
    'yyyy/MM/dd',
    'yyyy/M/d',
    'dd/MM/yyyy',
    'dd/MM/yy',
    'd/MM/yyyy',
    'd/M/yyyy',
    'yyyy-MM-dd',
    'yyyy-M-d',
    'dd-MM-yyyy',
    'dd-MM-yy',
    'd-M-yyyy',
    'dd/MM yyyy',
    'd. M. yyyy',
    'yyyy.MM.dd',
    'yyyy.MM.dd.',
    'yy.MM.dd',
    'MM.dd.yyyy',
    'dd.MM.yyyy',
    'dd.MM.yy',
    'd.M.yyyy',
    'd.MM.yyyy',
    'd.M.yyyy.'];

  loadData() {
    this.profileService.getMySettings(storage.getUserId()).subscribe((userSettings: UserSettings) => {
      this.settings = userSettings;
    });
  }

  saveOnClick() {
    this.profileService.saveMySettings(storage.getUserId(), this.settings).subscribe(success => {
      if (success) {
        const msg = ResourceManager.getString('success_save_my_settings');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_save_my_settings');
        this.showDanger(msg);
      }
    });
  }
}
