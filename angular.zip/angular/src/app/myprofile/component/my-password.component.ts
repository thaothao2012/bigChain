import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {storage} from '../../core';
import {MyPasswordChange} from '../model/MyPasswordChange';
import {MyProfileServiceImpl} from '../service/impl/MyProfileServiceImpl';
import {MyProfileService} from '../service/MyProfileService';
import {BaseMyProfileComponent} from './base-my-profile.component';

@Component({
  selector: 'app-my-password',
  templateUrl: '../view/mypassword.html',
  providers: [MyProfileServiceImpl]
})
export class MyPasswordComponent extends BaseMyProfileComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router, route: ActivatedRoute) {
    super(viewContainerRef, router, route);
  }

  user: MyPasswordChange = {
    userName: storage.getUserName(),
    currentPassword: '',
    newPassword: ''
  };

  changePassword() {
    this.navigate('signin');
  }
}
