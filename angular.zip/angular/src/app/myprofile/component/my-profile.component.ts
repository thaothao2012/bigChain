import {Component, ViewContainerRef} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ReflectionUtil, ResourceManager, storage, StringUtil, UIUtil} from '../../core';
import {PopupComponentService} from '../../shared/service/popupService';
import {Achievement, Interest, User} from '../../shared/user-model';
import {MyProfileServiceImpl} from '../service/impl/MyProfileServiceImpl';
import {MyProfileService} from '../service/MyProfileService';
import {BaseMyProfileComponent} from './base-my-profile.component';
import {GeneralInfoComponent} from './general-info.component';

@Component({
  selector: 'app-my-profile',
  templateUrl: '../view/myprofile.html',
  providers: [MyProfileServiceImpl],
  styleUrls: ['../view/my-profile.scss'],
  entryComponents: [GeneralInfoComponent]
})
export class MyProfileComponent extends BaseMyProfileComponent {
  constructor(viewContainerRef: ViewContainerRef, router: Router,
              route: ActivatedRoute, profileService: MyProfileServiceImpl,
              private popup: PopupComponentService) {
    super(viewContainerRef, router, route);
    this.profileService = profileService;
  }

  profileService: MyProfileService;
  user: User = new User();

  isOpen = false;
  isEditingAbout = false;
  isEditingInterest = false;
  isEditingAchievement = false;
  isEditingSkill = false;
  isLookingFor = false;
  achievementName = '';
  hightLightAchie = false;
  achievementDes = '';
  skillsEditing = [];
  bio = '';
  textSkillsEditing = '';
  interestEdit = '';
  newLookingFor = '';
  newSkillHireable = false;
  isEditing = false;
  objectUser = {};

  aboutEditing: string;
  interestEditing: Interest[] = new Array();
  achievementEditing: Achievement[] = new Array();

  newAchieName: string;
  newAchieDes: string;

  loadData() {
    this.profileService.getMyProfile(storage.getUserId()).subscribe((user: User) => {
      this.user = user;
      this.objectUser = ReflectionUtil.clone(this.user) ? ReflectionUtil.clone(this.user) : {};
    });
  }

  saveEditing() {
    if (this.isEditing) {
      this.profileService.saveMyProfile(storage.getUserId(), this.user).subscribe(successs => {
        if (successs) {
          const msg = ResourceManager.getString('success_save_my_profile');
          this.showInfo(msg);
          this.loadData();
          this.close();
        } else {
          const msg = ResourceManager.getString('fail_save_my_profile');
          this.alertError(msg);
        }
      }, err => {
        const msg = ResourceManager.getString('fail_save_my_profile');
        this.alertError(msg);
      });
    }
  }

  showChangeStatus = () => {

  };

  toggleEditModeAbout() {
    this.isEditingAbout = !this.isEditingAbout;
    this.isEditing = !this.isEditing;
  }

  toggleEditModeInterest() {
    this.isEditingInterest = !this.isEditingInterest;
    this.isEditing = !this.isEditing;
  }

  toggleEditModeAchievement() {
    this.isEditingAchievement = !this.isEditingAchievement;
    this.isEditing = !this.isEditing;
  }

  toggleEditingSkill() {
    this.isEditingSkill = !this.isEditingSkill;
    this.isEditing = !this.isEditing;
  }

  toggleEditingLookingFor() {
    this.isLookingFor = !this.isLookingFor;
    this.isEditing = !this.isEditing;
  }


  close() {
    if (this.isEditingAbout) {
      this.isEditingAbout = !this.isEditingAbout;
    }
    if (this.isEditingAchievement) {
      this.achievementName = '';
      this.hightLightAchie = false;
      this.achievementDes = '';
      this.isEditingAchievement = !this.isEditingAchievement;
    }
    if (this.isEditingInterest) {
      this.isEditingInterest = !this.isEditingInterest;
    }
    if (this.isEditingSkill) {
      this.textSkillsEditing = '';
      this.isEditingSkill = !this.isEditingSkill;
    }
    if (this.isLookingFor) {
      this.textSkillsEditing = '';
      this.isLookingFor = !this.isLookingFor;
    }
    console.log("test")
    this.isEditing = !this.isEditing;
  }

  cancel() {
    this.close();
    this.user = ReflectionUtil.clone(this.objectUser);
  }

  removeInterest(subject) {
    const user = this.user;
    if (this.user.interests) {
      const interests = user.interests.filter(item => item !== subject);
      user.interests = interests;
      this.user = user;
    }
  }


  removeAchievement(subject) {
    if (this.user.achievements) {
      const achievements = this.user.achievements.filter(item => item['subject'] !== subject);
      this.user.achievements = achievements;
    }
  }


  addAchievement() {
    const achievement: Achievement = new Achievement();
    let achievements = ReflectionUtil.cloneObject(this.user.achievements);
    achievement.subject = this.achievementName;
    achievement.description = this.achievementDes;
    achievement.highlight = this.hightLightAchie;
    if (this.achievementName && this.achievementName.trim().length > 0 && !this.isExistInArray(achievements, achievement, 'subject')) {
      achievements = achievements? achievements: [];
      achievements.push(achievement);
      this.user.achievements = achievements;
      this.user.achievements = achievements;
      this.achievementName = '';
      this.achievementDes = '';
      this.hightLightAchie = false;
    }
  }

  addInterestEditing() {
    const user = this.user;
    const interestEdit = this.interestEdit;
    const interests = user.interests ? user.interests : [];
    if (interestEdit && interestEdit.trim() !== '') {
      if (!this.isExistInArray(interests, interestEdit, '')) {
        // @ts-ignore
        interests.push(interestEdit);
        user.interests = interests;
      }
    }
  }

  addAboutEditing() {
    const bio = this.bio;
    const user = this.user;
    if (bio && bio.trim() !== '') {
      user.bio = bio;
      this.bio = bio;
      this.user = user;
    }
  }

  removeSkill(skillContent) {
    const user = this.user;
    user.skills = user.skills.filter(item => item['skill'] !== skillContent);
    this.user = user;
  }

  addSkill() {
    const user = this.user;
    const textSkillsEditing = this.textSkillsEditing;
    const newSkillHireable = this.newSkillHireable;
    const skillsEditing = user.skills ? user.skills : [];
    if (textSkillsEditing && textSkillsEditing.trim() !== '') {
      const item = {
        hirable: newSkillHireable,
        skill: textSkillsEditing
      };
      if (!this.isExistInArray(skillsEditing, item, 'skill')) {
        skillsEditing.push(item);
        user.skills = skillsEditing;
        this.textSkillsEditing = textSkillsEditing;
        this.user = user;
      }
    }
  }


  removeLookingFor(lookingForContent) {
    const user = this.user;
    user.lookingFor = user.lookingFor.filter(item => item !== lookingForContent);
    this.user = user;
  }

  addLookingFor() {
    const newLookingFor = this.newLookingFor;
    const user = this.user;
    const lookingFor = user.lookingFor ? user.lookingFor : [];
    if (newLookingFor && newLookingFor.trim() !== '') {
      if (!this.isExistInArray(lookingFor, newLookingFor, '')) {
        lookingFor.push(newLookingFor);
        user.lookingFor = lookingFor;
        this.user = user;
      }
    }
  }

  isExistInArray(arr, item, key) {
    let isExist = false;

    if (!arr || arr.length === 0) {
      return false;
    }
    if (!event) {
      return;
    }
    if (key.length !== 0) {
      isExist = arr.filter(itemFilter => itemFilter[key] === item[key]).length > 0;
    } else {
      isExist = arr.filter(itemFilter => itemFilter === item).length > 0;
    }
    const msg = StringUtil.format(ResourceManager.getString('error_item_exist'), '');
    if (isExist) {
      UIUtil.alertError(msg);
    }
    return isExist;
  }


  showPopup() {
    const ref = this.popup.show(
      GeneralInfoComponent,
      Object.assign({}, this.user)
    );
    ref.content.onClose.subscribe(res => {
      this.user = res.data;
      if (res.status && res.status === 'success') {
        const msg = ResourceManager.getString('success_save_my_profile');
        this.showInfo(msg);
      } else {
        if (res.status && res.status === 'fail') {
          const msg = ResourceManager.getString('fail_save_my_profile');
          this.showDanger(msg);
        }
      }
    });
  }
}
