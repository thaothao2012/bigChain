import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MyPasswordComponent} from './component/my-password.component';
import {MyProfileComponent} from './component/my-profile.component';
import {MySettingsComponent} from './component/my-settings.component';
import {MyProfileModuleComponent} from './my-profile.module.component';

const myProfileRoutes: Routes = [
  {
    path: '',
    component: MyProfileModuleComponent,
    children: [
      {path: 'myprofile', component: MyProfileComponent},
      {path: 'mysettings', component: MySettingsComponent},
      {path: 'mypassword', component: MyPasswordComponent}
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(myProfileRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class MyProfileRoutingModule {
}
