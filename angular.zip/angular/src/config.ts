const config = {
  backOfficeUrl: 'http://10.1.0.234:3002/',
  authenticationServiceUrl: 'http://10.1.0.234:3002',
  passwordServiceUrl: 'http://10.1.0.234:3002',
  userRegistrationServiceUrl: 'http://10.1.0.234:3002',
  myprofileServiceUrl: 'http://10.1.0.234:3002',
  userServiceUrl: 'http://10.1.0.234:3002/users',
  accessGroupServiceUrl: 'http://10.1.0.234:3002/accessGroup',
  accessRoleServiceUrl: 'http://10.1.0.234:3002/accessRoleAssignment',
  appAccessRoleServiceUrl: 'http://10.1.0.234:3002/common/resources/accessRole',
  articleServiceUrl: 'http://10.1.0.234:3002/articles',
  setupPayerUrl: 'http://10.1.0.234:3002/profilePayerCompany',
  setupPayeeUrl: 'http://10.1.0.234:3002/profilePayeeCompany',
  setupBankUrl: 'http://10.1.0.234:3002/banks',
  setupBranchUrl: 'http://10.1.0.234:3002/branch',
  setupPaymentAccountUrl: 'http://10.1.0.234:3002/branch'
};

export default config;
