import {Location} from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {NO_ERRORS_SCHEMA, ViewContainerRef} from '@angular/core';
import {async, fakeAsync, inject, TestBed, tick} from '@angular/core/testing';
import {FormsModule} from '@angular/forms';
import {Router} from '@angular/router';
import {RouterTestingModule} from '@angular/router/testing';
import {
    CollapseModule, ModalModule,
    PaginationConfig,
    PaginationModule,
} from 'ngx-bootstrap';
import {CookieService} from '../../node_modules/ngx-cookie-service';
import {of} from '../../node_modules/rxjs';
import config from '../config';

import {SigninComponent} from '../app/authentication/component/signin.component';
import {AuthenticationServiceImpl} from '../app/authentication/service/impl/AuthenticationServiceImpl';

const mockService = {
        'status': '1',
        'user': {
          'title': null,
          'gender': null,
          'image': 'images/avatar-default.jpg',
          'nationality': null,
          'email': 'tmhieu@tma.com.vn',
          'phone': '0123456789',
          'address': null,
          'bio': null,
          'website': null,
          'occupation': null,
          'company': null,
          'remark': null,
          'status': 'A',
          'userId': 'be2057f53d224bac85353ba3022ea9fb',
          'sourceType': null,
          'userName': 'dnhan@tma.com.vn',
          'firstName': 'Hieu Hieu Hieu Hieu Hieu Hieu Hieu Hieu Hieu',
          'middleName': null,
          'lastName': 'Thai Minh Thai Minh Thai Minh Thai Minh Thai Minh',
          'displayName': 'Hieu Hieu Hieu Hieu Hieu Hieu Hieu Hieu Hieu Thai Minh Thai Minh Thai Minh Thai Minh Thai Minh',
          'dateOfBirth': null,
          'coverImage': null,
          'alternativeEmail': null,
          'lookingFor': null,
          'userType': '1',
          'linkedinAccount': null,
          'linkedinEmail': null,
          'linkedinActive': null,
          'googleAccount': null,
          'googleEmail': null,
          'googleActive': null,
          'facebookAccount': null,
          'facebookEmail': null,
          'facebookActive': null,
          'userNameActive': 'A',
          'twitterLink': null,
          'skypeLink': null,
          'instagramLink': null,
          'linkedinLink': null,
          'dribbbleLink': null,
          'googleLink': null,
          'facebookLink': null,
          'customLink01': null,
          'customLink02': null,
          'customLink03': null,
          'customLink04': null,
          'customLink05': null,
          'customLink06': null,
          'customLink07': null,
          'customLink08': null,
          'createdBy': 'be2057f53d224bac85353ba3022ea9fb',
          'createdDate': '2016-09-12T02:53:53.000Z',
          'modifiedBy': 'be2057f53d224bac85353ba3022ea9fb',
          'modifiedDate': '2018-09-12T07:44:09.000Z',
          'rowVersion': 5,
          'availableStatus': 'A',
          'sysInfo': {
            'ip': '::ffff:192.168.75.25',
            'statements': [],
            'userId': 'be2057f53d224bac85353ba3022ea9fb'
          },
          'signInType': 'Email'
        },
        'data': '123123xX',
        'passwordStatus': '0',
        'functions': [],
        'token': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6ImJlMjA1N2Y1M2QyMjRiYWM4NTM1M2JhMzAyMmVhOWZiIiwiZW1haWwiOiJ0bWhpZXVAdG1hLmNvbS52biIsInR5cGUiOiJFbWFpbCIsImlhdCI6MTUzNjc1NDY2MywiZXhwIjoxNTM2ODQxMDYzfQ.BSvXGVtFEkbjcMXF9UUL1rni9ahw5DNJ_Pi07ndoZZ8',
        'tokenExpiredDate': '2018-09-13T12:17:43.000Z'
};


describe('ContentCategory', () => {
    let location: Location;
    let router: Router;
    let fixture;
    let component: SigninComponent;
    let service: AuthenticationServiceImpl;
    let httpMock: HttpTestingController;

    const initTest = (testBed) => {
        router = testBed.get(Router);
        location = testBed.get(Location);
        fixture = testBed.createComponent(SigninComponent);
        router.initialNavigation();
        component = fixture.componentInstance;
        service = testBed.get(AuthenticationServiceImpl);
        httpMock = testBed.get(HttpTestingController);
    };
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                RouterTestingModule.withRoutes([]),
                FormsModule,
                HttpClientTestingModule,
            ],
            declarations: [
                SigninComponent
            ],
            providers: [
                ViewContainerRef, CookieService, AuthenticationServiceImpl
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });
        initTest(TestBed);
    }));


    it('Should require Email',
        fakeAsync(() => {
            fixture.detectChanges();
            component.ngOnInit();
            component.signin();
            fixture.detectChanges();
            tick(1000);
            const div = fixture.nativeElement.querySelector('div.alert');
            expect(div.textContent).toBe('Email is required. Please enter Email.');
        })
    );
    it('Should require Password',
        fakeAsync(() => {
            initTest(TestBed);
            fixture.detectChanges();

            spyOn(service, 'signin').and.returnValue(Promise.resolve());
            component.ngOnInit();
            const userInput = fixture.nativeElement.querySelector('#userName');
            userInput.value = 'dnhan@tma.com.vn';
            component.signin();
            fixture.detectChanges();
            tick(1000);
            const div = fixture.nativeElement.querySelector('div.alert');
            expect(div.textContent).toBe('Password is required. Please enter Password.');
            // const req = httpMock.expectOne(GlobalApps.SERVICE_URL + '/' + 'authentication');
            // expect(req.request.method).toBe('POST');
            // req.flush({});
            tick(1000);
            fixture.detectChanges();
            expect(location.path()).toBe('/');
        })
    );
    it('Should logged in',
        fakeAsync(() => {
            initTest(TestBed);
            const cookiService = TestBed.get(CookieService);
            fixture.detectChanges();

            spyOn(service, 'signin').and.returnValue(of(mockService));
            spyOn(component, 'navigateToHome').and.returnValue({});
            spyOn(cookiService, 'set').and.returnValue({});

            component.ngOnInit();
            const userInput = fixture.nativeElement.querySelector('#userName');
            userInput.value = 'dnhan@tma.com.vn';
            const passInput = fixture.nativeElement.querySelector('#password');
            passInput.value = '123123xX';
            component.signin();
            fixture.detectChanges();
            tick(1000);
            const req = httpMock.expectOne(config.authenticationServiceUrl + '/' + 'authentication/signin');
            expect(req.request.method).toBe('POST');
            req.flush(mockService);
            tick(1000);
            fixture.detectChanges();
            expect(component.navigateToHome).toHaveBeenCalled();

        })
    );
});

