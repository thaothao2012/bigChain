import * as H from 'history';
import * as React from 'react';
import {connect} from 'react-redux';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';
import {updateGlobalState} from '../common/redux/action/actions';
import {WithDefaultProps} from '../container/default';
import {PrivateRoute} from '../PrivateRoute';
import {AccessRoleAssignmentDiffForm} from './component/access-role-assignment-diff-form';
import {AccessRoleAssignmentForm} from './component/access-role-assignment-form';
import {AccessRoleAssignmentsForm} from './component/access-role-assignment/access-role-assignments-form';
import {AccessRoleDiffForm} from './component/access-role-diff-form';
import {AccessRoleForm} from './component/access-role-form';
import {AccessRolesForm} from './component/access-roles-form';

interface AppProps {
  history: H.History;
  setGlobalState: (data: any) => void;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    const commonProps = {
      rootUrl: this.props.match.url,
      exact: true,
      setGlobalState: this.props.setGlobalState
    };
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/access-role-definition'} exact={true} component={WithDefaultLayout(AccessRolesForm)} />
        <Route path={this.props.match.url + '/access-role-definition/add'} exact={true} component={WithDefaultLayout(AccessRoleForm)} />
        <Route path={this.props.match.url + '/access-role-definition/edit/:roleId/:cId'} exact={true} component={WithDefaultLayout(AccessRoleForm)} />
        <Route path={this.props.match.url + '/access-role-definition/approve/:roleId/:cId'} exact={true} component={WithDefaultLayout(AccessRoleDiffForm)} />
        <Route path={this.props.match.url + '/access-role-assignment'} exact={true} component={WithDefaultLayout(AccessRoleAssignmentsForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/add'} exact={true} component={WithDefaultLayout(AccessRoleAssignmentForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/edit/:roleId/:cId'} exact={true} component={WithDefaultLayout(AccessRoleAssignmentForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/approve/:roleId/:cId'} exact={true} component={WithDefaultLayout(AccessRoleAssignmentDiffForm)} /> */}

        <Route path={this.props.match.url + '/access-role-definition'} exact={true} component={WithDefaultProps(AccessRolesForm)} />
        <Route path={this.props.match.url + '/access-role-definition/add'} exact={true} component={WithDefaultProps(AccessRoleForm)} />
        <Route path={this.props.match.url + '/access-role-definition/edit/:roleId/:cId'} exact={true} component={WithDefaultProps(AccessRoleForm)} />
        <Route path={this.props.match.url + '/access-role-definition/approve/:roleId/:cId'} exact={true} component={WithDefaultProps(AccessRoleDiffForm)} />
        <PrivateRoute path={this.props.match.url + '/access-role-assignment'} exact={true} {...commonProps} component={WithDefaultProps(AccessRoleAssignmentsForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/add'} exact={true} component={WithDefaultProps(AccessRoleAssignmentForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/edit/:roleId/:cId'} exact={true} component={WithDefaultProps(AccessRoleAssignmentForm)} />
        <Route path={this.props.match.url + '/access-role-assignment/approve/:roleId/:cId'} exact={true} component={WithDefaultProps(AccessRoleAssignmentDiffForm)} />
      </React.Fragment>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    setGlobalState: (res) => dispatch(updateGlobalState(res))
  };
}

const withConnect = connect(null, mapDispatchToProps);

const RoleRoutes = compose(
  withRouter,
  withConnect
)(StatelessApp);
export default RoleRoutes;
