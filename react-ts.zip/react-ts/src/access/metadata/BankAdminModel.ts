import {DataType, Model} from '../../core';

export const bankAdminModel: Model = {
  name: 'bankAdmin',
  attributes: {
    bankAdminId: {
      type: DataType.Integer,
      primaryKey: true
    },
    userId: {
      type: DataType.String,
      length: 20,
      nullable: false
    },
    staffId: {
      type: DataType.String,
      length: 20,
      nullable: false
    },
    firstName: {
      type: DataType.String,
      length: 100,
      nullable: false
    },
    lastName: {
      type: DataType.String,
      length: 100,
      nullable: true
    },
    title: {
      type: DataType.String,
      length: 100,
      nullable: true
    },
    gender: {
      type: DataType.String,
      length: 10,
      nullable: true
    },
    pos: {
      type: DataType.String,
      length: 20,
      nullable: true
    },
    telephone: {
      type: DataType.String,
      length: 100,
      nullable: true
    },
    email: {
      type: DataType.String,
      length: 100,
      nullable: true
    },
    groupId: {
      type: DataType.String,
      length: 20,
      nullable: true
    },
    roleType: {
      type: DataType.String,
      length: 1,
      nullable: false
    },
    accessDateFrom: {
      type: DataType.DateTime,
      nullable: true
    },
    accessDateTo: {
      type: DataType.DateTime,
      nullable: true
    },
    accessTimeFrom: {
      type: DataType.String,
      nullable: true
    },
    accessTimeTo: {
      type: DataType.String,
      nullable: true
    },
    activate: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    ctrlStatus: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    actionStatus: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    actedBy: {
      type: DataType.String,
      length: 50,
      nullable: true
    },
    createdDate: {
      type: DataType.String,
      nullable: true
    }
  }
};
