import {DataType, Model} from '../../core';

export const accessGroupModel: Model = {
  name: 'accessGroup',
  attributes: {
    groupId: {
      type: DataType.String,
      primaryKey: true
    },
    cId: {
      type: DataType.String,
      primaryKey: true
    },
    entityType: {
      type: DataType.String,
      length: 1,
      nullable: true
    },
    groupName: {
      type: DataType.String ,
      length: 60
    },
    actedBy: {
      type: DataType.String,
      length: 50
    },
    ctrlStatus: {
      type: DataType.String,
      length: 255
    },
    actionStatus: {
      type: DataType.String,
      length: 1
    }
  }
};
