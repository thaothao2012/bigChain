import {DataType, Model} from '../../core';

export const accessModuleModel: Model = {
  name: 'accessModule',
  attributes: {
    moduleId: {
      type: DataType.String,
      primaryKey: true
    },
    moduleName: {
      type: DataType.String,
      length: 255,
      nullable: true
    },
    fullName: {
      type: DataType.String ,
      length: 255
    },
    parentId: {
      type: DataType.String,
      length: 50
    },
    path: {
      type: DataType.String
    },
    icon: {
      type: DataType.String,
      length: 255
    },
    createdDate: {
      type: DataType.String,
      length: 255
    },
    updatedDate: {
      type: DataType.String,
      length: 255
    }
  }
};
