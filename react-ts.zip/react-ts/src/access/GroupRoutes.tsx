import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {AccessGroupDiffForm} from './component/access-group-diff-form';
import {AccessGroupForm} from './component/access-group-form';
import {AccessGroupsForm} from './component/access-groups-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/access-group'} exact={true} component={WithDefaultLayout(AccessGroupsForm)} />
        <Route path={this.props.match.url + '/access-group/add'} exact={true} component={WithDefaultLayout(AccessGroupForm)} />
        <Route path={this.props.match.url + '/access-group/edit/:groupId/:cId'} exact={true} component={WithDefaultLayout(AccessGroupForm)} />
        <Route path={this.props.match.url + '/access-group/approve/:groupId/:cId'} exact={true} component={WithDefaultLayout(AccessGroupDiffForm)} /> */}

        <Route path={this.props.match.url + '/access-group'} exact={true} component={WithDefaultProps(AccessGroupsForm)} />
        <Route path={this.props.match.url + '/access-group/add'} exact={true} component={WithDefaultProps(AccessGroupForm)} />
        <Route path={this.props.match.url + '/access-group/edit/:groupId/:cId'} exact={true} component={WithDefaultProps(AccessGroupForm)} />
        <Route path={this.props.match.url + '/access-group/approve/:groupId/:cId'} exact={true} component={WithDefaultProps(AccessGroupDiffForm)} />
      </React.Fragment>
    );
  }
}

const GroupRoutes = compose(
  withRouter,
)(StatelessApp);
export default GroupRoutes;

