import {CtrlStatus} from '../enum/CtrlStatus';
import {AccessModule} from './AccessModule';
import {BankAdmin} from './BankAdmin';
import {ControlModel} from './ControlModel';

export class AccessRole extends ControlModel {
  roleId: string;
  cId: string;
  roleDesc: string;
  roleName: string;
  userType: string;
  evUserReg: string;
  evUserRegBank: string;
  evResetPwdBank: string;
  evResetPwdNonBank: string;
  evActivate: string;
  modules: AccessModule[];
  users: BankAdmin[];
  assignedBy: string;
  assignedStatus: string;
  assignedCtrlStatus: CtrlStatus;
  assignedDate: Date;
}
