import {ControlModel} from './ControlModel';

export class AccessGroup extends ControlModel {
  cId: string;
  groupId: string;
  groupName: string;
  entityType: string;
}
