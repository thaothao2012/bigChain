export enum Gender {
  Male= 'M',
  Female = 'F',
}
