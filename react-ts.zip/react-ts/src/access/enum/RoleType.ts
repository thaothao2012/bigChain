export enum RoleType {
  Maker = 'M',
  Checker = 'C'
}
