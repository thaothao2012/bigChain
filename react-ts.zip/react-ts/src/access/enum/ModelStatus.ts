export enum ModelStatus {
  Activated = 'T',
  Deactivated = 'F'
}
