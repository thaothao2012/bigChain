import {ControlSearchModel} from './ControlSearchModel';

export interface BankAdminSM extends ControlSearchModel {
    userId: string;
    activate: string;
}
