import {EditPermissionBuilder, LocaleModelFormatter, SearchPermissionBuilder} from '../../core';
import {MasterDataService, MasterDataServiceImpl} from '../../shared/master-data';
import {ODDEditPermissionBuilder} from '../../shared/permission/ODDEditPermissionBuilder';
import {ODDSearchPermissionBuilder} from '../../shared/permission/ODDSearchPermissionBuilder';
import {BusinessSearchModelFormatter} from '../formatter/BusinessSearchModelFormatter';
import {AccessGroupService} from '../service/AccessGroupService';
import {AccessModuleService} from '../service/AccessModuleService';
import {AccessRoleAssignmentService} from '../service/AccessRoleAssignmentService';
import {AccessRoleService} from '../service/AccessRoleService';
import {ApprAccessGroupService} from '../service/ApprAccessGroupService';
import {ApprAccessRoleAssignmentService} from '../service/ApprAccessRoleAssignmentService';
import {ApprBankAdminService} from '../service/ApprBankAdminService';
import {BankAdminService} from '../service/BankAdminService';
import {AccessGroupServiceImpl} from '../service/impl/AccessGroupServiceImpl';
import {AccessModuleServiceImpl} from '../service/impl/AccessModuleServiceImpl';
import {AccessRoleAssignmentServiceImpl} from '../service/impl/AccessRoleAssignmentServiceImpl';
import {AccessRoleServiceImpl} from '../service/impl/AccessRoleServiceImpl';
import {ApprAccessGroupServiceImpl} from '../service/impl/ApprAccessGroupServiceImpl';
import {ApprAccessRoleAssignmentServiceImpl} from '../service/impl/ApprAccessRoleAssignmentServiceImpl';
import {ApprBankAdminServiceImpl} from '../service/impl/ApprBankAdminServiceImpl';
import {BankAdminServiceImpl} from '../service/impl/BankAdminServiceImpl';

class ApplicationContext {
  private readonly businessSearchModelFormatter: LocaleModelFormatter<any, any>;
  private readonly editPermissionBuilder: EditPermissionBuilder;
  private readonly searchPermissionBuilder: SearchPermissionBuilder;
  private readonly masterDataService: MasterDataService;
  private readonly accessGroupService: AccessGroupService;
  private readonly apprAccessGroupService: ApprAccessGroupService;
  private readonly accessRoleAssignmentService: AccessRoleAssignmentService;
  private readonly apprAccessRoleAssignmentService: ApprAccessRoleAssignmentService;
  private readonly accessRoleDefinitionService: AccessRoleService;
  private readonly accessModuleService: AccessModuleService;
  private readonly bankAdminService: BankAdminService;
  private readonly apprBankAdminService: ApprBankAdminService;

  constructor() {
    this.businessSearchModelFormatter = new BusinessSearchModelFormatter();
    this.editPermissionBuilder = new ODDEditPermissionBuilder();
    this.searchPermissionBuilder = new ODDSearchPermissionBuilder();
    this.masterDataService = new MasterDataServiceImpl();
    this.accessGroupService = new AccessGroupServiceImpl();
    this.apprAccessGroupService = new ApprAccessGroupServiceImpl();
    this.accessRoleAssignmentService = new AccessRoleAssignmentServiceImpl();
    this.apprAccessRoleAssignmentService = new ApprAccessRoleAssignmentServiceImpl();
    this.accessRoleDefinitionService = new AccessRoleServiceImpl();
    this.accessModuleService = new AccessModuleServiceImpl();
    this.bankAdminService = new BankAdminServiceImpl();
    this.apprBankAdminService = new ApprBankAdminServiceImpl();
  }

  getBusinessSearchModelFormatter(): LocaleModelFormatter<any, any> {
    return this.businessSearchModelFormatter;
  }

  getEditPermissionBuilder(): EditPermissionBuilder {
    return this.editPermissionBuilder;
  }

  getSearchPermissionBuilder(): SearchPermissionBuilder {
    return this.searchPermissionBuilder;
  }

  getMasterDataService(): MasterDataService {
    return this.masterDataService;
  }

  getAccessGroupService(): AccessGroupService {
    return this.accessGroupService;
  }

  getApprAccessGroupService(): ApprAccessGroupService {
    return this.apprAccessGroupService;
  }

  getAccessRoleAssignmentService(): AccessRoleAssignmentService {
    return this.accessRoleAssignmentService;
  }

  getApprAccessRoleAssignmentService(): ApprAccessRoleAssignmentService {
    return this.apprAccessRoleAssignmentService;
  }

  getAccessRoleDefinitionService(): AccessRoleService {
    return this.accessRoleDefinitionService;
  }

  getAccessModuleService(): AccessModuleService {
    return this.accessModuleService;
  }

  getBankAdminService(): BankAdminService {
    return this.bankAdminService;
  }

  getApprBankAdminService(): ApprBankAdminService {
    return this.apprBankAdminService;
  }
}

const applicationContext = new ApplicationContext();

export default applicationContext;
