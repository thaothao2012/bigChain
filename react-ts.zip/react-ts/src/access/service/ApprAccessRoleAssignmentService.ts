import {ViewSearchService} from '../../core';
import {AccessRole} from '../model/AccessRole';
import {AccessRoleSM} from '../search-model/AccessRoleSM';

export interface ApprAccessRoleAssignmentService extends ViewSearchService<AccessRole, AccessRoleSM> {
}
