import {GenericSearchDiffApprService} from '../../core';
import {AccessGroup} from '../model/AccessGroup';
import {AccessGroupSM} from '../search-model/AccessGroupSM';

export interface AccessGroupService extends GenericSearchDiffApprService<AccessGroup, AccessGroupSM> {
}
