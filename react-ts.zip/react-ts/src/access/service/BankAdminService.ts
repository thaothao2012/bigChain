import {GenericSearchDiffApprWebService} from '../../core';
import {BankAdmin} from '../model/BankAdmin';
import {BankAdminSM} from '../search-model/BankAdminSM';

export interface BankAdminService extends GenericSearchDiffApprWebService<BankAdmin, BankAdminSM> {
}
