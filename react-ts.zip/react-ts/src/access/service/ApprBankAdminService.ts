import {ViewSearchService} from '../../core';
import {BankAdmin} from '../model/BankAdmin';
import {BankAdminSM} from '../search-model/BankAdminSM';

export interface ApprBankAdminService extends ViewSearchService<BankAdmin, BankAdminSM> {
}
