import config from '../../../config';
import {GenericSearchDiffApprWebService} from '../../../core';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import {AccessRoleService} from '../AccessRoleService';

export class AccessRoleServiceImpl extends GenericSearchDiffApprWebService<AccessRole, AccessRoleSM> implements AccessRoleService {
  constructor() {
    super(config.backOfficeUrl + 'accessRoleDefinition', accessRoleModel);
  }

  protected formatObject(obj): AccessRole {
    const role: AccessRole = super.formatObject(obj);
    if (role.modules) {
      role.modules.forEach(module => {
          module.showName = module.parentId ? module.parentId + '->' + module.moduleName : module.moduleName;
      });
    }
    return role;
  }
}
