import config from '../../../config';
import {GenericSearchDiffApprWebService} from '../../../core';
import {accessGroupModel} from '../../metadata/AccessGroupModel';
import {AccessGroup} from '../../model/AccessGroup';
import {AccessGroupSM} from '../../search-model/AccessGroupSM';
import {AccessGroupService} from '../AccessGroupService';

export class AccessGroupServiceImpl extends GenericSearchDiffApprWebService<AccessGroup, AccessGroupSM> implements AccessGroupService {
  constructor() {
    super(config.backOfficeUrl + 'accessGroup', accessGroupModel);
  }
}
