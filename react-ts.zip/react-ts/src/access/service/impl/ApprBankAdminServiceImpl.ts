import config from '../../../config';
import {ViewSearchWebService} from '../../../core';
import {bankAdminModel} from '../../metadata/BankAdminModel';
import {BankAdmin} from '../../model/BankAdmin';
import {BankAdminSM} from '../../search-model/BankAdminSM';
import {ApprBankAdminService} from '../ApprBankAdminService';

export class ApprBankAdminServiceImpl extends ViewSearchWebService<BankAdmin, BankAdminSM> implements ApprBankAdminService {
  constructor() {
    super(config.backOfficeUrl + 'common/resources/bankAdmin', bankAdminModel);
  }
}
