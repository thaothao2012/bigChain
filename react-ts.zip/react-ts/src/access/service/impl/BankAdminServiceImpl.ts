import config from '../../../config';
import {GenericSearchDiffApprWebService} from '../../../core';
import {bankAdminModel} from '../../metadata/BankAdminModel';
import {BankAdmin} from '../../model/BankAdmin';
import {BankAdminSM} from '../../search-model/BankAdminSM';
import {BankAdminService} from '../BankAdminService';

export class BankAdminServiceImpl extends GenericSearchDiffApprWebService<BankAdmin, BankAdminSM> implements BankAdminService {
  constructor() {
    super(config.backOfficeUrl + 'bankAdmin', bankAdminModel);
  }
}
