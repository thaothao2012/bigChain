import config from '../../../config';
import {ViewWebService} from '../../../core';
import {accessModuleModel} from '../../metadata/AccessModuleModel';
import {AccessModule} from '../../model/AccessModule';
import {AccessModuleService} from '../AccessModuleService';

export class AccessModuleServiceImpl extends ViewWebService<AccessModule> implements AccessModuleService {
  constructor() {
    super(config.backOfficeUrl + 'common/resources/accessModule', accessModuleModel);
  }

  protected formatObjects(obj): AccessModule[] {
    const list: AccessModule[] = super.formatObject(obj);
    const available = [];
    if (list) {
      list.forEach(dad => {
        if (dad.parentId === '') {
          available.push(dad);
        }
      });
      available.sort((a, b) =>
        a.order - b.order);
      available.forEach(dad => {
        const son = list.filter(item => item.parentId === dad.moduleId);
        son.sort((a, b) =>
          a.order - b.order);
        dad.children = son;
      });
    }
    return available;
  }
}
