import config from '../../../config';
import {ViewSearchWebService} from '../../../core';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import {ApprAccessRoleAssignmentService} from '../ApprAccessRoleAssignmentService';

export class ApprAccessRoleAssignmentServiceImpl extends ViewSearchWebService<AccessRole, AccessRoleSM> implements ApprAccessRoleAssignmentService {
  constructor() {
    super(config.backOfficeUrl + 'common/resources/accessRole', accessRoleModel);
  }

  protected formatObject(obj): AccessRole {
    const role: AccessRole = super.formatObject(obj);
    if (role.modules) {
      role.modules.forEach(module => {
          module.showName = module.parentId ? module.parentId + '->' + module.moduleName : module.moduleName;
      });
    }
    return role;
  }
}
