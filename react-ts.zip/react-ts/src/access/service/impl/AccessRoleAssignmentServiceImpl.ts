import config from '../../../config';
import {GenericSearchDiffApprWebService} from '../../../core';
import {accessRoleModel} from '../../metadata/AccessRoleModel';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import {AccessRoleAssignmentService} from '../AccessRoleAssignmentService';

export class AccessRoleAssignmentServiceImpl extends GenericSearchDiffApprWebService<AccessRole, AccessRoleSM> implements AccessRoleAssignmentService {
  constructor() {
    super(config.backOfficeUrl + 'accessRoleAssignment', accessRoleModel);
  }

  protected formatObject(obj): AccessRole {
    const role: AccessRole = super.formatObject(obj);
    if (role.modules) {
      role.modules.forEach(module => {
          module.showName = module.parentId ? module.parentId + '->' + module.moduleName : module.moduleName;
      });
    }
    return role;
  }
}
