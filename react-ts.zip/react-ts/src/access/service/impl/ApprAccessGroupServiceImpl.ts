import config from '../../../config';
import {ViewSearchWebService} from '../../../core';
import {accessGroupModel} from '../../metadata/AccessGroupModel';
import {AccessGroup} from '../../model/AccessGroup';
import {AccessGroupSM} from '../../search-model/AccessGroupSM';
import {ApprAccessGroupService} from '../ApprAccessGroupService';

export class ApprAccessGroupServiceImpl extends ViewSearchWebService<AccessGroup, AccessGroupSM> implements ApprAccessGroupService {
  constructor() {
    super(config.backOfficeUrl + 'common/resources/accessGrp', accessGroupModel);
  }
}
