import {GenericSearchDiffApprWebService} from '../../core';
import {AccessRole} from '../model/AccessRole';
import {AccessRoleSM} from '../search-model/AccessRoleSM';

export interface AccessRoleService extends GenericSearchDiffApprWebService<AccessRole, AccessRoleSM> {
}
