import {ViewWebService} from '../../core';
import {AccessModule} from '../model/AccessModule';

export interface AccessModuleService extends ViewWebService<AccessModule> {

}
