import {ViewSearchService} from '../../core';
import {AccessGroup} from '../model/AccessGroup';
import {AccessGroupSM} from '../search-model/AccessGroupSM';

export interface ApprAccessGroupService extends ViewSearchService<AccessGroup, AccessGroupSM> {
}
