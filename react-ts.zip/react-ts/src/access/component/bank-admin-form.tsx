import * as React from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import 'react-day-picker/lib/style.css';
import {zip} from 'rxjs';
import '../../assets/css//datepicker.css';
import {DatePicker} from '../../control/DatePicker';
import {BaseInternalState, EditComponent, HistoryProps, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {Gender} from '../enum/Gender';
import {ModelStatus} from '../enum/ModelStatus';
import {RoleType} from '../enum/RoleType';
import {bankAdminModel} from '../metadata/BankAdminModel';
import {BankAdmin} from '../model/BankAdmin';

interface InternalState extends BaseInternalState {
  bankAdmin: BankAdmin;
}

export class BankAdminForm extends EditComponent<BankAdmin, HistoryProps, InternalState> {
  constructor(props) {
    super(props, bankAdminModel, applicationContext.getBankAdminService(), applicationContext.getEditPermissionBuilder());
    this.state = {
      bankAdmin: {},
      titleList: [],
      positionList: [],
      groups: [],
      selectedDay: undefined,
    };
    this.updateChangedOnly = false;
  }
  private readonly masterDataService = applicationContext.getMasterDataService();
  private readonly accessGroupService = applicationContext.getApprAccessGroupService();

  getKeyValue(objs, key, value) {
    return objs.map(item => {
      return { value: item[key], text: item[value] };
    });
  }

  initData() {
    zip(
      this.masterDataService.getTitles(),
      this.masterDataService.getPositions(),
      this.masterDataService.getGenders(),
      this.accessGroupService.getAll()
    ).subscribe(([titleList, positionList, groups]) => {
      groups = this.getKeyValue(groups, 'groupId', 'groupName');
      this.setState({
        titleList,
        positionList,
        groups
      }, this.loadData);
    }, this.handleError);
  }

  loadGender(bankAdmin?: BankAdmin) {
    bankAdmin = bankAdmin === undefined ? this.state.bankAdmin : bankAdmin;
    if (bankAdmin.title === 'Mr') {
      this.setState({ bankAdmin: { ...bankAdmin, gender: Gender.Male } });
    } else {
      this.setState({ bankAdmin: { ...bankAdmin, gender: Gender.Female } });
    }
  }

  createModel(): BankAdmin {
    const bankAdmin = super.createModel();
    bankAdmin.bankAdminId = 0;
    bankAdmin.activate = ModelStatus.Activated;
    bankAdmin.roleType = RoleType.Maker;
    bankAdmin.accessTimeFrom = '00:00';
    bankAdmin.accessTimeTo = '00:00';

    delete bankAdmin.createdDate;

    return bankAdmin;
  }

  render() {
    const resource = this.resource;
    const { bankAdmin } = this.state;
    const { titleList, positionList, groups } = this.state;
    const { accessDateFrom, accessDateTo } = bankAdmin;
    return (
      <div className='view-container'>
        <form id='bankAdminForm' name='bankAdminForm' model-name='bankAdmin' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{this.isNewMode() ? resource.create : resource.edit} {resource.bank_admin_subject}</h2>
          </header>
          <div className='row'>
            <label className='col s12 m6'>
              {resource.user_id}
              <input
                type='text'
                id='userId'
                name='userId'
                value={bankAdmin.userId}
                onChange={this.updateState}
                maxLength={20} required={true}
                placeholder={resource.user_id} />
            </label>
            <label className='col s12 m6'>
              {resource.bank_admin_staff_id}
              <input
                type='text'
                id='staffId'
                name='staffId'
                value={bankAdmin.staffId}
                onChange={this.updateState}
                maxLength={20} required={true}
                placeholder={resource.bank_admin_staff_id} />
            </label>
            <label className='col s12 m6'>
              {resource.first_name}
              <input
                type='text'
                id='firstName'
                name='firstName'
                value={bankAdmin.firstName}
                onChange={this.updateState}
                maxLength={100} required={true}
                placeholder={resource.first_name} />
            </label>
            <label className='col s12 m6'>
              {resource.last_name}
              <input
                type='text'
                id='lastName'
                name='lastName'
                value={bankAdmin.lastName}
                onChange={this.updateState}
                maxLength={100}
                placeholder={resource.last_name} />
            </label>
            <label className='col s12 m6'>
              {resource.person_title}
              <select
                id='title'
                name='title'
                value={bankAdmin.title}
                onChange={(e) => {
                  this.updateState(e, this.loadGender);
                }}>
                <option selected={true} value=''>{resource.please_select}</option>
                )
                  {titleList.map((item, index) => (
                  <option key={index} value={item.value}>{item.text}</option>)
                )}
              </select>
            </label>
            <label className='col s12 m6'>
              {resource.gender}
              <div className='radio-group'>
                <label>
                  <input
                    type='radio'
                    id='gender'
                    name='gender'
                    onChange={this.updateState}
                    disabled={bankAdmin.title !== 'Dr'}
                    value={Gender.Male} checked={bankAdmin.gender === Gender.Male} />
                  {resource.male}
                </label>
                <label>
                  <input
                    type='radio'
                    id='gender'
                    name='gender'
                    onChange={this.updateState}
                    disabled={bankAdmin.title !== 'Dr'}
                    value={Gender.Female} checked={bankAdmin.gender === Gender.Female} />
                  {resource.female}
                </label>
              </div>
            </label>
            <label className='col s12 m6'>
              {resource.bank_admin_position}
              <select
                id='pos'
                name='pos'
                value={bankAdmin.pos}
                onChange={this.updateState}>
                <option selected={true} value=''>{resource.please_select}</option>
                )
                  {positionList.map((item, index) => (
                  <option key={index} value={item.value}>{item.text}</option>)
                )}
              </select>
            </label>
            <label className='col s12 m6'>
              {resource.phone}
              <input
                type='tel'
                id='telephone'
                name='telephone'
                value={StringUtil.formatPhone(bankAdmin.telephone)}
                onChange={this.updatePhoneState}
                onBlur={this.checkPhoneOnBlur}
                maxLength={17}
                placeholder={resource.phone} />
            </label>
            <label className='col s12 m6'>
              {resource.email}
              <input
                type='text'
                id='email'
                name='email'
                data-type='email'
                value={bankAdmin.email}
                onChange={this.updateState}
                onBlur={this.checkEmailOnBlur}
                maxLength={100}
                placeholder={resource.email} />
            </label>
            <label className='col s12 m6'>
              {resource.group}
              <select
                id='groupId'
                name='groupId'
                value={bankAdmin.groupId}
                onChange={this.updateState}>
                <option selected={true} value=''>{resource.please_select}</option>
                )
                  {groups.map((item, index) => (
                  <option key={index} value={item.value}>{item.text}</option>)
                )}
              </select>
            </label>
            <div className='col s12 m6 radio-section'>
              {resource.role_type}
              <div className='radio-group'>
                <label>
                  <input
                    type='radio'
                    id='roleType'
                    name='roleType'
                    onChange={this.updateState}
                    value={RoleType.Maker} checked={bankAdmin.roleType === RoleType.Maker} />
                  {resource.role_type_maker}
                </label>
                <label>
                  <input
                    type='radio'
                    id='roleType'
                    name='roleType'
                    onChange={this.updateState}
                    value={RoleType.Checker} checked={bankAdmin.roleType === RoleType.Checker} />
                  {resource.role_type_checker}
                </label>
              </div>
            </div>
            <div className='col s12 m6 radio-section'>
              {resource.bank_admin_activate}
              <div className='radio-group'>
                <label>
                  <input
                    type='radio'
                    id='activate'
                    name='activate'
                    onChange={this.updateState}
                    value={ModelStatus.Activated} checked={bankAdmin.activate === ModelStatus.Activated} />
                  {resource.yes}
                </label>
                <label>
                  <input
                    type='radio'
                    id='activate'
                    name='activate'
                    onChange={this.updateState}
                    value={ModelStatus.Deactivated} checked={bankAdmin.activate === ModelStatus.Deactivated} />
                  {resource.no}
                </label>
              </div>
            </div>
            <label className='col s12 m6'>
              {resource.bank_admin_access_date} ({this.dateFormat})
              <div>
                <label className='col s12 m6 up-date-picker' data-field='accessDateFrom'>
                  {resource.from}
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    parseDate={this.parseDate}
                    value={bankAdmin.accessDateFrom}
                    onDayChange={this.updateDayPicker}
                  />
                </label>
                <label className='col s12 m6'>
                  {resource.to}
                  <DatePicker
                    onChangeData={this.updateDateState}
                    value={accessDateTo}
                    minDate={accessDateFrom}
                    required={true}
                    name='accessDateTo'
                    locale='en-IE'
                    className='form-group'
                  />
                </label>
              </div>
            </label>
            <label className='col s12 m6'>
              {resource.bank_admin_access_time}
              <div>
                <label className='col s12 m6'>
                  {resource.from}
                  <input
                    type='time'
                    id='accessTimeFrom'
                    name='accessTimeFrom'
                    value={bankAdmin.accessTimeFrom}
                    onChange={this.updateState} />
                </label>
                <label className='col s12 m6'>
                  {resource.to}
                  <input
                    type='time'
                    id='accessTimeTo'
                    name='accessTimeTo'
                    value={bankAdmin.accessTimeTo}
                    onChange={this.updateState} />
                </label>
              </div>
            </label>
          </div>
          <footer>
            {this.editable &&
              <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
                {resource.save}
              </button>}
          </footer>
        </form>
      </div>
    );
  }
}
