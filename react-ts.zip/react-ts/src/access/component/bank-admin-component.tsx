import * as React from 'react';
import {zip} from 'rxjs';
import {DatePicker} from '../../control/DatePicker';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {GenericSearchComponent, HistoryProps, SearchModel, SearchState, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {Gender} from '../enum/Gender';
import {ModelStatus } from '../enum/ModelStatus';
import {RoleType } from '../enum/RoleType';
import {bankAdminModel } from '../metadata/BankAdminModel';
import {BankAdmin} from '../model/BankAdmin';

export class BankAdminComponent extends GenericSearchComponent<BankAdmin, SearchModel, HistoryProps, SearchState<BankAdmin>> {
  constructor(props) {
    super(props, bankAdminModel, applicationContext.getBankAdminService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      ctrlStatusList: [],
      activationStatusList: [],
      results: [],
      ctrlStatus: [],
      activate: [],
      userId: '', // end of for search

      bankAdmin: {}, // for edit
      titleList: [],
      positionList: [],
      groups: [],
      selectedDay: undefined,
    };
    this.updateChangedOnly = false;
  }
  private readonly masterDataService = applicationContext.getMasterDataService();
  private readonly accessGroupService = applicationContext.getApprAccessGroupService(); // for edit only

  initData() {
    zip(
      this.masterDataService.getStatus(),
      this.masterDataService.getCtrlStatus(), // end of for search

      this.masterDataService.getTitles(), // for edit
      this.masterDataService.getPositions(),
      this.masterDataService.getGenders(),
      this.accessGroupService.getAll()
    ).subscribe(([
        activationStatusList, ctrlStatusList,
        titleList, positionList, groups]) => {
      groups = this.getKeyValue(groups, 'groupId', 'groupName');
      this.setState({
        activationStatusList,
        ctrlStatusList, // end of for search

        titleList, // end of for edit
        positionList,
        groups
      }, this.loadData);
    }, this.handleError);

    zip(
      this.masterDataService.getStatus(),
      this.masterDataService.getCtrlStatus()
    ).subscribe(([activationStatusList, ctrlStatusList]) => {
      this.setState({ activationStatusList, ctrlStatusList }, this.loadData);
    }, this.handleError);
  }

  edit = (e, id: string) => {
    e.preventDefault();
    this.props.history.push(`bank-admin/edit/${id}`);
  }

  approve = (e, id: string) => {
    e.preventDefault();
    this.props.history.push(`bank-admin/approve/${id}`);
  }

  // for edit
  getKeyValue(objs, key, value) {
    return objs.map(item => {
      return { value: item[key], text: item[value] };
    });
  }

  loadGender(bankAdmin?: BankAdmin) {
    bankAdmin = bankAdmin === undefined ? this.state.bankAdmin : bankAdmin;
    if (bankAdmin.title === 'Mr') {
      this.setState({ bankAdmin: { ...bankAdmin, gender: Gender.Male } });
    } else {
      this.setState({ bankAdmin: { ...bankAdmin, gender: Gender.Female } });
    }
  }

  createModel(): BankAdmin {
    const bankAdmin = super.createModel();
    bankAdmin.bankAdminId = 0;
    bankAdmin.activate = ModelStatus.Activated;
    bankAdmin.roleType = RoleType.Maker;
    bankAdmin.accessTimeFrom = '00:00';
    bankAdmin.accessTimeTo = '00:00';

    delete bankAdmin.createdDate;

    return bankAdmin;
  }

  render() {
    const resource = this.resource;
    const { ctrlStatusList, activationStatusList, userId, ctrlStatus, activate } = this.state; // for search

    const { bankAdmin } = this.state; // begin of for edit
    const { titleList, positionList, groups } = this.state;
    const { accessDateFrom, accessDateTo } = bankAdmin;

    return (
      <div className='list-detail-container' ref='container'>
        <div className='list-content'>
          <header>
            <h2>{resource.bank_admin_list}</h2>
            <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add} />
          </header>
          <div>
            <form id='bankAdminForm' name='bankAdminForm' noValidate={true}>
              <section className='row search-group inline'>
                <label className='col s12 m4 l3'>
                  {resource.user_id}
                  <input type='text'
                    id='userId' name='userId'
                    value={userId}
                    onChange={this.updateState}
                    maxLength={255}
                    placeholder={resource.user_id} />
                </label>
                <label className='col s12 m8 l4 checkbox-section'>
                  {resource.activation_status}
                  <section className='checkbox-group'>
                    {activationStatusList.map((item, index) => (
                      <label key={index}>
                        <input
                          type='checkbox'
                          id={item.value}
                          name='activate'
                          key={index}
                          value={item.value}
                          checked={activate.includes(item.value)}
                          onChange={this.updateState} />
                        {item.text}
                      </label>
                    )
                    )}
                  </section>
                </label>
                <label className='col s12 m12 l5'>
                  {resource.ctrl_status}
                  <section className='checkbox-group'>
                    {ctrlStatusList.map((item, index) => (
                      <label key={index}>
                        <input
                          type='checkbox'
                          id={item.value}
                          name='ctrlStatus'
                          key={index}
                          value={item.value}
                          checked={ctrlStatus.includes(item.value)}
                          onChange={this.updateState} />
                        {item.text}
                      </label>
                    )
                    )}
                  </section>
                </label>
              </section>
              <section className='btn-group'>
                <label>
                  {resource.page_size}
                  <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
                </label>
                <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
              </section>
            </form>
            <form className='list-result'>
              <div className='table-responsive'>
                <table>
                  <thead>
                    <tr>
                      <th>{resource.sequence}</th>
                      <th data-field='userId'><button type='button' id='sortUserId' onClick={this.sort}>{resource.user_id}</button></th>
                      <th data-field='roleType'><button type='button' id='sortRoleType' onClick={this.sort}>{resource.role_type}</button></th>
                      <th data-field='activate'><button type='button' id='sortActivate' onClick={this.sort}>{resource.activation_status}</button></th>
                      {/*
                      <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                      <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                      <th data-field='actionDate'><button type='button' id='sortActionDate' onClick={this.sort}>{resource.action_date}</button></th>
                      <th data-field='actionStatus'><button type='button' id='sortActionStatus' onClick={this.sort}>{resource.action_status}</button></th>
                      */}
                      <th className='action'>{resource.quick_action}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {this.state && this.state.results && this.state.results.map((bankadmin, i) => {
                      return (
                        <tr key={i}>
                          <td className='text-right'>{bankadmin.sequenceNo}</td>
                          <td>{bankadmin.userId}</td>
                          <td>{bankadmin.roleType}</td>
                          <td>{bankadmin.activate}</td>
                          {/*
                          <td>{bankadmin.ctrlStatusName}</td>
                          <td>{bankadmin.actedBy}</td>
                          <td>{bankadmin.actionDate}</td>
                          <td>{bankadmin.actionStatus}</td>
                          */}
                          <td>
                            {(this.editable || this.viewable) &&
                              <button type='button' className={this.editable ? 'btn-edit' : 'btn-view'}
                                onClick={(e) => this.loadModel(bankadmin.bankAdminId)} />}
                            {this.checkable && bankadmin.ctrlStatus === 'P' &&
                              <button type='button' className='btn-approve' onClick={(e) => this.approve(e, bankadmin.bankAdminId)} />}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
            </form>
          </div>
        </div>
        <div className='detail-content'>
          <form id='bankAdminForm' name='bankAdminForm' model-name='bankAdmin'>
            <header>
              <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back} />
              <h2>{this.isNewMode() ? resource.create : resource.edit} {resource.payer}</h2>
            </header>
            <div className='row'>
              <label className='col s12 m6'>
                {resource.user_id}
                <input
                  type='text'
                  id='userId'
                  name='userId'
                  value={bankAdmin.userId}
                  onChange={this.updateState}
                  maxLength={20} required={true}
                  placeholder={resource.user_id} />
              </label>
              <label className='col s12 m6'>
                {resource.bank_admin_staff_id}
                <input
                  type='text'
                  id='staffId'
                  name='staffId'
                  value={bankAdmin.staffId}
                  onChange={this.updateState}
                  maxLength={20} required={true}
                  placeholder={resource.bank_admin_staff_id} />
              </label>
              <label className='col s12 m6'>
                {resource.first_name}
                <input
                  type='text'
                  id='firstName'
                  name='firstName'
                  value={bankAdmin.firstName}
                  onChange={this.updateState}
                  maxLength={100} required={true}
                  placeholder={resource.first_name} />
              </label>
              <label className='col s12 m6'>
                {resource.last_name}
                <input
                  type='text'
                  id='lastName'
                  name='lastName'
                  value={bankAdmin.lastName}
                  onChange={this.updateState}
                  maxLength={100}
                  placeholder={resource.last_name} />
              </label>
              <label className='col s12 m6'>
                {resource.person_title}
                <select
                  id='title'
                  name='title'
                  value={bankAdmin.title}
                  onChange={(e) => {
                    this.updateState(e, this.loadGender);
                  }}>
                  <option selected={true} value=''>{resource.please_select}</option>
                  )
                      {titleList.map((item, index) => (
                    <option key={index} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <label className='col s12 m6'>
                {resource.gender}
                <div className='radio-group'>
                  <label>
                    <input
                      type='radio'
                      id='gender'
                      name='gender'
                      onChange={this.updateState}
                      disabled={bankAdmin.title !== 'Dr'}
                      value={Gender.Male} checked={bankAdmin.gender === Gender.Male} />
                    {resource.male}
                  </label>
                  <label>
                    <input
                      type='radio'
                      id='gender'
                      name='gender'
                      onChange={this.updateState}
                      disabled={bankAdmin.title !== 'Dr'}
                      value={Gender.Female} checked={bankAdmin.gender === Gender.Female} />
                    {resource.female}
                  </label>
                </div>
              </label>
              <label className='col s12 m6'>
                {resource.bank_admin_position}
                <select
                  id='pos'
                  name='pos'
                  value={bankAdmin.pos}
                  onChange={this.updateState}>
                  <option selected={true} value=''>{resource.please_select}</option>
                  )
                      {positionList.map((item, index) => (
                    <option key={index} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <label className='col s12 m6'>
                {resource.phone}
                <input
                  type='tel'
                  id='telephone'
                  name='telephone'
                  value={StringUtil.formatPhone(bankAdmin.telephone)}
                  onChange={this.updatePhoneState}
                  onBlur={this.checkPhoneOnBlur}
                  maxLength={17}
                  placeholder={resource.phone} />
              </label>
              <label className='col s12 m6'>
                {resource.email}
                <input
                  type='text'
                  id='email'
                  name='email'
                  data-type='email'
                  value={bankAdmin.email}
                  onChange={this.updateState}
                  onBlur={this.checkEmailOnBlur}
                  maxLength={100}
                  placeholder={resource.email} />
              </label>
              <label className='col s12 m6'>
                {resource.group}
                <select
                  id='groupId'
                  name='groupId'
                  value={bankAdmin.groupId}
                  onChange={this.updateState}>
                  <option selected={true} value=''>{resource.please_select}</option>
                  )
                      {groups.map((item, index) => (
                    <option key={index} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <div className='col s12 m6 radio-section'>
                {resource.role_type}
                <div className='radio-group'>
                  <label>
                    <input
                      type='radio'
                      id='roleType'
                      name='roleType'
                      onChange={this.updateState}
                      value={RoleType.Maker} checked={bankAdmin.roleType === RoleType.Maker} />
                    {resource.role_type_maker}
                  </label>
                  <label>
                    <input
                      type='radio'
                      id='roleType'
                      name='roleType'
                      onChange={this.updateState}
                      value={RoleType.Checker} checked={bankAdmin.roleType === RoleType.Checker} />
                    {resource.role_type_checker}
                  </label>
                </div>
              </div>
              <div className='col s12 m6 radio-section'>
                {resource.bank_admin_activate}
                <div className='radio-group'>
                  <label>
                    <input
                      type='radio'
                      id='activate'
                      name='activate'
                      onChange={this.updateState}
                      value={ModelStatus.Activated} checked={bankAdmin.activate === ModelStatus.Activated} />
                    {resource.yes}
                  </label>
                  <label>
                    <input
                      type='radio'
                      id='activate'
                      name='activate'
                      onChange={this.updateState}
                      value={ModelStatus.Deactivated} checked={bankAdmin.activate === ModelStatus.Deactivated} />
                    {resource.no}
                  </label>
                </div>
              </div>
              <label className='col s12 m6'>
                {resource.bank_admin_access_date} ({this.dateFormat})
                  <div>
                  <label className='col s12 m6 up-date-picker' data-field='accessDateFrom'>
                    {resource.from}
                    <DatePicker
                      onChangeData={this.updateDateState}
                      value={accessDateFrom}
                      required={true}
                      name='accessDateFrom'
                      locale='en-IE'
                      className='form-group'
                    />
                  </label>
                  <label className='col s12 m6'>
                    {resource.to}
                    <DatePicker
                      onChangeData={this.updateDateState}
                      value={accessDateTo}
                      minDate={accessDateFrom}
                      required={true}
                      name='accessDateTo'
                      locale='en-IE'
                      className='form-group'
                    />
                  </label>
                </div>
              </label>
              <label className='col s12 m6'>
                {resource.bank_admin_access_time}
                <div>
                  <label className='col s12 m6'>
                    {resource.from}
                    <input
                      type='time'
                      id='accessTimeFrom'
                      name='accessTimeFrom'
                      value={bankAdmin.accessTimeFrom}
                      onChange={this.updateState} />
                  </label>
                  <label className='col s12 m6'>
                    {resource.to}
                    <input
                      type='time'
                      id='accessTimeTo'
                      name='accessTimeTo'
                      value={bankAdmin.accessTimeTo}
                      onChange={this.updateState} />
                  </label>
                </div>
              </label>
            </div>
            <footer>
              {this.editable &&
                <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
                  {resource.save}
                </button>}
            </footer>
          </form>
        </div>
      </div>
    );
  }
}
