import * as React from 'react';
import {zip} from 'rxjs';
import {BaseInternalState, EditComponent, HistoryProps, UIUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {accessRoleModel} from '../metadata/AccessRoleModel';
import {AccessRole} from '../model/AccessRole';

interface InternalState extends BaseInternalState {
  accessRole: AccessRole;
}

export class AccessRoleForm extends EditComponent<AccessRole, HistoryProps, InternalState> {
  constructor(props) {
    super(props, accessRoleModel, applicationContext.getAccessRoleDefinitionService(), applicationContext.getEditPermissionBuilder());
    this.state = {
      accessRole: {},
      date: new Date(),
      userTypeList: [],
      availableModules: [],
      checkedAll: false,
      showModules: [],
      keyword: ''
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();
  private readonly accessModuleService = applicationContext.getAccessModuleService();

  initData() {
    zip(
      this.masterDataService.getUserTypes(),
      this.accessModuleService.getAll()
    ).subscribe(([userTypeList, availableModules]) => {
      this.setState({ userTypeList, availableModules, showModules: availableModules }, this.loadData);
    }, this.handleError);
  }
  showModel(model: AccessRole) {

    const promise = new Promise((resolve, reject) => {
      this.saveModelToState(model);
      resolve('Success!');
    });
    promise.then(() => {
      const { accessRole, availableModules } = this.state;
      const lenAv = availableModules.reduce((len, modules) =>
        len += modules.children.length, 0);
      accessRole.modules.length === lenAv ? this.setState({ checkedAll: true }) : this.setState({ checkedAll: false });
    });
  }
  handleCheck = (event) => {
    const { accessRole, availableModules } = this.state;
    event.persist();
    if (event.target.value === 'on') {
      const parent = availableModules.find(item =>
        item.moduleId === event.target.id);
      if (accessRole.modules.filter(item =>
        item.parentId === event.target.id).length === parent.children.length) {
        accessRole.modules = accessRole.modules.filter(item =>
          item.parentId !== event.target.id);
      } else {
        accessRole.modules = accessRole.modules.filter(item =>
          item.parentId !== event.target.id);
        accessRole.modules = accessRole.modules.concat(parent.children);
      }
    } else if (event.target.value === 'all') {
      accessRole.modules = [];
      if (event.target.checked) {
        accessRole.modules = availableModules.reduce((resultArray, currentArray) =>
          resultArray = resultArray.concat(currentArray.children), []
        );
      }
    } else {
      let checked = true;
      const parent = availableModules.find(item =>
        item.moduleId === event.target.value);
      const child = parent.children.
        find(value =>
          value.moduleId === event.target.id);
      if (accessRole.modules !== []) {
        checked = !!accessRole.modules.find(item =>
          item.moduleId === event.target.id);
      } else {
        checked = false;
      }
      if (!checked) {
        accessRole.modules.push(child);
      } else {
        accessRole.modules = accessRole.modules = accessRole.modules.filter(item =>
          item.moduleId !== event.target.id);
      }
    }
    this.setState({ accessRole }, () => this.isCheckedAll(event));
  }

  isCheckedAll = (event) => {
    const { availableModules } = this.state;
    const form = event.target.form;
    const controls = UIUtil.getControlsFromForm(form, availableModules.reduce((acc, current) =>
      acc = acc.concat(current.moduleId), []
    ));
    const checkedAll = controls.every(i => i.checked === true);
    this.setState({ checkedAll });
  }
  renderForms = (features) => {
    return (
      features.map((feature) => {
        return this.renderForm(feature);
      })
    );
  }

  renderForm = (feature: any) => {
    const { accessRole, availableModules, keyword } = this.state;
    if (feature.parentId === '') {
      const children = feature.children;
      const childrenLen = availableModules.find(item => item.moduleId === feature.moduleId).children.length;
      const checked = !!accessRole.modules ? (accessRole.modules.filter(item =>
        item.parentId === feature.moduleId).length === childrenLen) : false;
      return (
        <section className='col s12'>
          <label className='checkbox-container'>
            <input
              type='checkbox'
              id={feature.moduleId}
              disabled={keyword !== ''}
              name={feature.moduleId}
              checked={checked}
              onChange={this.handleCheck} />
            {feature.fullName}
          </label>
          <section className='row checkbox-group'>
            {this.renderForms(children)}
          </section>
          <hr />
        </section>
      );
    } else {
      return (
        <label className='col s6 m4 l3'>
          <input
            value={feature.parentId}
            type='checkbox'
            id={feature.moduleId}
            name={feature.moduleId}
            checked={!!accessRole.modules ? !!accessRole.modules.find(item =>
              item.moduleId === feature.moduleId) : false}
            onChange={this.handleCheck}
          />
          {/* {!!accessRole.modules ? !!accessRole.modules.find(item =>
            item.moduleId === feature.moduleId) : false} */}
          {feature.moduleName}
        </label>
      );
    }
  }
  onChangekeyword = (e) => {
    const keyword = e.target.value;
    const { availableModules } = this.state;
    if (keyword === '') {
      this.setState({ keyword, showModules: availableModules });
      return;
    } else {
      // const availableModulesCopy = [...availableModules];
      const showModules = availableModules.map(parent => {
        const parentCopy = Object.assign({}, parent);
        parentCopy.children = parentCopy.children.filter(son => son.moduleName.toLowerCase().includes(keyword.toLowerCase()));
        return parentCopy;
      }).filter(item => item.children.length > 0);
      this.setState({ keyword, showModules });
    }
  }
  render() {
    const resource = this.resource;
    const { showModules, keyword, accessRole, userTypeList } = this.state;
    return (
      <div className='view-container'>
        <form id='accessRoleForm' name='accessRoleForm' model-name='accessRole' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back} />
            <h2>{this.isNewMode() ? resource.create : resource.edit} {resource.role_subject}</h2>
          </header>
          <div>
            <section className='row'>
              <label className='col s12 m6'>
                {resource.user_type}
                <select id='userType' name='userType'
                  value={accessRole.userType}
                  onChange={this.updateState}
                  required={true}
                >
                  <option selected={true} value=''>{resource.please_select}</option>
                  {userTypeList.map((item, index) => (
                    <option key={index} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <label className='col s12 m6'>
                {resource.role_id}
                <input type='text'
                  id='roleId' name='roleId'
                  value={accessRole.roleId}
                  onChange={this.updateState}
                  maxLength={20} required={true}
                  disabled={!this.isNewMode()}
                  placeholder={resource.role_id} />
              </label>
              <label className='col s12 m6'>
                {resource.role_name}
                <input type='text'
                  id='roleName' name='roleName'
                  value={accessRole.roleName}
                  onChange={this.updateState}
                  maxLength={255}
                  placeholder={resource.role_name} />
              </label>
              <label className='col s12 m6'>
                {resource.description}
                <input type='text'
                  id='roleDesc' name='roleDesc'
                  value={accessRole.roleDesc}
                  onChange={this.updateState}
                  maxLength={255}
                  placeholder={resource.description} />
              </label>
            </section>
            <h4>
              <label>
                <input
                  type='checkbox'
                  value='all'
                  disabled={keyword !== ''}
                  checked={this.state.checkedAll}
                  onChange={this.handleCheck} />
                {resource.all_modules}
              </label>
              <label className='col s12 search-input'>
                <i className='btn-search' />
                <input type='text'
                  id='keyword'
                  name='keyword'
                  maxLength={40}
                  placeholder={resource.role_filter_modules}
                  value={keyword}
                  onChange={this.onChangekeyword} />
              </label>
            </h4>
            <section className='row hr-height-1'>
              {this.renderForms(showModules)}
            </section>
          </div>
          <footer>
            {this.editable &&
              <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
                {resource.save}
              </button>}
          </footer>
        </form>
      </div>
    );
  }
}
