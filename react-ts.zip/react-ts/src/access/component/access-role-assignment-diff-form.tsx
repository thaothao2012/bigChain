import * as React from 'react';
import DiffPanel from 'src/common/component/DiffPanel';
import {DiffApprComponent, DiffState, HistoryProps} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {accessRoleModel} from '../metadata/AccessRoleModel';
import {AccessRole} from '../model/AccessRole';

export class AccessRoleAssignmentDiffForm extends DiffApprComponent<AccessRole, HistoryProps, DiffState<AccessRole>> {
  constructor(props) {
    super(props, accessRoleModel, applicationContext.getAccessRoleAssignmentService());
    this.state = {
      oldValue: {},
      newValue: {},
    };
  }

  renderFields = [
    { resourceKey: 'user_type', name: 'userType' },
    { resourceKey: 'role_id', name: 'roleId' },
    { resourceKey: 'role_name', name: 'roleName' },
    { resourceKey: 'description', name: 'roleDesc' },
    { resourceKey: 'role_assigned_users', name: 'listUsername' },
  ];

  formatFields(value) {
    const listUsername = [];
    if (value.users) {
      for (const user of value.users) {
        listUsername.push(user.userId);
      }
    }

    return { ...value, listUsername };
  }

  render() {
    const resource = this.resource;
    const { oldValue, newValue, approveSuccess, rejectSuccess } = this.state;
    return (
      <div className='view-container'>
        <form id='accessRoleForm' name='accessRoleForm' model-name='accessRole' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back} />
            <h2>{resource.role_assignment_subject}</h2>
          </header>
          <DiffPanel oldValue={oldValue}
                     newValue={newValue}
                     resource={resource}
                     renderFields={this.renderFields}
          />
          <footer>
            <button type='submit' id='btnApprove' name='btnApprove' onClick={this.approve}
              disabled={approveSuccess}>
              {resource.approve}
            </button>
            <button type='button' id='btnReject' name='btnReject' onClick={this.reject}
              disabled={rejectSuccess}>
              {resource.reject}
            </button>
          </footer>
        </form>
      </div>
    );
  }

  detailForm = (valueForm, resource, subject) => {
    return (
      <React.Fragment>
        <h4>{subject}</h4>
        <label className='col s12 m6'>
          {resource.user_type}
          <label>
            {valueForm.userType}
          </label>
        </label>
        <label className='col s12 m6'>
          {resource.role_id}
          <label>
            {valueForm.roleId}
          </label>
        </label>
        <label className='col s12 m6'>
          {resource.role_name}
          <label>
            {valueForm.role_name}
          </label>
        </label>
        <label className='col s12 m6'>
          {resource.description}
          <label>
            {valueForm.roleDesc}
          </label>
        </label>
        <label className='col s12 m6'>
          {resource.role_assigned_users}
          <label>
            {valueForm && valueForm.users ? valueForm.users.map((item, index) => {
              return <li key={index}>{item.userId}</li>;
            }) : ''}
          </label>
        </label>
        <label className='col s12 m6'>
          {resource.role_roles_assign_to_groups}
          <label>
            {valueForm && valueForm.groups ? valueForm.groups.map((item, index) => {
              return <li key={index}>{item.groupName}</li>;
            }) : ''}
          </label>
        </label>
      </React.Fragment>
    );
  }
}
