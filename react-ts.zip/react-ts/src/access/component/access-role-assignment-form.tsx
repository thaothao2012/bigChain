import * as React from 'react';
import {zip} from 'rxjs';
import femaleIcon from '../../assets/images/female.png';
import maleIcon from '../../assets/images/male.png';
import {BaseInternalState, EditComponent, HistoryProps} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {accessRoleModel} from '../metadata/AccessRoleModel';
import {AccessRole} from '../model/AccessRole';
import {BankAdminsLookup} from './bank-admins-lookup';

interface InternalState extends BaseInternalState {
  accessRole: AccessRole;
}

export class AccessRoleAssignmentForm extends EditComponent<AccessRole, HistoryProps, InternalState> {
  constructor(props) {
    super(props, accessRoleModel, applicationContext.getAccessRoleAssignmentService(), applicationContext.getEditPermissionBuilder());
    this.state = {
      accessRole: {},
      date: new Date(),
      userTypeList: [],
      roles: [],
      availableUsers: [],
      roleAssignToUsers: null,
      textSearch: '',
      isOpenModel: false,
      isShowCheckbox: false,
      checkBoxList: []
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();
  private readonly roleService = applicationContext.getApprAccessRoleAssignmentService();
  private readonly bankAdminService = applicationContext.getApprBankAdminService();

  initData() {
    zip(
      this.masterDataService.getUserTypes(),
      this.roleService.getAll(),
      this.bankAdminService.getAll(),
    ).subscribe(([userTypeList, roles, availableUsers]) => {
      this.setState({ userTypeList, roles, availableUsers }, this.loadData);
    }, this.handleError);
    this.setNewMode(false);
  }

  handleUsersDeselect = (deselectedOptions) => {
    const { accessRole } = this.state;
    const selectedOptions = accessRole.users.slice();
    deselectedOptions.forEach(option => {
      selectedOptions.splice(selectedOptions.indexOf(option), 1);
    });
    this.setState({ accessRole: { ...accessRole, users: selectedOptions } });
  }

  handleUsersSelect = (selectedOptions) => {
    selectedOptions.sort((a, b) => a.id - b.id);
    const { accessRole } = this.state;
    this.setState({ accessRole: { ...accessRole, users: selectedOptions } });
  }

  handleGroupdIdChange = () => {
    const { roles, accessRole } = this.state;
    const a = roles.filter(item => item['roleId'] === accessRole.roleId);
    if (a.length > 0) {
      const selectedRole = a[0];
      const uType = accessRole.userType;
      const setRole = { ...selectedRole, userType: uType };
      this.setState({ accessRole: setRole });
    }
  }

  onSearch = (event) => {
    const { accessRole } = this.state;
    if (accessRole.users) {
      const result = accessRole.users.filter((value) => {
        return value['userId'].includes(event.target.value);
      });
      this.setState({ [event.target.name]: event.target.value, roleAssignToUsers: result });
    }
  }

  onModelSave = (array: []) => {
    let { roleAssignToUsers } = this.state;
    const { accessRole } = this.state;
    const roles = roleAssignToUsers ? roleAssignToUsers : accessRole.users ? accessRole.users : [];

    array.map((value) => {
      roles.push(value);
    });
    roleAssignToUsers = roles;
    accessRole.users = roles;
    this.setState({ accessRole, roleAssignToUsers, isOpenModel: false });
  }

  onModelClose = () => {
    this.setState({ isOpenModel: false });
  }

  // onRemoveUser = (e) => {
  // let { roleAssignToUsers } = this.state;
  // const { accessRole } = this.state;
  // const roles = roleAssignToUsers ? roleAssignToUsers : accessRole.users ? accessRole.users : [];
  // const rolesArr = [];
  // roles.map((value) => {
  //   if (e.target.value !== value.userId) {
  //     rolesArr.push(value);
  //   }
  // });
  // roleAssignToUsers = rolesArr;
  // accessRole.users = rolesArr;
  // this.setState({ accessRole, roleAssignToUsers });
  // }

  onCheckBox = (userId) => {
    const { accessRole, checkBoxList } = this.state;
    if (accessRole.users) {
      const result = accessRole.users.find((value) => {
        if (value) {
          return value.userId === userId;
        }
      });
      if (result) {
        const index = checkBoxList.indexOf(result);
        if (index !== -1) {
          delete checkBoxList[index];
        } else {
          checkBoxList.push(result);
        }
      }
    }
    this.setState({ checkBoxList });
  }

  onShowCheckBox = () => {
    let { isShowCheckbox } = this.state;
    if (isShowCheckbox === false) {
      isShowCheckbox = true;
    } else {
      isShowCheckbox = false;
    }
    this.setState({ isShowCheckbox });
  }

  onDeleteCheckBox = () => {
    if (confirm('Delete ?') === true) {
      let { roleAssignToUsers, checkBoxList } = this.state;
      const { accessRole } = this.state;
      const roles = roleAssignToUsers ? roleAssignToUsers : accessRole.users ? accessRole.users : [];
      const arr = [];
      roles.map((value) => {
        const result = checkBoxList.find((v) => {
          if (v) {
            return v.userId === value.userId;
          }
        });
        if (result === undefined) {
          arr.push(value);
        }
      });
      roleAssignToUsers = arr;
      accessRole.users = arr;
      checkBoxList = [];
      this.setState({ accessRole, roleAssignToUsers, checkBoxList, isShowCheckbox: false });
    }
  }

  onCheckAll = () => {
    let { checkBoxList } = this.state;
    const { accessRole } = this.state;
    if (accessRole.users) {
      checkBoxList = accessRole.users;
    }
    this.setState({ checkBoxList });
  }

  onUnCheckAll = () => {
    this.setState({ checkBoxList: [] });
  }

  render() {
    const resource = this.resource;
    const { accessRole, roleAssignToUsers, userTypeList, roles, availableUsers, isOpenModel, isShowCheckbox, checkBoxList } = this.state;
    const resultRoleAssignToUsers = roleAssignToUsers ? roleAssignToUsers : accessRole.users ? accessRole.users : [];
    return (
        <div className='view-container'>
          <form id='accessRoleForm' name='accessRoleForm' model-name='accessRole' ref='form'>
            <header>
              <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
              <h2>{this.isNewMode() ? resource.create : resource.edit} {resource.role_assignment_subject}</h2>
            </header>
            <div>
              <section className='row'>
                <h4>{resource.role_assignment_subject}</h4>
                <label className='col s12 m6'>
                  {resource.user_type}
                  <select id='userType' name='userType'
                    value={accessRole.userType}
                    onChange={this.updateState}>
                    <option selected={true} value=''>{resource.please_select}</option>
                    )
                  {userTypeList.map((item, index) => (
                      <option key={index} value={item.value}>{item.text}</option>)
                    )}
                  </select>
                </label>
                <label className='col s12 m6'>
                  {resource.role_id}
                  <select id='roleId' name='roleId'
                    value={accessRole.roleId}
                    onChange={(e) => {
                      this.updateState(e, this.handleGroupdIdChange);
                    }}>
                    <option selected={true} value=''>{resource.please_select}</option>
                    {roles.map((item, index) => (
                      <option key={index} value={item.roleId}>{item.roleId}</option>)
                    )}
                  </select>
                </label>
                <label className='col s12 m6'>
                  {resource.role_name}
                  <input type='text'
                    id='roleName' name='roleName'
                    value={accessRole.roleName}
                    onChange={this.updateState}
                    maxLength={255}
                    placeholder={resource.role_name}
                    disabled={true} />
                </label>
                <label className='col s12 m6'>
                  {resource.description}
                  <input type='text'
                    id='roleDesc' name='roleDesc'
                    value={accessRole.roleDesc}
                    onChange={this.updateState}
                    maxLength={255}
                    placeholder={resource.description}
                    disabled={true} />
                </label>
              </section>
              <section className='row detail'>
                <h4>
                  {resource.bank_admin_subject}
                  <div className='btn-group'>
                    {this.editable && <button type='button' onClick={() => this.setState({ isOpenModel: true })}>{resource.add}</button>}
                    {this.editable && <button type='button' onClick={this.onShowCheckBox}>{isShowCheckbox ? resource.deselect : resource.select}</button>}
                    {isShowCheckbox ? <button type='button' onClick={this.onCheckAll}>{resource.check_all}</button> : ''}
                    {isShowCheckbox ? <button type='button' onClick={this.onUnCheckAll}>{resource.uncheck_all}</button> : ''}
                    {isShowCheckbox ? <button type='button' onClick={this.onDeleteCheckBox}>{resource.delete}</button> : ''}
                  </div>
                </h4>
                {this.editable &&
                <label className='col s12 search-input'>
                  <i className='btn-search' />
                  <input type='text'
                    id='textSearch'
                    name='textSearch'
                    onChange={this.onSearch}
                    value={this.state.textSearch}
                    maxLength={40}
                    placeholder={resource.role_assignment_search_user} />
                </label>
                }
                <ul className='row list-view'>
                  {resultRoleAssignToUsers && resultRoleAssignToUsers.map((value, i) => {
                    const result = checkBoxList.find((v) => {
                      if (v) {
                        return v.userId === value.userId;
                      }
                    });
                    return (
                      <li key={i} className='col s12 m6 l4 xl3' onClick={isShowCheckbox === true ? () => this.onCheckBox(value.userId) : () => { }}>
                        <section>
                          {isShowCheckbox === true ? <input type='checkbox' name='selected' checked={result ? true : false} /> : ''}
                          <img src={value.gender === 'F' ? femaleIcon : maleIcon} className='round-border'/>
                          <div>
                            <h3>{value.userId}</h3>
                            <p>{value.firstName} {value.lastName}</p>
                          </div>
                        </section>
                      </li>
                    );
                  })}
                </ul>
              </section>
            </div>
            <footer>
              {this.editable &&
                <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
                  {resource.save}
                </button>}
            </footer>
          </form>
          <BankAdminsLookup
          location={this.props.location}
          history={this.props.history}
          props={this.props['props']}
          isOpenModel={isOpenModel}
          onModelClose={this.onModelClose}
          onModelSave={this.onModelSave}
          roleAssignToUsers={resultRoleAssignToUsers}
        />
        </div >
    );
  }
}

