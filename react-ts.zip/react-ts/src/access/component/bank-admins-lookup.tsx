import * as React from 'react';
import Modal from 'react-modal';
import {zip} from 'rxjs';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchModel, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {BankAdmin} from '../model/BankAdmin';

interface Props extends HistoryProps {
  isOpenModel?: any;
  onModelClose?: any;
  onModelSave?: any;
  roleAssignToUsers?: any;
  props?: any;
}

export class BankAdminsLookup extends SearchComponent<BankAdmin, SearchModel, Props, SearchState<BankAdmin>> {
  constructor(props) {
    super(props, applicationContext.getBankAdminService(), applicationContext.getSearchPermissionBuilder());
    this.state = {
      keyword: '',
      userId: '',
      results: [],
      roles: [],
      availableUsers: null
    };
  }

  onCheckUser = (event) => {
    const { roles } = this.state;
    const { results } = this.state;
    const result = results.find((value) => value.userId === event.target.value);
    if (result) {
      const index = roles.indexOf(result);
      if (index !== -1) {
        delete roles[index];
      } else {
        roles.push(result);
      }
      this.setState({ roles });
    }
  }

  onModelSave = () => {
    this.setState({ roles: [], availableUsers: null, textSearch: '' });
    this.props.onModelSave(this.state.roles);
  }

  onModelClose = (event) => {
    this.setState({ roles: [], availableUsers: null, textSearch: '' });
    this.props.onModelClose(event);
  }

  protected clearUserId = () => {
    this.setState({
      userId: ''
    });
  }

  onChangeText = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  }

  onSearch = (e) => {
    this.setState({ results: [] });
    this.searchOnClick(e);
  }

  render() {
    const { isOpenModel, roleAssignToUsers } = this.props;
    const { results } = this.state;
    const resource = this.resource;
    let index = 0;
    return (
      <Modal
        isOpen={isOpenModel}
        contentLabel='Modal'
        portalClassName='modal-portal'
        className='modal-portal-content'
        bodyOpenClassName='modal-portal-open'
        overlayClassName='modal-portal-backdrop'
      >
        <div className='view-container'>
          <header>
            <h2>{resource.bank_admins_lookup}</h2>
            <button type='button' id='btnClose' name='btnClose' className='btn-close' onClick={this.onModelClose}/>
          </header>
          <div>
            <form id='bankAdminLookupForm' name='bankAdminLookupForm' noValidate={true} ref='form'>
              <section className='row search-group'>
                <label className='col s12 m6 search-input'>
                  <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged}/>
                  <input type='text'
                    id='userId'
                    name='userId'
                    onChange={this.onChangeText}
                    value={this.state.userId}
                    maxLength={40}
                    placeholder={resource.bank_admin_lookup_search_user}/>
                  <button type='button' hidden={!this.state.userId} className='btn-remove-text' onClick={this.clearUserId}/>
                  <button type='submit' className='btn-search' onClick={this.onSearch}/>
                </label>
                <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
              </section>
            </form>
            <form className='list-result'>
              <div className='table-responsive'>
                <table>
                  <thead>
                    <tr>
                      <th>{resource.sequence}</th>
                      <th data-field='userId'><button type='button' id='sortUserId' onClick={this.sort}>{resource.user_id}</button></th>
                      <th data-field='lastName'><button type='button' id='sortLastName' onClick={this.sort}>{resource.last_name}</button></th>
                      <th data-field='firstName'><button type='button' id='sortFirstName' onClick={this.sort}>{resource.first_name}</button></th>
                      <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                      <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                      <th data-field=''>{resource.quick_action}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {this.state && results && results.map((value, i) => {
                      const result = roleAssignToUsers.find((v) => {
                        if (v) {
                          return v.userId === value.userId;
                        }
                        return false;
                      });
                      if (!result) {
                        index++;
                        return (
                          <tr key={i}>
                            <td className='text-right'>{index}</td>
                            <td>{value.userId}</td>
                            <td>{value.lastName}</td>
                            <td>{value.firstName}</td>
                            <td>{value.ctrlStatus}</td>
                            <td>{value.actedBy}</td>
                            <td>
                              <input type='checkbox' value={value.userId} onClick={this.onCheckUser} />
                            </td>
                          </tr>
                        );
                      }
                    })}
                  </tbody>
                </table>
              </div>
            </form>
          </div>
          <footer>
            <button type='button' onClick={this.onModelSave}>{resource.select}</button>
          </footer>
        </div>
      </Modal>
    );
  }
}
