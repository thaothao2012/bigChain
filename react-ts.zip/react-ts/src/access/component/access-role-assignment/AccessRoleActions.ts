import {ReducerActionType} from '../../../core';
import {AccessRoleActionType} from './AccessRoleActionType';

function createAction<T extends ReducerActionType<AccessRoleActionType>>(d: T): T {
  return d;
}

export const getAccessRoleList = (data: any) => createAction({
  type: AccessRoleActionType.GET_ACCESS_ROLE_LIST,
  payload: data
});


export const getAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.GET_ACCESS_ROLE,
  payload: data
});

export const updateAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.UPDATE_ACCESS_ROLE,
  payload: data
});

export const insertAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.INSERT_ACCESS_ROLE,
  payload: data
});

export const checkAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.CHECK_ACCESS_ROLE,
  payload: data
});

export const approveAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.APPROVE_ACCESS_ROLE,
  payload: data
});

export const rejectAccessRole = (data: any) => createAction({
  type: AccessRoleActionType.REJECT_ACCESS_ROLE,
  payload: data
});
