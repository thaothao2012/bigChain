import {GenericSearchDiffApprObservableEpics} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {AccessRole} from '../../model/AccessRole';
import {AccessRoleSM} from '../../search-model/AccessRoleSM';
import {AccessRoleActionType} from './AccessRoleActionType';

const actionType = {
  searchType: AccessRoleActionType.GET_ACCESS_ROLE_LIST,
  getByIdType: AccessRoleActionType.GET_ACCESS_ROLE,
  updateType: AccessRoleActionType.UPDATE_ACCESS_ROLE,
  insertType: AccessRoleActionType.INSERT_ACCESS_ROLE,
  checkDiff: AccessRoleActionType.CHECK_ACCESS_ROLE,
  approveType: AccessRoleActionType.APPROVE_ACCESS_ROLE,
  rejectType: AccessRoleActionType.REJECT_ACCESS_ROLE,
};

const accessRoleObservableEpics = new GenericSearchDiffApprObservableEpics<AccessRole, AccessRoleSM>(actionType, applicationContext.getAccessRoleAssignmentService());

export const paccessRoleEpics = {
  search: accessRoleObservableEpics.search,
  update: accessRoleObservableEpics.update,
  insert: accessRoleObservableEpics.insert,
  getById: accessRoleObservableEpics.getById,
  checkDiff: accessRoleObservableEpics.checkDiff,
  approve: accessRoleObservableEpics.approve,
  reject: accessRoleObservableEpics.reject,
};
