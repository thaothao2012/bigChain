import * as moment from 'moment';
import * as React from 'react';
import DiffPanel from 'src/common/component/DiffPanel';
import {DiffApprComponent, DiffState, HistoryProps, ReflectionUtil, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {bankAdminModel} from '../metadata/BankAdminModel';
import {BankAdmin} from '../model/BankAdmin';

export class BankAdminDiffForm extends DiffApprComponent<BankAdmin, HistoryProps, DiffState<BankAdmin>> {
  constructor(props) {
    super(props, bankAdminModel, applicationContext.getBankAdminService());
    this.state = {
      oldValue: {},
      newValue: {},
    };
  }

  renderFields = [
    {resourceKey: 'user_id', name: 'userId'},
    {resourceKey: 'bank_admin_staff_id', name: 'staffId'},
    {resourceKey: 'first_name', name: 'firstName'},
    {resourceKey: 'last_name', name: 'lastName'},
    {resourceKey: 'person_title', name: 'title'},
    {resourceKey: 'gender', name: 'gender'},
    {resourceKey: 'bank_admin_position', name: 'pos'},
    {resourceKey: 'phone', name: 'telephone'},
    {resourceKey: 'email', name: 'email'},
    {resourceKey: 'group', name: 'groupId'},
    {resourceKey: 'bank_admin_access_date_from', name: 'accessDateFrom'},
    {resourceKey: 'bank_admin_access_date_to', name: 'accessDateTo'},
    {resourceKey: 'bank_admin_access_time_from', name: 'accessTimeFrom'},
    {resourceKey: 'bank_admin_access_time_to', name: 'accessTimeTo'},
  ];

  formatFields(value) {
    const resource = this.resource;
    const gender = value && value.gender === 'M' ? resource.male : resource.female ;
    const roleType = value && value.roleType === 'M' ? resource.role_type_maker : resource.role_type_checker ;
    const pos = value.pos === 'E' ? resource.position_employee : (value.pos === 'M' ? resource.position_manager : resource.position_director);
    const activate = value.activate === 'T' ? resource.true : resource.false;
    const accessDateFrom = moment(value.accessDateFrom).format('YYYY-MM-DD');
    const accessDateTo = moment(value.accessDateTo).format('YYYY-MM-DD');
    return {...value, gender, roleType, pos, activate, accessDateFrom, accessDateTo};
  }

  render() {
    const resource = this.resource;
    const { oldValue, newValue, approveSuccess, rejectSuccess } = this.state;
    return (
      <div className='view-container'>
        <form id='bankAdminForm' name='bankAdminForm' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{resource.bank_admin_subject}</h2>
          </header>
          <DiffPanel oldValue= {oldValue} newValue= {newValue} resource={resource} renderFields={this.renderFields} />
          <footer>
            <button type='submit' id='btnApprove' name='btnApprove' onClick={this.approve} disabled={approveSuccess}>
              {resource.approve}
            </button>
            <button type='button' id='btnReject' name='btnReject' onClick={this.reject} disabled={rejectSuccess}>
              {resource.reject}
            </button>
          </footer>
        </form>
      </div>
    );
  }
}
