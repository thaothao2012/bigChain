import * as React from 'react';
import {BaseInternalState, EditComponent, HistoryProps} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {accessGroupModel} from '../metadata/AccessGroupModel';
import {AccessGroup} from '../model/AccessGroup';

interface InternalState extends BaseInternalState {
  accessGroup: AccessGroup;
}

export class AccessGroupForm extends EditComponent<AccessGroup, HistoryProps, InternalState> {
  constructor(props) {
    super(props, accessGroupModel, applicationContext.getAccessGroupService(), applicationContext.getEditPermissionBuilder());
    this.state = {
      accessGroup: {},
      date: new Date(),
      entityTypeList: []
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    this.masterDataService.getEntityTypes().subscribe((entityTypeList) => {
      this.setState(prevState => ({
        ...prevState,
        entityTypeList,
      }), this.loadData);
    }, this.handleError);
  }

  render() {
    const resource = this.resource;
    const accessGroup = this.state.accessGroup;
    const {entityTypeList} = this.state;
    return (
      <div className='view-container'>
        <form id='accessGroupForm' name='accessGroupForm' model-name='accessGroup' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{this.isNewMode() ? resource.create : resource.edit} {resource.group_subject}</h2>
          </header>
          <div>
            <div className='form-group'>
              <label htmlFor='entityType'>{resource.entity_type}</label>
              <select id='entityType' name='entityType'
                      className='form-control'
                      value={accessGroup.entityType}
                      onChange={this.updateState}
                      required={true}>
                <option selected={true} value=''>Please selet</option>
                {entityTypeList.map((item, index) => (
                  <option key={index} value={item.value}>{item.text}</option>
                ))}
              </select>
            </div>
            <div className='form-group'>
              <label htmlFor='groupId'>{resource.group_id}</label>
              <input type='text'
                     id='groupId' name='groupId'
                     className='form-control'
                     value={accessGroup.groupId}
                     onChange={this.updateState}
                     maxLength={20} required={true}
                     disabled={!this.isNewMode()}
                     placeholder={resource.group_id}/>
            </div>
            <div className='form-group'>
              <label htmlFor='groupName'>{resource.group_name}</label>
              <input type='text'
                     id='groupName' name='groupName'
                     className='form-control'
                     value={accessGroup.groupName}
                     onChange={this.updateState}
                     maxLength={20} required={true}
                     disabled={!this.isNewMode()}
                     placeholder={resource.group_id}/>
            </div>
            {/*
            <label className='col s12'>
              {resource.entity_type}
              <select id='entityType' name='entityType'
                      value={accessGroup.entityType}
                      onChange={this.updateState}
                      required={true}>
                <option selected={true} value=''>Please selet</option>
                {entityTypeList.map((item, index) => (
                  <option key={index} value={item.value}>{item.text}</option>
                ))}
              </select>
            </label>
            <label className='col s12 m6'>
              {resource.group_id}
              <input type='text'
                     id='groupId' name='groupId'
                     value={accessGroup.groupId}
                     onChange={this.updateState}
                     maxLength={20} required={true}
                     disabled={!this.isNewMode()}
                     placeholder={resource.group_id}/>
            </label>
            <label className='col s12'>
              {resource.group_name}
              <input type='text'
                     id='groupName' name='groupName'
                     value={accessGroup.groupName}
                     onChange={this.updateState}
                     maxLength={60} required={true}
                     placeholder={resource.group_name}/>
            </label>*/}
          </div>
          <footer>
            {this.editable &&
            <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
              {resource.save}
            </button>
            }
          </footer>
        </form>
      </div>
    );
  }
}
