import * as React from 'react';
import {zip} from 'rxjs';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchModel, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {BankAdmin} from '../model/BankAdmin';

export class BankAdminsForm extends SearchComponent<BankAdmin, SearchModel, HistoryProps, SearchState<BankAdmin>> {
  constructor(props) {
    super(props, applicationContext.getBankAdminService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      ctrlStatusList: [],
      activationStatusList: [],
      results: [],
      ctrlStatus: [],
      activate: [],
      userId: ''
    };
  }
  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    zip(
      this.masterDataService.getStatus(),
      this.masterDataService.getCtrlStatus()
    ).subscribe(([activationStatusList, ctrlStatusList]) => {
      this.setState({ activationStatusList, ctrlStatusList }, this.loadData);
    }, this.handleError);
  }

  edit = (e, id: string) => {
    e.preventDefault();
    this.props.history.push(`bank-admin/edit/${id}`);
  }

  approve = (e, id: string) => {
    e.preventDefault();
    this.props.history.push(`bank-admin/approve/${id}`);
  }

  render() {
    const resource = this.resource;
    const { ctrlStatusList, activationStatusList, userId, ctrlStatus, activate } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.bank_admin_list}</h2>
          {this.addable && <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add} />}
        </header>
        <div>
          <form id='bankAdminForm' name='bankAdminForm' noValidate={true} ref='form'>
            <section className='row search-group inline'>
              <label className='col s12 m4 l3'>
                {resource.user_id}
                <input type='text'
                  id='userId' name='userId'
                  value={userId}
                  onChange={this.updateState}
                  maxLength={255}
                  placeholder={resource.user_id} />
              </label>
              <label className='col s12 m8 l4 checkbox-section'>
                {resource.activation_status}
                <section className='checkbox-group'>
                  {activationStatusList.map((item, index) => (
                    <label key={index}>
                      <input
                        type='checkbox'
                        id={item.value}
                        name='activate'
                        key={index}
                        value={item.value}
                        checked={activate.includes(item.value)}
                        onChange={this.updateState} />
                      {item.text}
                    </label>
                  )
                  )}
                </section>
              </label>
              <label className='col s12 m12 l5'>
                {resource.ctrl_status}
                <section className='checkbox-group'>
                  {ctrlStatusList.map((item, index) => (
                    <label key={index}>
                      <input
                        type='checkbox'
                        id={item.value}
                        name='ctrlStatus'
                        key={index}
                        value={item.value}
                        checked={ctrlStatus.includes(item.value)}
                        onChange={this.updateState} />
                      {item.text}
                    </label>
                  )
                  )}
                </section>
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='userId'><button type='button' id='sortUserId' onClick={this.sort}>{resource.user_id}</button></th>
                    <th data-field='roleType'><button type='button' id='sortRoleType' onClick={this.sort}>{resource.role_type}</button></th>
                    <th data-field='activate'><button type='button' id='sortActivate' onClick={this.sort}>{resource.activation_status}</button></th>
                    <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                    <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                    <th data-field='actionDate'><button type='button' id='sortActionDate' onClick={this.sort}>{resource.action_date}</button></th>
                    <th data-field='actionStatus'><button type='button' id='sortActionStatus' onClick={this.sort}>{resource.action_status}</button></th>
                    <th className='action'>{resource.quick_action}</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((bankadmin, i) => {
                    return (
                      <tr key={i}>
                        <td className='text-right'>{bankadmin.sequenceNo}</td>
                        <td>{bankadmin.userId}</td>
                        <td>{bankadmin.roleType}</td>
                        <td>{bankadmin.activate}</td>
                        <td>{bankadmin.ctrlStatusName}</td>
                        <td>{bankadmin.actedBy}</td>
                        <td>{bankadmin.actionDate}</td>
                        <td>{bankadmin.actionStatus}</td>
                        <td>
                          {(this.editable || this.viewable) &&
                            <button type='button' className={this.editable ? 'btn-edit' : 'btn-view'}
                              onClick={(e) => this.edit(e, bankadmin.bankAdminId)} />}
                          {this.checkable && bankadmin.ctrlStatus === 'P' &&
                            <button type='button' className='btn-approve' onClick={(e) => this.approve(e, bankadmin.bankAdminId)} />}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
        </div>
      </div>
    );
  }
}
