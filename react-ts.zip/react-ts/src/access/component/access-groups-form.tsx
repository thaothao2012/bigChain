import * as React from 'react';
import {Link} from 'react-router-dom';
import {zip} from 'rxjs';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchModel, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {AccessGroup} from '../model/AccessGroup';

export class AccessGroupsForm extends SearchComponent<AccessGroup, SearchModel, HistoryProps, SearchState<AccessGroup>> {
  constructor(props) {
    super(props, applicationContext.getAccessGroupService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      ctrlStatusList: [],
      entityTypeList: [],
      results: [],
      ctrlStatus: [],
      entityType: [],
      groupId: ''
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    zip(
      this.masterDataService.getEntityTypes(),
      this.masterDataService.getCtrlStatus()
    ).subscribe(([entityTypeList, ctrlStatusList]) => {
      this.setState({ entityTypeList, ctrlStatusList }, this.loadData);
    }, this.handleError);
  }

  edit = (e, accessGroup: AccessGroup) => {
    e.preventDefault();
    this.props.history.push('access-group/edit/' + accessGroup.groupId + '/' + accessGroup.cId);
  }

  approve = (e, accessGroup: AccessGroup) => {
    e.preventDefault();
    this.props.history.push('access-group/approve/' + accessGroup.groupId + '/' + accessGroup.cId);
  }

  render() {
    const resource = this.resource;
    const { ctrlStatusList, entityTypeList, ctrlStatus, entityType, groupId } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.group_list}</h2>
          {this.addable && <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add} />}
        </header>
        <div>
          <form id='accessGroupsForm' name='accessGroupsForm' noValidate={true} ref='form'>
            <section className='row search-group inline'>
              <label className='col s12 m6 l3'>
                {resource.group_id}
                <input
                  type='text'
                  id='groupId'
                  name='groupId'
                  value={groupId}
                  onChange={this.updateState}
                  maxLength={20}
                  placeholder={resource.group_id} />
              </label>
              <label className='col s12 m6 l4'>
                {resource.entity_type}
                <section className='checkbox-group'>
                  {entityTypeList.map((item, index) => (
                    <label key={index}>
                      <input
                        type='checkbox'
                        id={item.value}
                        name='entityType'
                        key={index}
                        value={item.value}
                        checked={entityType.includes(item.value)}
                        onChange={this.updateState} />
                      {item.text}
                    </label>
                  )
                  )}
                </section>
              </label>
              <label className='col s12 m12 l5'>
                {resource.ctrl_status}
                <section className='checkbox-group'>
                  {ctrlStatusList.map((item, index) => (
                    <label key={index}>
                      <input
                        type='checkbox'
                        id={item.value}
                        name='ctrlStatus'
                        key={index}
                        value={item.value}
                        checked={ctrlStatus.includes(item.value)}
                        onChange={this.updateState} />
                      {item.text}
                    </label>
                  )
                  )}
                </section>
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='groupId'><button type='button' id='accessGroupId' onClick={this.sort}>{resource.group_id}</button></th>
                    <th data-field='groupName'><button type='button' id='accessgroupName' onClick={this.sort}>{resource.group_name}</button></th>
                    <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                    <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                    <th data-field='actionDate'><button type='button' id='sortActionDate' onClick={this.sort}>{resource.action_date}</button></th>
                    <th data-field='actionStatus'><button type='button' id='sortActionStatus' onClick={this.sort}>{resource.action_status}</button></th>
                    <th className='action'>{resource.quick_action}</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((accessGroup, i) => {
                    return (
                      <tr key={i}>
                        <td className='text-right'>{accessGroup.sequenceNo}</td>
                        <td><Link to={'access-group/' + accessGroup.groupId + '?action=edit'}>{accessGroup.groupId}</Link>
                        </td>
                        <td>{accessGroup.groupName}</td>
                        <td>{accessGroup.ctrlStatusName}</td>
                        <td>{accessGroup.actedBy}</td>
                        <td>{accessGroup.actionDate}</td>
                        <td>{accessGroup.actionStatus}</td>
                        <td>
                          {(this.editable || this.viewable) &&
                            <button type='button' className={this.editable ? 'btn-edit' : 'btn-view'} onClick={(e) => this.edit(e, accessGroup)} />}
                          {this.checkable && accessGroup.ctrlStatus === 'P' &&
                            <button type='button' className='btn-approve' onClick={(e) => this.approve(e, accessGroup)} />}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
        </div>
      </div>
    );
  }
}
