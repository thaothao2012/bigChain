import * as React from 'react';
import DiffPanel from 'src/common/component/DiffPanel';
import {DiffApprComponent, DiffState, HistoryProps} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {accessGroupModel} from '../metadata/AccessGroupModel';
import {AccessGroup} from '../model/AccessGroup';

interface InternalState extends DiffState<AccessGroup> {
  accessGroup: AccessGroup;
}

export class AccessGroupDiffForm extends DiffApprComponent<AccessGroup, HistoryProps, InternalState> {
  constructor(props) {
    super(props, accessGroupModel, applicationContext.getAccessGroupService());
    this.state = {
      date: new Date(),
      oldValue: {},
      newValue: {},
    };
  }

  renderFields = [
    {resourceKey: 'entity_type', name: 'entityType'},
    {resourceKey: 'group_id', name: 'groupId'},
    {resourceKey: 'group_name', name: 'groupName'}
  ];

  render() {
    const resource = this.resource;
    const { oldValue, newValue, approveSuccess, rejectSuccess } = this.state;
    return (
      <div className='view-container'>
        <form id='accessGroupForm' name='accessGroupForm' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{resource.group_subject}</h2>
          </header>
          <DiffPanel oldValue= {oldValue}
                     newValue= {newValue}
                     resource={resource}
                     renderFields={this.renderFields}
          />
          <footer>
            <button type='submit' id='btnApprove' name='btnApprove' onClick={this.approve} disabled={approveSuccess}>
              {resource.approve}
            </button>
            <button type='button' id='btnReject' name='btnReject' onClick={this.reject} disabled={rejectSuccess}>
              {resource.reject}
            </button>
          </footer>
        </form>
      </div>
    );
  }
}
