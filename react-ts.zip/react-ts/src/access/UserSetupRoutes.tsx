import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {BankAdminDiffForm} from './component/bank-admin-diff-form';
import {BankAdminForm} from './component/bank-admin-form';
import {BankAdminsForm} from './component/bank-admins-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/bank-admin'} exact={true} component={WithDefaultLayout(BankAdminsForm)} />
        <Route path={this.props.match.url + '/bank-admin/add'} exact={true} component={WithDefaultLayout(BankAdminForm)} />
        <Route path={this.props.match.url + '/bank-admin/edit/:id'} exact={true} component={WithDefaultLayout(BankAdminForm)} />
        <Route path={this.props.match.url + '/bank-admin/approve/:id'} exact={true} component={WithDefaultLayout(BankAdminDiffForm)}/> */}

        <Route path={this.props.match.url + '/bank-admin'} exact={true} component={WithDefaultProps(BankAdminsForm)} />
        <Route path={this.props.match.url + '/bank-admin/add'} exact={true} component={WithDefaultProps(BankAdminForm)} />
        <Route path={this.props.match.url + '/bank-admin/edit/:bankAdminId'} exact={true} component={WithDefaultProps(BankAdminForm)} />
        <Route path={this.props.match.url + '/bank-admin/approve/:bankAdminId'} exact={true} component={WithDefaultProps(BankAdminDiffForm)} />
      </React.Fragment>
    );
  }
}

const UserSetupRoutes = compose(
  withRouter,
)(StatelessApp);
export default UserSetupRoutes;

