import * as React from 'react';
import logo from '../../assets/images/logo.png';
import {
  BaseComponent,
  BaseInternalState,
  HistoryProps,
  ResourceManager,
  storage,
  StringUtil,
  UIUtil
} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {IntegrationConfiguration} from '../model/IntegrationConfiguration';
import {OAuth2Info} from '../model/OAuth2Info';
import {SigninResult} from '../model/SigninResult';
import {SigninStatus} from '../model/SigninStatus';
import {SigninType} from '../model/SigninType';

interface InternalState extends BaseInternalState {
  message: string;
}

export class ConnectForm extends BaseComponent<HistoryProps, InternalState> {
  private readonly oAuth2IntegrationService = applicationContext.getOAuth2IntegrationService();
  private integrationConfigurations: IntegrationConfiguration[];

  constructor(props) {
    super(props);
    this.state = {
      connectType: '',
      connectTypePretty: '',
      message: '',
      componentRef: React.createRef()
    };
    this.connect = this.connect.bind(this);
  }

  // TODO: remove when BaseComponent add componentDidMount() and loadData()
  componentDidMount(): void {
    this.loadData();
  }

  loadData() {
    // @ts-ignore
    let connectType = this.props.match.params['connectType'].toLowerCase();
    if (connectType !== 'signin' && connectType !== 'signup') {
      connectType = 'signup';
    }

    const connectTypePretty = connectType === 'signup' ? 'Sign up' :  'Sign in';
    this.setState({connectType, connectTypePretty});

    this.oAuth2IntegrationService.getIntegrationConfigurations().subscribe(integrationConfigurations => {
      this.integrationConfigurations = integrationConfigurations;
    }, err => this.handleError(err));
  }

  getIntegrationConfiguration(type: string): IntegrationConfiguration {
    for (const integrationConfiguration of this.integrationConfigurations) {
      if (integrationConfiguration.sourceType === type) {
        return integrationConfiguration;
      }
    }
    return null;
  }

  connect(signInType?: string) {
    this.hideMessage();

    const connectType = this.state.connectType;
    if (StringUtil.isEmpty(signInType)) {
      return this.props.history.push('/auth/' + connectType);
    }

    const integrationConfiguration = this.getIntegrationConfiguration(signInType);
    if (!integrationConfiguration) {
      return this.showDanger(StringUtil.format(ResourceManager.getString('msg_set_integration_information'), signInType));
    }

    let url;
    const redirectUrl = storage.getRedirectUrl();
    if (signInType === SigninType.Linkedin) {
      url = 'https://www.linkedin.com/uas/oauth2/authorization?client_id=' + integrationConfiguration.clientId + '&response_type=code&redirect_uri='
        + redirectUrl + '&state=Rkelw7xZWQlV7f8d&scope=r_basicprofile%20r_emailaddress';
    } else if (signInType === SigninType.Google) {
      url = 'https://accounts.google.com/o/oauth2/auth?client_id=' + integrationConfiguration.clientId + '&response_type=code&redirect_uri='
        + redirectUrl + '&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&include_granted_scopes=true';
    } else if (signInType === SigninType.Facebook) {
      url = 'https://www.facebook.com/v2.5/dialog/oauth?client_id=' + integrationConfiguration.clientId + '&redirect_uri='
        + redirectUrl + '&scope=public_profile%2cemail%2cuser_birthday';
    }

    const oAuth2Info: OAuth2Info = {
      signInType: SigninType[signInType],
      redirectUri: redirectUrl,
      code: null
    };

    const left = screen.width / 2 - 300;
    const top = screen.height / 2 - 350;
    const win = window.open(url, '', 'top=' + top + ',left=' + left + ', width=600, height=700');

    const interval = window.setInterval(() => {
      try {
        if (win == null || win.closed) {
          window.clearInterval(interval);
          let code = localStorage.getItem('code');
          if (!StringUtil.isEmpty(code)) {
            // $scope.showLoading();
            if (oAuth2Info.signInType === SigninType.Google) {
              code = encodeURIComponent(code);
            }
            oAuth2Info.code = code;

            this.oAuth2IntegrationService.authenticate(oAuth2Info).subscribe((result: SigninResult) => {
              const status = result.status;
              if (status === SigninStatus.Success || status === SigninStatus.SuccessAndReactivated) {
                if (status === SigninStatus.Success) {
                  storage.setUser(result.user);
                  this.navigateToHome();
                } else {
                  const message3 = ResourceManager.getString('msg_account_reactivated');
                  UIUtil.alertInfo(message3, null, function () {
                    storage.setUser(result.user);
                    this.navigateToHome();
                  });
                }
              } else {
                storage.setUser(null);
                let msg: string;
                switch (status) {
                  case SigninStatus.Fail:
                    msg = ResourceManager.getString('fail_authentication');
                    break;
                  case SigninStatus.WrongPassword:
                    msg = ResourceManager.getString('fail_wrong_password');
                    break;
                  case SigninStatus.PasswordExpired:
                    msg = ResourceManager.getString('fail_password_expired');
                    break;
                  case SigninStatus.Suspended:
                    msg = ResourceManager.getString('fail_suspended_account');
                    break;
                  default:
                    msg = ResourceManager.getString('fail_authentication');
                    break;
                }
                this.showDanger(msg);
              }
            }, this.handleError);
          } else {
            // $scope.hideLoading();
          }
        }
      } catch (e) {
        // $scope.hideLoading();
      }
    }, 1000);
  }

  render() {
    const resource = this.resource;
    const connectTypePretty = this.state.connectTypePretty;
    return (
      <div className='view-container central-full' ref={this.state.componentRef}>
        <form id='connectForm' name='connectForm' noValidate={true} autoComplete='off'>
          <div>
            <img className='logo' src={logo}/>
            <h2>{connectTypePretty}</h2>
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <button type='button' onClick={() => this.connect('LinkedIn')}>{resource.connect_linkedin}</button>
            <button type='button' onClick={() => this.connect('Google')}>{resource.connect_google}</button>
            <button type='button' onClick={() => this.connect('Facebook')}>{resource.connect_facebook}</button>
            <button type='submit' onClick={() => this.connect()}>{resource.connect_userName}</button>
            <button type='button' className='btn-cancel' onClick={this.back}>{resource.button_back}</button>
          </div>
        </form>
      </div>
    );
  }
}
