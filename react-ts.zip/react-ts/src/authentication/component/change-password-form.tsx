import * as React from 'react';
import logo from '../../assets/images/logo.png';
import {BaseComponent, BaseInternalState, HistoryProps, ResourceManager, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {PasswordChange} from '../model/PasswordChange';
import {PasswordService} from '../service/PasswordService';


export interface ChangePasswordWithState extends BaseInternalState {
  userName: string;
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export class ChangePasswordForm extends BaseComponent<HistoryProps, ChangePasswordWithState> {
  constructor(props) {
    super(props);
    this.signin = this.signin.bind(this);
    this.changePassword = this.changePassword.bind(this);
    this.passwordService = applicationContext.getPasswordService();
    this.state = {
      userName: '',
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    };
  }

  private passwordService: PasswordService;

  signin() {
    this.navigate('signin');
  }

  validate = () => {
    if (StringUtil.isEmpty(this.state.newPassword)) {
      const msg = ResourceManager.format('error_required', 'password');
      this.showDanger(msg);
      return false;
    } else {
      if (StringUtil.isEmpty(this.state.currentPassword)) {
        const msg = ResourceManager.format('error_required', 'password');
        this.showDanger(msg);
        return false;
      }
      if (this.state.newPassword !== this.state.confirmPassword) {
        const msg = ResourceManager.format('error_required', 'error_confirmed_password');
        this.showDanger(msg);
        return false;
      }
    }
    return true;
  }

  changePassword = (event) => {
    event.preventDefault();
    if (!this.validate()) {
      return;
    }
    this.hideMessage();

    const user: PasswordChange = {
      userName: this.state.userName,
      currentPassword: this.state.currentPassword,
      newPassword: this.state.newPassword
    };

    this.passwordService.changePassword(user).subscribe(success => {
      if (success) {
        const msg = ResourceManager.getString('success_change_password');
        this.showInfo(msg);
        setTimeout(() => {
          this.signin();
        }, 3000);
      } else {
        const msg = ResourceManager.getString('fail_change_password');
        this.showDanger(msg);
      }
    });
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container central-full'>
        <form id='changePasswordForm' name='changePasswordForm' noValidate={true} autoComplete='off' ref='form'>
          <div>
            <img className='logo' src={logo}/>
            <h2>{resource.change_password}</h2>
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <label>
              {resource.user_name}
              <input type='text'
                     id='userName' name='userName'
                     onChange={this.updateState}
                     maxLength={255} required={true}
                     placeholder={resource.placeholder_user_name}/>
            </label>
            <label>
              {resource.current_password}
              <input type='password' className='form-control'
                     id='currentPassword' name='currentPassword'
                     onChange={this.updateState}
                     maxLength={255} required={true}
                     placeholder={resource.placeholder_current_password}/>
            </label>
            <label>
              {resource.new_password}
              <input type='password' className='form-control'
                     id='newPassword' name='newPassword'
                     onChange={this.updateState}
                     maxLength={255} required={true}
                     placeholder={resource.placeholder_new_password}/>
            </label>
            <label>
              {resource.confirm_password}
              <input type='password' className='form-control'
                     id='confirmPassword' name='confirmPassword'
                     onChange={this.updateState}
                     maxLength={255} required={true}
                     placeholder={resource.placeholder_confirm_password}/>
            </label>
            <section>
              <button type='submit' id='btnChangePassword' name='btnChangePassword'
                      onClick={this.changePassword}>{resource.button_change_password}</button>
              <a id='btnSignin' onClick={this.signin}>{resource.button_signin}</a>
            </section>
          </div>
        </form>
      </div>
    );
  }
}
