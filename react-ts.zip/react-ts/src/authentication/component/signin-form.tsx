import {Base64} from 'js-base64';
import * as React from 'react';
import footer from '../../assets/images/footer.png';
import KCorp_login_final_CashConnectPlus from '../../assets/images/KCorp_login_final_CashConnectPlus.jpg';
import {
  BaseComponent,
  BaseInternalState,
  CookieService,
  DateUtil,
  DefaultCookieService,
  HistoryProps,
  ResourceManager,
  storage,
  StringUtil,
  UIUtil
} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {SigninInfo} from '../model/SigninInfo';
import {SigninResult} from '../model/SigninResult';
import {SigninStatus} from '../model/SigninStatus';
import {AuthenticationService} from '../service/AuthenticationService';
import './signin.css';

interface InternalState extends BaseInternalState {
  userName: string;
  password: string;
  remember: boolean;
  cookieService: CookieService;
}

export class SigninForm extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.signin = this.signin.bind(this);
    this.signup = this.signup.bind(this);
    this.forgotPassword = this.forgotPassword.bind(this);
    this.authenticationService = applicationContext.getAuthenticationService();
    const cookieService = new DefaultCookieService(document);
    const str = cookieService.get('data');
    let userName = '';
    let password = '';
    let remember = false;
    if (!!str && str.length > 0) {
      try {
        const tmp: any = JSON.parse(Base64.decode(str));
        userName = tmp.userName;
        password = tmp.password;
        remember = true;
      } catch (error) {
      }
    }
    this.state = {
      userName,
      password,
      remember,
      cookieService
    };
  }

  private authenticationService: AuthenticationService;

  forgotPassword() {
    this.navigate('/auth/forgot-password');
  }

  signup() {
    this.navigate('connect/signup');
  }

  signin(event) {
    event.preventDefault();
    let valid = true;
    if (StringUtil.isEmpty(this.state.userName)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'user_name');
      this.showDanger(msg);
    } else if (StringUtil.isEmpty(this.state.password)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'password');
      this.showDanger(msg);
    }

    if (valid === false) {
      return;
    }
    const cookieService = this.state.cookieService;
    const remember = this.state.remember;
    const user: SigninInfo = {
      userName: this.state.userName,
      password: this.state.password
    };
    this.authenticationService.authenticate(user).subscribe((result: SigninResult) => {
      const status = result.status;
      if (status === SigninStatus.Success || status === SigninStatus.SuccessAndReactivated) {
        if (remember === true) {
          const data = {
            userName: user.userName,
            password: user.password
          };
          const expiredDate = DateUtil.addDays(DateUtil.now(), 7);
          cookieService.set('data', Base64.encode(JSON.stringify(data)), expiredDate);
        } else {
          cookieService.delete('data');
        }
        const expiredDays = DateUtil.dayDiff(result.user.passwordExpiredTime, DateUtil.now());
        if (expiredDays > 0) {
          const message2 = ResourceManager.getString('msg_password_expired_soon', expiredDays);
          UIUtil.showToast(message2);
        }
        if (status === SigninStatus.Success) {
          storage.setUser(result.user);
          const forms = result.user.hasOwnProperty('modules') ? result.user.modules : null;
          if (forms !== null && forms.length !== 0) {
            storage.setForms(null);
            storage.setForms(forms);
          }
          this.navigateToHome();
        } else {
          const message3 = ResourceManager.getString('msg_account_reactivated');
          UIUtil.alertInfo(message3, null, function () {
            storage.setUser(result.user);
            const forms = result.user.hasOwnProperty('modules') ? result.user.modules : null;
            if (forms !== null && forms.length !== 0) {
              storage.setForms(null);
              storage.setForms(forms);
            }
            this.navigateToHome();
          });
        }
      } else {
        storage.setUser(null);
        storage.setForms(null);
        let msg: string;
        switch (status) {
          case SigninStatus.Fail:
            msg = ResourceManager.getString('fail_authentication');
            break;
          case SigninStatus.WrongPassword:
            msg = ResourceManager.getString('fail_wrong_password');
            break;
          case SigninStatus.PasswordExpired:
            msg = ResourceManager.getString('fail_password_expired');
            break;
          case SigninStatus.Suspended:
            msg = ResourceManager.getString('fail_suspended_account');
            break;
          default:
            msg = ResourceManager.getString('fail_authentication');
            break;
        }
        this.showDanger(msg);
      }
    }, this.handleError);
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container central-full sign-in-view-container'>
        <div className='row'>
          <div className='col s12 m8 offset-m2'>
            <img className='img-responsive' src={KCorp_login_final_CashConnectPlus} alt='KCorp_login' />
          </div>
        </div>
        <div className='row'>
          <div className='col s12 m8 offset-m2'>
            <h3 className='sign-in-welcome'>
              Welcome to
              <p className='k-cash'>K-Cash Connect Plus</p>
            </h3>
          </div>
        </div>
        <form id='signinForm' name='signinForm' noValidate={true} autoComplete='off' ref='form'>
          <div>
            {/* <img className='logo' src={logo} /> */}
            {/* <h2>{resource.signin}</h2> */}
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <label>
              {resource.email}
              <input type='text'
                id='userName' name='userName'
                value={this.state.userName}
                placeholder={resource.placeholder_user_name}
                onChange={this.updateState}
                maxLength={255} required={true} />
            </label>
            <label>
              {resource.password}
              <input type='password'
                id='password' name='password'
                value={this.state.password}
                placeholder={resource.placeholder_password}
                onChange={this.updateState}
                maxLength={255} required={true} />
            </label>
            <label className='col s12 checkbox-container'>
              <input type='checkbox'
                id='remember' name='remember'
                checked={this.state.remember ? true : false}
                onChange={this.updateState} />
              {resource.signin_remember_me}
            </label>
            <button type='submit' id='btnSignin' name='btnSignin'
              onClick={this.signin}>{resource.button_signin}</button>
            <a id='btnForgotPassword' onClick={this.forgotPassword}>{resource.forgot_password}</a>
            <a id='btnSignup' onClick={this.signup}>{resource.signup}</a>
          </div>
        </form>
        <div className='row'>
          <div className='col s12 compatible'>
            Compatible with Internet Explorer version 10+ or Google Chrome version 40+ or Firefox version
            52+
          </div>
          <div className='col s12 m8 offset-m2'>
            <img src={footer} className='img-responsive' alt='footer' />
          </div>
        </div>
      </div>
    );
  }
}
