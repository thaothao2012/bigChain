import * as React from 'react';
import {
  BaseComponent,
  BaseInternalState,
  HistoryProps,
  ResourceManager,
  storage,
  StringUtil,
  UIUtil
} from '../../core';
import {MyProfileServiceImpl} from '../../my-profile/service/impl/MyProfileServiceImpl';
import applicationContext from '../config/ApplicationContext';
import {IntegrationConfiguration} from '../model/IntegrationConfiguration';
import {OAuth2Info} from '../model/OAuth2Info';
import {SigninResult} from '../model/SigninResult';
import {SigninStatus} from '../model/SigninStatus';
import {SigninType} from '../model/SigninType';

interface InternalState extends BaseInternalState {
  message: string;
}

export class LinkSocialAccountsForm extends BaseComponent<HistoryProps, InternalState> {
  private readonly oAuth2IntegrationService = applicationContext.getOAuth2IntegrationService();
  private readonly myProfileService = new MyProfileServiceImpl();
  private integrationConfigurations: IntegrationConfiguration[];

  constructor(props) {
    super(props);
    this.state = {
      message: '',
      componentRef: React.createRef(),
      user: {}
    };
    this.connect = this.connect.bind(this);
  }

  // TODO: remove when BaseComponent add componentDidMount() and loadData()
  componentDidMount(): void {
    this.loadData();
  }

  loadMyProfile() {
    const userId = storage.getUserId();
    this.myProfileService.getMyProfile(userId).subscribe(res => {
      this.setState({user: res});
    }, this.handleError);
  }

  loadData() {
    this.loadMyProfile();

    this.oAuth2IntegrationService.getIntegrationConfigurations().subscribe(integrationConfigurations => {
      this.integrationConfigurations = integrationConfigurations;
    }, err => this.handleError(err));
  }

  getIntegrationConfiguration(type: string): IntegrationConfiguration {
    for (const integrationConfiguration of this.integrationConfigurations) {
      if (integrationConfiguration.sourceType === type) {
        return integrationConfiguration;
      }
    }
    return null;
  }

  connect(signInType?: string) {
    this.hideMessage();

    const integrationConfiguration = this.getIntegrationConfiguration(signInType);
    if (!integrationConfiguration) {
      return this.showDanger(StringUtil.format(ResourceManager.getString('msg_set_integration_information'), signInType));
    }

    let url;
    const redirectUrl = storage.getRedirectUrl();
    if (signInType === SigninType.Linkedin) {
      url = 'https://www.linkedin.com/uas/oauth2/authorization?client_id=' + integrationConfiguration.clientId + '&response_type=code&redirect_uri='
        + redirectUrl + '&state=Rkelw7xZWQlV7f8d&scope=r_basicprofile%20r_emailaddress';
    } else if (signInType === SigninType.Google) {
      url = 'https://accounts.google.com/o/oauth2/auth?client_id=' + integrationConfiguration.clientId + '&response_type=code&redirect_uri='
        + redirectUrl + '&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile&include_granted_scopes=true';
    } else if (signInType === SigninType.Facebook) {
      url = 'https://www.facebook.com/v2.5/dialog/oauth?client_id=' + integrationConfiguration.clientId + '&redirect_uri='
        + redirectUrl + '&scope=public_profile%2cemail%2cuser_birthday';
    }

    const oAuth2Info: OAuth2Info = {
      signInType: SigninType[signInType],
      redirectUri: redirectUrl,
      code: null,
      isLink: true
    };

    const left = screen.width / 2 - 300;
    const top = screen.height / 2 - 350;
    const win = window.open(url, '', 'top=' + top + ',left=' + left + ', width=600, height=700');

    const interval = window.setInterval(() => {
      try {
        if (win == null || win.closed) {
          window.clearInterval(interval);
          let code = localStorage.getItem('code');
          if (!StringUtil.isEmpty(code)) {
            // $scope.showLoading();
            if (oAuth2Info.signInType === SigninType.Google) {
              code = encodeURIComponent(code);
            }
            oAuth2Info.code = code;

            this.oAuth2IntegrationService.authenticate(oAuth2Info).subscribe((result: SigninResult) => {
              const status = result.status;
              if (status === SigninStatus.Success || status === SigninStatus.SuccessAndReactivated) {
                if (status === SigninStatus.Success) {
                  storage.setUser(result.user);
                  this.loadMyProfile();
                } else {
                  const message3 = ResourceManager.getString('msg_account_reactivated');
                  UIUtil.alertInfo(message3, null, function () {
                    storage.setUser(result.user);
                    this.loadMyProfile();
                  });
                }
              } else {
                storage.setUser(null);
                let msg: string;
                switch (status) {
                  case SigninStatus.Fail:
                    msg = ResourceManager.getString('fail_authentication');
                    break;
                  case SigninStatus.WrongPassword:
                    msg = ResourceManager.getString('fail_wrong_password');
                    break;
                  case SigninStatus.PasswordExpired:
                    msg = ResourceManager.getString('fail_password_expired');
                    break;
                  case SigninStatus.Suspended:
                    msg = ResourceManager.getString('fail_suspended_account');
                    break;
                  default:
                    msg = ResourceManager.getString('fail_authentication');
                    break;
                }
                this.showDanger(msg);
              }
            }, this.handleError);
          } else {
            // $scope.hideLoading();
          }
        }
      } catch (e) {
        // $scope.hideLoading();
      }
    }, 1000);
  }

  disconnect = (e) => {
  }

  render() {
    const user = this.state.user;

    return (
      <div className='view-container central-full'>
        <form id='signinForm' name='signinForm' noValidate={true} autoComplete='off'>
          <div className='row justify-content-center'>
            <div className='col'>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='username'>LinkedIn</label>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  {user && user.linkedinActive === 'A' ? (
                    <label htmlFor='username'>{user.linkedinEmail}</label>
                  ) : (
                    <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.connect('LinkedIn')}>
                      Connect
                    </button>
                  )}
                </div>
                <div className='col form-group'>
                  {user && user.linkedinActive === 'A' &&
                  <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.disconnect('LinkedIn')}>
                    Unlink
                  </button>
                  }
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='username'>Google</label>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  {user && user.googleActive === 'A' ? (
                    <label htmlFor='username'>{user.googleEmail}</label>
                  ) : (
                    <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.connect('Google')}>
                      Connect
                    </button>
                  )}
                </div>
                <div className='col form-group'>
                  {user && user.googleActive === 'A' &&
                  <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.disconnect('Google')}>
                    Unlink
                  </button>
                  }
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='username'>Facebook</label>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  {user && user.facebookActive === 'A' ? (
                    <label htmlFor='username'>{user.facebookEmail}</label>
                  ) : (
                    <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.connect('Facebook')}>
                      Connect
                    </button>
                  )}
                </div>
                <div className='col form-group'>
                  {user && user.facebookActive === 'A' &&
                  <button type='button' className='btn btn-link' id='btnEmail' name='btnEmail' onClick={() => this.disconnect('Facebook')}>
                    Unlink
                  </button>
                  }
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}
