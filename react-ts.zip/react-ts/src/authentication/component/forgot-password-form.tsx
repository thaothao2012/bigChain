import * as H from 'history';
import * as React from 'react';
import logo from '../../assets/images/logo.png';
import {BaseComponent, BaseInternalState, HistoryProps, ResourceManager, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {PasswordService} from '../service/PasswordService';

interface InternalState extends BaseInternalState {
  email: string;
}

export class ForgotPasswordForm extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.signin = this.signin.bind(this);
    this.resetPassword = this.resetPassword.bind(this);
    this.forgotPassword = this.forgotPassword.bind(this);
    this.passwordService = applicationContext.getPasswordService();
    this.state = {
      email: ''
    };
  }

  private passwordService: PasswordService;

  signin() {
    this.navigate('signin');
  }

  resetPassword() {
    this.navigate('reset-password');
  }

  forgotPassword = (event) => {
    event.preventDefault();
    if (StringUtil.isEmpty(this.state.email)) {
      const msg = ResourceManager.format('error_required', 'email');
      this.showDanger(msg);
      return;
    }
    this.passwordService.forgotPassword(this.state.email).subscribe(success => {
      if (success) {
        const msg = ResourceManager.getString('success_forgot_password');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_forgot_password');
        this.showDanger(msg);
      }
    });
  }

  render() {
    const resource = this.resource;
    console.log('this.state._message', this.state._message);
    return (
      <div className='view-container central-full'>
        <form id='forgotPasswordForm' name='forgotPasswordForm' noValidate={true} autoComplete='off' ref='form'>
          <div>
            <img className='logo' src={logo} />
            <h2>{resource.forgot_password}</h2>
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <label>
              {resource.email}
              <input type='text'
                id='email' name='email'
                placeholder={resource.placeholder_user_email}
                onChange={this.updateState}
                maxLength={255} required={true}
              />
            </label>
            <button type='submit' id='btnForgotPassword' name='btnForgotPassword'
                onClick={this.forgotPassword}>{resource.button_forgot_password}</button>
            <a id='btnSignin' onClick={this.signin}>{resource.button_signin}</a>
            <a id='btnResetPassword' onClick={this.resetPassword}>{resource.button_reset_password}</a>
          </div>
        </form>
      </div>
    );
  }
}
