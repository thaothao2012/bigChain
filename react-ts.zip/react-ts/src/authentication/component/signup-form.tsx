import * as H from 'history';
import * as React from 'react';
import logo from '../../assets/images/logo.png';
import {BaseComponent, BaseInternalState, HistoryProps, ResourceManager, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {UserRegistration} from '../model/UserRegistration';
import {UserRegistrationService} from '../service/UserRegistrationService';

interface InternalState extends BaseInternalState {
  email: string;
  userName: string;
  password: string;
}

export class SignupForm extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.signin = this.signin.bind(this);
    this.signup = this.signup.bind(this);
    this.userRegistrationService = applicationContext.getUserRegistrationService();
    this.state = {
      userName: '',
      email: '',
      password: '',
    };
  }

  private userRegistrationService: UserRegistrationService;

  signin() {
    this.navigate('connect/signin');
  }

  signup(event) {
    event.preventDefault();
    if (!StringUtil.isEmail(this.state.userName)) {
      const msg = ResourceManager.format('error_email', 'email');
      this.showDanger(msg);
      return;
    } else if (StringUtil.isEmpty(this.state.userName)) {
      const msg = ResourceManager.format('error_required', 'email');
      this.showDanger(msg);
      return;
    } else {
      if (StringUtil.isEmpty(this.state.password)) {
        const msg = ResourceManager.format('error_required', 'password');
        this.showDanger(msg);
        return;
      }
    }
    const user: UserRegistration = {
      email: this.state.userName,
      userName: this.state.userName,
      password: this.state.password
    };
    this.userRegistrationService.registerUser(user).subscribe(result => {
      if (result.success) {
        const msg = ResourceManager.getString('success_sign_up');
        this.showInfo(msg);
      } else {
        let message = '';
        for (const err of result.errors) {
          message += err.message;
        }
        this.showDanger(message);
      }
    });
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container central-full'>
        <form id='signupForm' name='signupForm' noValidate={true} autoComplete='off' ref='form'>
          <div>
            <img className='logo' src={logo}/>
            <h2>{resource.signup}</h2>
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <label>
              {resource.user_name}
              <input type='text'
                id='userName' name='userName'
                datatype='email'
                placeholder={resource.placeholder_user_name}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <label>
              {resource.password}
              <input type='password'
                id='password' name='password'
                placeholder={resource.placeholder_password}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <button type='submit' id='btnSignup' name='btnSignup' onClick={this.signup}>
              {resource.button_signup}
            </button>
            <a id='btnSignin' onClick={this.signin}>{resource.button_signin}</a>
          </div>
        </form>
      </div>
    );
  }
}
