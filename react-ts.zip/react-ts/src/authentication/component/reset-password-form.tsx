import * as H from 'history';
import * as React from 'react';
import logo from '../../assets/images/logo.png';
import {BaseComponent, BaseInternalState, HistoryProps, ResourceManager, StringUtil} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {PasswordReset} from '../model/PasswordReset';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {PasswordService} from '../service/PasswordService';

interface InternalState extends BaseInternalState {
  userName: string;
  passcode: string;
  newPassword: string;
  confirmPassword: string;
}

export class ResetPasswordForm extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.signin = this.signin.bind(this);
    this.resetPassword = this.resetPassword.bind(this);
    this.passwordService = applicationContext.getPasswordService();
    this.state = {
      userName: '',
      passcode: '',
      newPassword: '',
      confirmPassword: ''
    };
  }

  private passwordService: PasswordService;

  signin() {
    this.navigate('signin');
  }

  resetPassword(event) {
    event.preventDefault();
    let valid = true;
    if (StringUtil.isEmpty(this.state.userName)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'user_name');
      this.showDanger(msg);
    } else if (StringUtil.isEmpty(this.state.passcode)) {
      valid = false;
      const msg = ResourceManager.getString('error_required_passcode');
      this.showDanger(msg);
    } else if (StringUtil.isEmpty(this.state.newPassword)) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'new_password');
      this.showDanger(msg);
    } else if (this.state.newPassword !== this.state.confirmPassword) {
      valid = false;
      const msg = ResourceManager.format('error_required', 'error_confirmed_password');
      this.showDanger(msg);
    }
    if (!valid) {
      return;
    }
    const user: PasswordReset = {
      userName: this.state.userName,
      passcode: this.state.passcode,
      newPassword: this.state.newPassword,
    };

    this.passwordService.resetPassword(user).subscribe(success => {
      if (success) {
        const msg = ResourceManager.getString('success_reset_password');
        this.showInfo(msg);
      } else {
        const msg = ResourceManager.getString('fail_reset_password');
        this.showDanger(msg);
      }
    }, this.handleError);
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container central-full'>
        <form id='resetPasswordForm' name='resetPasswordForm' noValidate={true} autoComplete='off' ref='form'>
          <div>
            <img className='logo' src={logo}/>
            <h2>{resource.reset_password}</h2>
            <div className={'message ' + this.alertClass}>
              {this.state._message}
              <span onClick={this.hideMessage} hidden={!this.state._message || this.state._message === ''}/>
            </div>
            <label>
              {resource.user_name}
              <input type='text'
                id='userName' name='userName'
                datatype='email'
                placeholder={resource.placeholder_user_name}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <label>
              {resource.passcode}
              <input type='text'
                id='passcode' name='passcode'
                placeholder={resource.placeholder_passcode}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <label>
              {resource.new_password}
              <input type='password'
                id='newPassword' name='newPassword'
                placeholder={resource.placeholder_new_password}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <label>
              {resource.confirm_password}
              <input type='password'
                id='confirmPassword' name='confirmPassword'
                placeholder={resource.placeholder_confirm_password}
                onChange={this.updateState}
                maxLength={255} required={true}/>
            </label>
            <button type='submit' id='btnResetPassword' name='btnResetPassword' onClick={this.resetPassword}>
              {resource.button_reset_password}
            </button>
            <a id='btnSignin' onClick={this.signin}>
              {resource.button_signin}
            </a>
          </div>
        </form>
      </div>
    );
  }
}
