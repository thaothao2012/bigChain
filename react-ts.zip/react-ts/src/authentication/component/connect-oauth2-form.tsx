import * as React from 'react';

import {BaseComponent, BaseInternalState, HistoryProps} from '../../core';

interface InternalState extends BaseInternalState {
  message: string;
}

export class ConnectOauth2Form extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
  }

  componentDidMount(): void {
    // @ts-ignore
    const urlSearchParams = new URLSearchParams(this.props.location.search);
    const code = urlSearchParams.get('code');
    localStorage.setItem('code', code);
    window.close();
  }

  render() {
    return (
      <div>{}</div>
    );
  }
}
