export interface SigninInfo {
  userName: string;
  password: string;
}
