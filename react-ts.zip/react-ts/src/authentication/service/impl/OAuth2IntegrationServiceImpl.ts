import {Observable} from 'rxjs';

import config from '../../../config';
import {WebClientUtil} from '../../../core';
import {IntegrationConfiguration} from '../../model/IntegrationConfiguration';
import {OAuth2Info} from '../../model/OAuth2Info';
import {SigninResult} from '../../model/SigninResult';
import {OAuth2IntegrationService} from '../OAuth2IntegrationService';

export class OAuth2IntegrationServiceImpl implements OAuth2IntegrationService {
  private serviceUrl = config.authenticationServiceUrl;

  getIntegrationConfigurations(): Observable<IntegrationConfiguration[]> {
    const url = this.serviceUrl  + '/integrationConfigurations';
    const objectObservable: any = WebClientUtil.get(url);
    return objectObservable;
  }

  authenticate(auth: OAuth2Info): Observable<SigninResult> {
    const url = this.serviceUrl + '/oauth2/authenticate';
    return WebClientUtil.postObject<SigninResult>(url, auth);
  }

}
