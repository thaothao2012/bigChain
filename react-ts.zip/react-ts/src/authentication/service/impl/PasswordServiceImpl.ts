import {Observable} from 'rxjs';
import config from '../../../config';
import {WebClientUtil} from '../../../core';
import {PasswordChange} from '../../model/PasswordChange';
import {PasswordReset} from '../../model/PasswordReset';
import {PasswordService} from '../PasswordService';

export class PasswordServiceImpl implements PasswordService {
  serviceUrl = config.passwordServiceUrl + '/' + 'password';

  changePassword(pass: PasswordChange): Observable<boolean> {
    const url = this.serviceUrl + '/change';
    return WebClientUtil.putObject<boolean>(url, pass);
  }

  forgotPassword(email: string): Observable<boolean> {
    const url = this.serviceUrl + '/forgot';
    return WebClientUtil.postObject<boolean>(url, {'email': email});
  }

  resetPassword(pass: PasswordReset): Observable<boolean> {
    const url = this.serviceUrl + '/reset';
    return WebClientUtil.postObject<boolean>(url, pass);
  }
}
