import {Observable} from 'rxjs';

import config from '../../../config';
import {WebClientUtil} from '../../../core';
import {SigninInfo} from '../../model/SigninInfo';
import {SigninResult} from '../../model/SigninResult';
import {AuthenticationService} from '../AuthenticationService';

export class AuthenticationServiceImpl implements AuthenticationService {
  constructor() {
    console.log('new authentication service impl');
  }
  authenticate(user: SigninInfo): Observable<SigninResult> {
    const url = config.authenticationServiceUrl + '/authentication/authenticate';
    return WebClientUtil.postObject<SigninResult>(url, user);
    // const url = config.authenticationServiceUrl + '/login.json';
    // return WebClientUtil.getObject<SigninResult>(url);
  }
}
