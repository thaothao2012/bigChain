import {Observable} from 'rxjs';

import {IntegrationConfiguration} from '../model/IntegrationConfiguration';
import {OAuth2Info} from '../model/OAuth2Info';
import {SigninResult} from '../model/SigninResult';

export interface OAuth2IntegrationService {
  getIntegrationConfigurations(): Observable<IntegrationConfiguration[]>;
  authenticate(auth: OAuth2Info): Observable<SigninResult>;
}
