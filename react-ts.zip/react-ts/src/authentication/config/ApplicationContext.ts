import {AuthenticationService} from '../service/AuthenticationService';
import {AuthenticationServiceImpl} from '../service/impl/AuthenticationServiceImpl';
import {OAuth2IntegrationServiceImpl} from '../service/impl/OAuth2IntegrationServiceImpl';
import {PasswordServiceImpl} from '../service/impl/PasswordServiceImpl';
import {UserRegistrationServiceImpl} from '../service/impl/UserRegistrationServiceImpl';
import {OAuth2IntegrationService} from '../service/OAuth2IntegrationService';
import {PasswordService} from '../service/PasswordService';
import {UserRegistrationService} from '../service/UserRegistrationService';

class ApplicationContext {
  private readonly userRegistrationService: UserRegistrationService;
  private readonly authenticationService: AuthenticationService;
  private readonly passwordService: PasswordService;
  private readonly oAuth2IntegrationService: OAuth2IntegrationService;

  constructor() {
    this.userRegistrationService = new UserRegistrationServiceImpl();
    this.authenticationService = new AuthenticationServiceImpl();
    this.passwordService = new PasswordServiceImpl();
    this.oAuth2IntegrationService = new OAuth2IntegrationServiceImpl();
  }

  getUserRegistrationService(): UserRegistrationService {
    return this.userRegistrationService;
  }

  getAuthenticationService(): AuthenticationService {
    return this.authenticationService;
  }

  getPasswordService(): PasswordService {
    return this.passwordService;
  }

  getOAuth2IntegrationService(): OAuth2IntegrationService {
    return this.oAuth2IntegrationService;
  }
}

const applicationContext = new ApplicationContext();

export default applicationContext;
