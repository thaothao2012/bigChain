import * as H from 'history';
import * as React from 'react';
import {connect} from 'react-redux';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';
import {WithDefaultProps} from '../container/default';
import {updateGlobalState} from '../core';
import {PrivateRoute} from '../PrivateRoute';
import {BankDiffForm} from './component/bank/bank-diff-form';
import {BankForm} from './component/bank/bank-form';
import {BanksForm} from './component/bank/banks-form';
import {PaymentAccountDiffForm} from './component/payment-account-diff-form';
import {PaymentAccountForm} from './component/payment-account-form';
import {PaymentAccountsForm} from './component/payment-accounts-form';
import {ReceivingAccountDiffForm} from './component/receiving-account-diff-form';
import {ReceivingAccountForm} from './component/receiving-account-form';
import {ReceivingAccountsForm} from './component/receiving-accounts-form';

interface AppProps {
  history: H.History;
  setGlobalState: (data: any) => void;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    const commonProps = {
      rootUrl: this.props.match.url,
      exact: true,
      setGlobalState: this.props.setGlobalState
    };
    return (
      <React.Fragment>
        {/* <PrivateRoute path={this.props.match.url + '/bank/approve/:id'} exact={true} {...commonProps} component={WithDefaultLayout(BankDiffForm)} />
        <PrivateRoute path={this.props.match.url + '/bank/add'} exact={true} {...commonProps} component={WithDefaultLayout(BankForm)} />
        <PrivateRoute path={this.props.match.url + '/bank/edit/:id'} exact={true} {...commonProps} component={WithDefaultLayout(BankForm)} />
        <PrivateRoute path={this.props.match.url + '/bank'} exact={true} {...commonProps} component={WithDefaultLayout(BanksForm)} />

        <Route path={this.props.match.url + '/odd-account'} exact={true} component={WithDefaultLayout(PaymentAccountsForm)} />
        <Route path={this.props.match.url + '/odd-account/add'} exact={true} component={WithDefaultLayout(PaymentAccountForm)} />
        <Route path={this.props.match.url + '/odd-account/edit/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultLayout(PaymentAccountForm)} />
        <Route path={this.props.match.url + '/odd-account/approve/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultLayout(PaymentAccountDiffForm)} />

        <Route path={this.props.match.url + '/receiving-account/approve/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultLayout(ReceivingAccountDiffForm)} />
        <Route path={this.props.match.url + '/receiving-account/edit/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultLayout(ReceivingAccountForm)} />
        <Route path={this.props.match.url + '/receiving-account/add'} exact={true} component={WithDefaultLayout(ReceivingAccountForm)} />
        <Route path={this.props.match.url + '/receiving-account'} exact={true} component={WithDefaultLayout(ReceivingAccountsForm)} /> */}

        <PrivateRoute path={this.props.match.url + '/bank/approve/:bankId'} exact={true} {...commonProps} component={WithDefaultProps(BankDiffForm)} />
        <PrivateRoute path={this.props.match.url + '/bank/add'} exact={true} {...commonProps} component={WithDefaultProps(BankForm)} />
        <PrivateRoute path={this.props.match.url + '/bank/edit/:bankId'} exact={true} {...commonProps} component={WithDefaultProps(BankForm)} />
        <PrivateRoute path={this.props.match.url + '/bank'} exact={true} {...commonProps} component={WithDefaultProps(BanksForm)} />

        <Route path={this.props.match.url + '/odd-account'} exact={true} component={WithDefaultProps(PaymentAccountsForm)} />
        <Route path={this.props.match.url + '/odd-account/add'} exact={true} component={WithDefaultProps(PaymentAccountForm)} />
        <Route path={this.props.match.url + '/odd-account/edit/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultProps(PaymentAccountForm)} />
        <Route path={this.props.match.url + '/odd-account/approve/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultProps(PaymentAccountDiffForm)} />

        <Route path={this.props.match.url + '/receiving-account/approve/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultProps(ReceivingAccountDiffForm)} />
        <Route path={this.props.match.url + '/receiving-account/edit/:bankId/:entityId/:accNo'} exact={true} component={WithDefaultProps(ReceivingAccountForm)} />
        <Route path={this.props.match.url + '/receiving-account/add'} exact={true} component={WithDefaultProps(ReceivingAccountForm)} />
        <Route path={this.props.match.url + '/receiving-account'} exact={true} component={WithDefaultProps(ReceivingAccountsForm)} />
      </React.Fragment>
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    setGlobalState: (res) => dispatch(updateGlobalState(res)),
  };
}
const withConnect = connect(null, mapDispatchToProps);

const BankSetupRoutes = compose(
  withRouter,
  withConnect
)(StatelessApp);
export default BankSetupRoutes;
