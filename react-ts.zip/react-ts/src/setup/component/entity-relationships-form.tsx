import * as React from 'react';
import {zip} from 'rxjs';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {EntityType} from '../enum/EntityType';
import {EntityRelationship} from '../model/EntityRelationship';
import {EntityRelationshipSM} from '../search-model/EntityRelationshipSM';

export class EntityRelationshipsForm extends SearchComponent<EntityRelationship, EntityRelationshipSM, HistoryProps, SearchState<EntityRelationship>> {
  constructor(props) {
    super(props, applicationContext.getEntityRelationService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      entityName: '',
      esSysName: '',
      keyword: '',
      ctrlStatusList: [],
      results: [],
      ctrlStatus: []
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    zip(
      this.masterDataService.getCtrlStatus(),
    ).subscribe(([ctrlStatusList]) => {
      this.setState({ ctrlStatusList }, this.loadData);
    }, this.handleError);
  }

  getSearchModel(): EntityRelationshipSM {
    const model = this.populateSearchModel();
    model.entityType = EntityType.Payee;
    return model;
  }

  approve = (e, esId: string, payeeId: string) => {
    e.preventDefault();
    this.props.history.push(`entity-relationship/approve/${esId}/${payeeId}`);
  }

  edit = (e, esId: string, payeeId: string) => {
    e.preventDefault();
    this.props.history.push(`entity-relationship/edit/${esId}/${payeeId}`);
  }

  render() {
    const resource = this.resource;
    const { ctrlStatusList, ctrlStatus, esSysName } = this.state;

    return (
      <div className='view-container'>
        <header>
          <h2>{resource.entity_relationship_list}</h2>
          {this.addable && <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add} />}
        </header>
        <div>
          <form id='payeesForm' name='payeesForm' noValidate={true} ref='form'>
            <section className='row search-group inline'>
              <label className='col s12 m6 l3'>
                {resource.external_system}
                <input
                  type='text'
                  id='esSysName'
                  name='esSysName'
                  value={esSysName}
                  onChange={this.updateState}
                  maxLength={240}
                  placeholder={resource.external_system} />
              </label>
              <label className='col s12 m6 l3'>
                {resource.entity_relationship_payee_company_sys}
                <input type='text'
                  id='entityName' name='entityName'
                  value={this.state.entityName}
                  onChange={this.updateState}
                  maxLength={240}
                  placeholder={resource.entity_relationship_payee_company_sys} />
              </label>
              <label className='col s12 m12 l6'>
                {resource.ctrl_status}
                <section className='checkbox-group'>
                  {ctrlStatusList.map((item, index) => (
                    <label key={index}>
                      <input
                        type='checkbox'
                        id={item.value}
                        name='ctrlStatus'
                        key={index}
                        value={item.value}
                        checked={ctrlStatus.includes(item.value)}
                        onChange={this.updateState} />
                      {item.text}
                    </label>
                  )
                  )}
                </section>
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='esSysName'><button type='button' id='sortEssysName' onClick={this.sort}>{resource.externalsys_name}</button></th>
                    <th data-field='entityName'><button type='button' id='sortCompanyName' onClick={this.sort}>{resource.entity_relationship_payee_company_sys}</button></th>
                    <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                    <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                    <th data-field='actionDate'><button type='button' id='sortActionDate' onClick={this.sort}>{resource.action_date}</button></th>
                    <th data-field='actionStatus'><button type='button' id='sortActionStatus' onClick={this.sort}>{resource.action_status}</button></th>
                    <th className='action'>{resource.quick_action}</th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((entityRelationship, i) => {
                    return (
                      <tr key={i}>
                        <td className='text-right'>{entityRelationship.sequenceNo}</td>
                        <td>{entityRelationship.esSysName}</td>
                        <td>{entityRelationship.entityName}</td>
                        <td>{entityRelationship.ctrlStatusName}</td>
                        <td>{entityRelationship.actedBy}</td>
                        <td>{entityRelationship.actionDate}</td>
                        <td>{entityRelationship.actionStatus}</td>
                        <td>
                          {(this.editable || this.viewable) &&
                            <button type='button' className={this.editable ? 'btn-edit' : 'btn-view'} onClick={(e) => this.edit(e, entityRelationship.esId, entityRelationship.payeeId)} />}
                          {this.checkable && entityRelationship.ctrlStatus === 'P' &&
                            <button type='button' className='btn-approve' onClick={(e) => this.approve(e, entityRelationship.esId, entityRelationship.payeeId)} />}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
        </div>
      </div>
    );
  }
}
