import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {EditDynamicLayoutComponent} from '../../../common/component/EditDynamicLayoutComponent';
import {BaseInternalState, EditComponent, GLOBAL_STATE, globalStateReducer, HistoryProps, updateGlobalState, withReducer} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {dynamicFormModel} from '../../metadata/DynamicModel';
import {DynamicForm} from '../../model/DynamicForm';
import {getDynamicFormById, insertDynamicForm, updateDynamicForm} from '../payee/payeeActions';
import {payeeSelector} from '../payee/PayeeSelector';
import {JsonEditor} from './json-editor';

interface DispatchProps {
  setGlobalState?: (data) => void;
  getDynamicFormById?: (data: any) => any;
  updateDynamicFormInfo?: (data: any) => any;
  insertDynamicFormInfo?: (data: any) => any;
}

interface InternalState extends BaseInternalState {
  dynamicForm: DynamicForm;
}

type DynamicPropsType = DispatchProps & InternalState;
type DynamicHistorypropsType = HistoryProps & InternalState;

class DynamicActionComponent extends EditDynamicLayoutComponent<DynamicForm, DynamicHistorypropsType, DynamicPropsType> {
  constructor(props) {
    const service = {
      getDynamicFormById: props.getDynamicFormById,
      update: props.updateDynamicFormInfo,
      insert: props.insertDynamicFormInfo
    };
    super(props, dynamicFormModel, service, applicationContext.getEditPermissionBuilder());
    this.state = {
      date: new Date()
    };
  }

  createModel(): DynamicForm {
    const dynamicForm = super.createModel();
    return dynamicForm;
  }

  getModel(): DynamicForm {
    const dynamicForm = this.getModelFromState();
    return dynamicForm;
  }

  render() {
    const resource = this.resource;
    const { dynamicForm } = this.props;

    return (
      <div className='view-container'>
        <form id='dynamicForm' name='dynamicForm' model-name='dynamicForm' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{this.isNewMode() ? resource.create : resource.edit} {'Dynamic Form'}</h2>
          </header>
          <div className='row'>
            <label className='col s12 m4'>
              Form Name
              <input
                type='text'
                id='formName'
                name='formName'
                value={dynamicForm.formName}
                onChange={this.updateState}
                maxLength={255}
                required={true}
                placeholder='Form Name' />
            </label>
            <label className='col s12 m8'>
              Json Dynamic Form
              <JsonEditor
                json={dynamicForm}
                onChange={this.updateState}
                setGlobalState={(this.props as any).setGlobalState}
                formName='dynamicForm'
              />
            </label>
          </div>
          <footer>
            {this.editable &&
              <button type='submit' id='btnSave' name='btnSave' onClick={this.saveOnClick}>
                {resource.save}
              </button>}
          </footer>
        </form>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    dynamicForm: payeeSelector.selectDynamicForm(state)
  };
}

function mapDispatchToProps(dispatch): DispatchProps {
  return {
    setGlobalState: (data) => dispatch(updateGlobalState(data)),
    getDynamicFormById: (data) => dispatch(getDynamicFormById(data)),
    updateDynamicFormInfo: (data) => dispatch(updateDynamicForm(data)),
    insertDynamicFormInfo: (data) => dispatch(insertDynamicForm(data))
  };
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const PayerForm = compose(
  withStore,
  withConnect
)(DynamicActionComponent);
