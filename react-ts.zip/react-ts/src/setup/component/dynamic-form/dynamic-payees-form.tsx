import {cloneDeep} from 'lodash';
import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {ReduxSearchDynamicComponent} from '../../../common/component/ReduxSearchDynamicComponent';
import {BaseInternalState, GLOBAL_STATE, globalStateReducer, HistoryProps, SearchDispatchProps, SearchState, withReducer} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {EntityType} from '../../enum/EntityType';
import {Payee} from '../../model/Payee';
import {EntitySearchModel} from '../../search-model/EntitySearchModel';
import {PAYEES_FORM} from '../payee/Constants';
import {getDynamicFormByModelName, getPayeeList} from '../payee/payeeActions';
import {payeeSelector} from '../payee/PayeeSelector';
const DynamicLayout = React.lazy(() => import('../../../common/component/DynamicLayout'));

interface InternalState extends BaseInternalState {
  payees: Payee;
  dynamicForm: any;
}

interface InternalDispatchProps {
  setGlobalState?: (data) => void;
  getDynamicFormByModelName?: (data: any) => any;
}

type PayeesPropsType = SearchState<Payee> & InternalState & SearchDispatchProps & HistoryProps & InternalDispatchProps;

class PayeesComponent extends ReduxSearchDynamicComponent<Payee, EntitySearchModel, PayeesPropsType, SearchState<Payee>> {
  constructor(props) {
    super(props,
      applicationContext.getSearchPermissionBuilder(),
      true,
      null,
      { getDynamicFormByModelName: props.getDynamicFormByModelName }
    );
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      ctrlStatus: [],
      results: [],
      ctrlStatusList: []
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    this.masterDataService.getCtrlStatus().subscribe(
      ctrlStatusList => {
        this.setState({ ctrlStatusList }, this.loadData);
      }, this.handleError);
  }

  getSearchModel(): EntitySearchModel {
    const model = this.populateSearchModel();
    model.entityType = EntityType.Payee;
    return model;
  }

  edit = (e, id: string) => {
    e.preventDefault();
    this.props.history.push('payee/edit/' + id);
  }

  approve = (e, id: string) => {
    e.preventDefault();
    this.props.history.push('payee/approve/' + id);
  }

  render() {
    const resource = this.resource;
    const { ctrlStatusList, ctrlStatus } = this.state;
    const { dynamicForm } = this.props;
    const results = this.props.results;
    const eventButton = this.editable || this.viewable ? 'btn-edit' : 'btn-view';

    const staticData = {
      'tagName': 'div',
      'attributes': {
        'className': 'view-container'
      },
      'childComponents': [
        {
          'tagName': 'header',
          'childComponents': [
            {
              'tagName': 'h2',
              'text': 'payees_list'
            },
            {
              'tagName': 'button',
              'attributes': {
                'type': 'button',
                'className': 'btn-new'
              },
              'actions': {
                'type': 'application',
                'events': {
                  'onClick': 'add'
                }
              }
            }
          ]
        },
        {
          'tagName': 'div',
          'childComponents': [
            {
              'tagName': 'form',
              'attributes': {
                'id': 'payeesForm',
                'name': 'payeesForm',
                'ref': 'form'
              },
              'customs': {
                'noValidate': true
              },
              'childComponents': [
                {
                  'tagName': 'section',
                  'attributes': {
                    'className': 'row search-group inline'
                  },
                  'childComponents': [
                    {
                      'tagName': 'label',
                      'text': 'company_name',
                      'attributes': {
                        'className': 'col s12 m5 l6'
                      },
                      'childComponents': [
                        {
                          'tagName': 'input',
                          'attributes': {
                            'type': 'text',
                            'id': 'entityName',
                            'name': 'entityName',
                            'value': 'entityName',
                            'maxLength': 255,
                            'placeholder': 'company_name'
                          },
                          'actions': {
                            'type': 'application',
                            'events': {
                              'onChange': 'updateState'
                            }
                          }
                        }
                      ]
                    },
                    {
                      'tagName': 'label',
                      'text': 'ctrl_status',
                      'attributes': {
                        'className': 'col s12 m5 l6'
                      },
                      'childComponents': [
                        {
                          'tagName': 'section',
                          'attributes': {
                            'className': 'checkbox-group'
                          },
                          'loopData': {
                            'nameOfListData': 'ctrlStatusList',
                            'listAttributes': [
                              'value',
                              'text'
                            ]
                          },
                          'childComponents': [
                            {
                              'tagName': 'label',
                              'text': 'text',
                              'isLoopElement': true,
                              'childComponents': [
                                {
                                  'tagName': 'input',
                                  'attributes': {
                                    'type': 'checkbox',
                                    'name': 'ctrlStatus',
                                    'value': 'value',
                                    'checked': {
                                      'customFunc': 'includes',
                                      'nameOfList': 'ctrlStatus'
                                    }
                                  },
                                  'actions': {
                                    'type': 'application',
                                    'events': {
                                      'onClick': 'updateState'
                                    }
                                  }
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  'tagName': 'section',
                  'attributes': {
                    'className': 'btn-group'
                  },
                  'childComponents': [
                    {
                      'tagName': 'label',
                      'text': 'page_size',
                      'childComponents': [
                        {
                          'tagName': 'PageSizeSelect',
                          'path': 'src/control/PageSizeSelect',
                          'isCustomComponent': true,
                          'attributes': {
                            'pageSize': 'pageSize',
                            'pageSizes': 'pageSizes',
                            'onPageSizeChanged': 'pageSizeChanged'
                          }
                        }
                      ]
                    },
                    {
                      'tagName': 'button',
                      'text': 'search',
                      'attributes': {
                        'type': 'submit',
                        'className': 'btn-search'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onClick': 'searchOnClick'
                        }
                      }
                    }
                  ]
                }
              ]
            },
            {
              'tagName': 'form',
              'attributes': {
                'className': 'list-result'
              },
              'childComponents': [
                {
                  'tagName': 'div',
                  'attributes': {
                    'className': 'table-responsive'
                  },
                  'childComponents': [
                    {
                      'tagName': 'table',
                      'childComponents': [
                        {
                          'tagName': 'thead',
                          'childComponents': [
                            {
                              'tagName': 'tr',
                              'childComponents': [
                                {
                                  'tagName': 'th',
                                  'text': 'sequence'
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'entityName'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'company_name',
                                      'attributes': {
                                        'id': 'sortCompanyName'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'shortName'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'payer_list_short_name',
                                      'attributes': {
                                        'id': 'sortCompanyShortName'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'ctrlStatus'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'ctrl_status',
                                      'attributes': {
                                        'id': 'sortCtrlStatus'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'actedBy'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'acted_by',
                                      'attributes': {
                                        'id': 'sortActedBy'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'actionDate'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'action_date',
                                      'attributes': {
                                        'id': 'sortActionDate'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'attributes': {
                                    'data-field': 'actionStatus'
                                  },
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'text': 'action_status',
                                      'attributes': {
                                        'id': 'sortActionStatus'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'sort'
                                        }
                                      }
                                    }
                                  ]
                                },
                                {
                                  'tagName': 'th',
                                  'text': 'quick_action'
                                }
                              ]
                            }
                          ]
                        },
                        {
                          'tagName': 'tbody',
                          'loopData': {
                            'nameOfListData': 'payees',
                            'listAttributes': [
                              'sequenceNo',
                              'entityName',
                              'shortName',
                              'ctrlStatusName',
                              'actedBy',
                              'actionDate',
                              'actionStatus'
                            ]
                          },
                          'childComponents': [
                            {
                              'tagName': 'tr',
                              'isLoopElement': true,
                              'attributes': {
                                'key': 'i'
                              },
                              'childComponents': [
                                {
                                  'tagName': 'td',
                                  'text': 'sequenceNo'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'entityName'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'shortName'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'ctrlStatusName'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'actedBy'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'actionDate'
                                },
                                {
                                  'tagName': 'td',
                                  'text': 'actionStatus'
                                },
                                {
                                  'tagName': 'td',
                                  'childComponents': [
                                    {
                                      'tagName': 'button',
                                      'attributes': {
                                        'type': 'button'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'edit'
                                        },
                                        'params': ['entityId']
                                      },
                                      'conditions': {
                                        'show': 'eventButton'
                                      }
                                    },
                                    {
                                      'tagName': 'button',
                                      'attributes': {
                                        'type': 'button',
                                        'className': 'btn-approve'
                                      },
                                      'actions': {
                                        'type': 'application',
                                        'events': {
                                          'onClick': 'approve'
                                        }
                                      },
                                      'conditions': {
                                        'show': 'checkable'
                                      }
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  'tagName': 'Pagination',
                  'path': 'src/control/Pagination',
                  'isCustomComponent': true,
                  'attributes': {
                    'className': 'col s12 m6',
                    'totalRecords': 'itemTotal',
                    'itemsPerPage': 'pageSize',
                    'maxSize': 'pageMaxSize',
                    'currentPage': 'currentPage',
                    'onPageChanged': 'pageChanged'
                  }
                }
              ]
            }
          ]
        }
      ]
    };

    const dynamicFormClone = cloneDeep(dynamicForm.flow);

    const props = {
      modelData: results,
      listData: [
        {
          name: 'ctrlStatusList',
          data: ctrlStatusList
        },
        {
          name: 'ctrlStatus',
          data: ctrlStatus
        },
        {
          name: 'payees',
          data: results
        },
        {
          name: 'pageSize',
          data: this.pageSize
        },
        {
          name: 'pageSizes',
          data: this.pageSizes
        },
        {
          name: 'pageSizeChanged',
          data: this.pageSizeChanged
        },
        {
          name: 'pageMaxSize',
          data: this.pageMaxSize
        },
        {
          name: 'currentPage',
          data: this.currentPage
        },
        {
          name: 'pageChanged',
          data: this.pageChanged
        },
        {
          name: 'itemTotal',
          data: this.itemTotal
        }
      ],
      json: dynamicFormClone,
      resource,
      self: this,
      eventButton
    };

    return (
      <React.Fragment>
        {
          results && Object.keys(results).length > 0 ?
            <React.Suspense fallback={<div />}>
              <DynamicLayout {...props} />
            </React.Suspense>
            : <form name={PAYEES_FORM} ref='form' />
        }
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    results: payeeSelector.selectListData(state),
    dynamicForm: payeeSelector.selectDynamicForm(state)
  };
}

function mapDispatchToProps(dispatch): SearchDispatchProps {
  return {
    search: (data) => dispatch(getPayeeList(data)),
    getDynamicFormByModelName: (data) => dispatch(getDynamicFormByModelName(data))
  };
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const PayeesForm = compose(
  withStore,
  withConnect
)(PayeesComponent);
