import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {ReduxSearchDynamicComponent} from '../../../common/component/ReduxSearchDynamicComponent';
import PageSizeSelect from '../../../control/PageSizeSelect';
import Pagination from '../../../control/Pagination';
import {
  GLOBAL_STATE,
  globalStateReducer,
  HistoryProps,
  SearchDispatchProps,
  SearchState,
  withReducer
} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {EntityType} from '../../enum/EntityType';
import {Payee} from '../../model/Payee';
import {EntitySearchModel} from '../../search-model/EntitySearchModel';
import {DYNAMIC_LIST_FORM} from '../payee/Constants';
import {deleteDynamicForm, getAllDynamicForm} from '../payee/payeeActions';
import {payeeSelector} from '../payee/PayeeSelector';

type DynamicListPropsType = SearchState<Payee> & SearchDispatchProps & HistoryProps;
interface InternalPropsType extends SearchDispatchProps {
  delete?: (data) => void;
}

class DynamicListComponent extends ReduxSearchDynamicComponent<Payee, EntitySearchModel, DynamicListPropsType, SearchState<Payee>> {
  constructor(props) {
    super(props,
      applicationContext.getSearchPermissionBuilder(),
      true,
      null,
      { delete: props.delete }
    );
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: ''
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    this.masterDataService.getCtrlStatus().subscribe(
      ctrlStatusList => {
        this.setState({ ctrlStatusList }, this.loadData);
      }, this.handleError);
  }

  getSearchModel(): EntitySearchModel {
    const model = this.populateSearchModel();
    model.entityName = EntityType.DynamicForm;
    return model;
  }

  edit = (e, id: string) => {
    e.preventDefault();
    // Just using for demo
    this.props.history.push('payer/edit/' + id);
  }

  add = (e) => {
    e.preventDefault();
    // Just using for demo
    this.props.history.push('payer/add');
  }

  render() {
    const resource = this.resource;
    const results = this.props.results as any;

    return (
      <div className='view-container'>
        <header>
          <h2>Dynamic Form Summary</h2>
          {this.addable && <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add} />}
        </header>
        <div>
          <form id={DYNAMIC_LIST_FORM} name={DYNAMIC_LIST_FORM} noValidate={true} ref='form'>
            <section className='row search-group inline'>
              <label className='col s12 m5 l6'>
                Form Name
                <input type='text'
                  id='entityName'
                  name='entityName'
                  value={this.state.entityName}
                  onChange={this.updateState}
                  maxLength={255}
                  placeholder='Form Name' />
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect
                  pageSize={this.pageSize}
                  pageSizes={this.pageSizes}
                  onPageSizeChanged={this.pageSizeChanged}
                />
              </label>
              <button type='submit' className='btn-search'
                onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>No.</th>
                    <th>
                      <button type='button' id='dynamicFormName'
                        onClick={this.sort}>Form Name</button>
                    </th>
                    <th>{resource.quick_action}</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((dynamicForm, i) => {
                    return (
                      <tr key={i}>
                        <td>{i + 1}</td>
                        <td>{dynamicForm.formName}</td>
                        <td>
                          <button type='button' className='btn-edit'
                            onClick={(e) => this.edit(e, dynamicForm.formId)}
                          />
                          <button type='button' className='btn-remove'
                            onClick={(e) => this.delete(e, dynamicForm.formId)}
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize}
              maxSize={this.pageMaxSize} currentPage={this.currentPage}
              onPageChanged={this.pageChanged} />
          </form>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    results: payeeSelector.selectListDynamicForm(state)
  };
}

function mapDispatchToProps(dispatch): InternalPropsType {
  return {
    search: (data) => dispatch(getAllDynamicForm(data)),
    delete: (data) => dispatch(deleteDynamicForm(data))
  };
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const PayersForm = compose(
  withStore,
  withConnect
)(DynamicListComponent);

