import * as React from 'react';
import JSONInput from 'react-json-editor-ajrm/index';
import locale from 'react-json-editor-ajrm/locale/en';

export class JsonEditor extends React.Component<any, any> {
  onChange = (e) => {
    const { setGlobalState, json, formName } = this.props;
    const { jsObject } = e;
    if ( jsObject && setGlobalState ) {
      const changeData = {flow: jsObject};
      setGlobalState({ [formName]: {...json, ...changeData} });
    }
  }
  render() {
    const { style, colors, json = {}, theme = 'light_mitsuketa_tribute', height = '450px', width = '100%' } = this.props;
    const styleDefault = {
      contentBox: {
        'background': '#F4F4F4',
      },
      body: {
        'fontSize': '14px'
      }
    };
    const colorsDefault = {
      keys: 'black',
      string: '#DAA520',
      default: 'grey'
    };

    return (
      <React.Fragment>
        <JSONInput
          placeholder={json.flow || {}}
          theme={theme}
          locale={locale}
          colors={colors || colorsDefault}
          height={height}
          width={width}
          onKeyPressUpdate={false}
          style={style || styleDefault}
          onChange={this.onChange}
        />
      </React.Fragment>
    );
  }
}
