import {cloneDeep} from 'lodash';
import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {EditDynamicLayoutComponent} from '../../../common/component/EditDynamicLayoutComponent';
import {GLOBAL_STATE} from '../../../common/Constants';
import {BaseInternalState, globalStateReducer, HistoryProps, updateGlobalState, withReducer} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {payeeModel} from '../../metadata/PayeeModel';
import {Payee} from '../../model/Payee';
import {PAYEE_FORM} from '../payee/Constants';
import {getDynamicFormByModelName, getPayee, insertPayee, updatePayee} from '../payee/payeeActions';
import {payeeSelector} from '../payee/PayeeSelector';
const DynamicLayout = React.lazy(() => import('../../../common/component/DynamicLayout'));

interface DispatchProps {
  setGlobalState?: (data) => void;
  getPayeeInfo?: (data: any) => any;
  updatePayeeInfo?: (data: any) => any;
  insertPayeeInfo?: (data: any) => any;
  getDynamicFormByModelName?: (data: any) => any;
}

interface InternalState extends BaseInternalState {
  payee: Payee;
  dynamicForm: any;
}

type PayeePropsType = DispatchProps & InternalState;
type PayeeHistorypropsType = HistoryProps & InternalState;

class PayeeComponent extends EditDynamicLayoutComponent<Payee, PayeeHistorypropsType, PayeePropsType> {
  constructor(props) {
    const service = {
      getById: props.getPayeeInfo,
      update: props.updatePayeeInfo,
      insert: props.insertPayeeInfo,
      getDynamicFormByModelName: props.getDynamicFormByModelName
    };
    super(props, payeeModel, service, applicationContext.getEditPermissionBuilder());
    this.state = {
      date: new Date()
    };
  }

  createModel(): Payee {
    const payee = super.createModel();
    payee.entityType = 'E';
    return payee;
  }

  getModel(): Payee {
    const payee = this.getModelFromState();
    const data = typeof (payee.maxAtmPtrn) === 'string' ? payee.maxAtmPtrn.split(',').join('') : payee.maxAtmPtrn;
    payee.maxAtmPtrn = parseFloat(data);
    payee.webConfirmation = 0;
    return payee;
  }

  render() {
    const resource = this.resource;
    const { payee, dynamicForm } = this.props;
    const titleForm = this.isNewMode() ? resource.create : resource.edit + ' ' + resource.payee;

    const staticData = {
      'tagName': 'div',
      'attributes': {
        'className': 'view-container'
      },
      'childComponents': [
        {
          'tagName': 'form',
          'attributes': {
            'id': 'payeeForm',
            'name': 'payeeForm',
            'ref': 'form'
          },
          'customs': {
            'model-name': 'payee'
          },
          'childComponents': [
            {
              'tagName': 'header',
              'childComponents': [
                {
                  'tagName': 'button',
                  'attributes': {
                    'type': 'button',
                    'className': 'btn-back'
                  },
                  'actions': {
                    'type': 'application',
                    'events': {
                      'onClick': 'back'
                    }
                  }
                },
                {
                  'tagName': 'h2',
                  'text': 'titleForm'
                }
              ]
            },
            {
              'tagName': 'div',
              'attributes': {
                'className': 'row'
              },
              'childComponents': [
                {
                  'tagName': 'label',
                  'text': 'company_name',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'entityName',
                        'name': 'entityName',
                        'value': 'entityName',
                        'maxLength': 255,
                        'required': true,
                        'placeholder': 'company_name'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'short_name',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'shortName',
                        'name': 'shortName',
                        'value': 'shortName',
                        'maxLength': 12,
                        'required': true,
                        'placeholder': 'company_name'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'company_id',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'companyID',
                        'name': 'companyID',
                        'value': 'companyId',
                        'maxLength': 50,
                        'placeholder': 'company_id'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'payment_amount_max',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'maxAtmPtrn',
                        'name': 'maxAtmPtrn',
                        'value': {
                          'value': 'maxAtmPtrn',
                          'formatedBy': 'formatCurrencyOnLoad'
                        },
                        'maxLength': 30,
                        'placeholder': 'payment_amount_max'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState',
                          'onBlur': 'updateState',
                          'onFocus': 'currencyOnFocus'
                        }
                      },
                      'customs': {
                        'data-type': 'currency',
                        'disable-style-on-focus': 'disabled'
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'address',
                  'attributes': {
                    'className': 'col s12'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'add1',
                        'name': 'add1',
                        'value': 'add1',
                        'maxLength': 255,
                        'required': true,
                        'placeholder': 'company_id'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'attributes': {
                    'className': 'col s12'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'add2',
                        'name': 'add2',
                        'value': 'add2',
                        'maxLength': 255,
                        'placeholder': 'placeholder_address2'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    },
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'add3',
                        'name': 'add3',
                        'value': 'add3',
                        'maxLength': 255,
                        'placeholder': 'placeholder_address3'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'postcode',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'postalCode',
                        'name': 'postalCode',
                        'value': 'postalCode',
                        'maxLength': 255,
                        'placeholder': 'postalCode'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'state',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'stateName',
                        'name': 'stateName',
                        'value': 'stateName',
                        'maxLength': 255,
                        'placeholder': 'state'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'country',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'value': {
                          'value': 'THAILAND',
                          'isStaticText': true
                        },
                        'required': true,
                        'disabled': true
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'contact_name',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'contactName',
                        'name': 'contactName',
                        'value': 'contactName',
                        'maxLength': 255,
                        'required': true,
                        'placeholder': 'contact_name'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'contact_phone',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'contactNo',
                        'name': 'contactNo',
                        'value': {
                          'value': 'contactNo',
                          'formatedBy': 'formatPhoneOnLoad'
                        },
                        'maxLength': 17,
                        'placeholder': 'contact_phone'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState',
                          'onBlur': 'checkPhoneOnBlur'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'contact_fax',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'faxNo',
                        'name': 'faxNo',
                        'value': {
                          'value': 'faxNo',
                          'formatedBy': 'formatFaxOnLoad'
                        },
                        'maxLength': 10,
                        'placeholder': 'contact_fax'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updatePhoneState'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'mobile_phone_number',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'mobilePhone',
                        'name': 'mobilePhone',
                        'value': {
                          'value': 'mobilePhone',
                          'formatedBy': 'formatPhoneOnLoad'
                        },
                        'maxLength': 17,
                        'placeholder': 'contact_name'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updatePhoneState',
                          'onBlur': 'checkPhoneOnBlur'
                        }
                      }
                    }
                  ]
                },
                {
                  'tagName': 'label',
                  'text': 'email',
                  'attributes': {
                    'className': 'col s12 m6'
                  },
                  'childComponents': [
                    {
                      'tagName': 'input',
                      'attributes': {
                        'type': 'text',
                        'id': 'emailAdd',
                        'name': 'emailAdd',
                        'value': 'emailAdd',
                        'maxLength': 255,
                        'required': true,
                        'placeholder': 'email'
                      },
                      'actions': {
                        'type': 'application',
                        'events': {
                          'onChange': 'updateState'
                        }
                      },
                      'customs': {
                        'data-type': 'email'
                      }
                    }
                  ]
                },
                {
                  'tagName': 'div',
                  'text': 'entity_type',
                  'attributes': {
                    'className': 'col s12 m6 checkbox-section'
                  },
                  'childComponents': [
                    {
                      'tagName': 'label',
                      'text': 'payee_set_as_payer',
                      'attributes': {
                        'className': 'checkbox-container'
                      },
                      'childComponents': [
                        {
                          'tagName': 'input',
                          'attributes': {
                            'type': 'checkbox',
                            'id': 'entityType',
                            'name': 'entityType',
                            'value': 'entityType',
                            'checked': {
                              'compareValue': 'R',
                              'compareSyntax': '='
                            }
                          },
                          'actions': {
                            'type': 'application',
                            'events': {
                              'onChange': 'updateState'
                            }
                          },
                          'customs': {
                            'data-on-value': 'R',
                            'data-off-value': 'E'
                          }
                        }
                      ]
                    }
                  ]
                },
                {
                  'tagName': 'div',
                  'text': 'business_type',
                  'attributes': {
                    'className': 'col s12 m6 radio-section'
                  },
                  'childComponents': [
                    {
                      'tagName': 'div',
                      'attributes': {
                        'className': 'radio-group'
                      },
                      'childComponents': [
                        {
                          'tagName': 'label',
                          'text': 'business_type_b2b',
                          'childComponents': [
                            {
                              'tagName': 'input',
                              'attributes': {
                                'type': 'radio',
                                'id': 'businessType',
                                'name': 'businessType',
                                'checked': {
                                  'compareValue': 'B2B',
                                  'compareSyntax': '='
                                },
                                'value': {
                                  'value': 'B2B',
                                  'isStaticText': true
                                }
                              },
                              'actions': {
                                'type': 'application',
                                'events': {
                                  'onChange': 'updateState'
                                }
                              }
                            }
                          ]
                        },
                        {
                          'tagName': 'label',
                          'text': 'business_type_b2c',
                          'childComponents': [
                            {
                              'tagName': 'input',
                              'attributes': {
                                'type': 'radio',
                                'id': 'businessType',
                                'name': 'businessType',
                                'checked': {
                                  'compareValue': 'B2C',
                                  'compareSyntax': '='
                                },
                                'value': {
                                  'value': 'B2C',
                                  'isStaticText': true
                                }
                              },
                              'actions': {
                                'type': 'application',
                                'events': {
                                  'onChange': 'updateState'
                                }
                              }
                            }
                          ]
                        },
                        {
                          'tagName': 'label',
                          'text': 'business_type_both',
                          'childComponents': [
                            {
                              'tagName': 'input',
                              'attributes': {
                                'type': 'radio',
                                'id': 'businessType',
                                'name': 'businessType',
                                'checked': {
                                  'compareValue': 'BOTH',
                                  'compareSyntax': '='
                                },
                                'value': {
                                  'value': 'BOTH',
                                  'isStaticText': true
                                }
                              },
                              'actions': {
                                'type': 'application',
                                'events': {
                                  'onChange': 'updateState'
                                }
                              }
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            },
            {
              'tagName': 'footer',
              'childComponents': [
                {
                  'tagName': 'button',
                  'text': 'save',
                  'attributes': {
                    'type': 'submit',
                    'id': 'btnSave',
                    'name': 'btnSave'
                  },
                  'actions': {
                    'type': 'application',
                    'events': {
                      'onClick': 'saveOnClick'
                    }
                  },
                  'conditions': {
                    'show': 'editable'
                  }
                }
              ]
            }
          ]
        }
      ]
    };
    const dynamicFormClone = cloneDeep(dynamicForm.flow);

    const props = {
      modelData: payee,
      json: dynamicFormClone,
      resource,
      self: this,
      titleForm
    };

    return (
      <React.Fragment>
        {
          payee && Object.keys(payee).length > 0 ?
          <React.Suspense fallback={<div />}>
            <DynamicLayout {...props} />
          </React.Suspense>
          : <form name={PAYEE_FORM} ref='form' />
        }
      </React.Fragment>
    );
  }
}

function mapStateToProps(state) {
  return {
    payee: payeeSelector.selectFormData(state),
    dynamicForm: payeeSelector.selectDynamicForm(state)
  };
}

function mapDispatchToProps(dispatch): DispatchProps {
  return {
    setGlobalState: (data) => dispatch(updateGlobalState(data)),
    getPayeeInfo: (data) => dispatch(getPayee(data)),
    updatePayeeInfo: (data) => dispatch(updatePayee(data)),
    insertPayeeInfo: (data) => dispatch(insertPayee(data)),
    getDynamicFormByModelName: (data) => dispatch(getDynamicFormByModelName(data))
  };
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const PayeeForm = compose(
  withStore,
  withConnect
)(PayeeComponent);
