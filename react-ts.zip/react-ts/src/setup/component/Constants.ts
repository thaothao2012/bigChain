export const TRANSACTION_FEE_SET_UP_FORM              = 'transactionFeeSetupForm';
export const BANK_ADMIN_FORM                          = 'bankAdminForm';
export const CHANGE_PASSWORD_FORM                     = 'changePasswordForm';

export enum Form {
  CHANGE_PASSWORD_FORM = 'changePasswordForm',
  BANK_ADMIN_FORM = 'bankAdminForm',
  TRANSACTION_FEE_SET_UP_FORM = 'transactionFeeSetupForm',
}
