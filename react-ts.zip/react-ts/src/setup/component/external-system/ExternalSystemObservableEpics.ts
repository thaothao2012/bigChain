import {GenericSearchDiffApprObservableEpics} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {ExternalSys} from '../../model/ExternalSys';
import {ExternalSysSM} from '../../search-model/ExternalSysSM';
import {ExternalSystemActionType} from './ExternalSystemActionType';

const actionType = {
  searchType: ExternalSystemActionType.GET_EXTERNALSYSTEM_LIST,
  getByIdType: ExternalSystemActionType.GET_EXTERNALSYSTEM,
  updateType: ExternalSystemActionType.UPDATE_EXTERNALSYSTEM,
  insertType: ExternalSystemActionType.INSERT_EXTERNALSYSTEM,
  checkDiff: ExternalSystemActionType.CHECK_EXTERNALSYSTEM,
  approveType: ExternalSystemActionType.APPROVE_EXTERNALSYSTEM,
  rejectType: ExternalSystemActionType.REJECT_EXTERNALSYSTEM,
};

const externalSysObservableEpics = new GenericSearchDiffApprObservableEpics<ExternalSys, ExternalSysSM>(actionType, applicationContext.getExternalSysService());

export const externalSysEpics = {
  search: externalSysObservableEpics.search,
  update: externalSysObservableEpics.update,
  insert: externalSysObservableEpics.insert,
  getById: externalSysObservableEpics.getById,
  checkDiff: externalSysObservableEpics.checkDiff,
  approve: externalSysObservableEpics.approve,
  reject: externalSysObservableEpics.reject,
};
