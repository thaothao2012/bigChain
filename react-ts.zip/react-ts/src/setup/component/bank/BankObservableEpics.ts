import {GenericSearchDiffApprObservableEpics} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {Bank} from '../../model/Bank';
import {BankSM} from '../../search-model/BankSM';
import {BankActionType} from './BankActionType';

const actionType = {
  searchType: BankActionType.GET_BANK_LIST,
  getByIdType: BankActionType.GET_BANK,
  updateType: BankActionType.UPDATE_BANK,
  insertType: BankActionType.INSERT_BANK,
  checkDiff: BankActionType.CHECK_BANK,
  approveType: BankActionType.APPROVE_BANK,
  rejectType: BankActionType.REJECT_BANK,
};

const bankObservableEpics = new GenericSearchDiffApprObservableEpics<Bank, BankSM>(actionType, applicationContext.getBankService());

export const bankEpics = {
  search: bankObservableEpics.search,
  update: bankObservableEpics.update,
  insert: bankObservableEpics.insert,
  getById: bankObservableEpics.getById,
  checkDiff: bankObservableEpics.checkDiff,
  approve: bankObservableEpics.approve,
  reject: bankObservableEpics.reject,
};
