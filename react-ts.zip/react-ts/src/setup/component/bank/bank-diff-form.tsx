import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import DiffPanel from 'src/common/component/DiffPanel';
import {BaseInternalState, DiffApprDispatchProps, DiffApprPropsType, DiffSelector, ReduxDiffApprComponent, StringUtil, withReducer} from '../../../core';
import {bankModel} from '../../metadata/BankModel';
import {Bank} from '../../model/Bank';
import {checkDiff, updateApprove, updateReject} from './bankActions';
import {bankEpics} from './BankObservableEpics';

export const BANK_DIFF_FORM = 'bankDiffForm';

class BankDiffComponent extends ReduxDiffApprComponent<Bank, DiffApprPropsType, BaseInternalState> {
  constructor(props) {
    super(props, bankModel);
    this.state = {
      isDisable: false,
      oldValue: {},
      newValue: {}
    };
  }

  renderFields = [
    {resourceKey: 'bank_name', name: 'bankName'},
    {resourceKey: 'bank_short_name', name: 'bankShortName'},
    {resourceKey: 'bank_branch_id', name: 'branchId'},
    {resourceKey: 'address', name: 'add1'},
    {resourceKey: 'address', name: 'add2'},
    {resourceKey: 'address', name: 'add3'},
    {resourceKey: 'postcode', name: 'postalCode'},
    {resourceKey: 'state', name: 'stateName'},
    {resourceKey: 'country', name: 'countryCode'},
    {resourceKey: 'bank_base_currency', name: 'baseCcyCode'},
    {resourceKey: 'contact_name', name: 'contactName'},
    {resourceKey: 'contact_phone', name: 'contactNo'},
    {resourceKey: 'contact_fax', name: 'faxNo'},
    {resourceKey: 'email', name: 'emailAdd'},
    {resourceKey: 'bank_host_bank', name: 'hostBankFlag'},
    {resourceKey: 'password_delivery_method', name: 'passwordDeliveryMethod'},
  ];

  formatFields(value) {
    const passwordDeliveryMethod =  value && value.passwordDeliveryMethod  && value.passwordDeliveryMethod === 'P' ? 'Pinmailer' : '' ||
                                    value.passwordDeliveryMethod === 'E' ? 'Email Without Challenge' : '' ||
                                    value.passwordDeliveryMethod === 'C' ? 'Email With Challenge' : '';
    const hostBankFlag = value && value.hostBankFlag  && value.hostBankFlag === 'Y' ? 'Enable Host Bank' : 'None Host Bank';
    const contactNo = value && value.contactNo  && StringUtil.formatPhone(value.contactNo.toString()) || '';
    const faxNo = value && value.faxNo && StringUtil.formatPhone(value.faxNo.toString()) || '';
    const countryCode = value && value.countryCode && value.countryCode === 'TH' ? 'THAILAND' : 'THAILAND' || '';
    const baseCcyCode = value && value.baseCcyCode && value.baseCcyCode === 'THB' ? 'Thai Bath' : 'Thai Bath' || '';
    const bankName = value && value.bankName || '';
    const bankShortName = value && value.bankShortName || '';
    const branchId = value && value.branchId || '';
    const stateName = value && value.stateName  || '';
    const contactName = value && value.contactName  || '';
    const emailAdd = value && value.emailAdd  || '';
    const postalCode = value && value.postalCode  || '';
    const add1 = value && value.add1  || '';
    const add2 = value && value.add2  || '';
    const add3 = value && value.add3  || '';
    return {...value, passwordDeliveryMethod, hostBankFlag, contactNo, faxNo, countryCode, baseCcyCode, bankName, bankShortName, branchId, stateName, contactName, emailAdd, postalCode, add1, add2, add3};
  }

  render() {
    const resource = this.resource;
    const { approveSuccess, rejectSuccess } = this.state;
    const { diffInfo = null } = this.props;
    return (
      <div className='view-container'>
        <form id={BANK_DIFF_FORM} name={BANK_DIFF_FORM} model-name='bank' ref='form'>
          <header>
            <button type='button' id='btnBack' name='btnBack' className='btn-back' onClick={this.back}/>
            <h2>{resource.bank}</h2>
          </header>
          <DiffPanel oldValue= {diffInfo.oldValue ? diffInfo.oldValue : {}} newValue= {diffInfo.newValue ? diffInfo.newValue : {}} resource={resource} renderFields={this.renderFields} />
          <footer>
            <button type='submit' id='btnApprove' name='buttonApprove' onClick={this.approve} disabled={approveSuccess}>
              {resource.approve}
            </button>
            <button type='button' id='btnReject' name='buttonReject' onClick={this.reject} disabled={rejectSuccess}>
              {resource.reject}
            </button>
          </footer>
        </form>
      </div>
    );
  }
}

const bankDiffSelector = new DiffSelector(BANK_DIFF_FORM);

function mapStateToProps(state) {
  return {
    diffInfo: bankDiffSelector.selectDiff(state)
  };
}

function mapDispatchToProps(dispatch): DiffApprDispatchProps {
  return {
    checkDiff: (data) => dispatch(checkDiff(data)),
    approve: (data) => dispatch(updateApprove(data)),
    reject: (data) => dispatch(updateReject(data)),
  };
}

const withStore = withReducer(bankEpics, BANK_DIFF_FORM);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const BankDiffForm = compose(
  withStore,
  withConnect
)(BankDiffComponent);
