import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import PageSizeSelect from '../../../control/PageSizeSelect';
import Pagination from '../../../control/Pagination';
import {
  GLOBAL_STATE,
  globalStateReducer,
  HistoryProps,
  ListGlobalStateSelector,
  ReduxSearchComponent,
  SearchDispatchProps,
  SearchState,
  withReducer
} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {Bank} from '../../model/Bank';
import {BankSM} from '../../search-model/BankSM';
import {getBankList} from './bankActions';

export const BANKS_FORM = 'banksForm';

type BanksPropsType = SearchState<Bank> & SearchDispatchProps & HistoryProps;

class BanksComponent extends ReduxSearchComponent<Bank, BankSM, BanksPropsType, SearchState<Bank>> {
  constructor(props) {
    super(props, applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      results: [],
      bankName: '',
      bankShortName: '',
    };
  }

  edit = (e, id: string) => {
    e.preventDefault();
    this.props.history.push('bank/edit/' + id);
  }

  approve = (e, id: string) => {
    e.preventDefault();
    this.props.history.push('bank/approve/' + id);
  }

  render() {
    const resource = this.resource;
    const results = this.props.results || this.state.results;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.bank_list}</h2>
          {this.addable && <button type='button' id='btnNew' name='btnNew' className='btn-new' onClick={this.add}/>}
        </header>
        <div>
          <form id={BANKS_FORM} name={BANKS_FORM} noValidate={true} ref='form'>
            <section className='row search-group inline'>
              <label className='col s12 m6'>
                {resource.bank_name}
                <input type='text'
                  id='bankName' name='bankName'
                  value={this.state.bankName}
                  onChange={this.updateState}
                  maxLength={240}
                  placeholder={resource.bank_name}/>
              </label>
              <label className='col s12 m6'>
                {resource.bank_short_name}
                <input type='text'
                  id='bankShortName' name='bankShortName'
                  value={this.state.bankShortName}
                  onChange={this.updateState}
                  maxLength={240}
                  placeholder={resource.bank_short_name}/>
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged}/>
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='bankName'><button type='button' id='bankName' onClick={this.sort}>{resource.bank_name}</button></th>
                    <th data-field='bankShortName'><button type='button' id='bankShortName' onClick={this.sort}>{resource.bank_short_name}</button></th>
                    <th data-field='branchId'><button type='button' id='branchId' onClick={this.sort}>{resource.bank_branch_id}</button></th>
                    <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                    <th data-field='hostBankFlag'><button type='button' id='hostBankFlag' onClick={this.sort}>{resource.bank_host_bank}</button></th>
                    <th className='action'>{resource.quick_action}</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((bank, i) => {
                    return (
                      <tr key={i}>
                        <td className='text-right'>{bank.sequenceNo}</td>
                        <td>{bank.bankName}</td>
                        <td>{bank.bankShortName}</td>
                        <td>{bank.branchId}</td>
                        <td>{bank.ctrlStatusName}</td>
                        <td>{bank.hostBankFlag}</td>
                        <td>
                          {(this.editable || this.viewable) &&
                          <button type='button' className={this.editable ? 'btn-edit' : 'btn-view'} onClick={(e) => this.edit(e, bank.bankId)}/>}
                          {this.checkable && bank.ctrlStatus === 'P' &&
                          <button type='button' className='btn-approve' onClick={(e) => this.approve(e, bank.bankId)}/>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged}/>
          </form>
        </div>
      </div>
    );
  }
}

export const banksSelector = new ListGlobalStateSelector(BANKS_FORM);

function mapStateToProps(state) {
  return {
    results: banksSelector.selectListData(state)
  };
}

function mapDispatchToProps(dispatch): SearchDispatchProps {
  return {
    search: (data) => dispatch(getBankList(data))
  };
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);
const withConnect = connect(mapStateToProps, mapDispatchToProps);

export const BanksForm = compose(
  withStore,
  withConnect
)(BanksComponent);
