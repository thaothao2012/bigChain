export const PAYEE_FORM    = 'payeeForm';
export const PAYEES_FORM   = 'payeesForm';
export const PAYEE_DIFF_FORM   = 'payeeDiffForm';
export const PAYEE_REDUCER = 'payeeReducer';
export const DYNAMIC_LIST_FORM    = 'dynamicListForm';
