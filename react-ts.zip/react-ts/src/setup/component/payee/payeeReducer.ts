import {ReflectionUtil} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {PayeeActionType} from './PayeeActionType';

function initGlobalState<T extends object>(): T {
  const t: any = {};
  return t;
}

export function payeeReducer<T extends object>(state: T = initGlobalState(), action: any) {
  const service = applicationContext.getPayeeService();
  const { payload } = action;
  const self = ReflectionUtil.valueOf(payload, 'callback.self');
  const execute = ReflectionUtil.valueOf(payload, 'callback.execute');

  switch (action.type) {
    case PayeeActionType.GET_PAYEE_LIST:
      return service.search(payload.s).subscribe(
        (sr: any) => payload.callback(payload.s, sr, payload.self),
        err => payload.self.handleError(err)
      );

    case PayeeActionType.GET_PAYEE:
      return service.getById(payload.id).subscribe(
        res => execute(res, self),
        err => self.handleError(err)
      );

    case PayeeActionType.CHECK_PAYEE:
      return service.checkDiff(payload.id).subscribe(
        res => execute(res, self),
        err => self.handleError(err)
      );

    case PayeeActionType.INSERT_PAYEE:
      return service.insert(payload.obj).subscribe(
        res => {
          return execute(res, self);
        },
        err => self.handleError(err)
      );

    case PayeeActionType.UPDATE_PAYEE:
      return service.update(payload.obj).subscribe(
        res => {
          return execute(res, self);
        },
        err => self.handleError(err)
      );

    case PayeeActionType.APPROVE_PAYEE:
      return service.approve(payload.obj).subscribe(
        res => execute(self, true),
        err => execute(self, false, err)
      );

    case PayeeActionType.REJECT_PAYEE:
      return service.reject(payload.obj).subscribe(
        res => execute(self, true),
        err => execute(self, false, err)
      );
    default:
      return state;
  }
}
