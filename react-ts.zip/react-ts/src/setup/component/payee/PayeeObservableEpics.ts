import {GenericSearchDiffApprObservableEpics} from '../../../core';
import applicationContext from '../../config/ApplicationContext';
import {Payee} from '../../model/Payee';
import {PayeeSM} from '../../search-model/PayeeSM';
import {PayeeActionType} from './PayeeActionType';

const actionType = {
  getAllDynamicFormType: PayeeActionType.GET_ALL_DYNAMIC_FORM,
  getDynamicFormByModelNameType: PayeeActionType.GET_DYNAMIC_FORM_BY_MODEL_NAME,
  getDynamicFormByIdType: PayeeActionType.GET_DYNAMIC_FORM_BY_ID,
  insertDynamicFormType: PayeeActionType.INSERT_DYNAMIC_FORM,
  updateDynamicFormType: PayeeActionType.UPDATE_DYNAMIC_FORM,
  deleteDynamicFormType: PayeeActionType.DELETE_DYNAMIC_FORM,

  searchType: PayeeActionType.GET_PAYEE_LIST,
  getByIdType: PayeeActionType.GET_PAYEE,
  updateType: PayeeActionType.UPDATE_PAYEE,
  insertType: PayeeActionType.INSERT_PAYEE,
  checkDiff: PayeeActionType.CHECK_PAYEE,
  approveType: PayeeActionType.APPROVE_PAYEE,
  rejectType: PayeeActionType.REJECT_PAYEE,
};

const payeeObservableEpics = new GenericSearchDiffApprObservableEpics<Payee, PayeeSM>(actionType, applicationContext.getPayeeService());

export const payeeEpics = {
  search: payeeObservableEpics.search,
  update: payeeObservableEpics.update,
  insert: payeeObservableEpics.insert,
  getById: payeeObservableEpics.getById,
  checkDiff: payeeObservableEpics.checkDiff,
  approve: payeeObservableEpics.approve,
  reject: payeeObservableEpics.reject,
  getAllDynamicForm: payeeObservableEpics.getAllDynamicForm,
  getDynamicFormByModelName: payeeObservableEpics.getDynamicFormByModelName,

  getDynamicFormById: payeeObservableEpics.getDynamicFormById,
  insertDynamicForm: payeeObservableEpics.insertDynamicForm,
  updateDynamicForm: payeeObservableEpics.updateDynamicForm,
  deleteDynamicForm: payeeObservableEpics.deleteDynamicForm
};
