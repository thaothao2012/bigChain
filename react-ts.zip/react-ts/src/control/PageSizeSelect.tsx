import * as React from 'react';

interface Props {
  pageSizes: number[];
  pageSize: number;
  onPageSizeChanged: any;
}

class PageSizeSelect extends React.Component<Props, any> {
  render() {
    const {pageSizes, pageSize, onPageSizeChanged} = this.props;
    const pageSizeOptions = pageSizes.map(pgSize => (
      <option key={pgSize} value={pgSize}>{pgSize}</option>)
    );
    return (
      <select value={pageSize} onChange={onPageSizeChanged}>
        {pageSizeOptions}
      </select>
    );
  }
}

export default PageSizeSelect;
