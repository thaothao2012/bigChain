import * as React from 'react';
import * as LazyLoadModule from 'react-loadable/lib/index';
import {Redirect, Route, RouteComponentProps, Switch, withRouter} from 'react-router-dom';
import {compose} from 'redux';
import AuthenticationRoutes from './authentication/AuthenticationRoutes';
import {Loading} from './common/component/Loading';
import DefaultWrapper from './container/default';
import {WelcomeForm} from './container/welcome-form';
import {GLOBAL_STATE, globalStateReducer, storage, withReducer} from './core';
import NotFoundPage from './core/containers/400/page';
import UnAuthorizedPage from './core/containers/401/page';
import InternalServerErrorPage from './core/containers/500/page';
import MyProfileRoutes from './my-profile/MyProfileRoutes';

// const NotFoundPage = LazyLoadModule({ loader: () => import(`./core/containers/400/page`), loading: Loading });
// const UnAuthorizedPage = LazyLoadModule({ loader: () => import(`./core/containers/401/page`), loading: Loading });
// const InternalServerErrorPage = LazyLoadModule({ loader: () => import(`./core/containers/500/page`), loading: Loading });
// const DefaultWrapper = LazyLoadModule({ loader: () => import(`./container/default`), loading: Loading });
// const WelcomeRoute = LazyLoadModule({ loader: () => import(`./container/welcome/WelcomeRoute`), loading: Loading });
// const AuthenticationRoutes = LazyLoadModule({ loader: () => import(`./authentication/AuthenticationRoutes`), loading: Loading });
const GroupRoutes = LazyLoadModule({ loader: () => import(`./access/GroupRoutes`), loading: Loading });
const RoleRoutes = LazyLoadModule({ loader: () => import(`./access/RoleRoutes`), loading: Loading });
const UserSetupRoutes = LazyLoadModule({ loader: () => import(`./access/UserSetupRoutes`), loading: Loading });
const BankSetupRoutes = LazyLoadModule({ loader: () => import(`./setup/BankSetupRoutes`), loading: Loading });
const SetupRoutes = LazyLoadModule({ loader: () => import(`./setup/SetupRoutes`), loading: Loading });
const TransactionFeeSetupRoutes = LazyLoadModule({ loader: () => import(`./setup/TransactionFeeSetupRoutes`), loading: Loading });
const AuditTrailRoutes = LazyLoadModule({ loader: () => import(`./report/AuditTrailRoutes`), loading: Loading });
const CustomerSupportUnitRoutes = LazyLoadModule({ loader: () => import(`./report/CustomerSupportUnitRoutes`), loading: Loading });
const ReportEngineRoutes = LazyLoadModule({ loader: () => import(`./report/FeeDetailReportRoutes`), loading: Loading });
const AccountInfoRoutes = LazyLoadModule({ loader: () => import(`./report/AccountInfoRoutes`), loading: Loading });

interface StateProps {
  anyProps?: any;
}

type AppProps = StateProps;

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    if (location.href.startsWith(storage.REDIRECT_URL)) {
      window.location.href = location.origin + '/auth/connect/oAuth2' + location.search;
    }
    return (
      <Switch>
        <Route path='/401' component={UnAuthorizedPage} />
        <Route path='/500' component={InternalServerErrorPage} />
        <Route path='/auth' component={AuthenticationRoutes} />

        {/* <Route path='/myprofile' exact={true} component={WithDefaultProps(MyProfileForm)} />
          <Route path='/mysetting' exact={true} component={WithDefaultProps(MySetting)} />
          <Route path='/mysetting/changeEmail' exact={true} component={WithDefaultProps(ChangeEmail)} />
          <Route path='/mysetting/addEmail' exact={true} component={WithDefaultProps(AddEmail)} />
          <Route path='/welcome' component={WelcomeRoute} />
          <Route path='/odd/setup' component={SetupRoutes} />
          <Route path='/odd/user-setup' component={UserSetupRoutes} />
          <Route path='/odd/bank-setup' component={BankSetupRoutes} />
          <Route path='/odd/role' component={RoleRoutes} />
          <Route path='/odd/group' component={GroupRoutes} />
          <Route path='/odd/customer-support-unit' component={CustomerSupportUnitRoutes} />
          <Route path='/odd/reporting-engine' component={ReportEngineRoutes} />
          <Route path='/odd/audit-trail' component={AuditTrailRoutes} />
          <Route path='/odd/transaction-fee-setup' component={TransactionFeeSetupRoutes} />
          <Route path='/odd/account-info' component={AccountInfoRoutes} /> */}

        <Route path='/' exact={true} render={(props) => (<Redirect to='/auth' {...props} />)} />

        <DefaultWrapper history={this.props.history} location={this.props.location}>
          <Route path='/welcome' component={WelcomeForm} />
          <Route path='/my-profile' component={MyProfileRoutes} />
          <Route path='/odd/group' component={GroupRoutes} />
          <Route path='/odd/role' component={RoleRoutes} />
          <Route path='/odd/user-setup' component={UserSetupRoutes} />
          <Route path='/odd/bank-setup' component={BankSetupRoutes} />
          <Route path='/odd/setup' component={SetupRoutes} />
          <Route path='/odd/customer-support-unit' component={CustomerSupportUnitRoutes} />
          <Route path='/odd/reporting-engine' component={ReportEngineRoutes} />
          <Route path='/odd/audit-trail' component={AuditTrailRoutes} />
          <Route path='/odd/transaction-fee-setup' component={TransactionFeeSetupRoutes} />
          <Route path='/odd/account-info' component={AccountInfoRoutes} />
        </DefaultWrapper>

        <Route path='**' component={NotFoundPage} />
        {/* <PrivateRoute path='/mytesting' component={WithDefaultLayout(AddEmail)}/> */}
      </Switch>
    );
  }
}

const withStore = withReducer(globalStateReducer, GLOBAL_STATE);

export const App = compose(
  withStore,
  withRouter
)(StatelessApp);
