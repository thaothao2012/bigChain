import {AccessGroupService} from '../../access/service/AccessGroupService';
import {AccessGroupServiceImpl} from '../../access/service/impl/AccessGroupServiceImpl';
import {LocaleModelFormatter, SearchPermissionBuilder} from '../../core';
import {ApprExternalSysService} from '../../setup/service/ApprExternalSysService';
import {ApprPayeeService} from '../../setup/service/ApprPayeeService';
import {ApprPayerService} from '../../setup/service/ApprPayerService';
import {ApprPaymentAccountService} from '../../setup/service/ApprPaymentAccountService';
import {ApprReceivingAccountService} from '../../setup/service/ApprReceivingAccountService';
import {EntProfileService} from '../../setup/service/EntProfileService';
import {ApprExternalSysServiceImpl} from '../../setup/service/impl/ApprExternalSysServiceImpl';
import {ApprPayeeServiceImpl} from '../../setup/service/impl/ApprPayeeServiceImpl';
import {ApprPayerServiceImpl} from '../../setup/service/impl/ApprPayerServiceImpl';
import {ApprPaymentAccountServiceImpl} from '../../setup/service/impl/ApprPaymentAccountServiceImpl';
import {ApprReceivingAccountServiceImpl} from '../../setup/service/impl/ApprReceivingAccountServiceImpl';
import {EntProfileServiceImpl} from '../../setup/service/impl/EntProfileServiceImpl';
import {MasterDataService, MasterDataServiceImpl} from '../../shared/master-data';
import {ODDSearchPermissionBuilder} from '../../shared/permission/ODDSearchPermissionBuilder';
import {BusinessSearchModelFormatter} from '../formatter/BusinessSearchModelFormatter';
import {BalanceInquiryService} from '../service/BalanceInquiryService';
import {FeeDetailReportService} from '../service/FeeDetailReportService';
import {BalanceInquiryServiceImpl} from '../service/impl/BalanceInquiryServiceImpl';
import {FeeDetailReportServiceImpl} from '../service/impl/FeeDetailReportServiceImpl';
import {PaymentDetailServiceImpl} from '../service/impl/PaymentDetailServiceImpl';
import {TransactionLogServiceImpl} from '../service/impl/TransactionLogServiceImpl';
import {UserActivityLogServiceImpl} from '../service/impl/UserActivityLogServiceImpl';
import {WebServiceTransLogServiceImpl} from '../service/impl/WebServiceTransLogServiceImpl';
import {PaymentDetailService} from '../service/PaymentDetailService';
import {TransactionlogService} from '../service/TransactionLogService';
import {UserActivityLogService} from '../service/UserActivityLogService';
import {WebServiceTransLogService} from '../service/WebServiceTransLogService';

class ApplicationContext {
  private readonly businessSearchModelFormatter: LocaleModelFormatter<any, any>;
  private readonly masterDataService: MasterDataService;
  private readonly accessGroupService: AccessGroupService;
  private readonly transactionLogService: TransactionlogService;
  private readonly userActivityLogService: UserActivityLogService;
  private readonly webServiceTransLogService: WebServiceTransLogService;
  private readonly apprPayeeService: ApprPayeeService;
  private readonly apprPayerService: ApprPayerService;
  private readonly apprExternalSysService: ApprExternalSysService;
  private readonly paymentDetailService: PaymentDetailService;
  private readonly feeDetailReportService: FeeDetailReportService;
  private readonly balanceInquiryService: BalanceInquiryService;
  private readonly searchPermissionBuilder: SearchPermissionBuilder;
  private readonly apprReceivingAccountService: ApprReceivingAccountService;
  private readonly apprPaymentAccountService: ApprPaymentAccountService;
  private readonly entProfileService: EntProfileService;

  constructor() {
    this.businessSearchModelFormatter = new BusinessSearchModelFormatter();
    this.masterDataService = new MasterDataServiceImpl();
    this.searchPermissionBuilder = new ODDSearchPermissionBuilder();
    this.accessGroupService = new AccessGroupServiceImpl();
    this.transactionLogService = new TransactionLogServiceImpl();
    this.userActivityLogService = new UserActivityLogServiceImpl();
    this.webServiceTransLogService = new WebServiceTransLogServiceImpl();
    this.apprPayeeService = new ApprPayeeServiceImpl();
    this.apprPayerService = new ApprPayerServiceImpl();
    this.apprExternalSysService = new ApprExternalSysServiceImpl();
    this.paymentDetailService = new PaymentDetailServiceImpl();
    this.feeDetailReportService = new FeeDetailReportServiceImpl();
    this.balanceInquiryService = new BalanceInquiryServiceImpl();
    this.apprReceivingAccountService = new ApprReceivingAccountServiceImpl();
    this.apprPaymentAccountService = new ApprPaymentAccountServiceImpl();
    this.entProfileService = new EntProfileServiceImpl();
  }

  getBusinessSearchModelFormatter(): LocaleModelFormatter<any, any> {
    return this.businessSearchModelFormatter;
  }

  getSearchPermissionBuilder(): SearchPermissionBuilder {
    return this.searchPermissionBuilder;
  }

  getMasterDataService(): MasterDataService {
    return this.masterDataService;
  }

  getAccessGroupService(): AccessGroupService {
    return this.accessGroupService;
  }

  getTransactionLogService(): TransactionlogService {
    return this.transactionLogService;
  }

  getUserActivityLogService(): UserActivityLogService {
    return this.userActivityLogService;
  }

  getWebServiceTransLogService(): WebServiceTransLogService {
    return this.webServiceTransLogService;
  }

  getApprPayeeService(): ApprPayeeService {
    return this.apprPayeeService;
  }

  getApprPayerService(): ApprPayerService {
    return this.apprPayerService;
  }

  getApprExternalSysService(): ApprExternalSysService {
    return this.apprExternalSysService;
  }

  getPaymentDetailService(): PaymentDetailService {
    return this.paymentDetailService;
  }

  getFeeDetailReportService(): FeeDetailReportService {
    return this.feeDetailReportService;
  }

  getBalanceInquiryService(): BalanceInquiryService {
    return this.balanceInquiryService;
  }

  getApprReceivingAccountService(): ApprReceivingAccountService {
    return this.apprReceivingAccountService;
  }

  getApprPaymentAccountService(): ApprPaymentAccountService {
    return this.apprPaymentAccountService;
  }

  getEntProfileService(): EntProfileService {
    return this.entProfileService;
  }

}

const applicationContext = new ApplicationContext();

export default applicationContext;
