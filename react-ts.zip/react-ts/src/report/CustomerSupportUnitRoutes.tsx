import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {PaymentDetailHistoryForm} from './component/payment-detail-history-form';
import {PaymentDetailSearchForm} from './component/payment-detail-search-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/payment-detail-search'} exact={true} component={WithDefaultLayout(PaymentDetailSearchForm)} />
        <Route path={this.props.match.url + '/payment-detail-search/history'} exact={true} component={WithDefaultLayout(PaymentDetailHistoryForm)} /> */}

        <Route path={this.props.match.url + '/payment-detail-search'} exact={true} component={WithDefaultProps(PaymentDetailSearchForm)} />
        <Route path={this.props.match.url + '/payment-detail-search/history'} exact={true} component={WithDefaultProps(PaymentDetailHistoryForm)} />
      </React.Fragment>
    );
  }
}

const CustomerSupportUnitRoutes = compose(
  withRouter,
)(StatelessApp);
export default CustomerSupportUnitRoutes;
