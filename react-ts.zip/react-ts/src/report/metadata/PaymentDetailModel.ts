import {Model} from '../../core';

export const paymentDetailModel: Model = {
  name: 'paymentDetail',
  attributes: {
  }
};
