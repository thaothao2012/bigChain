import {DataType, Model} from '../../core';

export const balanceInquiryModel: Model = {
  name: 'balanceInquiry',
  attributes: {
    entityId: {
      type: DataType.String,
      primaryKey: true
    },
    accountNo: {
      type: DataType.String,
      primaryKey: true
    }
  }
};
