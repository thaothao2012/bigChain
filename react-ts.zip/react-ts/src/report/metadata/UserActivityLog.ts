import {DataType, Model} from '../../core';

export const userActivityLog: Model = {
  name: 'userActivityLog',
  attributes: {
    idActivityUser: {
      type: DataType.String,
      primaryKey: true
    },
    consumer: {
      type: DataType.String ,
      length: 60
    },
    entityName: {
      type: DataType.String,
      length: 60
    },
    entityType: {
      type: DataType.String ,
      length: 60
    },
    actedBy: {
      type: DataType.String ,
      length: 60
    },
    actionDate: {
      type: DataType.DateTime
    },
    actionStatus: {
      type: DataType.String,
      length: 50
    },
    userId: {
      type: DataType.String,
      length: 50
    }
  }
};
