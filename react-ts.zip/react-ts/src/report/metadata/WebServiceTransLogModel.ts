import {DataType, Model} from '../../core';

export const webServiceTransLogModel: Model = {
  name: 'webServiceTransLog',
  attributes: {
    exSysRefNo: {
      type: DataType.String,
      primaryKey: true
    },
    exSysName: {
      type: DataType.String ,
      length: 60
    },
    transNo: {
      type: DataType.String,
      primaryKey: true
    },
    webServicesType: {
      type: DataType.String ,
      length: 60
    },
    receiveDate: {
      type: DataType.DateTime
    },
    detail: {
      type: DataType.String,
      length: 500
    },
    statusCode: {
      type: DataType.String,
      length: 10
    }
  }
};
