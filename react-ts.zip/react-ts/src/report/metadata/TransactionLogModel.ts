import {DataType, Model} from '../../core';

export const transactionLogModel: Model = {
  name: 'transactionLog',
  attributes: {
    id: {
      type: DataType.String,
      primaryKey: true
    },
    consumer: {
      type: DataType.String
    },
    externalSystem: {
      type: DataType.String ,
      primaryKey: true
    },
    payeeId: {
      type: DataType.String ,
      primaryKey: true
    },
    payerId: {
      type: DataType.String,
      primaryKey: true
    },
    paymentDate: {
      type: DataType.DateTime
    },
    paymentAmount: {
      type: DataType.String
    },
    externalSystemNumber: {
      type: DataType.String,
      length: 500
    },
    lastStatus: {
      type: DataType.String,
      length: 10
    },
    userId: {
      type: DataType.String,
      length: 10
    }
  }
};
