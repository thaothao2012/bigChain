import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {FeeDetailReportForm} from './component/fee-detail-report-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/fee-detail-report'} exact={true} component={WithDefaultLayout(FeeDetailReportForm)}/> */}

        <Route path={this.props.match.url + '/fee-detail-report'} exact={true} component={WithDefaultProps(FeeDetailReportForm)}/>
      </React.Fragment>
    );
  }
}

const ReportEngineRoutes = compose(
  withRouter,
)(StatelessApp);
export default ReportEngineRoutes;
