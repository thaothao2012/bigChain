export enum FeePostingType {
  Immediately = 'I',
  Daily = 'D',
  Monthly = 'M'
}
