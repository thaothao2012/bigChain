export enum FeeChargeType {
  Payee = 'E',
  Payer = 'R',
  Waived = 'W'
}
