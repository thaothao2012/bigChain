export class BalanceInquiry {
  entityId: string;
  accountNo: string;
  accountBalance: number;
  accountType: string;
}
