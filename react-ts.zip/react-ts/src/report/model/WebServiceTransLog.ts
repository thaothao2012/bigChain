export class WebServiceTransLog {
  exSysRefNo: string;
  transNo: string;
  exSysName: string;
  webServicesType: string;
  receiveDate: Date;
  detail: string;
  statusCode: string;
}
