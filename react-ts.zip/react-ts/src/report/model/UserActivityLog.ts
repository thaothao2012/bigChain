export class UserActivityLog {
  idActivityUser: string;
  consumer: string;
  entityName: string;
  actedBy: string;
  entityType: string;
  actionDate: Date;
  actionStatus: string;
  userId: string;
  description: string;
  ipAddr: string;
}

