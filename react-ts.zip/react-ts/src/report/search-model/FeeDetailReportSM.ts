import {SearchModel} from '../../core';

export interface FeeDetailReportSM extends SearchModel {
  payersList: string[];
  transactionDate: Date;
  feeDueDate: Date;
  feeStatus: string;
  feeDebitBankAccount: string;
}
