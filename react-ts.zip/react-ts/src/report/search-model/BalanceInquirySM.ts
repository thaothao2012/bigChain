import {SearchModel} from '../../common/model/SearchModel';

export interface BalanceInquirySM extends SearchModel {
  entityId: string;
  accountNo: string;
}
