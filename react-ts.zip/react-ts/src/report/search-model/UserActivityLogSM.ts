import {DateRange, SearchModel} from '../../core';

export interface UserActivityLogSM extends SearchModel {
  idActivityUser: string;
  consumer: string;
  entityName: string;
  entityType: string;
  userId: string;
  actionDate: DateRange;
}
