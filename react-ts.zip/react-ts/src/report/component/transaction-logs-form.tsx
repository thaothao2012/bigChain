import * as React from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import 'react-day-picker/lib/style.css';
import {zip} from 'rxjs';
import '../../assets/css/datepicker.css';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {TransactionLog} from '../model/TransactionLog';
import {TransactionLogSM} from '../search-model/TransactionLogSM';

enum RadioValue {
  C = 'C',
  PE = 'PE',
  PR = 'PR',
}


enum Operator {
  BETWEEN = 'B',
  EQUAL = 'E',
  GREATER_THAN = 'GT',
  GREATER_THAN_OR_EQUAL = 'BTOR',
  LESS_THAN = 'LT',
  LESS_THAN_OR_EQUAL = 'LTOE',
  UNKNOW = ''
}

export class TransactionLogsForm extends SearchComponent<TransactionLog, TransactionLogSM, HistoryProps, SearchState<TransactionLog>> {
  constructor(props) {
    super(props, applicationContext.getTransactionLogService(), applicationContext.getSearchPermissionBuilder());
    this.state = {
      keyword: '',
      exShortName: '',
      payerShortName: '',
      payeeShortName: '',
      operatorAmount: '',
      valueTextOptions: [],
      entityType: RadioValue.C,
      results: [],
      operatorsAmount: [],
      actionDate: {
        startDate: new Date(),
        endDate: new Date()
      }
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    zip(
      this.masterDataService.getPaymentAmount(),
    ).subscribe(([operatorsAmount]) => {
      this.setState({operatorsAmount}, this.loadData);
    }, this.handleError);
  }

  edit = (e, id: string) => {
    e.preventDefault();
    this.props.history.push('transaction-log/' + id + '?action=edit');
  }

  render() {
    const resource = this.resource;
    const {operatorsAmount} = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.audit_trail_transaction_search}</h2>
        </header>
        <div>
          <form id='TransactionLogsForm' name='TransactionLogsForm' noValidate={true} ref='form'>
            <section className='row'>
                <label className='col s12 m6 l4'>
                  {resource.externalsys_short_name}
                  <input
                    type='text'
                    id='exShortName'
                    name='exShortName'
                    value={this.state.exShortName}
                    onChange={this.updateState}
                    maxLength={50}
                    placeholder={resource.externalsys_short_name}
                  />
                </label>
                <label className='col s12 m6 l4'>
                  {resource.payer_short_name}
                  <input
                    type='text'
                    id='payerShortName'
                    name='payerShortName'
                    value={this.state.payerShortName}
                    onChange={this.updateState}
                    maxLength={50}
                    placeholder={resource.payer_short_name}
                  />
                </label>
                <label className='col s12 m6 l4'>
                  {resource.payee_short_name}
                  <input
                    type='text'
                    id='payeeShortName' name='payeeShortName'
                    value={this.state.payeeShortName}
                    onChange={this.updateState}
                    maxLength={50}
                    placeholder={resource.payee_short_name}
                  />
                </label>
                <label className='col s6 m3 l2' data-field='actionDate.startDate'>
                  {resource.transaction_payment_date_from}
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    parseDate={this.parseDate}
                    value={this.state.actionDate.startDate}
                    onDayChange={this.updateDayPicker}
                  />
                </label>
                <label className='col s6 m3 l2' data-field='actionDate.endDate'>
                  {resource.transaction_payment_date_to}
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    parseDate={this.parseDate}
                    value={this.state.actionDate.endDate}
                    onDayChange={this.updateDayPicker}
                  />
                </label>
                <label className='col s12 m6 l4'>
                  {resource.transaction_payment_amount}
                  <select
                    id='operatorAmount'
                    name='operatorAmount'
                    onChange={this.updateState}
                  >
                    <option value=''>{resource.please_select}</option>
                    {operatorsAmount.map((item, index) => (
                      <option key={index} value={item.value}>{item.text}</option>)
                    )}
                  </select>
                </label>
                <label className='col s6 m3 l2' hidden={this.state.operatorAmount === Operator.UNKNOW}>
                  {resource.transaction_amount_first}
                  <input
                    type='number'
                    id='firstAmount' name='firstAmount'
                    onChange={this.updateState}
                    value={this.state.firstAmount}
                    placeholder={resource.transaction_amount_first}
                  />
                </label>
                <label className='col s6 m3 l2' hidden={this.state.operatorAmount === Operator.UNKNOW || this.state.operatorAmount !== Operator.BETWEEN}>
                  {resource.transaction_amount_second}
                  <input
                    type='number'
                    id='secondAmount'
                    name='secondAmount'
                    onChange={this.updateState}
                    value={this.state.secondAmount}
                    placeholder={resource.transaction_amount_second}
                  />
                </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged}/>
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                <tr>
                  <th>{resource.sequence}</th>
                  <th data-field='exShortName'><button type='button' id='exShortName' onClick={this.sort}>{resource.externalsys_short_name}</button></th>
                  <th data-field='payerShortName'><button type='button' id='payerShortName' onClick={this.sort}>{resource.payer_short_name}</button></th>
                  <th data-field='payeeShortName'><button type='button' id='payeeShortName' onClick={this.sort}>{resource.payee_short_name}</button></th>
                  <th data-field='amount'><button type='button' id='amount' onClick={this.sort}>{resource.transaction_log_amount}</button></th>
                  <th data-field='currency'><button type='button' id='currency' onClick={this.sort}>{resource.transaction_log_currency}</button></th>
                  <th data-field='actionDate'><button type='button' id='actionDate' onClick={this.sort}>{resource.action_date}</button></th>
                  <th data-field='actionStatus'><button type='button' id='actionStatus' onClick={this.sort}>{resource.action_status}</button></th>
                  <th data-field='description'><button type='button' id='description' onClick={this.sort}>{resource.transaction_log_description}</button></th>
                </tr>
                </thead>
                <tbody>
                {this.state && this.state.results && this.state.results.map((transactionLog, i) => {
                  return (
                    <tr key={i}>
                      <td className='text-right'>{transactionLog.sequenceNo}</td>
                      <td>{transactionLog.exShortName}</td>
                      <td>{transactionLog.payerShortName}</td>
                      <td>{transactionLog.payeeShortName}</td>
                      <td>{transactionLog.amount}</td>
                      <td>{transactionLog.currency}</td>
                      <td>{transactionLog.actionDate}</td>
                      <td>{transactionLog.actionStatus}</td>
                      <td>{transactionLog.description}</td>
                    </tr>
                  );
                })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize}
                        maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged}/>
          </form>
        </div>
      </div>
    );
  }
}
