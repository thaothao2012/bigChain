import * as React from 'react';
import {BaseComponent, BaseInternalState, HistoryProps} from '../../core';

interface Props extends HistoryProps {
  data: any;
  resource: any;
  close: any;
}

export class FeeDetailHistoryForm extends BaseComponent<Props, BaseInternalState> {
  constructor(props) {
    super(props);
    this.state = {
      feeDetailReport: this.props.data,
    };
  }

  close = () => {
    this.props.close();
  }

  render() {
    const resource = this.resource;
    const {feeDetailReport} = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.fee_detail_report_tile}</h2>
          <button type='button' id='btnClose' name='btnClose' className='btn-close' onClick={this.close}/>
        </header>
        <div>
          <article>
            <p><label>{resource.payer_name}:</label> {feeDetailReport.payerName}</p>
            <p><label>{resource.fee_detail_report_list_transaction_date}:</label> {feeDetailReport.paymentDate}</p>
            <p><label>{resource.fee_detail_report_list_transaction_no}:</label> {feeDetailReport.paymentId}</p>
            <p><label>{resource.fee_detail_report_list_transaction_status}:</label> {feeDetailReport.paymentStatus}</p>
            <p><label>{resource.fee_detail_report_list_fee_amount}:</label> {feeDetailReport.feeAmount}</p>
            <p><label>{resource.fee_detail_report_list_fee_transaction_no}:</label> {feeDetailReport.feeTransactionNo}</p>
            <p><label>{resource.fee_detail_report_fee_effective_day}:</label> {feeDetailReport.feeDueDate}</p>
            <p><label>{resource.fee_detail_report_list_fee_positing_type}:</label> {feeDetailReport.postingType}</p>
            <p><label>{resource.fee_detail_report_list_debit_account}:</label> {feeDetailReport.feeDebitBankAccount}</p>
          </article>
        </div>
      </div>
    );
  }
}
