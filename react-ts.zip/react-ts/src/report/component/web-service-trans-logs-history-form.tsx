import * as React from 'react';
import {BaseComponent, BaseInternalState, HistoryProps} from '../../core';

interface Props extends HistoryProps {
  data: any;
  resource: any;
  close: any;
}

export class WebServiceTransLogsHistoryForm extends BaseComponent<Props, BaseInternalState> {
  constructor(props) {
    super(props);
    this.state = {
      log: this.props.data,
    };
  }

  close = () => {
    this.props.close();
  }

  render() {
    const resource = this.resource;
    const { log } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.web_services_trans_search}</h2>
          <button type='button' id='btnClose' name='btnClose' className='btn-close' onClick={this.close} />
        </header>
        <div>
          <article>
            <p><label>{resource.corr_id}:</label> {log.exSysRefNo}</p>
            <p><label>{resource.transNo}:</label> {log.transNo}</p>
            <p><label>{resource.externalsys_name}:</label> {log.exSysName}</p>
            <p><label>{resource.web_services_type}:</label> {log.webServicesType}</p>
            <p><label>{resource.detail}:</label> {log.detail}</p>
            <p><label>{resource.action_date}:</label> {log.statusCode}</p>
            <p><label>{resource.created_date}:</label> {log.receiveDate}</p>
          </article>
        </div>
      </div>
    );
  }
}
