import * as React from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import 'react-day-picker/lib/style.css';
import Modal from 'react-modal';
import '../../assets/css/datepicker.css';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, SearchComponent, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {WebServiceTransLog} from '../model/WebServiceTransLog';
import {WebServiceTransLogSM} from '../search-model/WebServiceTransLogSM';
import {WebServiceTransLogsHistoryForm} from './web-service-trans-logs-history-form';

const DEFAULT_DATE = 'Mon Jan 01 0001';
export class WebServiceTransLogsForm extends SearchComponent<WebServiceTransLog, WebServiceTransLogSM, HistoryProps, SearchState<WebServiceTransLog>> {
  constructor(props) {
    super(props, applicationContext.getWebServiceTransLogService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      keyword: '',
      transactionNo: '',
      exSystemRefNo: '',
      webServiceTypes: [],
      webServiceTransLog: {},
      results: [],
      webServicesType: '',
      receiveDate: {
        startDate: new Date(),
        endDate: new Date()
      },
      showData: WebServiceTransLog
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    this.masterDataService.getWebServiceTypes().subscribe((webServiceTypes) => {
      this.setState(prevState => ({
        ...prevState,
        webServiceTypes,
      }), this.loadData);
    }, this.handleError);
  }

  checkDate(value) {
    const defaultDate = new Date(DEFAULT_DATE);
    const webServiceTransLogDate = new Date(value);
    if (webServiceTransLogDate.getDate() !== defaultDate.getDate() && webServiceTransLogDate.getMonth() !== defaultDate.getMonth() && webServiceTransLogDate.getFullYear() !== defaultDate.getFullYear()) {
      return true;
    }
    return false;
  }

  showPopup = (e, showData) => {
    e.preventDefault();
    this.setState({ modalIsOpen: true, showData });
  }

  closeModal = () => {
    this.setState({ modalIsOpen: false });
  }

  render() {
    const resource = this.resource;
    const { exSystemRefNo, transactionNo } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.web_services_trans_search}</h2>
        </header>
        <div>
          <form id='webServicesTransLogForm' name='webServicesTransLogForm' noValidate={true} ref='form'>
            <section className='row search-group'>
              <label className='col s6 m6 l3'>
                {resource.corr_id}
                <input
                  type='text'
                  id='exSystemRefNo'
                  name='exSystemRefNo'
                  value={exSystemRefNo}
                  onChange={this.updateState}
                  maxLength={12}
                  placeholder={resource.corr_id} />
              </label>
              <label className='col s6 m6 l3'>
                {resource.transNo}
                <input
                  type='text'
                  id='transactionNo'
                  name='transactionNo'
                  value={transactionNo}
                  onChange={this.updateState}
                  maxLength={12}
                  placeholder={resource.transNo} />
              </label>
              <label className='col s12 m6 l3' data-field='receiveDate.startDate'>
                {resource.receive_date_from} ({this.dateFormat})
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    parseDate={this.parseDate}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    value={this.state.receiveDate.startDate}
                    onDayChange={this.updateDayPicker}
                  />
              </label>
              <label className='col s12 m6 l3' data-field='receiveDate.endDate'>
                {resource.receive_date_to} ({this.dateFormat})
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    parseDate={this.parseDate}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    value={this.state.receiveDate.endDate}
                    onDayChange={this.updateDayPicker}
                  />
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='exSysRefNo'><button type='button' id='aexSysRefNo' onClick={this.sort}>{resource.corr_id}</button></th>
                    <th data-field='transNo'><button type='button' id='transNo' onClick={this.sort}>{resource.transNo}</button></th>
                    <th data-field='exSysName'><button type='button' id='exSysName' onClick={this.sort}>{resource.externalsys_name}</button></th>
                    <th data-field='webServicesType'><button type='button' id='sortWebServicesType' onClick={this.sort}>{resource.web_services_type}</button></th>
                    <th data-field='detail'><button type='button' id='detail' onClick={this.sort}>{resource.detail}</button></th>
                    <th data-field='statusCode'><button type='button' id='statusCode' onClick={this.sort}>{resource.action_date}</button></th>
                    <th data-field='receiveDate'><button type='button' id='receiveDate' onClick={this.sort}>{resource.created_date}</button></th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((log, i) => {
                    return (
                      <tr key={i} onClick={(e) => this.showPopup(e, log)}>
                        <td className='text-right'>{log.sequenceNo}</td>
                        <td>{log.exSysRefNo}</td>
                        <td>{log.transNo}</td>
                        <td>{log.exSysName}</td>
                        <td>{log.webServicesType}</td>
                        <td>{log.detail}</td>
                        <td>{log.statusCode}</td>
                        <td>{log.receiveDate}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
          <Modal
              isOpen={this.state.modalIsOpen}
              onRequestClose={this.closeModal}
              contentLabel='Modal'
              portalClassName='modal-portal'
              className='modal-portal-content small-width'
              bodyOpenClassName='modal-portal-open'
              overlayClassName='modal-portal-backdrop'
          >
            <WebServiceTransLogsHistoryForm history={this.props.history}
              resource={resource}
              close={this.closeModal}
              data={this.state.showData}
              location={this.props.location} />
          </Modal>
        </div>
      </div>
    );
  }
}
