import * as React from 'react';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import 'react-day-picker/lib/style.css';
import '../../assets/css/datepicker.css';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {DateUtil, HistoryProps, SearchComponent, SearchState} from '../../core';
import applicationContext from '../config/ApplicationContext';
import {UserActivityLog} from '../model/UserActivityLog';
import {UserActivityLogSM} from '../search-model/UserActivityLogSM';

enum RadioValue  {
  C = 'C',
  CN = 'CN'
}

export class UserActivityLogForm extends SearchComponent<UserActivityLog, UserActivityLogSM, HistoryProps, SearchState<UserActivityLog>> {
  constructor(props) {
    super(props, applicationContext.getUserActivityLogService(), applicationContext.getSearchPermissionBuilder());
    this.state = {
      entityType: '',
      results: [],
      userActivityLogsList: [],
      actionStatus: '',
      actionDate: {
        startDate: DateUtil.now(),
        endDate: DateUtil.now()
      },
      consumer: '',
      entityName: ''
    };
  }

  private readonly masterDataService = applicationContext.getMasterDataService();

  initData() {
    this.masterDataService.getUserActivityLogs().subscribe((userActivityLogsList) => {
      this.setState(prevState => ({
        ...prevState,
        userActivityLogsList,
      }), this.loadData);
    }, this.handleError);
  }

  render() {
    const resource = this.resource;
    const { actionStatus, userActivityLogsList, consumer, entityName } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.user_activity_log_search}</h2>
        </header>
        <div>
          <form id='userActivityLogForm' name='userActivityLogForm'  noValidate={true} ref='form'>
            <section className='row radio-group'>
              <label className='col s6'>
                <input
                  type='radio'
                  id='entityType'
                  name='entityType'
                  onChange={this.updateState}
                  checked={this.state.entityType === RadioValue.C.toString() ? true : false}
                  value={RadioValue.C}
                />
                {resource.transaction_fee_setup_form_consumer}
                <input
                  type='text'
                  id='consumer'
                  name='consumer'
                  value={consumer}
                  onChange={this.updateState}
                  maxLength={255}
                  disabled={this.state.entityType !== RadioValue.C}
                  placeholder={resource.transaction_fee_setup_form_consumer} />
              </label>
              <label className='col s6'>
                <input
                  type='radio'
                  id='entityType'
                  name='entityType'
                  onChange={this.updateState} checked={this.state.entityType === RadioValue.CN.toString() ? true : false}
                  value={RadioValue.CN}
                />
                {resource.company_name}
                <input
                  type='text'
                  id='entityName'
                  name='entityName'
                  value={entityName}
                  onChange={this.updateState}
                  maxLength={255}
                  disabled={this.state.entityType !== RadioValue.CN}
                  placeholder={resource.company_name} />
              </label>
            </section>
            <section className='row search-group'>
              <label className='col s6 m6 l3'>
                {resource.action_type}
                <select
                  id='actionStatus'
                  name='actionStatus'
                  value={actionStatus}
                  onChange={this.updateState}
                >
                  <option key={0} value=''>{resource.all}</option>
                  )
                  {userActivityLogsList.map((item, index) => (
                    <option key={index + 1} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <label className='col s6 m6 l3'>
                {resource.user_id}
                <input
                  type='text'
                  id='userId'
                  name='userId'
                  value={this.state.userId}
                  onChange={this.updateState}
                  maxLength={255}
                  placeholder={resource.user_id} />
              </label>
              <label className='col s6 m6 l3' data-field='actionDate.startDate'>
                {resource.bank_admin_access_date_from}
                  {/* <DatePicker
                    onChangeData={this.updateDateState}
                    value={this.state.startDate}
                    maxDate={this.state.endDate}
                    required={true}
                    name='startDate'
                    locale='en-IE'
                    className='form-group'
                  /> */}
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    parseDate={this.parseDate}
                    value={this.state.actionDate.startDate}
                    onDayChange={this.updateDayPicker}
                  />
              </label>
              <label className='col s6 m6 l3 up-date-picker2' data-field='actionDate.endDate'>
                {resource.bank_admin_access_date_to}
                  {/* <DatePicker
                    onChangeData={this.updateDateState}
                    value={this.state.endDate}
                    minDate={this.state.startDate}
                    required={true}
                    name='endDate'
                    locale='en-IE'
                    className='form-group'
                  /> */}
                  <DayPickerInput
                    placeholder={this.dateFormat}
                    format={this.dateFormat}
                    formatDate={this.formatDate}
                    parseDate={this.parseDate}
                    value={this.state.actionDate.endDate}
                    onDayChange={this.updateDayPicker}
                  />
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged}/>
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr>
                    <th>{resource.sequence}</th>
                    <th data-field='userId'><button type='button' id='sortUserId' onClick={this.sort}>{resource.user_id}</button></th>
                    <th data-field='actedBy'><button type='button' id='sortActedBy' onClick={this.sort}>{resource.acted_by}</button></th>
                    <th data-field='ctrlStatus'><button type='button' id='sortCtrlStatus' onClick={this.sort}>{resource.ctrl_status}</button></th>
                    <th data-field='actionDate'><button type='button' id='sortActionDate' onClick={this.sort}>{resource.action_date}</button></th>
                    <th data-field='description'><button type='button' id='sortDescription' onClick={this.sort}>{resource.description}</button></th>
                    <th data-field='IpAddr'><button type='button' id='sortIpAddr' onClick={this.sort}>{resource.user_activity_log_IP}</button></th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((usersActivityLog, i) => {
                    return (
                      <tr key={i}>
                        <td className='text-right'>{usersActivityLog.sequenceNo}</td>
                        <td>{usersActivityLog.userId}</td>
                        <td>{usersActivityLog.actedBy}</td>
                        <td>{usersActivityLog.actionStatus}</td>
                        <td>{DateUtil.formatDate(usersActivityLog.actionDate, this.dateTimeFormat)}</td>
                        <td>{usersActivityLog.description}</td>
                        <td>{usersActivityLog.IpAddr}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
        </div>
      </div>
    );
  }
}
