import * as React from 'react';
import Chips from 'react-chips';
import Modal from 'react-modal';
import {zip} from 'rxjs';
import PageSizeSelect from '../../control/PageSizeSelect';
import Pagination from '../../control/Pagination';
import {HistoryProps, ResourceManager, SearchComponent, SearchState} from '../../core';
import {CtrlStatus} from '../../setup/enum/CtrlStatus';
import {PayerSM} from '../../setup/search-model/PayerSM';
import applicationContext from '../config/ApplicationContext';
import {FeeDetailReport} from '../model/FeeDetailReport';
import {FeeDetailReportSM} from '../search-model/FeeDetailReportSM';
import {FeeDetailHistoryForm} from './fee-detail-history-form';
import {PayersLookup} from './payers-lookup';

export const ITEMS_PER_PAGE = 10;
export class FeeDetailReportForm extends SearchComponent<FeeDetailReport, FeeDetailReportSM, HistoryProps, SearchState<FeeDetailReport>> {
  constructor(props) {
    super(props, applicationContext.getFeeDetailReportService(), applicationContext.getSearchPermissionBuilder());
    this.formatter = applicationContext.getBusinessSearchModelFormatter();
    this.state = {
      feeStatusList: [],
      feeDebitBankAccount: '',
      feeStatus: '',
      payers: [],
      payersList: [],
      transactionDate: new Date(),
      feeDueDate: new Date(),
      showData: {},
      chips: [],
      payerSuggestions: [],
      currentPagePayerModal: 1,
      payersTotal: 0
    };
  }
  private readonly masterDataService = applicationContext.getMasterDataService();
  private readonly apprPayerService = applicationContext.getApprPayerService();

  componentDidMount() {
    zip(
      this.masterDataService.getDefaultAcounts(),
      this.masterDataService.getFeeStatus(),
      this.apprPayerService.getAll(),
    ).subscribe(([debitAccountList, feeStatusList, payers]) => {
      this.setState({ debitAccountList, feeStatusList, payers }, () => {
        const promise = new Promise((resolve, reject) => {
          this.loadData();
          resolve('Success!');
        });
        promise.then(() => {
          const chips = this.state.payers.filter((payer) =>
            this.state.payersList.includes(payer.entityId));
          this.setState({ chips });
        });
      });
    });
  }

  showPopup = (e, showData) => {
    e.preventDefault();
    this.setState({ modalIsOpen: true, showData });
  }

  closeModal = () => {
    this.setState({ modalIsOpen: false, modalPayerIsOpen: false });
  }

  getSearchModel(): FeeDetailReportSM {
    const model = super.getSearchModel();
    model.payersList = this.state.payersList;
    return model;
  }

  onChangeChips = chips => {
    let { payersList } = this.state;
    const { payers } = this.state;

    payersList = [];
    chips.map((value, index) => {
      const x = payers.find((v) => v.entityId === value.entityId);
      payersList.push(x.entityId);
    });
    this.setState({ chips, payersList });
  }


  fetchSuggestions = (keyWords) => {
    return new Promise((resolve, reject) => {
      const { payersList } = this.state;
      this.apprPayerService.getByKeyWords(keyWords).subscribe((rs) => {
        rs = rs.filter(obj => !payersList.find(payer => obj.entityId === payer));
        resolve(rs);
      });
    });
  }
  openPayerModal = () => {
    this.setState({ modalPayerIsOpen: true });
  }
  onRemoveChips = (id) => {
    let { payersList, chips } = this.state;
    payersList = payersList.filter(payerId => payerId !== id);
    chips = chips.filter(chip => chip.entityId !== id);
    this.setState({ payersList, chips });
  }

  onModalSave = (payers) => {
    let { chips, payersList } = this.state;
    chips = chips.concat(payers);
    payersList = payersList.concat(payers.map(payer => payer.entityId));
    this.setState({ chips, payersList, modalPayerIsOpen: false });
  }

  render() {
    const resource = ResourceManager.getResource();
    const { feeStatusList, feeDebitBankAccount, payersList } = this.state;
    return (
      <div className='view-container'>
        <header>
          <h2>{resource.fee_detail_report_tile_summary}</h2>
        </header>
        <div>
          <form id='feeDetailReportForm' name='feeDetailReportForm' noValidate={true} ref='feeDetailReportForm'>
            <section className='row search-group'>
              <label className='col s6 m6 l3'>
                {resource.fee_detail_report_list_transaction_date}
                <input type='date'
                  id='transactionDate' name='transactionDate'
                  value={this.dateToDefaultString(this.state.transactionDate)}
                  onChange={this.updateState} />
              </label>
              <label className='col s6 m6 l3'>
                {resource.fee_detail_report_fee_effective_day}
                <input type='date'
                  id='feeDueDate' name='feeDueDate'
                  value={this.dateToDefaultString(this.state.feeDueDate)}
                  onChange={this.updateState} />
              </label>
              <label className='col s6 m6 l3'>
                {resource.fee_detail_report_fee_status}
                <select id='feeStatus' name='feeStatus'
                  value={this.state.feeStatus}
                  onChange={this.updateState}
                >
                  )
                {feeStatusList.map((item, index) => (
                    <option key={index} value={item.value}>{item.text}</option>)
                  )}
                </select>
              </label>
              <label className='col s6 m6 l3'>
                {resource.fee_detail_report_fee_debit_account}
                <input
                  type='text'
                  id='feeDebitBankAccount'
                  name='feeDebitBankAccount'
                  value={feeDebitBankAccount}
                  onChange={this.updateState}
                  maxLength={12}
                  placeholder={resource.fee_detail_report_fee_debit_account} />
              </label>
              <label className='col s12 chip-container'>
                {resource.payer_name}
                <Chips
                  value={this.state.chips}
                  onChange={this.onChangeChips}
                  fetchSuggestions={this.fetchSuggestions}
                  shouldRenderSuggestions={value => value.length >= 1}
                  renderChip={(item) => (
                    <div>
                      <div>{item.entityName} <span onClick={() => this.onRemoveChips(item.entityId)}>&times; &nbsp;</span></div>
                    </div>
                  )}
                  fromSuggestionsOnly={false}
                  renderSuggestion={(item, { query }) => (
                    <div
                      key={item.entityName}>
                      {item.entityName}
                    </div>
                  )}
                  getSuggestionValue={suggestion => suggestion.entityName}
                />
                <button type='button' className='btn-lookup' onClick={this.openPayerModal} />
              </label>
            </section>
            <section className='btn-group'>
              <label>
                {resource.page_size}
                <PageSizeSelect pageSize={this.pageSize} pageSizes={this.pageSizes} onPageSizeChanged={this.pageSizeChanged} />
              </label>
              <button type='submit' className='btn-search' onClick={this.searchOnClick}>{resource.search}</button>
            </section>
          </form>
          <form className='list-result'>
            <div className='table-responsive'>
              <table>
                <thead>
                  <tr className='w'>
                    <th>{resource.sequence}</th>
                    <th data-field='payerName'><button type='button' id='sortPayerName' onClick={this.sort}>{resource.payer_name}</button></th>
                    <th data-field='transactionDate'><button type='button' id='sortTransactionDate' onClick={this.sort}>{resource.fee_detail_report_list_transaction_date}</button></th>
                    <th data-field='transactionNo'><button type='button' id='sortTransactionNo' onClick={this.sort}>{resource.fee_detail_report_list_transaction_no}</button></th>
                    <th data-field='transactionStatus'><button type='button' id='sortTransactionStatus' onClick={this.sort}>{resource.fee_detail_report_list_transaction_status}</button></th>
                    <th data-field='feeAmount'><button type='button' id='sortFeeAmount' onClick={this.sort}>{resource.fee_detail_report_list_fee_amount}</button></th>
                    <th data-field='feeTransactionNo'><button type='button' id='sortFeeTransactionNo' onClick={this.sort}>{resource.fee_detail_report_list_fee_transaction_no}</button></th>
                    <th data-field='feeEffectiveDate'><button type='button' id='sortFeeEffectiveDate' onClick={this.sort}>{resource.fee_detail_report_fee_effective_day}</button></th>
                    <th data-field='feePositingType'><button type='button' id='sortFeePositingType' onClick={this.sort}>{resource.fee_detail_report_list_fee_positing_type}</button></th>
                    <th data-field='feeDebitAccount'><button type='button' id='sortFeeDebitAccount' onClick={this.sort}>{resource.fee_detail_report_list_debit_account}</button></th>
                  </tr>
                </thead>
                <tbody>
                  {this.state && this.state.results && this.state.results.map((feeDetailReport, i) => {
                    return (
                      <tr key={i} onClick={(e) => this.showPopup(e, feeDetailReport)}>
                        <td className='text-right'>{feeDetailReport.sequenceNo}</td>
                        <td>{feeDetailReport.payerName}</td>
                        <td>{feeDetailReport.paymentDate}</td>
                        <td>{feeDetailReport.paymentId}</td>
                        <td>{feeDetailReport.paymentStatus}</td>
                        <td>{feeDetailReport.feeAmount}</td>
                        <td>{feeDetailReport.feeTransactionNo}</td>
                        <td>{feeDetailReport.feeDueDate}</td>
                        <td>{feeDetailReport.postingType}</td>
                        <td>{feeDetailReport.feeDebitBankAccount}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <Pagination className='col s12 m6' totalRecords={this.itemTotal} itemsPerPage={this.pageSize} maxSize={this.pageMaxSize} currentPage={this.currentPage} onPageChanged={this.pageChanged} />
          </form>
          <Modal
            isOpen={this.state.modalIsOpen}
            onRequestClose={this.closeModal}
            contentLabel='Modal'
            portalClassName='modal-portal'
            className='modal-portal-content small-width'
            bodyOpenClassName='modal-portal-open'
            overlayClassName='modal-portal-backdrop'
          >
            <FeeDetailHistoryForm history={this.props.history}
              resource={resource}
              close={this.closeModal}
              data={this.state.showData}
              location={this.props.location} />
          </Modal>
          <PayersLookup
            resource={resource}
            isOpenModal={this.state.modalPayerIsOpen}
            closeModal={this.closeModal}
            history={this.props.history}
            location={this.props.location}
            props={this.props['props']}
            onModalSave={this.onModalSave}
            excluding={{ entityId: payersList }}
          />
        </div>
      </div>
    );
  }

  getPayerSM(entityName, pageIndex, pageSize): PayerSM {
    // @ts-ignore
    const obj: PayerSM = {};
    obj.entityName = entityName;
    obj.entityType = 'R';
    obj.pageIndex = pageIndex;
    obj.pageSize = pageSize;
    obj.ctrlStatus = [CtrlStatus.Approved];
    return obj;
  }
}
