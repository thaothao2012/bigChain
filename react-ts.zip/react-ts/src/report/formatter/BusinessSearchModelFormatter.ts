import {DateUtil, Language, LocaleModelFormatter} from '../../core';

export class BusinessSearchModelFormatter implements LocaleModelFormatter<any, any> {
  format(obj: any, locale: Language): any {
    if (obj.ctrlStatus) {
      const v = obj.ctrlStatus;
      if (v === 'A') {
        obj.ctrlStatusName = 'Approved';
      } else if (v === 'R') {
        obj.ctrlStatusName = 'Rejected';
      } else if (v === 'P') {
        obj.ctrlStatusName = 'Pending';
      }
    }

    if (obj.actionStatus) {
      const v = obj.actionStatus;
      if (v === 'C') {
        obj.actionStatus = 'Created';
      } else if (v === 'U') {
        obj.actionStatus = 'Updated';
      } else {
        obj.actionStatus = 'Deleted';
      }
    }

    if (obj.createdDate) {
      obj.createdDate = DateUtil.formatDate(obj.createdDate, 'DD.MM.YYYY hh:mm:ss');
    } else if (obj.createdDate) {
      obj.createdDate = DateUtil.formatDate(obj.createdDate, 'DD.MM.YYYY hh:mm:ss');
    }

    if (obj.paymentDate) {
      obj.paymentDate = DateUtil.formatDate(obj.paymentDate, 'DD.MM.YYYY hh:mm:ss');
    }

    if (obj.actionDate) {
      obj.actionDate = DateUtil.formatDate(obj.actionDate, 'DD.MM.YYYY hh:mm:ss');
    }

    if (obj.receiveDate) {
      obj.receiveDate = DateUtil.formatDate(obj.receiveDate, 'DD.MM.YYYY hh:mm:ss');
    }

    if (obj.activate) {
      if (obj.activate === 'T') {
        obj.activate = 'Activated';
      } else if (obj.activate === 'F') {
        obj.activate = 'Deactivated';
      }
    }

    if (obj.activateFlag) {
      if (obj.activateFlag === 'T') {
        obj.activateFlag = 'Activated';
      } else {
        obj.activateFlag = 'Deactivated';
      }
    }

    if (obj.roleType) {
      obj.roleType = (obj.roleType === 'C' ? 'Checker' : 'Maker');
    }

    if (obj.postingType) {
      if (obj.postingType === 'I') {
        obj.postingType = 'Immediately';
      } else if (obj.postingType === 'D') {
        obj.postingType = 'Daily';
      } else {
        obj.postingType = 'Monthly';
      }
    }

    if (obj.paymentStatus) {
      if (obj.paymentStatus === 'D') {
        obj.paymentStatus = 'Debited';
      } else if (obj.paymentStatus === 'C') {
        obj.paymentStatus = 'Credited';
      } else if (obj.paymentStatus === 'S') {
        obj.paymentStatus = 'Success';
      } else {
        obj.paymentStatus = 'Fail';
      }
    }
    return obj;
  }
}
