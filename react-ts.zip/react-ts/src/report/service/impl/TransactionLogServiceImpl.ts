import config from '../../../config';
import {GenericSearchWebService} from '../../../core';
import {transactionLogModel} from '../../metadata/TransactionLogModel';
import {TransactionLog} from '../../model/TransactionLog';
import {TransactionLogSM} from '../../search-model/TransactionLogSM';
import {TransactionlogService} from '../TransactionLogService';

export class TransactionLogServiceImpl extends GenericSearchWebService<TransactionLog, TransactionLogSM> implements TransactionlogService {
  constructor() {
    super(config.backOfficeUrl + 'transactionLog', transactionLogModel);
  }
}
