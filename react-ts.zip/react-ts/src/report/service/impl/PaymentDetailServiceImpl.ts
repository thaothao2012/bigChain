import config from '../../../config';
import {GenericSearchWebService} from '../../../core';
import {paymentDetailModel} from '../../metadata/PaymentDetailModel';
import {PaymentDetail} from '../../model/PaymentDetail';
import {PaymentDetailSM} from '../../search-model/PaymentDetailSM';
import {PaymentDetailService} from '../PaymentDetailService';

export class PaymentDetailServiceImpl extends GenericSearchWebService<PaymentDetail, PaymentDetailSM> implements PaymentDetailService {
  constructor() {
    super(config.backOfficeUrl + 'paymentDetails', paymentDetailModel);
  }
}
