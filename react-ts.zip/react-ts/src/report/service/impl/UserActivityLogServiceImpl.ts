import config from '../../../config';
import {GenericSearchWebService} from '../../../core';
import {userActivityLog} from '../../metadata/UserActivityLog';
import {UserActivityLog} from '../../model/UserActivityLog';
import {UserActivityLogSM} from '../../search-model/UserActivityLogSM';
import {UserActivityLogService} from '../UserActivityLogService';

export class UserActivityLogServiceImpl extends GenericSearchWebService<UserActivityLog, UserActivityLogSM> implements UserActivityLogService {
  constructor() {
    super(config.backOfficeUrl + 'userActivityLog', userActivityLog);
  }
}
