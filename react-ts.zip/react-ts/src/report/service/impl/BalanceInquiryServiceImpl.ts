import config from '../../../config';
import {GenericSearchDiffApprWebService} from '../../../core';
import {balanceInquiryModel} from '../../metadata/BalanceInquiryModel';
import {BalanceInquiry} from '../../model/BalanceInquiry';
import {BalanceInquirySM} from '../../search-model/BalanceInquirySM';
import {BalanceInquiryService} from '../BalanceInquiryService';

export class BalanceInquiryServiceImpl extends GenericSearchDiffApprWebService<BalanceInquiry, BalanceInquirySM> implements BalanceInquiryService {
  constructor() {
    super(config.backOfficeUrl + 'accountInfo', balanceInquiryModel);
  }

}
