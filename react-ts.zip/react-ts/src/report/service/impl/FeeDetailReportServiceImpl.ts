import config from '../../../config';
import {GenericSearchWebService} from '../../../core';
import {feeDetailReportModel} from '../../metadata/FeeDetailReportModel';
import {FeeDetailReport} from '../../model/FeeDetailReport';
import {FeeDetailReportSM} from '../../search-model/FeeDetailReportSM';
import {FeeDetailReportService} from '../FeeDetailReportService';

export class FeeDetailReportServiceImpl extends GenericSearchWebService<FeeDetailReport, FeeDetailReportSM> implements FeeDetailReportService {
  constructor() {
    super(config.backOfficeUrl + 'transactionFeeDetail', feeDetailReportModel);
  }
}
