import config from '../../../config';
import {GenericSearchWebService} from '../../../core';
import {webServiceTransLogModel} from '../../metadata/WebServiceTransLogModel';
import {WebServiceTransLog} from '../../model/WebServiceTransLog';
import {WebServiceTransLogSM} from '../../search-model/WebServiceTransLogSM';
import {WebServiceTransLogService} from '../WebServiceTransLogService';

export class WebServiceTransLogServiceImpl extends GenericSearchWebService<WebServiceTransLog, WebServiceTransLogSM> implements WebServiceTransLogService {
  constructor() {
    super(config.backOfficeUrl + 'webServicesTransLog', webServiceTransLogModel);
  }
}
