import {GenericSearchService} from '../../core';
import {UserActivityLog} from '../model/UserActivityLog';
import {UserActivityLogSM} from '../search-model/UserActivityLogSM';

export interface UserActivityLogService extends GenericSearchService<UserActivityLog, UserActivityLogSM> {

}
