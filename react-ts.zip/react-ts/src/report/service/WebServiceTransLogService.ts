import {GenericSearchService} from '../../core';
import {WebServiceTransLog} from '../model/WebServiceTransLog';
import {WebServiceTransLogSM} from '../search-model/WebServiceTransLogSM';

export interface WebServiceTransLogService extends GenericSearchService<WebServiceTransLog, WebServiceTransLogSM> {

}
