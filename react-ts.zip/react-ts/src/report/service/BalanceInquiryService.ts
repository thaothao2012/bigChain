import {GenericSearchDiffApprWebService} from '../../core';
import {BalanceInquiry} from '../model/BalanceInquiry';
import {BalanceInquirySM} from '../search-model/BalanceInquirySM';

export interface BalanceInquiryService extends GenericSearchDiffApprWebService<BalanceInquiry, BalanceInquirySM> {

}
