import {GenericSearchService} from '../../core';
import {TransactionLog} from '../model/TransactionLog';
import {TransactionLogSM} from '../search-model/TransactionLogSM';

export interface TransactionlogService extends GenericSearchService<TransactionLog, TransactionLogSM> {

}
