import {GenericSearchService} from '../../core';
import {PaymentDetail} from '../model/PaymentDetail';
import {PaymentDetailSM} from '../search-model/PaymentDetailSM';

export interface PaymentDetailService extends GenericSearchService<PaymentDetail, PaymentDetailSM> {
}
