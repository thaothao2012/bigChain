import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {BalanceInquiryForm} from './component/balance-inquiry-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/balance-inquiry/'} exact={true} component={WithDefaultLayout(BalanceInquiryForm)} /> */}

        <Route path={this.props.match.url + '/balance-inquiry/'} exact={true} component={WithDefaultProps(BalanceInquiryForm)} />
      </React.Fragment>
    );
  }
}

const AccountInfoRoutes = compose(
  withRouter,
)(StatelessApp);
export default AccountInfoRoutes;
