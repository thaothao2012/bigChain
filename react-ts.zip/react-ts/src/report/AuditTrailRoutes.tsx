import * as H from 'history';
import * as React from 'react';
import {Route, RouteComponentProps, withRouter} from 'react-router-dom';
import {compose} from 'redux';

// import {WithDefaultLayout} from '../container/default';
import {WithDefaultProps} from '../container/default';
import {TransactionLogsForm} from './component/transaction-logs-form';
import {UserActivityLogForm} from './component/user-activity-log-form';
import {WebServiceTransLogsForm} from './component/web-service-trans-logs-form';

interface AppProps {
  history: H.History;
}

class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    return (
      <React.Fragment>
        {/* <Route path={this.props.match.url + '/user-activity-log'} exact={true} component={WithDefaultLayout(UserActivityLogForm)} />
        <Route path={this.props.match.url + '/transaction-log'} exact={true} component={WithDefaultLayout(TransactionLogsForm)} />
        <Route path={this.props.match.url + '/web-services-trans-log'} exact={true} component={WithDefaultLayout(WebServiceTransLogsForm)} /> */}

        <Route path={this.props.match.url + '/user-activity-log'} exact={true} component={WithDefaultProps(UserActivityLogForm)} />
        <Route path={this.props.match.url + '/transaction-log'} exact={true} component={WithDefaultProps(TransactionLogsForm)} />
        <Route path={this.props.match.url + '/web-services-trans-log'} exact={true} component={WithDefaultProps(WebServiceTransLogsForm)} />
      </React.Fragment>
    );
  }
}

const AuditTrailRoutes = compose(
  withRouter,
)(StatelessApp);
export default AuditTrailRoutes;
