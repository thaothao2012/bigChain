import AccessResourcesEN from '../access/resource/AccessResourceEN';
import AccessResourcesTH from '../access/resource/AccessResourceTH';
import AuthenticationResourceEN from '../authentication/resource/AuthenticationResourceEN';
import AuthenticationResourceTH from '../authentication/resource/AuthenticationResourceTH';
import {Language} from '../common/Language';
import MyProfileResourceEN from '../my-profile/resource/MyProfileResourceEN';
import MyProfileResourceTH from '../my-profile/resource/MyProfileResourceTH';
import ReportResourcesEN from '../report/resource/ReportResourceEN';
import ReportResourcesTH from '../report/resource/ReportResourceTH';
import SetupResourcesEN from '../setup/resource/SetupResourceEN';
import SetupResourcesTH from '../setup/resource/SetupResourceTH';
import CommonResourcesEN from './common/commonResourcesEN';
import CommonResourcesTH from './common/commonResourcesTH';

const ResourcesEN = {
  ...ReportResourcesEN,
  ...SetupResourcesEN,
  ...AccessResourcesEN,
  ...MyProfileResourceEN,
  ...AuthenticationResourceEN,
  ...CommonResourcesEN,
};
const ResourcesTH = {
  ...ReportResourcesTH,
  ...SetupResourcesTH,
  ...AccessResourcesTH,
  ...MyProfileResourceTH,
  ...AuthenticationResourceTH,
  ...CommonResourcesTH,
};

const Resources = {
  [Language.English]: ResourcesEN,
  [Language.Thai]: ResourcesTH
};

export default Resources;
