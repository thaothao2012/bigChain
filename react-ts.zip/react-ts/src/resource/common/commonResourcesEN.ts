﻿const CommonResourcesEN = {
  format_date: 'dd/mm/yyyy',
  format_momnent_date: 'DD/MM/YYYY, h:mm:ss a',

  home: 'Home',
  dashboard: 'Dashboard',
  settings: 'Settings',
  audit_trails: 'Audit Trail',
  help: 'Help',
  events_history: 'Event History',

  confirm: 'Confirm',
  create: 'Create',
  add: 'Add',
  edit: 'Edit',
  reset: 'Reset',
  search: 'Search',
  save: 'Save',
  cancel: 'Cancel',
  approve: 'Approve',
  reject: 'Reject',
  delete: 'Delete',
  select: 'Select',
  deselect: 'Deselect',
  check_all: 'Check All',
  uncheck_all: 'Uncheck All',
  yes: 'Yes',
  no: 'No',

  button_ok: 'OK',
  button_yes: 'Yes',
  button_no: 'No',
  button_home: 'Home',
  button_browse: 'Browse',
  button_test_connection: 'Test Connection',
  button_activate: 'Activate',
  button_deactivate: 'Deactivate',
  button_filter: 'Filter',
  button_show_more: 'Show more...',
  button_view: 'View',
  button_view_history: 'View History',
  button_update: 'Update',
  button_validate: 'Validate',
  button_continue: 'Continue',
  button_retry: 'Retry',
  button_skip: 'Skip',
  button_invite: 'Invite',
  button_apply: 'Apply',
  button_reject: 'Reject',
  button_delete: 'Delete',
  button_remove: 'Remove',
  button_finish: 'Finish',
  button_complete: 'Complete',
  button_close: 'Close',
  button_comment: 'Comment',
  button_post: 'Post',
  button_upload: 'Upload',
  button_download: 'Download',
  button_reorder: 'Reorder',
  button_confirm: 'Confirm',
  button_advance_search: 'Advance Search',
  button_basic_search: 'Basic Search',
  button_back: 'Back',

  msg_save_header: 'Confirm save',
  msg_confirm_save: 'Are you sure you want to save?',
  msg_save_success: 'Data have been saved successfully',
  msg_approve_success: 'Data have been approved successfully',
  msg_reject_success: 'Data have been rejected successfully',
  msg_delete_header: 'Confirm delete',
  msg_confirm_delete: 'Are you sure you want to delete?',
  msg_delete_confirm_in_list: 'Are you sure to delete {0} ?',
  msg_delete_failed: 'This item was not deleted successfully',
  msg_no_change: 'You do not change anything.',
  msg_confirm_rule: 'Do you want to skip current rule information?',

  page_size: 'Page Size',
  msg_no_data_found: 'No data found.',
  msg_search_result_sequence: 'Items {0} to {1}.',
  msg_search_result_page_sequence: 'Items {0} to {1} of {2}. Page {3} of {4}.',

  error_system_error: 'System Error.',
  error_required: '{0} is required.',
  error_invalid: 'You have inserted invalid {0}. Please try again',
  error_required_minlength: '{0} is required and {0} cannot be less than {1} characters.',
  error_minlength: '{0} cannot be less than {1} characters.',
  error_maxlength: '{0} cannot be greater than {1} characters.',
  error_min: '{0} must be greater than or equal to {1}.',
  error_max: '{0} must be smaller than or equal to {1}.',
  error_equal: '{0} must be equal to {1}.',
  error_greater: '{0} must be greater than {1}.',
  error_min_date: '{0} cannot be before {1}.',
  error_max_date: '{0} cannot be after {1}.',
  error_range: '{0} is not in the range {1} through {2}.',
  error_byte: '{0} must be a byte.',
  error_short: '{0} must be a short.',
  error_long: '{0} must be a long.',
  error_float: '{0} must be a float.',
  error_double: '{0} must be a double.',
  error_integer: '{0} must be a integer.',
  error_number: '{0} must be a number.',
  error_required_number: '{0} is required and must be a number',
  error_date: '{0} is not a valid date.',
  error_email: 'Please enter a valid email address.',
  error_required_email: '{0} is required and must be a valid email address.',
  error_required_passcode: 'Code is required. Please enter Code.',
  error_phone: 'Invalid phone number. Please include area code and full phone number.',
  error_fax: 'Invalid fax number. Please include area code and full fax number.',
  error_url: '{0} is not a valid URL.',
  error_cash: 'Please enter a valid amount money.',
  error_credit_card: '{0} is a valid credit card',
  error_port: 'Invalid Port (min. 0, max. 65535)',
  error_password: 'Your new password is invalid. The password length must be between 8 and 14 characters, and no dictionary words permitted. Also, your password must contain at least 3 out of 4 following rules: lowercase, uppercase, numerals, special characters such as !@#$%^&*(){}[].',
  error_account_number: '{0} is not a valid checking account number.',
  error_routing_number: '{0} is not a valid routing number.',

  error_item_exist: 'This {0} is already existed in the system. Please try a different one',
  error_item_not_exist: 'This {0} does not exist in the system. Please try a different one',

  error_network: 'Cannot access server. Maybe network is corrupted.',
  error_internal: 'Internal error',

  error_unauthorized: 'You have not logged in or the session was expired. Please log in.', /* use for 401 */
  error_item_not: 'Item not Exist.', /* use for 404 */
  error_forbidden: 'You do not have permission for this page or for this action.', /* use for 403 */
  error_data_integrity: 'Data has been changed by someone. Please refresh screen and continue.',
  error_data_corrupt: 'Data has been corrupt. You cannot proceed this business.',
  error_required_id: 'You must input id.',
  error_duplicated_id: 'The id is duplicated.',
  error_duplicated: '{0} is duplicated.',

  error_permission: 'Permission error',
  error_permission_search: 'You do not permission to use this page.',
  error_permission_view: 'You do not permission to use this page.',
  error_permission_add: 'You do not have "add" permission. You are not allowed to "add".',
  error_permission_edit: 'You do not have "add" permission. You are not allowed to "edit".',
  error_permission_delete: 'You do not have "add" permission. You are not allowed to "delete".',

  error_delete_transaction_account_code: 'Can not delete the account code has transactions.',
  error_invalid_payment_rule: 'Invalid payment amount of rule',

  /**
   * MESSAGE
   *
   * msg_
   */

  msg_delete_confirm: 'Are you sure to delete this item?',

  msg_cancel_header: 'Confirm cancel',
  msg_cancel_confirm: 'Do you want to leave the page without saving?',
  msg_header_reset_pass: 'Reset User Account Password',
  msg_confirm_reset_pass: 'Are you sure you want to reset the password for this account?',

  msg_after_add: '{0} have been created successfully',
  msg_after_save: '{0} have been saved successfully',
  msg_user_no_role: 'Your account has no valid role. Please contact the administrator for support',

  /**
   * Boolean
   */
  true: 'True',
  false: 'False',

  /**
   * STATUS
   *
   * status_*
   */
  status: 'Status',
  status_away: 'Away',
  status_available: 'Available',
  status_idle: 'Idle',
  status_busy: 'Busy',
  status_invisible: 'Invisible',
  status_changing: 'Set Status to',

  please_select: 'Please Select',
  /**
   * GENERAL
   */
  address: 'Address',
  street: 'Street',
  ward: 'Ward',
  district: 'District',
  city: 'City',
  county: 'County',
  prefecture: 'Prefecture',
  state: 'State',
  country: 'Country',
  postcode: 'Postal Code',

  users: 'Users',
  user: 'User',
  user_list: 'Search users',
  user_info: 'User information',
  user_type: 'User Type',

  /*
   * Authentication Service
   */
  user_id: 'User Id',
  user_name: 'Email',
  password: 'Password',

  gender: 'Gender',
  male: 'Male',
  female: 'Female',
  name: 'Name',
  email: 'Email',
  notification: 'Notification',
  first_name: 'First Name',
  last_name: 'Last Name',
  middle_name: 'Middle Name',
  display_name: 'Display Name',
  phone: 'Telephone',

  from: 'From',
  to: 'To',
  field: 'Field',
  error: 'Error',

  skills: 'Skills',
  interests: 'Interests',
  achievements: 'Achievements',

  keyword: 'Keyword',
  remark: 'Remark',
  all: 'All',
  pending: 'Pending',
  approved: 'Approved',
  rejected: 'Rejected',
  detail: 'Detail',
  description: 'Description',
  sequence: 'No.',
  total: 'Total',

  start_date: 'Start Date',
  end_date: 'End Date',
  short_name: 'Short Name',
  action_type: 'Action Type',

  fee_charges: 'Fee Charges',
  external_system: 'External System',
  private_key: 'Private Key',

  old_data_subject: 'Old Register Data',
  new_data_subject: 'New Register Data',

  contact_name: 'Contact Name',
  contact_phone: 'Contact Telephone No',
  contact_fax: 'Contact Facsimile No',
  company_id: 'Company ID',
  company_name: 'Company Name',
  company_short_name: 'Company Short Name',

  payment_summary: 'Payment Summary',
  activation_status: 'Activation Status',
  password_delivery_method: 'Password Delivery Method',
  payment_amount_max: 'Maximum Payment Amount Per Transaction',
  mobile_phone_number: 'Mobile Phone No',
  // Account
  account_currency: 'Account Currency',
  account_number: 'Account No',
  account_name: 'Account Name',

  ctrl_status: 'Control Status',
  acted_by: 'Acted By',
  action_status: 'Action Status',
  action_date: 'Action Date',
  created_date: 'Timestamp ',
  quick_action: 'Q.Action',

  /**
   * START Common-auth
   */
  applicant_title: 'Apply for {0}',
  applicant_subtitle: 'Applicant Information',
  account_subtitle: 'Account Linked to the Service',
  summary_title: 'Summary',
  term_title: 'Terms and Conditions',
  success_title: 'Success',
  error_title: 'Appologize',
  edit_info_title: 'Edit Information',

  email_title: 'Email Information',
  occupation_title: 'Edit Information',

  section_applicant_info: 'Applicant',
  section_occupation_info: 'Profession',
  section_email_info: 'Email Info',
  section_work_address: 'Work Address',
  section_account: 'Link Account to Service',

  person_enName: 'Name (English)',
  person_thName: 'Name (Thai)',
  person_gender: 'Gender',
  person_dateOfBirth: 'Date Of Birth',
  person_citizenId: 'Citizen ID',
  person_passportNo: 'Passport No.',
  person_nationality: 'Nationality',
  person_title: 'Title',
  person_image: 'Image',

  registered_address: 'Registration Address',
  outside_address: 'Address in the Country of Nationality',
  contact_address: 'Contact Address',
  work_address: 'Workplace Address',

  occupation: 'Occupation',
  profession: 'Career Field',
  occupation_professionOther: 'Profession Other',
  occupation_income: 'Monthly Income',
  occupation_incomeCountry: 'Major Source of Income',
  occupation_workAddressName: 'Workplace Name',

  address_village: 'Village',
  address_moo: 'VillageNo',
  address_building: 'Building',
  address_room: 'Room',
  address_floor: 'Floor',
  address_mailNum: 'HouseNo',
  address_soi: 'alley',
  address_road: 'street',
  address_province: 'province',
  address_amphur: 'district',
  address_tumbol: 'SubDistrict',
  address_postCode: 'ZipCode',
  default_registration_address: 'Same with Registration Address',
  default_contact_address: 'Same with Contact Address',

  term_header: 'Privacy Consent',
  term_content: 'The User agrees to authorize KBank to disclose the User’s information as shown below to {1} for the purpose of application for and use of {0}. The User has the right to access, right to rectification, right to restrict data processing, and right to be forgotten information related to the User which is in possession of',

  condition_header: 'Market Conduct Consent',
  condition_content: `I hereby authorize KASIKORNBANK PUBLIC COMPANY LIMITED (“Bank”) to disclose my nformation provided to, or held by, the Bank, or which the Bank has received or access from other sources, including but not limited to accounts, loans and transactions information to any of KASIKORNBANK FINANCIAL CONGLOMERATE and any of the Bank's assignees* and any notified addition of the assignees** for the purpose of offering me the news or special products/services and/or for any other purpose(s), and also allow the assignees to compile, use and disclose the information in accordance with the purposes notified to the Bank.`,
  condition_note: 'Remarks',
  condition_sub_note: `* KASIKORNBANK FINANCIAL CONGLOMERATE and any of the Bank's assignees mean;`,
  condition_note1: 'KASIKORNBANK FINANCIAL CONGLOMERATE (Details can be found at www.kasikornbank.com/financial-conglomerate)',
  condition_note2: '**Addition of the assignees: The Bank may add the list of assignees, and shall notify you in advance of the list of the additional assignees including the consent rejection channel. It shall be deemed that you have given consent to disclose the information to the notified assignees if no rejection is received by the Bank within the established period.',
  condition_contact: 'If you wish to change your consent for disclosing of personal information, please contact K-Contact Center at 02-8888888.',
  condition_agree: 'Allow information disclosure',
  condition_disagree: 'Deny information disclosure',

  radio_copyRegisterAddress: 'Same as Register Address',
  radio_contactAddress: 'Same as Contact Address',
  radio_createNewAddress: 'Other Address',

  incomeSuffix: '/Month',
  incomeRangSuffix: 'Bath/Month',
  bath: 'Bath',

  button_next: 'Next',
  button_back_to: 'Back to {0}',
  button_cancel: 'Cancel',
  button_accept: 'Accept',
  button_done: 'Done',

  error_message: 'ธนาคารไม่สามารถดำเนินรายการนี้ได้<br /> กรุณาทำรายการอีกครั้งในภายหลัง<br />',

  error_mobile_10201: 'Invalid mobile number from service request.',
  error_field_10202: 'Required field(s) is(are) missing, invalid value or invalid format.',
  error_lead_10212: 'Lead Id of feed is mandatory.',
  error_feed_10212: 'Feed parameter is mandatory.',
  error_token_10212: 'tokenId of feed parameter is mandatory.',
  error_feed_404: 'Feed Not Found',
  error_profile_404: 'Profile Not Found',
  error_address_404: 'Cannot get address from temp database (REDIS).',

  modal_confirm_content: '<b>แจ้งเตือน</b><br/>คุณต้องการกลับแอปพลิเคชันต้นทางหรือไม่',
  modal_confirm_btnCancel: 'No',
  modal_confirm_btnAccept: 'Ok',

  email_note: 'Remark: The above email will be used to apply for this service only.',
  /**
   * END Common-auth
   */
};

// @ts-ignore
export default CommonResourcesEN;
