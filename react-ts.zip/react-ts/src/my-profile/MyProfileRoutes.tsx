import * as React from 'react';
import {Route, RouteComponentProps, Switch, withRouter} from 'react-router-dom';
import {compose} from 'redux';
import AddEmail from './component/AddEmailForm';
import ChangeEmail from './component/ChangeEmailForm';
import MyProfileForm from './component/my-profile-form';
import MySettingsForm from './component/my-settings-form';

interface StateProps {
  anyProps?: any;
}

type AppProps = StateProps;
class StatelessApp extends React.Component<AppProps & RouteComponentProps<any>, {}> {
  render() {
    const currentUrl = this.props.match.url;
    return (
      <Switch>
        <Route path={'/my-profile/my-settings'} exact={true} component={MySettingsForm} />
        <Route path={currentUrl + '/my-settings/change-email'} exact={true} component={ChangeEmail} />
        <Route path={currentUrl + '/my-settings/add-email'} exact={true} component={AddEmail} />
        <Route path={currentUrl} exact={true} component={MyProfileForm} />
      </Switch>
    );
  }
}

const MyProfileRoutes = compose(
  withRouter,
)(StatelessApp);
export default MyProfileRoutes;
