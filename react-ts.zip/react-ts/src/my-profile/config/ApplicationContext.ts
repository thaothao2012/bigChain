import {MyProfileServiceImpl} from '../service/impl/MyProfileServiceImpl';
import {MyProfileService} from '../service/MyProfileService';

class ApplicationContext {
  private readonly myProfileService: MyProfileService;

  constructor() {
    this.myProfileService = new MyProfileServiceImpl();
  }

  getMyProfileService(): MyProfileService {
    return this.myProfileService;
  }
}

const applicationContext = new ApplicationContext();

export default applicationContext;
