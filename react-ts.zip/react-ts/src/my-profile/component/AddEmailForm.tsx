import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {getFormValues, InjectedFormProps, reduxForm} from 'redux-form';
import {BaseComponent, BaseInternalState, HistoryProps, StringUtil} from '../../core';
import {UserSettings} from '../../shared/user-model';
import applicationContext from '../config/ApplicationContext';

interface ReduxProps {
  userSettings: UserSettings;
}

type InternalState = BaseInternalState;

class AddEmailForm extends BaseComponent<HistoryProps & InjectedFormProps & ReduxProps, InternalState> {
  constructor(props) {
    super(props);
    this.state = {
      message: ''
    };
  }

  private myProfileService = applicationContext.getMyProfileService();

  saveOnClick = (e) => {
    e.preventDefault();
    this.hideMessage();

    const email = this.state.email;
    const password = this.state.password;

    if (StringUtil.isEmpty(email)) {
      return this.showMessage('Email is required');
    } else if (StringUtil.isEmpty(password)) {
      return this.showMessage('Password is required');
    }

    this.myProfileService.addEmail(email, password).subscribe(res => {
      this.showMessage(res);
    }, err => console.log(err));
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container'>
        <form id='signinForm' name='signinForm' noValidate={true} autoComplete='off'>
          <div className='row justify-content-center'>
            <div className='col'>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='username'>{resource.user_name}</label>
                  <input type='text' className='form-control'
                         id='email' name='email'
                         value={this.state.email}
                         onChange={this.updateState}
                         maxLength={255} required={true}
                         placeholder={resource.placeholder_user_name}/>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='password'>{resource.password}</label>
                  <input type='password' className='form-control'
                         id='password' name='password'
                         value={this.state.password}
                         onChange={this.updateState}
                         maxLength={255} required={true}
                         placeholder={resource.placeholder_password}/>
                </div>
              </div>
              <div className='row'>
                <div className='col message'>
                  {this.state.message === '' || this.state.message === null ? '' :
                    <div className={this.alertClass}>
                      <a onClick={this.hideMessage} className='alert-ms close ' data-dismiss='alert'>
                        <i className='fa fa-window-close' aria-hidden='true'/>
                      </a>
                      {this.state.message}
                    </div>
                  }
                </div>
              </div>
              <div className='row'>
                <div className='col center'>
                  <button type='submit' className='btn btn-primary'
                          id='btnSignin' name='btnSignin'
                          onClick={this.saveOnClick}>{resource.button_add_email}</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

function mapStateToProps(state): ReduxProps {
  return {
    userSettings: getFormValues('AddEmailForm')(state) as UserSettings || {} as UserSettings,
  };
}

function mapDispatchToProps(state) {
  return {};
}


const withConnect = connect(mapStateToProps, mapDispatchToProps);


const AddEmail = compose(withConnect, reduxForm<{}>({
  form: 'AddEmailForm',
}))(AddEmailForm);
export default AddEmail;
