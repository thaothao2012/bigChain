import * as React from 'react';
import Modal from 'react-modal';
import imageOnline from '../../assets/images/status/online.svg';
import {
  BaseComponent,
  BaseInternalState,
  HistoryProps,
  ReflectionUtil,
  ResourceManager,
  storage, StringUtil, UIUtil, ValidationUtil
} from '../../core';
import {Achievement, User} from '../../shared/user-model';
import applicationContext from '../config/ApplicationContext';
import GeneralInfo from './general-info';
import './my-profile.scss';

interface InternalState extends BaseInternalState {
  isEditingAbout: boolean;
  isEditingInterest: boolean;
  isEditingAchievement: boolean;
  achievementName: string;
  hightLightAchie: string;
  achievementDes: string;
  user: User;
}

export default class MyProfileForm extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.state = {
      isOpen: false,
      isEditingAbout: false,
      isEditingInterest: false,
      isEditingAchievement: false,
      isEditingSkill: false,
      isLookingFor: false,
      achievementName: '',
      hightLightAchie: '',
      achievementDes: '',
      skillsEditing: [],
      bio: '',
      textSkillsEditing: '',
      interestEdit: '',
      newLookingFor: '',
      newSkillHireable: false,
      isEditing: false,
      objectUser: {},
      user: new User()
    };
    this.loadData();
  }


  loadData() {
    const userId = storage.getUserId();
    applicationContext.getMyProfileService().getMyProfile(userId).subscribe((user: User) => {
      this.setState({ user, objectUser: ReflectionUtil.clone(user) });
    });
  }

  showChangeStatus = () => {

  }

  showPopup = (e) => {
    e.preventDefault();
    this.setState({ modalIsOpen: true });
  }

  toggleEditModeAbout = (e) => {
    e.preventDefault();
    this.setState({ isEditingAbout: !this.state.isEditingAbout, isEditing: !this.state.isEditing });
  }

  toggleEditModeInterest = (e) => {
    e.preventDefault();
    this.setState({ isEditingInterest: !this.state.isEditingInterest, isEditing: !this.state.isEditing });
  }
  toggleEditModeAchievement = (e) => {
    e.preventDefault();
    this.setState({ isEditingAchievement: !this.state.isEditingAchievement, isEditing: !this.state.isEditing });
  }

  toggleEditingSkill = (e) => {
    e.preventDefault();
    this.setState({ isEditingSkill: !this.state.isEditingSkill, isEditing: !this.state.isEditing });
  }

  toggleEditingLookingFor = (e) => {
    e.preventDefault();
    this.setState({ isLookingFor: !this.state.isLookingFor, isEditing: !this.state.isEditing });
  }

  saveEditing = (event) => {
    event.preventDefault();
    const { isEditing } = this.state;
    if (isEditing) {
      applicationContext.getMyProfileService().saveMyProfile(storage.getUserId(), this.state.user).subscribe(successs => {
        console.log('rs save ', successs);
        if (successs) {
          const msg = ResourceManager.getString('success_save_my_profile');
          this.loadData();
          this.close();
          this.showInfo(msg);
        } else {
          const msg = ResourceManager.getString('fail_save_my_profile');
          this.showDanger(msg);
        }
      }, err => {
        const msg = ResourceManager.getString('fail_save_my_profile');
        this.showDanger(msg);
      });
    }
  }

  close = () => {
    const { isEditingAbout, isEditingAchievement, isEditingInterest, isEditingSkill, isLookingFor } = this.state;
    if (isEditingAbout) {
      this.setState({ isEditingAbout: !isEditingAbout });
    }
    if (isEditingAchievement) {
      this.setState({
        achievementName: '',
        hightLightAchie: '',
        achievementDes: '',
        isEditingAchievement: !isEditingAchievement,
      });
    }
    if (isEditingInterest) {
      this.setState({
        isEditingInterest: !isEditingInterest,
      });
    }
    if (isEditingSkill) {
      this.setState({
        textSkillsEditing: '',
        isEditingSkill: !isEditingSkill
      });
    }
    if (isLookingFor) {
      this.setState({
        textSkillsEditing: '',
        isLookingFor: !isLookingFor
      });
    }
    this.setState({ isEditing: !this.state.isEditing });
  }

  cancel = () => {
    const { isEditingAbout, isEditingAchievement, isEditingInterest, isEditingSkill, isLookingFor, objectUser } = this.state;
    this.close();
    this.setState({ isEditing: !this.state.isEditing, user: ReflectionUtil.clone(objectUser) });
  }

  removeInterest = (e, subject) => {
    e.preventDefault();
    const { user } = this.state;
    if (user.interests) {
      const interests = user.interests.filter(item => item !== subject);
      user.interests = interests;
      this.setState({ user });
    }
  }


  removeAchievement = (e, subject) => {
    e.preventDefault();
    const { user } = this.state;
    if (user.achievements) {
      const achievements = user.achievements.filter(item => item['subject'] !== subject);
      user.achievements = achievements;
      this.setState({ user });
    }
  }


  addAchievement = (e) => {
    e.preventDefault();
    const achievement: Achievement = new Achievement();
    const { achievementName, achievementDes, hightLightAchie, user } = this.state;
    const achievements = ReflectionUtil.cloneObject(user.achievements);
    achievement.subject = achievementName;
    achievement.description = achievementDes;
    achievement.highlight = hightLightAchie;
    if (achievementName && achievementName.trim().length > 0 && !this.isExistInArray(event, achievements, achievement, 'subject')) {
      achievements.push(achievement);
      user.achievements = achievements;
      this.setState({ user, achievementName: '', achievementDes: '', hightLightAchie: '' });
      const ctrl = this.getControlElement(event);
      ValidationUtil.removeErrorMessage(ctrl);
    }
  }

  addInterestEditing = (event) => {
    event.preventDefault();
    const { interestEdit, user } = this.state;
    const interests = user.interests ? user.interests : [];
    if (interestEdit && interestEdit.trim() !== '') {
      if (!this.isExistInArray(event, interests, interestEdit, '')) {
        interests.push(interestEdit);
        user.interests = interests;
        this.setState({ user });
        const ctrl = this.getControlElement(event);
        ValidationUtil.removeErrorMessage(ctrl);
      }
    }
  }

  addAboutEditing = (event) => {
    event.preventDefault();
    this.updateState(event, function () {
      const { bio, user } = this.state;
      if (bio && bio.trim() !== '') {
        user.bio = bio;
        this.setState({ bio, user });
      }
    });
  }

  removeSkill = (e, skillContent) => {
    e.preventDefault();
    const { user } = this.state;
    user.skills = user.skills.filter(item => item['skill'] !== skillContent);
    this.setState({ user });
  }

  addSkill = (e) => {
    e.preventDefault();
    const { user, textSkillsEditing, newSkillHireable } = this.state;
    const skillsEditing = user.skills ? user.skills : [];
    if (textSkillsEditing && textSkillsEditing.trim() !== '') {
      const item = {
        hirable: newSkillHireable,
        skill: textSkillsEditing
      };
      if (!this.isExistInArray(e, skillsEditing, item, 'skill')) {
        skillsEditing.push(item);
        user.skills = skillsEditing;
        this.setState({ textSkillsEditing, user });
        const ctrl = this.getControlElement(event);
        ValidationUtil.removeErrorMessage(ctrl);
      }
    }
  }


  removeLookingFor = (e, lookingForContent) => {
    e.preventDefault();
    const { user } = this.state;
    user.lookingFor = user.lookingFor.filter(item => item !== lookingForContent);
    this.setState({ user });
  }

  addLookingFor = (e) => {
    e.preventDefault();
    const { user, newLookingFor } = this.state;
    const lookingFor = user.lookingFor ? user.lookingFor : [];
    if (newLookingFor && newLookingFor.trim() !== '') {
      if (!this.isExistInArray(e, lookingFor, newLookingFor, '')) {
        lookingFor.push(newLookingFor);
        user.lookingFor = lookingFor;
        this.setState({ user });
        const ctrl = this.getControlElement(event);
        ValidationUtil.removeErrorMessage(ctrl);
      }
    }
  }


  closeModal = () => {
    this.setState({ modalIsOpen: false });
  }

  saveEmit = (rs) => {
    if (rs.status === 'success' && rs.data) {
      this.setState({ user: ReflectionUtil.clone(rs.data) });
      const msg = ResourceManager.getString('success_save_my_profile');
      this.showInfo(msg);
    } else {
      const msg = ResourceManager.getString('fail_save_my_profile');
      this.showDanger(msg);
    }
  }

  isExistInArray = (event, arr, item, key) => {
    if (!arr || arr.length === 0) {
      return false;
    }
    if (!event) {
      return;
    }
    let isExist = false;
    if (key.length !== 0) {
      isExist = arr.filter(itemFilter => itemFilter[key] === item[key]).length > 0;
    } else {
      isExist = arr.filter(itemFilter => itemFilter === item).length > 0;
    }
    const ctrl = this.getControlElement(event);
    const msg = StringUtil.format(ResourceManager.getString('error_item_exist'), '');
    if (isExist) {
      ValidationUtil.addErrorMessage(ctrl, msg);
      UIUtil.alertError(msg);
    }
    return isExist;
  }

  getControlElement = (event) => {
    const btn = event.currentTarget;
    let ctrl = btn.ownerDocument.activeElement.parentElement.childNodes[0].childNodes[0];
    const childNodes = btn.ownerDocument.activeElement.parentElement.childNodes[1];
    if (childNodes && childNodes.classList && childNodes.classList.contains('btn-add')) { // class btn-add in label
      ctrl = btn.ownerDocument.activeElement.parentElement.childNodes[0];
    }
    return ctrl;
  }

  render() {
    const resource = this.resource;
    const {
      user,
      achievementDes, isEditingAchievement,
      achievementName, hightLightAchie,
      isEditingAbout,
      isEditingInterest,
      isLookingFor,
      isEditing
    } = this.state;
    const { newLookingFor, textSkillsEditing, isEditingSkill } = this.state;
    return (
      <div className='profile view-container'>
        <form id='myProfileForm' name='myProfileForm'>
          <header className='border-bottom-highlight'>
            <picture className='profile-avatar'>
              <img
                src='https://pre00.deviantart.net/6ecb/th/pre/f/2013/086/3/d/facebook_cover_1_by_alphacid-d5zfrww.jpg' />
            </picture>
            <div className='profile-wallpaper-wrapper'>
              <div className='avatar-wrapper'>
                <img className='avatar'
                  src={user.image || 'https://www.bluebridgewindowcleaning.co.uk/wp-content/uploads/2016/04/default-avatar.png'} />
                <img className='profile-status' alt='status' onMouseOver={this.showChangeStatus}
                  src={imageOnline} />
              </div>
              <div className='profile-title'>
                <h3>{user.displayName}</h3>
                <p>{user.website}</p>
              </div>
              <div className='profile-description'>
                <a><i className='fa fa-user-o highlight' /> Followers <span>{user.followerCount || 0}</span></a>
                <a><i className='fa fa-user-o highlight' /> Following <span>{user.followingCount || 0}</span></a>
              </div>
            </div>
          </header>
          <div className='row'>
            <div className='col m12 l4'>
              <div className='card'>
                <header>
                  <i className='fas fa-pencil-ruler highlight' />
                  {resource.user_profile_basic_info}
                  <button type='button' id='btnBasicInfo' name='btnBasicInfo' hidden={isEditing} className='btn-edit'
                    onClick={this.showPopup} />
                </header>
                <p>{user.occupation}</p>
                <p>{user.company}</p>
              </div>
              {!isEditingSkill &&
                <div className='card'>
                  <header>
                    <i className='fas fa-pencil-ruler highlight' />
                    {resource.skills}
                    <button type='button' id='btnSkill' name='btnSkill' hidden={isEditing} className='btn-edit'
                      onClick={this.toggleEditingSkill} />
                  </header>
                  <section>
                    {
                      user.skills && user.skills.map((item, index) => {
                        return <p key={index}>{item.skill}
                          {
                            item.hirable !== '0' && <i className='star highlight' />
                          }
                        </p>;
                      })
                    }
                    <hr />
                    <p className='description'>
                      <i className='star highlight' />
                      {resource.user_profile_hireableSkill}
                    </p>
                  </section>
                </div>
              }
              {isEditingSkill &&
                <div className='card'>
                  <header>
                    <i className='fas fa-pencil-ruler highlight' />
                    {resource.skills}
                    <button type='button' id='btnSkill' name='btnSkill' className='btn-close'
                      onClick={this.toggleEditingSkill} />
                  </header>
                  <section>
                    {
                      user.skills && user.skills.map((item, index) => {
                        return (
                          <div key={index} className='chip'>
                            {item.skill}
                            {item.hirable === true && <i className='star highlight' />}
                            <button type='button' name='btnRemoveSkill' className='close' onClick={(e) => {
                              this.removeSkill(e, item.skill);
                            }} />

                          </div>
                        );
                      })
                    }
                    <label className='form-group inline-input'>
                      <input type='text' id='textSkillsEditing' name='textSkillsEditing'
                        value={textSkillsEditing} onChange={this.updateState}
                        placeholder={resource.placeholder_user_profile_skill} maxLength={50} />
                      <button type='button' id='btnAddSkill' name='btnAddSkill' className='btn-add'
                        onClick={this.addSkill} />
                    </label>
                    <label className='checkbox-container'>
                      <input type='checkbox' id='newSkillHireable' name='newSkillHireable'
                        value={this.state.newSkillHireable} onChange={this.updateState} />
                      {resource.user_profile_hireableSkill}</label>
                    <hr />
                    <p className='description'>
                      <i className='star highlight' />{resource.user_profile_hireableSkill}
                    </p>
                  </section>
                  <footer>
                    <button type='button' id='btnCancelSkill' name='btnCancelSkill' className='btn-cancel' onClick={this.cancel}>
                      {resource.cancel}
                    </button>
                    <button type='button' id='btnSaveSkill' name='btnSaveSkill' onClick={this.saveEditing}>
                      {resource.save}
                    </button>
                  </footer>
                </div>
              }
              {
                !isLookingFor &&
                <div className='card'>
                  <header>
                    <i className='fas fa-pencil-ruler highlight' />
                    {resource.user_profile_looking_for}
                    <button type='button' id='btnLookingFor' name='btnLookingFor'
                      hidden={isEditing && !isLookingFor}
                      className='btn-edit'
                      onClick={this.toggleEditingLookingFor} />
                  </header>
                  <section>
                    {
                      user.lookingFor && user.lookingFor.map((item, index) => {
                        return (<p key={index}>{item}</p>);
                      })
                    }
                  </section>
                </div>
              }
              {isLookingFor &&
                <div className='card'>
                  <header>
                    <i className='fas fa-pencil-ruler highlight' />
                    {resource.user_profile_looking_for}
                    <button type='button' id='btnLookingFor' name='btnLookingFor' className='btn-close'
                      onClick={this.toggleEditingLookingFor} />
                  </header>
                  <section>
                    {
                      user.lookingFor && user.lookingFor.map((item, index) => {
                        return (<div key={index} className='chip' tabIndex={index}>
                          {item}
                          <button type='button' name='btnRemoveLookingFor' className='close'
                            onClick={(e) => this.removeLookingFor(e, item)} />
                        </div>);
                      })
                    }
                    <label className='form-group inline-input'>
                      <input name='newLookingFor' className='form-control'
                        value={newLookingFor} onChange={this.updateState}
                        placeholder={resource.placeholder_user_profile_looking_for} maxLength={100} />
                      <button type='button' name='btnAddLookingFor' className='btn-add' onClick={this.addLookingFor} />
                    </label>
                  </section>
                  <footer>
                    <button type='button' id='btnCancelLookingFor' name='btnCancelLookingFor' className='btn-cancel' onClick={this.cancel}>
                      {resource.cancel}
                    </button>
                    <button type='button' id='btnSaveLookingFor' name='btnSaveLookingFor' onClick={this.saveEditing}>
                      {resource.save}
                    </button>
                  </footer>
                </div>
              }
              <div className='card'>
                <header>
                  <i className='fas fa-comments highlight' />
                  {resource.user_profile_social}
                  <button type='button' id='btnSocial' name='btnSocial' hidden={isEditing} className='btn-edit' onClick={this.showPopup} />
                </header>
                <div>
                  {
                    user.facebookLink &&
                    <a href={'https://facebookcom/' + user.facebookLink} title='facebook' target='_blank'>
                      <i className='fa fa-facebook' />
                      <span>facebook</span>
                    </a>
                  }
                  {
                    user.skypeLink &&
                    <a href={'https://skype.com/' + user.skypeLink} title='Skype' target='_blank'>
                      <i className='fa fa-skype' />
                      <span>Skype</span>
                    </a>
                  }
                  {
                    user.twitterLink &&
                    <a href={'https://twitter.com/' + user.twitterLink} title='Twitter' target='_blank'>
                      <i className='fa fa-twitter' />
                      <span>Twitter</span>
                    </a>
                  }
                  {
                    user.instagramLink &&
                    <a href={'https://instagram.com/' + user.instagramLink} title='Instagram' target='_blank'>
                      <i className='fa fa-instagram' />
                      <span>Instagram</span>
                    </a>
                  }
                  {
                    user.linkedinLink &&
                    <a href={'https://linkedin.com/' + user.linkedinLink} title='Linked in' target='_blank'>
                      <i className='fa fa-linkedin' />
                      <span>Linked in</span>
                    </a>
                  }
                  {
                    user.googleLink &&
                    <a href={'https://plus.google.com/' + user.googleLink} title='Google' target='_blank'>
                      <i className='fa fa-google' />
                      <span>Google</span>
                    </a>
                  }
                  {
                    user.dribbbleLink &&
                    <a href={'https://dribbble.com/' + user.dribbbleLink} title='dribbble' target='_blank'>
                      <i className='fa fa-dribbble' />
                      <span>dribbble</span>
                    </a>
                  }

                  {
                    user.customLink01 &&
                    <a href={user.customLink01} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink02 &&
                    <a href={user.customLink02} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink03 && <a href={user.customLink03} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink04 && <a href={user.customLink04} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink05 && <a href={user.customLink05} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink06 && <a href={user.customLink06} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink07 && <a href={user.customLink07} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                  {
                    user.customLink08 && <a href={user.customLink08} target='_blank'>
                      <i className='fab fa-globe-asia' />
                    </a>
                  }
                </div>
              </div>
            </div>

            <div className='col m12 l8'>
              <div className='card border-bottom-highlight'>
                <header>
                  <i className='fas fa-user-alt highlight' />
                  {resource.user_profile_bio}
                  <button type='button' id='btnBio' name='btnBio'
                    hidden={isEditing && !isEditingAbout}
                    className={(!isEditingAbout ? 'btn-edit' : 'btn-close')}
                    onClick={this.toggleEditModeAbout} />
                </header>
                {!isEditingAbout &&
                  <p>{user.bio}</p>}
                {isEditingAbout &&
                  <textarea onChange={this.addAboutEditing} name='bio' value={user.bio} />
                }
                {isEditingAbout &&
                  <footer>
                    <button type='button' id='btnCancelBio' name='btnCancelBio' className='btn-cancel'
                      onClick={this.cancel}>
                      {resource.cancel}
                    </button>
                    <button type='button' id='btnSaveBio' name='btnSaveBio' onClick={this.saveEditing}>
                      {resource.save}
                    </button>
                  </footer>
                }
              </div>

              {
                <div className='card border-bottom-highlight'>
                  <header>
                    <i className='fas fa-bolt highlight' />
                    {resource.interests}
                    <button type='button' id='btnInterest' name='btnInterest'
                      hidden={isEditing && !isEditingInterest}
                      className={(!isEditingInterest ? 'btn-edit' : 'btn-close')}
                      onClick={this.toggleEditModeInterest} />
                  </header>
                  {!isEditingInterest &&
                    <section className='row'>
                      {
                        user.interests && user.interests.map((item, index) => {
                          return (<span key={index} className='col s4'>{item}</span>);
                        })
                      }
                    </section>
                  }

                  {isEditingInterest &&
                    <section className='row'>
                      {user.interests && user.interests.map((item, index) => {
                        return (<div key={index} className='chip' tabIndex={index}>{item}
                          <button type='button' name='btnRemoveInterest' className='close'
                            onClick={(e) => this.removeInterest(e, item)} />
                        </div>);
                      })
                      }
                      <label className='col s12 inline-input'>
                        <input type='text' name='interestEdit' onChange={this.updateState}
                          placeholder={resource.placeholder_user_profile_interest} maxLength={100} />
                        <button type='button' id='btnAddInterest' name='btnAddInterest' className='btn-add'
                          onClick={this.addInterestEditing} />
                      </label>
                    </section>
                  }
                  {isEditingInterest &&
                    <footer>
                      <button type='button' id='btnCancelInterest' name='btnCancelInterest' className='btn-cancel'
                        onClick={this.cancel}>
                        {resource.cancel}
                      </button>
                      <button type='button' id='btnSaveInterest' name='btnSaveInterest' onClick={this.saveEditing}>
                        {resource.save}
                      </button>
                    </footer>}
                </div>
              }

              <div className='card border-bottom-highlight'>
                <header>
                  <i className='fas fa-award highlight' />
                  {resource.achievements}
                  <button type='button' id='btnAchievement' name='btnAchievement'
                    hidden={isEditing && !isEditingAchievement}
                    className={!isEditingAchievement ? 'btn-edit' : 'btn-close'}
                    onClick={this.toggleEditModeAchievement} />
                </header>
                {
                  !isEditingAchievement && user.achievements && user.achievements.map((achieve, index) => {
                    return <section key={index}>
                      <h3>{achieve.subject}
                        {achieve.highlight !== false &&
                          <i className='star highlight float-right' />}
                      </h3>
                      <p className='description'>{achieve.description}</p>
                      <hr />
                    </section>;
                  })
                }
                {
                  isEditingAchievement && user.achievements && user.achievements.map((achieve, index) => {
                    return <section key={index}>
                      <h3>{achieve.subject}
                        {achieve.highlight !== false &&
                          <i className='star highlight' />}
                      </h3>
                      <p className='description'>{achieve.description}</p>
                      <button type='button' className='btn-remove'
                        onClick={(e) => this.removeAchievement(e, achieve.subject)} />
                      <hr />
                    </section>;
                  })
                }

                {isEditingAchievement &&
                  <section>
                    <div className='form-group'>
                      <input type='text' name='achievementName' className='form-control'
                        value={achievementName} onChange={this.updateState}
                        placeholder={resource.placeholder_user_profile_achievement_name} maxLength={50} required={true} />
                      <input type='text' name='achievementDes' className='form-control'
                        value={achievementDes} onChange={this.updateState}
                        placeholder={resource.placeholder_user_profile_achievement_description} maxLength={100} required={true} />
                    </div>
                    <label className='checkbox-container'>
                      <input type='checkbox' id='hightLightAchie' name='hightLightAchie'
                        value={hightLightAchie} onChange={this.updateState} />
                      {resource.user_profile_highlight_achievement}
                    </label>
                    <div className='btn-group'>
                      <button type='button' id='btnAddAchievement' name='btnAddAchievement' className='btn-add'
                        onClick={this.addAchievement} />
                      {resource.button_add_achievement}
                    </div>
                  </section>
                }
                {isEditingAchievement &&
                  <footer>
                    <button type='button' id='btnCancelAchievement' name='btnCancelAchievement' className='btn-cancel'
                      onClick={this.cancel}>
                      {resource.cancel}
                    </button>
                    <button type='button' id='btnSaveAchievement' name='btnSaveAchievement'
                      onClick={this.saveEditing}>
                      {resource.save}
                    </button>
                  </footer>
                }
              </div>
            </div>
          </div>
        </form>
        <Modal
          isOpen={this.state.modalIsOpen}
          onRequestClose={this.closeModal}
          contentLabel='Modal'
          portalClassName='modal-portal'
          className='modal-portal-content'
          bodyOpenClassName='modal-portal-open'
          overlayClassName='modal-portal-backdrop'
        >
          <GeneralInfo history={this.props.history}
            resource={resource}
            close={this.closeModal}
            saveEmit={this.saveEmit}
            user={user} location={this.props.location} />
        </Modal>
      </div>
    );
  }
}
