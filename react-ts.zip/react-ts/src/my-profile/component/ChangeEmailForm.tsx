import * as React from 'react';
import {connect} from 'react-redux';
import {compose} from 'redux';
import {getFormValues, InjectedFormProps, reduxForm} from 'redux-form';
import {BaseComponent, BaseInternalState, HistoryProps, StringUtil} from '../../core';
import {UserSettings} from '../../shared/user-model';
import applicationContext from '../config/ApplicationContext';

interface ReduxProps {
  userSettings: UserSettings;
}

type InternalState = BaseInternalState;

class ChangeEmailForm extends BaseComponent<HistoryProps & InjectedFormProps & ReduxProps, InternalState> {
  constructor(props) {
    super(props);
    this.state = {
      message: ''
    };
  }

  private myProfileService = applicationContext.getMyProfileService();

  saveOnClick = (e) => {
    e.preventDefault();
    this.hideMessage();

    const currentEmail = this.state.currentEmail;
    const newEmail = this.state.newEmail;
    const password = this.state.password;

    if (StringUtil.isEmpty(currentEmail)) {
      return this.showMessage('current email is required');
    } else if (StringUtil.isEmpty(newEmail)) {
      return this.showMessage('new email is required');
    } else if (currentEmail.toLowerCase().trim() === newEmail.toLowerCase().trim()) {
      return this.showMessage('current email and new email same');
    } else if (StringUtil.isEmpty(password)) {
      return this.showMessage('password is required');
    }

    this.myProfileService.changeEmail(currentEmail, newEmail, password).subscribe(res => {
      this.showMessage(res);
    }, err => console.log(err));
  }

  render() {
    const resource = this.resource;
    return (
      <div className='view-container'>
        <form id='signinForm' name='signinForm' noValidate={true} autoComplete='off'>
          <div className='row justify-content-center'>
            <div className='col'>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='currentEmail'>{resource.current_email}</label>
                  <input type='text' className='form-control'
                         id='currentEmail' name='currentEmail'
                         value={this.state.currentEmail}
                         onChange={this.updateState}
                         maxLength={255} required={true}
                         placeholder={resource.placeholder_user_name}/>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='newEmail'>{resource.new_email}</label>
                  <input type='text' className='form-control'
                         id='newEmail' name='newEmail'
                         value={this.state.newEmail}
                         onChange={this.updateState}
                         maxLength={255} required={true}
                         placeholder={resource.placeholder_user_name}/>
                </div>
              </div>
              <div className='row'>
                <div className='col form-group'>
                  <label htmlFor='password'>{resource.current_password}</label>
                  <input type='password' className='form-control'
                         id='password' name='password'
                         value={this.state.password}
                         onChange={this.updateState}
                         maxLength={255} required={true}
                         placeholder={resource.placeholder_password}/>
                </div>
              </div>
              <div className='row'>
                <div className='col message'>
                  {this.state.message === '' || this.state.message === null ? '' :
                    <div className={this.alertClass}>
                      <a onClick={this.hideMessage} className='alert-ms close ' data-dismiss='alert'>
                        <i className='fa fa-window-close' aria-hidden='true'/>
                      </a>
                      {this.state.message}
                    </div>
                  }
                </div>
              </div>
              <div className='row'>
                <div className='col center'>
                  <button type='submit' className='btn btn-primary'
                          id='btnSignin' name='btnSignin'
                          onClick={this.saveOnClick}>{resource.button_change_email}</button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    );
  }
}

function mapStateToProps(state): ReduxProps {
  return {
    userSettings: getFormValues('ChangeEmailForm')(state) as UserSettings || {} as UserSettings,
  };
}

function mapDispatchToProps(state) {
  return {};
}


const withConnect = connect(mapStateToProps, mapDispatchToProps);


const ChangeEmail = compose(withConnect, reduxForm<{}>({
  form: 'ChangeEmailForm',
}))(ChangeEmailForm);
export default ChangeEmail;
