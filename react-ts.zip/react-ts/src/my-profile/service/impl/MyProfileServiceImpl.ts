import {Observable} from 'rxjs';
import config from '../../../config';
import {GenericSearchWebService, SearchModel, WebClientUtil} from '../../../core';
import {User, UserSettings, userSettingsModel} from '../../../shared/user-model';
import {MyProfileService} from '../MyProfileService';

export class MyProfileServiceImpl extends GenericSearchWebService<User, SearchModel>  implements MyProfileService {
  constructor() {
    super(config.myprofileServiceUrl, userSettingsModel);
  }

  serviceUrl = config.myprofileServiceUrl;

  getMyProfile(userId: string): Observable<User> {
    const url = this.serviceUrl + '/myprofile/' + userId;
    return WebClientUtil.getObject<User>(url);
  }

  saveMyProfile(userId: string, user: User): Observable<boolean> {
    const url = this.serviceUrl + '/saveMyProfile/' + userId;
    return WebClientUtil.putObject(url, user);
  }

  getMySettings(userId): Observable<UserSettings> {
    const url = this.serviceUrl + '/mysettings/' + userId;
    return WebClientUtil.getObject<UserSettings>(url);
  }

  saveMySettings(userId: string, settings: UserSettings): Observable<boolean> {
    const url = this.serviceUrl + '/mysettings/' + userId;
    return WebClientUtil.putObject(url, settings);
  }

  changeEmail(currentEmail: string, newEmail: string, password: string): Observable<boolean> {
    const url = this.serviceUrl + '/changeEmail';
    const obj = {currentEmail, newEmail, password};
    return WebClientUtil.putObject(url, obj);
  }

  addEmail(email: string, password: string): Observable<boolean> {
    const url = this.serviceUrl + '/addEmail';
    const obj = {email, password};
    return WebClientUtil.putObject(url, obj);
  }
}
