import {Observable} from 'rxjs';
import {User, UserSettings} from '../../shared/user-model';

export interface MyProfileService {
  getMyProfile(userId: string): Observable<User>;
  saveMyProfile(userId: string, user: User): Observable<boolean>;

  getMySettings(userId): Observable<UserSettings>;
  saveMySettings(userId: string, settings: UserSettings): Observable<boolean>;
  changeEmail(currentEmail: string, newEmail: string, password: string): Observable<boolean>;
  addEmail(email: string, password: string): Observable<boolean>;
}
