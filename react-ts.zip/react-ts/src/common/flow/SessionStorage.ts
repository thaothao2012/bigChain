import {Storage} from './Storage';

export class SessionStorage implements Storage {
  get<T>(key: string): T {
    const item = sessionStorage.getItem(key);
    if (!item) {
      return null;
    } else {
      return JSON.parse(item);
    }
  }

  put<T>(key: string, obj: T) {
    if (!obj) {
      sessionStorage.removeItem(key);
    } else {
      sessionStorage.setItem(key, JSON.stringify(obj));
    }
  }

  delete(key: string) {
    sessionStorage.removeItem(key);
  }
}
