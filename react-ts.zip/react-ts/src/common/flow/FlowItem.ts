import {Language} from '../Language';
import {Flow} from './Flow';
import {FormConfig} from './FormConfig';

export interface FlowItem<T> {
  init();
  loadData();
  accept(event);
  back(event);
  cancel(event);

  getFlowId(): string;
  getFlow(): Flow;
  getFormConfig(): FormConfig;

  getEnv(): any;
  getLanguage(): Language;

  getFromStorage<K>(key: string): K;
  saveToStorage<K>(key: string, obj: K);
  removeFromStorage(key: string);
}
