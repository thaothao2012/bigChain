import * as moment from 'moment';
import 'moment/locale/th';
import {BaseInternalState} from '../component/BaseInternalState';
import {HistoryProps} from '../component/HistoryProps';
import {ComponentStateUtil} from '../config/ComponentStateUtil';
import {ResourceManager} from '../ResourceManager';
import {storage} from '../storage';
import {LoadingUtil} from '../util/LoadingUtil';
import {FirstFlowItem} from './FirstFlowItem';
import {FlowInitializer} from './FlowInitializer';
import {FlowItemComponent} from './FlowItemComponent';
import {FlowService} from './FlowService';

export class FirstFlowItemComponent<T, W extends HistoryProps, I extends BaseInternalState> extends FlowItemComponent<T, W, I> implements FirstFlowItem {
  constructor(props) {
    super(props);
  }

  isLoadedInitData(): boolean {
    try {
      const initData = this.getInitData();
      if (initData) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      return false;
    }
  }

  isFlowInitialized(): boolean {
    const flow = this.getFlow();
    if (flow && flow.storage) {
      return true;
    } else {
      return false;
    }
  }

  getFlowInitializer(): FlowInitializer {
    throw new Error('Method not implemented.');
  }

  getFlowService(): FlowService {
    throw new Error('Method not implemented.');
  }

  init() {
    if (this.isFlowInitialized()) {
      const formConfig = this.getFormConfig();
      if (this.form && formConfig) {
        ComponentStateUtil.handleFormByConfig(this.form, formConfig.components, null);
      }
      try {
        this.loadData();
      } catch (error) {
        this.handleReportError(error);
      }
    } else {
      LoadingUtil.hideLoading();
      const flowService = this.getFlowService();
      const flowId = this.getFlowId();

      const initStorage = {};

      const subscribeFlow = flowService.getFlow(flowId).subscribe(flow => {
        flow.storage = initStorage;
        if (!flow.storage) {
          flow.storage = {};
        }
        if (!flow.env) {
          flow.env = {};
        }
        moment.locale(flow.env.locale);
        ResourceManager.setResource(flow.env.locale);
        this.resource = ResourceManager.getResource();
        storage.setFlow(flowId, flow);
        const initializer = this.getFlowInitializer();
        const subscribeInitializer = initializer.initialize().subscribe(res => {
          try {
            const store = this.getFlow().storage;
            const keys = Object.keys(res);
            for (const key of keys) {
              store[key] = res[key];
              // store.put(key, res[key]);
            }
            this.initFormConfig(this.getFormName());
            const formConfig = this.getFormConfig();
            if (this.form && formConfig) {
              ComponentStateUtil.handleFormByConfig(this.form, formConfig.components, null);
            }
            this.loadData();
            LoadingUtil.setIsFirstTime(false);
          } catch (error) {
            this.handleReportError(error);
          }
        }, err => this.handleError(err));
        this.addSubscribeid(subscribeInitializer);
      }
        , err0 => this.handleError(err0)
      );
      this.addSubscribeid(subscribeFlow);
    }
  }

  protected addSubscribeid(subscribeid: any) {
    if (!this.subscribeid) {
      this.subscribeid = [];
    }
    this.subscribeid.push(subscribeid);
  }
}
