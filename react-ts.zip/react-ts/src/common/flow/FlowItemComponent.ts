import {BaseComponent} from '../component/BaseComponent';
import {BaseInternalState} from '../component/BaseInternalState';
import {HistoryProps} from '../component/HistoryProps';
import {ComponentStateUtil} from '../config/ComponentStateUtil';
import {InitModel} from '../InitModel';
import {Language} from '../Language';
import {NativeFunction} from '../native/NativeFunction';
import {storage} from '../storage';
import {LoadingUtil} from '../util/LoadingUtil';
import {ValidationUtil} from '../util/ValidationUtil';
import {Flow} from './Flow';
import {FlowItem} from './FlowItem';
import {FormConfig} from './FormConfig';

export class FlowItemComponent<T, W extends HistoryProps, I extends BaseInternalState> extends BaseComponent<W, I> implements FlowItem<T> {
  constructor(props) {
    super(props);
    this._flowId = this.props.match.params['flow'];
    this.formName = this.getFormNameFromPath(this.props.match.path);
    if (this.formName != null) {
      this.initFormConfig(this.formName);
    }
    this.getFlowId = this.getFlowId.bind(this);
    this.getFlow = this.getFlow.bind(this);
    this.getFormConfig = this.getFormConfig.bind(this);
    this.getFullState = this.getFullState.bind(this);
    this.accept = this.accept.bind(this);
    this.validateAndSave = this.validateAndSave.bind(this);
    this.save = this.save.bind(this);
    this.back = this.back.bind(this);
    this.closeWebForm = this.closeWebForm.bind(this);
    this.cancel = this.cancel.bind(this);
  }

  private rootPath = 'common-auth/';
  private _flowId: string;
  private formConfig: FormConfig;
  private formName: string;
  protected reportService = null;

  protected initFormConfig(formName: string) {
    const flow = this.getFlow();
    if (flow) {
      for (const form of flow.forms) {
        if (form.name === formName) {
          this.formConfig = form;
          break;
        }
      }
    }
  }

  protected getFormName(): string {
    return this.formName;
  }

  private getFormNameFromPath(path: string) {
    const i = path.indexOf(this.rootPath);
    if (i >= 0) {
      const j = path.indexOf('/', i + this.rootPath.length);
      if (j > 0) {
        return path.substring(i + this.rootPath.length, j);
      }
    }
    return null;
  }

  init() {
    const formConfig = this.getFormConfig();
    if (this.form && formConfig) {
      ComponentStateUtil.handleFormByConfig(this.form, formConfig.components, null);
    }
    try {
      this.loadData();
    } catch (error) {
      this.handleReportError(error);
    }
  }

  getInitData() {
    return storage.getInitModel();
  }

  getFlowId() {
    return this._flowId;
  }

  getFlow(): Flow {
    const flowId = this.getFlowId();
    const flow = storage.getFlow(flowId);
    return flow;
  }

  getFormConfig(): FormConfig {
    return this.formConfig;
  }

  getEnv(): any {
    const flow = this.getFlow();
    if (flow && flow.env) {
      return flow.env;
    } else {
      return {};
    }
  }

  getLanguage(): Language {
    const model = storage.getInitModel();
    if (model) {
      if (model.language === ''
          || model.language === 'th' || model.language === 'TH'
          || model.language === 't' || model.language === 'T') {
        return Language.Thai;
      }
    }
    return Language.English;
  }

  handleReportError(error) {
    this.reportService.sendReport(error.toString()).subscribe(() => {
       this.handleError(error);
    }, err => this.handleError(err));
  }

  validateAndSave(event) {
    event.preventDefault();
    try {
      const valid = ValidationUtil.validateForm(this.form, true);
      if (valid) {
        this.save(event);
      }
    } catch (error) {
      this.handleReportError(error);
    }
  }

  save(event) {

  }

  accept(event) {
    event.preventDefault();
    try {
      const formConfig = this.getFormConfig();
      if (!!formConfig && !!formConfig.acceptState) {
        const nextState = this.getFullState(formConfig.acceptState);
        this.props.history.push(nextState);
      }
    } catch (error) {
      this.handleReportError(error);
    }
  }

  protected getFullState(state: string): string {
    return '/' + this.rootPath + state + '/' + this.getFlowId();
  }
  protected getFullStateWithParam(state: string, parameter: string): string {
    return '/' + this.rootPath + state + '/' + this.getFlowId() + '/' + parameter;
  }

  back(event) {
    event.preventDefault();
    this.props.history.goBack();
  }

  cancel(event) {
    event.preventDefault();
    const resource = this.resource;
    this.confirm(resource.modal_confirm_content,
      () => this.closeWebForm('user_cancel'), () => {});
  }

  closeWebForm(status?: string) {
    try {
      const initData = this.getInitData();
      NativeFunction.closeWeb({osPlatform: initData.os, backToRoot: '', status, menuCode: ''});
    } catch (error) {
      this.handleReportError(error);
    }
  }

  updateResultResponse() {
    try {
      const initData = this.getInitData();
      NativeFunction.updateResultResponse({
        osPlatform: initData.os,
        sender: 'CANCEL_TOKEN',
        code: '200',  // response code
        desc: 'failure',  // response desc
        freeText: ''
      });
    } catch (error) {
      this.handleReportError(error);
    }
  }

  getFromStorage<K>(key: string): K {
    return this.getFlow().storage[key];
  }
  saveToStorage<K>(key: string, obj: K) {
    try {
      this.getFlow().storage[key] = obj;
      return true;
    } catch (error) {
      this.handleReportError(error);
      return false;
    }
  }
  removeFromStorage(key: string) {
    delete this.getFlow().storage[key];
  }
}
