import {Observable} from 'rxjs';
import {Flow} from './Flow';

export interface FlowService {
  getFlow(id: string): Observable<Flow>;
}
