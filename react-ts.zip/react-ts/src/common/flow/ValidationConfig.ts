export interface ValidationConfig {
  name: string;
  pattern?: string;
  patternModifier?: string;
  errorKey: string;
}
