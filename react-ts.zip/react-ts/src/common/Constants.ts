export const GLOBAL_STATE = 'globalState';
export const FORM_DATA_STATE = 'formDataState';
