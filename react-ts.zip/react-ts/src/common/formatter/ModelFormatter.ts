export interface ModelFormatter<T, K> {
  format(obj: T): K;
}
