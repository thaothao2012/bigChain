export interface Formatter<T> {
  format(obj: T): string;
}
