import {Language} from '../Language';

export interface LocaleFormatter<T> {
  format(obj: T, locale: Language): string;
}
