export interface ArrayFormatter<T> {
  format(obj: T): any[];
}
