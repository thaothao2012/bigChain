export enum AcceptTerms {
  Accept = 'Y',
  NotAccept = 'N'
}