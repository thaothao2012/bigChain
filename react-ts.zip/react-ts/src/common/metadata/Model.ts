export interface Model {
  name: string;
  attributes: any;
  modelAttributes?: any;
  sourceName?: string;
}
