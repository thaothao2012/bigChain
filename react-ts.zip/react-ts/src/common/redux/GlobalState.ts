export interface GlobalState<G> {
  globalState: G;
}
