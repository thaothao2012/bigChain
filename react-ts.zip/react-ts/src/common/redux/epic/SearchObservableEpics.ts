import {ofType} from 'redux-observable';
import {throwError} from 'rxjs';
import {catchError, map, mergeMap} from 'rxjs/operators';
import {SearchModel} from '../../model/SearchModel';
import {SearchService} from '../../service/SearchService';
import {BaseActionType} from '../action/BaseActionType';
import {SearchActionType} from '../action/SearchActionType';

export class SearchObservableEpics<T, S extends SearchModel> {
  constructor(private searchActionType: SearchActionType, private genericSearchService: SearchService<T, S>) {
    this.search.bind(this);
  }

  search = action$ => action$.pipe(
    ofType(this.searchActionType.searchType),
    mergeMap((action: any) => {
      const { s, callback } = action.payload;
      return this.genericSearchService.search(s).pipe(
        map((list) => {
          callback(s, list);
          return ({
            type: BaseActionType.ACTION_SUCCESS
          });
        }),
        catchError((error) => throwError(error))
      );
    })
  )
}
