export interface SearchActionType {
  searchType: string;
}
