export interface ReducerActionType<T> {
  type: T;
}
