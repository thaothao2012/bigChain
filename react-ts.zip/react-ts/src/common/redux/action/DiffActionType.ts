export interface DiffActionType {
  checkDiff: string;
}
