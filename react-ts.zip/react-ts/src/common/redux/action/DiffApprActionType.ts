import {ApprActionType} from './ApprActionType';
import {DiffActionType} from './DiffActionType';

export interface DiffApprActionType extends DiffActionType, ApprActionType {

}
