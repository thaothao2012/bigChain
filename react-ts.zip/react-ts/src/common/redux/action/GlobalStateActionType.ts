export enum GlobalStateActionType {
  INIT_DATA            = 'INIT_DATA',
  UPDATE_GLOBAL_STATE  = 'UPDATE_GLOBAL_STATE',
  REMOVE_GLOBAL_STATE  = 'REMOVE_GLOBAL_STATE'
}
