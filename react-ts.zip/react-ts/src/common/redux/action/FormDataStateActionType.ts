export enum FormDataStateActionType {
  SET_FORM_DATA    = 'SET_FORM_DATA',
  UPDATE_FORM_DATA = 'UPDATE_FORM_DATA',
}
