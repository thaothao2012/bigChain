export interface ApprActionType {
  approveType: string;
  rejectType: string;
}
