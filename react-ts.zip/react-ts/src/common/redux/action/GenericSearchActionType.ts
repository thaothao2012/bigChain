import {GenericActionType} from './GenericActionType';
import {SearchActionType} from './SearchActionType';

export interface GenericSearchActionType extends GenericActionType, SearchActionType {

}
