export enum BaseActionType {
  ACTION_SUCCESS                    = 'ACTION_SUCCESS',
}
