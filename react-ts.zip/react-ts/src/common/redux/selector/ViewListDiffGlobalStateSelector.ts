import {createSelector} from 'reselect';
import {DiffModel} from '../../model/DiffModel';
import {GlobalState} from '../GlobalState';
import {ViewListGlobalStateSelector} from './ViewListGlobalStateSelector';

export class ViewListDiffGlobalStateSelector<G, T> extends ViewListGlobalStateSelector<G, T> {
  constructor(formName: string, listFormName: string, protected diffFormName: string) {
    super(formName, listFormName);
  }

  public selectDiff = createSelector<GlobalState<G>, any, DiffModel<T>>(
    this.selectGlobalState,
    (globalState: any) => {
      if (globalState) {
        const diff = globalState[this.diffFormName];
        if (diff) {
          const result = {
            entityId: diff.entityId || '',
            oldValue: diff.oldValue,
            newValue: diff.newValue,
          };
          return result;
        }
      }
      return new DiffModel();
    }
  );
}
