import {createSelector} from 'reselect';
import {DiffModel} from '../../model/DiffModel';
import {GlobalState} from '../GlobalState';
import {GlobalStateSelector} from './GlobalStateSelector';

export class DiffSelector<G, T> extends GlobalStateSelector<G> {
  constructor(protected diffFormName: string) {
    super();
  }

  public selectDiff = createSelector<GlobalState<G>, any, DiffModel<T>>(
    this.selectGlobalState,
    (globalState: any) => {
      if (globalState) {
        const diff = globalState[this.diffFormName];
        if (diff) {
          const result = {
            entityId: diff.entityId || '',
            oldValue: diff.oldValue,
            newValue: diff.newValue,
          };
          return result;
        }
      }
      return new DiffModel();
    }
  );
}
