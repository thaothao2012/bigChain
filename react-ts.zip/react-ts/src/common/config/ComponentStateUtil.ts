import {ValidationConfig} from '../flow/ValidationConfig';
import {ComponentConfig} from './ComponentConfig';
import {State} from './State';

export class ComponentStateUtil {
  public static handleFormByConfig(form, rootConfigs: ComponentConfig[], patternConfigs: ValidationConfig[]): ComponentConfig[] {
    const u: ComponentConfig[] = [];
    if (!form || !rootConfigs || rootConfigs.length === 0) {
      return u;
    }
    const requiredConfigs: ComponentConfig[] = [];
    const configs: ComponentConfig[] = [];
    for (const config of rootConfigs) {
      if (config.state === State.Required) {
        requiredConfigs.push(config);
      } else {
        configs.push(config);
      }
    }
    this.handleRequiredConfigs(form, requiredConfigs);
    this.handlePatternConfigs(form, patternConfigs);

    const len = form.length;
    for (const config of configs) {
      let handled = false;
      for (let i = 0; i < len; i++) {
        const ctrl = form[i];
        if (ctrl.name === config.name || config.name === ctrl.getAttribute('data-field')) {
          this.handleComponentByConfig(ctrl, config);
          handled = true;
        }
      }
      if (handled === false) {
        u.push(config);
      }
    }
    if (u.length > 0) {
      const allDataFields = this.getAllDataFields(form);
      if (allDataFields && allDataFields.length > 0) {
        form.dataFields = allDataFields;
      }
      const u2: ComponentConfig[] = [];
      for (const config of u) {
        const field = this.getDataField(config, allDataFields);
        if (field != null) {
          this.handleComponentByConfig(field, config);
        } else {
          u2.push(config);
        }
      }
      return u2;
    } else {
      return u;
    }
  }

  private static handlePatternConfigs(form, patternConfigs: ValidationConfig[]) {
    if (!form || !patternConfigs) {
      return;
    }
    const len = form.length;
    for (const config of patternConfigs) {
      if (config.pattern) {
        for (let i = 0; i < len; i++) {
          const ctrl = form[i];
          if (ctrl.name === config.name || config.name === ctrl.getAttribute('data-field')) {
            ctrl.setAttribute('config-pattern', config.pattern);
            ctrl.setAttribute('config-pattern-modifier', config.patternModifier || 'g');
            ctrl.setAttribute('config-pattern-error-key', config.errorKey);
          }
        }
      }
    }
  }

  public static handleRequiredConfigs(form, configs: ComponentConfig[]) {
    const len = form.length;
    for (const config of configs) {
      for (let i = 0; i < len; i++) {
        const ctrl = form[i];
        if (ctrl.name === config.name || config.name === ctrl.getAttribute('data-field')) {
          ctrl.setAttribute('config-required', 'true');
        }
      }
    }
  }

  private static getAllDataFields(form): any[] {
    let results = [];
    const attributeValue = form.getAttribute('data-field');
    if (attributeValue && attributeValue.length > 0) {
      results.push(form);
    }
    const childNodes = form.childNodes;
    if (childNodes.length > 0) {
      for (const childNode of childNodes) {
        if (childNode.nodeType === Node.ELEMENT_NODE) {
          results = results.concat(this.getAllDataFields(childNode));
        }
      }
    }
    return results;
  }

  private static getDataField(config: ComponentConfig, fields): any {
    const len = fields.length;
    for (let i = 0; i < len; i++) {
      const dataField = fields[i].getAttribute('data-field');
      if (dataField === config.name) {
        return fields[i];
      }
    }
    return null;
  }

  public static handleComponentByConfig(com, config: ComponentConfig) {
    const nodeName = com.nodeName;
    const parent = com.parentElement;
    if (config.state === State.Hidden) {
      if ((nodeName === 'INPUT' || nodeName === 'SELECT') && parent.nodeName === 'LABEL'
          || nodeName === 'SPAN' && (parent.nodeName === 'P' || parent.nodeName === 'ADDRESS')) {
        parent.style.display = 'none';
      } else if (nodeName === 'BUTTON' && parent.nodeName === 'SECTION') {
        com.style.visibility = 'hidden';
      } else {
        com.style.display = 'none';
      }
    } else if (config.state === State.Readonly) {
      if (nodeName === 'SECTION' || nodeName === 'FIELDSET' || nodeName === 'DIV' || nodeName === 'FORM' ) {
        this.handleContainerByConfig(com, config);
      } else {
        this.handleControlByConfig(com, config);
      }
    }
  }

  public static handleContainerByConfig(com, config: ComponentConfig) {
    const fields = com.querySelectorAll('input, select, checkbox, radio, submit, button');
    const len = fields.length;
    for (let i = 0; i < len; i++) {
      const field = fields[i];
      this.handleControlByConfig(field, null);
    }
  }

  public static handleControlByConfig(com, config: ComponentConfig) {
    const nodeName = com.nodeName;
    if (nodeName !== 'INPUT') {
      com.disabled = true;
    } else {
      let type = com.getAttribute('type');
      if (type != null) {
        type = type.toLowerCase();
      }
      if (type === 'checkbox'
          || type === 'radio'
          || type === 'submit'
          || type === 'button'
          || type === 'reset') {
        com.disabled = true;
      } else {
        com.readOnly = true;
      }
    }
  }
}
