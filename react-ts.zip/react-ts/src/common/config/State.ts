export enum State {
  Required = 'required',
  Normal = 'normal',
  Readonly = 'readonly',
  Hidden = 'hidden'
}
