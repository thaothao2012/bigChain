export class StringFormat {
  texts: string[];
  parameters: string[];
}
