import {Language} from '../../Language';
import {MessageModel} from '../MessageModel';
import {ResourceLoader} from '../ResourceLoader';
import {BaseMessageManager} from './BaseMessageManager';

export class DefaultMessageManager extends BaseMessageManager {
  constructor(private resourceLoader: ResourceLoader<MessageModel>) {
    super();
  }

  getRawMessage(msgId: string, locale: Language): MessageModel {
    return this.resourceLoader.load(msgId, locale);
  }

  getRawText(msgId: string, locale: Language): string {
    const messageModel = this.getRawMessage(msgId, locale);
    if (messageModel == null) {
      return '';
    }
    return messageModel.rawMsg.get('MESSAGE');
  }

  refresh() {
    // TODO: implement latter to clean cache
  }

}
