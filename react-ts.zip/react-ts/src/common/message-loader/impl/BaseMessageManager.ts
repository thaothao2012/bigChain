import {Language} from '../../Language';
import {MessageManager} from '../MessageManager';
import {MessageModel} from '../MessageModel';
import {StringFormat} from './StringFormat';

export abstract class BaseMessageManager implements MessageManager {
  protected static readonly THAI = 'T';
  protected static readonly ENG = 'E';
  protected static readonly CHINESE = 'C';

  private _cacheFormats: Map<string, StringFormat> = new Map<string, StringFormat>();

  private keys: string[] = null;

  abstract getRawMessage(msgId: string, locale: Language): MessageModel;

  abstract getRawText(msgId: string, locale: Language): string;

  abstract refresh();

  getInitialKeys(): string[] {
    return this.keys;
  }

  setInitialKeys(keys: string[]) {
    this.keys = keys;
  }

  getMessage(msgId: string, locale: Language, params: object): MessageModel {
    const model = this.getRawMessage(msgId, locale);
    model.formattedMsg = new Map<string, string>();

    model.rawMsg.forEach((value, key) => {
      const format = this.getStringFormat(value);
      if (params instanceof Map) {
        model.formattedMsg.set(key, this.mergeStringFormatWithMap(format, params));
      } else {
        model.formattedMsg.set(key, this.mergeStringFormat(format, params));
      }
    });
    return model;
  }

  protected getStringFormat(str: string): StringFormat {
    let format = this._cacheFormats.get(str);
    if (!format) {
      format = this.buildFormat(str);
      this._cacheFormats.set(str, format);
    }
    return format;
  }

  private buildFormat(str: string): StringFormat {
    const strs: string[] = [];
    const parameters: string[] = [];
    let from = 0;
    let from2 = 0;
    let i: number;
    let j: number;

    while (true) {
      i = str.indexOf('#', from2);
      if (i >= 0) {
        j = str.indexOf('#', i + 1);
        if (j >= 0) {
          const pro = str.substring(i + 1, j);
          if (this.isValidProperty(pro)) {
            strs.push(str.substring(from, i));
            parameters.push(pro);
            from = j + 1;
            from2 = from;
          } else {
            from2 = j + 1;
          }
        } else {
          from = i + 1;
          from2 = from;
        }
      } else {
        strs.push(str.substring(from));
        break;
      }
    }

    const format = new StringFormat();
    format.texts = strs.splice(0);
    format.parameters = parameters.splice(0);
    return format;
  }

  private isValidProperty(str: string): boolean {
    const length = str.length;
    for (let i = 0; i < length; i++) {
      const chr = str.charAt(i);
      if (!(chr >= 'a' && chr <= 'z'
        || chr >= 'A' && chr <= 'Z'
        || chr >= '0' && chr <= '9'
        || chr === '_')) {
        return false;
      }
    }
    return true;
  }

  private mergeStringFormatWithMap(format: StringFormat, map: any): string {
    const strs = format.texts;
    const parameters = format.parameters;
    const results = [];
    const length = parameters.length;
    for (let i = 0; i < length; i++) {
      if (strs[i].length > 0) {
        results.push(strs[i]);
      }
      const p = map.get(parameters[i]);
      if (p != null) {
        const str = p;
        if (str.length > 0) {
          results.push(str);
        }
      }
    }
    results.push(strs[length]);
    return results.join('');
  }

  private mergeStringFormat(format: StringFormat, obj: any): string {
    const strs = format.texts;
    const parameters = format.parameters;
    const results = [];
    const length = parameters.length;
    for (let i = 0; i < length; i++) {
      if (strs[i].length > 0) {
        results.push(strs[i]);
      }
      const p = obj[parameters[i]];
      if (p != null && p.length > 0) {
        results.push(p);
      }
    }
    results.push(strs[length]);
    return results.join('');
  }
}


