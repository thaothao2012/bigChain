import {Language} from '../../Language';
import {MessageModel} from '../MessageModel';
import {ResourceLoader} from '../ResourceLoader';

export class DefaultResourceLoader implements ResourceLoader<MessageModel> {
  constructor(private _resources: Map<Language, any>) {
  }

  load(key: string, locale: Language): MessageModel {
    const messageModel: MessageModel = new MessageModel();
    messageModel.rawMsg = new Map<string, string>();
    messageModel.rawMsg.set('MESSAGE', this._resources.get(locale)[key]);
    return messageModel;
  }

}
