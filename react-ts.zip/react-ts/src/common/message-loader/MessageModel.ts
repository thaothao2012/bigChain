export class MessageModel {
  templateId: string;
  rawMsg: Map<string, string>;
  formattedMsg: Map<string, string>;
}
