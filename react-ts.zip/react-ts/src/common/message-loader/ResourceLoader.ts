import {Language} from '../Language';
import {MessageModel} from './MessageModel';

export interface ResourceLoader<T extends MessageModel> {
  load(key: string, locale: Language): T;
}
