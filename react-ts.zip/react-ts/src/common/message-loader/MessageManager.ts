import {Language} from '../Language';
import {MessageModel} from './MessageModel';

export interface MessageManager {
  getInitialKeys(): string[];
  setInitialKeys(keys: string[]);
  refresh();

  getRawText(msgId: string, locale: Language): string;
  getRawMessage(msgId: string, locale: Language): MessageModel;
  getMessage(msgId: string, locale: Language, params: object): MessageModel;
}
