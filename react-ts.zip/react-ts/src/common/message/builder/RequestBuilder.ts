
import {BaseInitModel} from '../../InitModel';
import {RequestHeader} from '../RequestHeader';

export interface RequestBuilder {
  buildRequestHeader(initModel: BaseInitModel): RequestHeader;
}
