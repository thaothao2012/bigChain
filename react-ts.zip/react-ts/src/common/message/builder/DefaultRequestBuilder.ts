import uuidv4 from 'uuid/v4';
import {BaseInitModel} from '../../InitModel';
import {RequestHeader} from '../RequestHeader';
import {RequestBuilder} from './RequestBuilder';

export class DefaultRequestBuilder implements RequestBuilder {
  constructor() {
    const header = new RequestHeader();
    header.mobileNo = '';
    header.mobileOS = '';
    header.appVersion = '1';
    header.appId = '715';
    header.inboxSessionId = '';
    header.language = 'TH';
    header.corrId = '1';
    this.defaultHeader = header;
  }

  private defaultHeader: RequestHeader;
  private _reg = /-/g;
  private mapWithZero = (value) => ('0' + value).slice(-2);

  private reqdate() {
    const date = new Date();
    const m = this.mapWithZero(date.getMonth() + 1);
    const d = this.mapWithZero(date.getDate());
    const h = this.mapWithZero(date.getHours());
    const minute = this.mapWithZero(date.getMinutes());
    const second = this.mapWithZero(date.getSeconds());
    return date.getFullYear().toString() + m + d + h + minute + second;
  }

  private setDefaultHeader(initData: BaseInitModel): void {
    const header: RequestHeader = new RequestHeader();
    header.mobileNo = initData.mobileNo;
    header.mobileOS = initData.mobileOS;
    header.appVersion = initData.appVersion;
    header.appId = initData.appId;
    header.inboxSessionId = initData.inboxSessionId;
    header.language = initData.language;
    header.corrId = initData.corrId;
    Object.keys(this.defaultHeader).forEach(item => {
      if (!header[item]) {
        header[item] = this.defaultHeader[item];
      }
    });
    this.defaultHeader = header;
  }

  private buildRequestIdAndRequestTime = (): RequestHeader => {
    const header = this.defaultHeader;
    header.requestDateTime = this.reqdate();
    header.requestUniqueId = `715` + this.uuid() + `120`;
    return this.defaultHeader;
  }

  private uuid(): string {
    const f: string = uuidv4();
    return f.replace(this._reg, '');
  }

  buildRequestHeader(initModel: BaseInitModel): RequestHeader {
    if (!initModel) {
      return this.buildRequestIdAndRequestTime();
    } else {
      this.setDefaultHeader(initModel);
      return this.buildRequestIdAndRequestTime();
    }
  }
}
