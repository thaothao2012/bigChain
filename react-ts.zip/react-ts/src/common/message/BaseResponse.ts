import {ResponseHeader} from './ResponseHeader';

export class BaseResponse<T> {
  header: ResponseHeader;
  data: T;
}
