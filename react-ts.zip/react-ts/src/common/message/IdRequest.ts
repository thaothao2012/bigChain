import {BaseRequest} from './BaseRequest';
import {GenericId} from './GenericId';

export class IdRequest<Id, T extends GenericId<Id>> extends BaseRequest<T> {

}
