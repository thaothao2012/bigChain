import {createLogger, format, transports} from 'winston';
import {LogStashFormat} from './winston/format/LogStashFormat';
import {LogTraceFormat} from './winston/format/LogTraceFormat';
import {SimpleFormat} from './winston/format/SimpleFormat';
import {HttpTransform} from './winston/transport/HttpTransform';

const { combine, timestamp } = format;

export const logger = createLogger({
  level: 'debug',
  format: combine(
    timestamp(),
    LogTraceFormat(),
    process.env.NODE_ENV === 'development' ? SimpleFormat() : LogStashFormat()
  ),
  transports: [
    process.env.NODE_ENV === 'development' ? new transports.Console() : new transports.Http(HttpTransform.getReportHttpOption())
  ]
});
