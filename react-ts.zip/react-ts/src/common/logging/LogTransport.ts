export interface LogTransport {
  log(obj: any): boolean;
}
