import {DefaultRequestBuilder} from '../message/builder/DefaultRequestBuilder';
import {DefaultTransport} from './DefaultTransport';
import {DefaultWebFormFlowLog} from './webform-flow/DefaultWebFormFlowLog';
import {DefaultFormat} from './webform-flow/format/DefaultFormat';
import {WebformLogTransport} from './webform-flow/transport/WebformLogTransport';

export const webformFlowLogger = DefaultWebFormFlowLog.createLogger({
  format: [
    new DefaultFormat()
  ],
  transports: [
    new DefaultTransport(),
    new WebformLogTransport(new DefaultRequestBuilder())
  ]
});
