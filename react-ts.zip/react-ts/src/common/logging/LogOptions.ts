import {LogFormat} from './LogFormat';
import {LogTransport} from './LogTransport';

export interface LogOptions {
  format: LogFormat[];
  transports: LogTransport[];
}
