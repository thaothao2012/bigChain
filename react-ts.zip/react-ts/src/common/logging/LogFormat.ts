export interface LogFormat {
  format(obj: any): any;
}
