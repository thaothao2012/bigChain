import config from '../../config';
import {DefaultAnalyticLog} from './analytic/DefaultAnalyticLog';
import {DefaultFormat} from './analytic/format/DefaultFormat';
import {DebugHttpTransport} from './analytic/transport/DebugHttpTransport';
import {GoogleAnalyticsTransport} from './analytic/transport/GoogleAnalyticsTransport';
import {DefaultTransport} from './DefaultTransport';

export const analyticLogger = DefaultAnalyticLog.createLogger({
  format: [
    new DefaultFormat()
  ],
  transports: [
    new DefaultTransport(),
    new GoogleAnalyticsTransport(),
    // process.env.NODE_ENV === 'development' ? new DebugHttpTransport() : null
    config.analyticLogTestUrlEnable ? new DebugHttpTransport() : null
  ]
});
