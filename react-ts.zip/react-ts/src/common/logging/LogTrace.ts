export class LogTrace {
  startTime: number ;
  attributes: Map<string, string>;
  markers: Map<string, string>;
}
