/**
 * Interface of WebformFlowLog.
 * TODO: Consider to Remove.
 */
export interface WebformFlowLog {
  sendLog(callback?: (res: any) => void): void;
  addPerformanceLog(detail: PerformanceDetail): boolean;
}

export interface PerformanceDetail {
  details: any;
  processTime: number;
}
