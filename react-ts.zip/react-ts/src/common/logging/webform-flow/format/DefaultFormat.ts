import {LogFormat} from '../../LogFormat';

export class DefaultFormat implements LogFormat {
  format(obj: any): any {
    return obj;
  }
}
