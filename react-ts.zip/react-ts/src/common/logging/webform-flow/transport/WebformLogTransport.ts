import {map} from 'rxjs/operators';
import config from '../../../../config';
import {ReduxState, store} from '../../../../core';
import {BaseInitModel, InitModel} from '../../../InitModel';
import {RequestBuilder} from '../../../message/builder/RequestBuilder';
import {storage} from '../../../storage';
import {WebClientUtil} from '../../../util/WebClientUtil';
import {logger} from '../../logger';
import {LogTransport} from '../../LogTransport';

export class WebformLogTransport implements LogTransport {
  constructor(private requestBuilder: RequestBuilder) {
  }

  log(obj: any): boolean {
    // TODO: TB
    //  This clone from WebFormLogService , consider to not duplicated code.
    //  Cannot inject WebFormLogsService cause it is on particular project, Log is from common module.
    logger.debug('WebformLogTransport', new Date().getTime());
    const webFormLog = storage.getWebFormLog();
    if (webFormLog) {
      webFormLog.details.map((item, index) => {
        item.seq = index + 1;
      });
    }
    const url = config.logUrl + '/webformFlowlog';
    const requestParams = this.selectRequestHeaderData(store.getState());
    const rq = {
      header: this.requestBuilder.buildRequestHeader(requestParams),
      data: webFormLog
    };
    WebClientUtil.postObject<any>(url, rq, true).pipe(map(res => res.data)).subscribe(rs => {
      logger.debug('WebformLogTransport', new Date().getTime());
      logger.debug(rs);
    }, error => {
      logger.debug('WebformLogTransport', new Date().getTime());
      logger.debug(error);
    }
    );
    return true;
  }

  protected selectInitData = (state: ReduxState<any, any>): InitModel => state['globalState'].initData;

  protected selectRequestHeaderData = (state: any): BaseInitModel => {
    const { mobileNo, mobileOS, appVersion, appId, inboxSessionId, language, corrId } = state['globalState'].initData;
    return { mobileNo, mobileOS, appVersion, appId, inboxSessionId, language, corrId };
  }
}
