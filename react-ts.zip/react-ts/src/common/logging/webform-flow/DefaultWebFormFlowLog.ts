import {storage} from '../../storage';
import {WebFormLogDetail} from '../../WebFormLog';
import {DefaultLog} from '../DefaultLog';
import {LogOptions} from '../LogOptions';
import {PerformanceDetail, WebformFlowLog} from './WebformFlowLog';

interface ResponseHeader {
  corrId: string;
  errors: any;
  inboxSessionId: string;
  mobileNo: string;
  requestDateTime: string;
  requestedUniqueId: string;
  responseCode: string;
  responseDateTime: string;
  responseDesc: string;
  responseId: string;
  status: string;
}

export class DefaultWebFormFlowLog extends DefaultLog implements WebformFlowLog {
  private static webFormFlowLog;

  private constructor(wfOption: LogOptions) {
    super(wfOption);
  }

  public static createLogger(option: LogOptions): WebformFlowLog {
    if (!this.webFormFlowLog) {
      this.webFormFlowLog = new DefaultWebFormFlowLog(option);
      return this.webFormFlowLog;
    } else {
      return this.webFormFlowLog;
    }
  }

  sendLog(callback?: (res: any) => void): void {
    this.send({}, callback);
  }

  private handleWithServerError(detail: PerformanceDetail) {
    const logDetail: WebFormLogDetail = {
      from: 'Client',
      to: 'UCT',
      reason: (detail.details.response && detail.details.response.data) || detail.details.message,
      remark: detail.details.config.data,
      processTime: Math.round(detail.processTime),
      rqUid: null,
      rsUid: null,
      status: 'F'
    };
    return [logDetail];
  }

  private handleWithResponse(detail: PerformanceDetail) {
    const logDetailFromServer: WebFormLogDetail[] = (detail.details.data.data && detail.details.data.data.logDetails) || [];
    const responseHeader: ResponseHeader = detail.details.data.header;
    // const bodyData = detail.details.data;

    const status = responseHeader.responseCode === '200' ? 'S' : 'F';
    const reason = responseHeader.status === 'F' ? 'Fail' : null;
    const remark = responseHeader.status === 'F' ? detail.details.config.data : null;

    const logDetail: WebFormLogDetail = {
      from: 'Client',
      to: 'UCT',
      reason,
      remark,
      processTime: Math.round(detail.processTime),
      rqUid: responseHeader.requestedUniqueId ? responseHeader.requestedUniqueId : null,
      rsUid: responseHeader.responseId ? responseHeader.responseId : null,
      status
    };
    const mappingLogDetailFromServer = logDetailFromServer.map(item => {
      return { ...item, from: 'UCT' };
    });
    return [logDetail, ...mappingLogDetailFromServer];
  }

  addPerformanceLog(detail: PerformanceDetail): boolean {
    if (detail.details.status === 200) {
      const data = detail.details.data;
      const responseHeader: ResponseHeader = data.header;
      const mapping = this.handleWithResponse(detail);
      storage.addWebFormLogDetail({
        detailLog: mapping,
        reason: mapping[0].reason,
        remark: mapping[0].remark,
        responseCode: responseHeader.responseCode,
        status: responseHeader.status
      });
      return responseHeader.status === 'F';
    } else {
      const mapping = this.handleWithServerError(detail);
      storage.addWebFormLogDetail({
        detailLog: mapping,
        reason: mapping[0].reason,
        remark: mapping[0].remark,
        responseCode: '500',
        status: 'F'
      });
      return true;
    }
  }
}
