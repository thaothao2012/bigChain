import {forkJoin, Observable, of} from 'rxjs';
import {catchError, flatMap} from 'rxjs/operators';
import {LogOptions} from './LogOptions';

export class DefaultLog {
  private option: LogOptions;
  constructor(option: LogOptions) {
    this.option = option;
  }

  protected send(obj: any, callback?: (res: any) => void): void {
    const format = of(this.assembleLog(obj));
    format.pipe(flatMap(result => {
      console.log(result);
      return this.assembleTransport(result);
    }),
      catchError(err => {
        console.log(err);
        return of('error found');
      }))
      .subscribe(rs => {
        console.log(rs);
        // callback(rs);
      });
  }

  private assembleLog(obj): any {
    let result = obj;
    this.option.format.forEach(item => result = item.format(result));
    return result;
  }

  private assembleTransport(obj: any): Observable<any> {
    const transports = [];
    this.option.transports.forEach(item => {
      if (item) {
        const objs = of(item.log(obj));
        transports.push(objs);
      }
    });
    const result = forkJoin(transports);
    return result;
  }
}
