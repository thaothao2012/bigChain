export enum TrackingType {
  View,
  Event
}
