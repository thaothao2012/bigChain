import {LogTransport} from '../../LogTransport';
import {TrackingType} from '../enum/TrackingType';
import {GoogleAnalyticsUtil} from '../GoogleAnalyticsUtil';

export class GoogleAnalyticsTransport implements LogTransport {
  log(obj: any): boolean {
    if (TrackingType.Event === obj['type']) {
      GoogleAnalyticsUtil.event(obj);
    } else {
      GoogleAnalyticsUtil.screenView(obj['path'], obj['screenName']);
    }
    return true;
  }
}
