import config from '../../../../config';
import {storage} from '../../../storage';
import {WebClientUtil} from '../../../util/WebClientUtil';
import {logger} from '../../logger';
import {LogTransport} from '../../LogTransport';

export class DebugHttpTransport implements LogTransport {
  log(obj: any): boolean {
    try {
      logger.debug('DebugHttpTransport', new Date().getTime());
      const url = new URL(config.analyticLogTestUrl);
      const initModel = storage.getInitModel();
      url.searchParams.append('username', initModel ?  (initModel.uuid || '') : '');
      url.searchParams.append('screen', obj.screenName ? obj.screenName : '');
      url.searchParams.append('category', obj.eventCategory ? obj.eventCategory : '');
      url.searchParams.append('action', obj.eventAction ?  obj.eventAction : '');
      url.searchParams.append('label', obj.eventLabel ?  obj.eventLabel : '');
      url.searchParams.append('value', obj.eventValue ?  obj.eventValue : '');
      WebClientUtil.get(url.toString()).subscribe(rs => {
            logger.debug('DebugHttpTransport', new Date().getTime());
            logger.debug(rs);
          }, error => {
            logger.debug('DebugHttpTransport', new Date().getTime());
            logger.debug(error);
          }
      );
    } catch (e) {
      logger.debug(e);
    }
    return true;
  }
}
