import config from '../../../../config';
import {storage} from '../../../storage';
import {LogFormat} from '../../LogFormat';

export class DefaultFormat implements LogFormat {
  format(obj: any): any {
    const initModel = storage.getInitModel();
    if (initModel) {
      obj['mobileNo'] = initModel.mobileNo;
      // Temp remove mapping from form ID due to Flow name will change
      // obj['eventCategory'] = initModel.formId;
      obj['eventCategory'] = config.analyticLogCommAuthCat;
    }
    return obj;
  }
}
