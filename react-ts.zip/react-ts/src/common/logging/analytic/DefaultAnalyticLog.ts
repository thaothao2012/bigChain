import config from '../../../config';

import {storage} from '../../storage';
import {DefaultLog} from '../DefaultLog';
import {LogOptions} from '../LogOptions';
import {AnalyticLog} from './AnalyticLog';
import {TrackingType} from './enum/TrackingType';
import {GoogleAnalyticsUtil} from './GoogleAnalyticsUtil';
import {AnalyticLogItem} from './model/AnalyticLogItem';

export class DefaultAnalyticLog extends DefaultLog implements AnalyticLog {
  private static analyticLog;

  private constructor(alOption: LogOptions) {
    super(alOption);
  }

  public static createLogger(option: LogOptions): AnalyticLog {
    if (!DefaultAnalyticLog.analyticLog) {
      const initModel = storage.getInitModel();
      GoogleAnalyticsUtil.initialize(config.analyticLogGAID);
      if (initModel) {
        GoogleAnalyticsUtil.setUUID(initModel.uuid);
      }
      DefaultAnalyticLog.analyticLog = new DefaultAnalyticLog(option);
      return DefaultAnalyticLog.analyticLog;
    } else {
      return DefaultAnalyticLog.analyticLog;
    }
  }

  sendViewTracking(screenName: string, path?: string, callback?: (res: any) => void): void {
    const obj = {};
    obj['type'] = TrackingType.View;
    obj['screenName'] = screenName;
    obj['path'] = path;
    this.send(obj, callback);
  }

  sendEvent(screenName: string, eventAction: string, eventLabel: string, eventValue?: string, callback?: (res: any) => void): void {
    const obj = {};
    obj['type'] = TrackingType.Event;
    obj['screenName'] = screenName;
    obj['eventAction'] = eventAction;
    obj['eventLabel'] = eventLabel;
    obj['eventValue'] = eventValue;
    this.send(obj, callback);
  }

  sendLog(logItem: AnalyticLogItem, callback?: (res: any) => void): void {
    this.send(logItem, callback);
  }
}
