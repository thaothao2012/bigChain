import * as ReactGA from 'react-ga';
import {AnalyticLogItem} from './model/AnalyticLogItem';

export class GoogleAnalyticsUtil {
  private static ga = null;

  public static initialize(id: string) {
    if (GoogleAnalyticsUtil.ga === null) {
      GoogleAnalyticsUtil.ga = ReactGA.initialize(id);
    }
  }

  public static setUUID(uuid: string) {
    ReactGA.set({ dimension1: uuid });
  }

  public static screenView(path: string, screenName?: string) {
    const view = screenName ? screenName : path;
    ReactGA.pageview(view);
  }

  public static event(obj: AnalyticLogItem) {
    const event = {
      category: obj.eventCategory,
      action: obj.eventAction,
      label: obj.eventLabel
    };
    console.log(event);
    ReactGA.event(event);
  }

}
