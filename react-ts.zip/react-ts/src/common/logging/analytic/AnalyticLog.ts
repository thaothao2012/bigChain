/**
 * Interface of AnalyticLog.
 * TODO: Consider to Remove.
 */
import {AnalyticLogItem} from './model/AnalyticLogItem';

export interface AnalyticLog {
  sendViewTracking(screenName: string, path?: string, callback?: (res: any) => void): void;
  sendEvent(screenName: string, eventAction: string, eventLabel: string, eventValue?: string, callback?: (res: any) => void): void;
  sendLog(logItem: AnalyticLogItem, callback?: (res: any) => void): void;
}
