import {TrackingType} from '../enum/TrackingType';

export class AnalyticLogItem {
  type: TrackingType;
  screenName: string;
  eventCategory: string;
  eventAction: string;
  eventLabel: string;
  eventValue: string;
}
