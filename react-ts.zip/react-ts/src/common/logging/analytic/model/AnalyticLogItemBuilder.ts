export interface AnalyticLogItemBuilder {
  buildEvent(screenName: string , eventAction: string, eventLabel: string, eventValue: string);
  buildTrackingView(screenName: string);
}
