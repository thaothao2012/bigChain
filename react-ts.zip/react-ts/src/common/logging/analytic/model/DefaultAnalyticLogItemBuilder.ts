import {AnalyticLogItem} from './AnalyticLogItem';

export class AnalyticLogItemBuilder implements AnalyticLogItemBuilder {

  buildEvent(screenName: string, eventAction: string, eventLabel: string, eventValue?: string): AnalyticLogItem {
    const logItem = new AnalyticLogItem();
    logItem.screenName = screenName;
    logItem.eventAction = eventAction;
    logItem.eventLabel = eventLabel;
    logItem.eventValue = eventValue;
    return logItem;
  }

  buildTrackingView(screenName: string): AnalyticLogItem {
    const logItem = new AnalyticLogItem();
    logItem.screenName = screenName;
    return logItem;
  }
  /* private _logItem  = new AnalyticLogItem();
   public eventLog(): AnalyticLogItemBuilder{
       this._logItem.type = TrackingType.EVENT;
       return this;
   }
   public viewLog(): AnalyticLogItemBuilder{
       this._logItem.type = TrackingType.VIEW;
       return this;
   }
   public screenName(screenName : string): AnalyticLogItemBuilder{
       this._logItem.screenName = screenName;
       return this;
   }
   public event(eventAction: string, eventLabel: string, eventValue?: string): AnalyticLogItemBuilder{
       this._logItem.eventAction = eventAction;
       this._logItem.eventLabel = eventLabel;
       this._logItem.eventValue = eventValue;
       return this;
   }
   public build(): AnalyticLogItem{
       return this._logItem;
   }*/
}
