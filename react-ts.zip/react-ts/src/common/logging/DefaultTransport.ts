import {LogTransport} from './LogTransport';

export class DefaultTransport implements LogTransport {
  log(obj: any): boolean {
    console.log('DefaultTransport', new Date().getTime());
    console.log('DefaultTransport', obj);
    return true;
  }
}
