export interface Native {
  osPlatform: string;
  functionName: string;
  params: object;
}
