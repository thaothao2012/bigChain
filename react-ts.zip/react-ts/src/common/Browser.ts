export enum Browser {
  Chrome = 'Chrome',
  Firefox = 'Firefox',
  InternetExplorer = 'IE',
  Opera = 'Opera',
  Safari = 'Safari',
  Edge = 'Edge',
  Blink = 'Blink'
}
