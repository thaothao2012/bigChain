import {storage} from '../storage';

export class AuthorizationRequiredService {
  static isLoggedIn(): boolean {
    const user = storage.getUser();
    if (!user) {
      return false;
    } else {
      return true;
    }
  }
  static checkPrevileges(path: string): boolean {
    const privileges = storage.getUser() ? null : storage.getUser().privileges;
    if (!privileges) {
      return false;
    } else {
      return privileges.indexOf(path) >= 0;
    }
  }
}
