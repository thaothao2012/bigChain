import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {Model} from '../../metadata/Model';
import {MetadataUtil} from '../../metadata/util/MetadataUtil';
import {DiffModel} from '../../model/DiffModel';
import {ResultModel} from '../../model/ResultModel';
import {SearchModel} from '../../model/SearchModel';
import {WebClientUtil} from '../../util/WebClientUtil';
import {GenericSearchDiffApprService} from '../GenericSearchDiffApprService';
import {GenericSearchWebService} from './GenericSearchWebService';

export class GenericSearchDiffApprWebService<T, S extends SearchModel> extends GenericSearchWebService<T, S> implements GenericSearchDiffApprService<T, S> {
  constructor(serviceUrl: string, model: Model) {
    super(serviceUrl, model);
  }

  checkDiff(id): Observable<DiffModel<T>> {
    let url = this.serviceUrl + '/' + id + '/checker';
    console.log('ID ', id);
    if (typeof id === 'object' && this.model) {
      const metaModel = MetadataUtil.getMetaModel(this.model);
      if (metaModel.primaryKeys && metaModel.primaryKeys.length > 0) {
        url = this.serviceUrl;
        for (const key of metaModel.primaryKeys) {
          url = url + '/' + id[key.name];
        }
        url = url + '/checker';
      }
    }
    return WebClientUtil.get(url)
      .pipe(map((res: any) => {
        if (!res.newValue) {
          res.newValue = {};
        }
        if (typeof res.newValue === 'string') {
            res.newValue = JSON.parse(res.newValue);
        }
        if (!res.oldValue) {
          res.oldValue = {};
        }
        if (typeof res.oldValue === 'string') {
          res.oldValue = JSON.parse(res.oldValue);
        }
        return res;
      }));
  }

  approve(model: T): Observable<ResultModel> {
    const url = this.serviceUrl + '/approve';
    return WebClientUtil.patchObject<T>(url, model)
      .pipe(map((res: any) => res));
  }

  reject(model: T): Observable<ResultModel> {
    const url = this.serviceUrl + '/reject';
    return WebClientUtil.patchObject<T>(url, model)
      .pipe(map((res: any) => res));
  }
}
