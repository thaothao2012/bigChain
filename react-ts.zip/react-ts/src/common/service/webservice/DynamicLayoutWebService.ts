import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ReflectionUtil, ResultInfo} from '../../../core';
import {Model} from '../../metadata/Model';
import {MetadataUtil} from '../../metadata/util/MetadataUtil';
import {SearchResult} from '../../model/SearchResult';
import {WebClientUtil} from '../../util/WebClientUtil';
import {DynamicLayoutService} from '../DynamicLayoutService';
import {BaseWebService} from './BaseWebService';

export class DynamicLayoutWebService<T> extends BaseWebService implements DynamicLayoutService<T> {
  private serviceDynamicUrl = 'http://localhost:3005/dynamicForm';
  constructor(protected serviceUrl: string, protected model: Model) {
    super();
  }

  getMetaData(): Model {
    return this.model;
  }

  getAll(): Observable<T[]> {
    return WebClientUtil.get(this.serviceUrl)
      .pipe(map((res: any) => this.formatObjects(res)));
  }

  getAllDynamicForm(s: any): Observable<SearchResult<T>> {
    const postSearchUrl = `${this.serviceDynamicUrl}/search`;
    const obj = {
      entityName: 'dynamicForm',
      includeTotal: true,
      pageIndex: s.pageIndex,
      pageSize: s.pageSize
    };
    return WebClientUtil.postRequest(postSearchUrl, obj)
    .pipe(map((res: SearchResult<T>) => {
      return this.buildSearchDynamicFormResult(res);
    }));
  }

  getDynamicFormByModelName(modelName): Observable<T> {
    let url = `${this.serviceDynamicUrl}/getByName/${modelName}`;
    if (typeof modelName === 'object' && this.model) {
      const metaModel = MetadataUtil.getMetaModel(this.model);
      if (metaModel.primaryKeys && metaModel.primaryKeys.length > 0) {
        url = this.serviceDynamicUrl;
        for (const key of metaModel.primaryKeys) {
          url = url + '/' + modelName[key.name];
        }
      }
    }
    return WebClientUtil.get(url).pipe(map((res: any) => this.formatObject(res)));
  }

  getDynamicFormById(modelName): Observable<T> {
    let url = `${this.serviceDynamicUrl}/${modelName}`;
    if (typeof modelName === 'object' && this.model) {
      const metaModel = MetadataUtil.getMetaModel(this.model);
      if (metaModel.primaryKeys && metaModel.primaryKeys.length > 0) {
        url = this.serviceDynamicUrl;
        for (const key of metaModel.primaryKeys) {
          url = url + '/' + modelName[key.name];
        }
      }
    }
    return WebClientUtil.get(url).pipe(map((res: any) => this.formatObject(res)));
  }

  insertDynamicForm(obj: any): Observable<ResultInfo<T>> {
    const obj2 = ReflectionUtil.deepClone(obj);
    return WebClientUtil.postRequest(this.serviceDynamicUrl, obj2)
      .pipe(map((res: any) => this.formatResultInfo(res)));
  }

  updateDynamicForm(obj: any): Observable<ResultInfo<T>> {
    const obj2 = ReflectionUtil.deepClone(obj);
    ReflectionUtil.dateToISO(obj2);
    const metadata = MetadataUtil.getMetaModel(this.model);
    let url = this.serviceDynamicUrl;
    for (const item of metadata.primaryKeys) {
      url += '/' + obj2['formId'];
    }
    delete obj2['formId'];
    return WebClientUtil.putRequest(url, obj2)
      .pipe(map((res: any) => this.formatResultInfo(res)));
  }

  deleteDynamicForm(id: string): Observable<ResultInfo<T>> {
    return WebClientUtil.deleteRequest(this.serviceDynamicUrl + '/' + id)
      .pipe(map((res: any) => this.formatResultInfo(res)));
  }

  protected formatObjects(list: any[]): any[] {
    if (!list || list.length === 0) {
      return list;
    }
    const metadata = this.getMetaData();
    for (const obj of list) {
      MetadataUtil.json(obj, metadata);
    }
    return list;
  }

  protected formatObject(obj): any {
    return MetadataUtil.json(obj, this.getMetaData());
  }

  protected buildSearchDynamicFormResult(r: SearchResult<T>): SearchResult<T> {
    if (r != null && r.results != null && r.results.length > 0) {
      this.formatObjects(r.results);
    }
    return r;
  }

  protected formatResultInfo(result: ResultInfo<T>): ResultInfo<T> {
    result.value = MetadataUtil.json(result.value, this.getMetaData());
    return result;
  }
}
