import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {ResultInfo} from '../../../core';
import {Model} from '../../metadata/Model';
import {MetadataUtil} from '../../metadata/util/MetadataUtil';
import {SearchResult} from '../../model/SearchResult';
import {WebClientUtil} from '../../util/WebClientUtil';
import {ViewService} from '../ViewService';
import {BaseWebService} from './BaseWebService';
import { DynamicLayoutWebService } from './DynamicLayoutWebService';

export class ViewWebService<T> extends DynamicLayoutWebService<T> implements ViewService<T> {
  constructor(protected serviceUrl: string, protected model: Model) {
    super(serviceUrl, model);
  }

  getMetaData(): Model {
    return this.model;
  }

  getAll(): Observable<T[]> {
    return WebClientUtil.get(this.serviceUrl)
      .pipe(map((res: any) => this.formatObjects(res)));
  }

  getById(id): Observable<T> {
    let url = this.serviceUrl + '/' + id;
    if (typeof id === 'object' && this.model) {
      const metaModel = MetadataUtil.getMetaModel(this.model);
      if (metaModel.primaryKeys && metaModel.primaryKeys.length > 0) {
        url = this.serviceUrl;
        for (const key of metaModel.primaryKeys) {
          url = url + '/' + id[key.name];
        }
      }
    }
    return WebClientUtil.get(url)
      .pipe(map((res: any) => this.formatObject(res)));
  }

  protected formatObjects(list: any[]): any[] {
    if (!list || list.length === 0) {
      return list;
    }
    const metadata = this.getMetaData();
    for (const obj of list) {
      MetadataUtil.json(obj, metadata);
    }
    return list;
  }

  protected formatObject(obj): any {
    return MetadataUtil.json(obj, this.getMetaData());
  }

  protected buildSearchDynamicFormResult(r: SearchResult<T>): SearchResult<T> {
    if (r != null && r.results != null && r.results.length > 0) {
      this.formatObjects(r.results);
    }
    return r;
  }

  protected formatResultInfo(result: ResultInfo<T>): ResultInfo<T> {
    result.value = MetadataUtil.json(result.value, this.getMetaData());
    return result;
  }
}
