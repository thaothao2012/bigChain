export class BaseWebService {

}
