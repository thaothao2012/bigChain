export class DateRange {
  startDate: Date;
  endDate: Date;
}
