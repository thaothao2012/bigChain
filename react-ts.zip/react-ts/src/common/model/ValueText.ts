export interface ValueText {
  value: string;
  text: string;
}
