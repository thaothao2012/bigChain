export interface NumberValueText {
  value: number;
  text: string;
}
