export class ResultModel {
  error: Error;
  status: string;
}
