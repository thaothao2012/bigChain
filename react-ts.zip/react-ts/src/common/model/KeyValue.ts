export interface KeyValue {
  key: string;
  value: string;
}
