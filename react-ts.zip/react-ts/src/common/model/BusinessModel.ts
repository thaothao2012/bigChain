import {BaseModel} from './BaseModel';

export class BusinessModel extends BaseModel {
  constructor() {
    super();
  }
  id: string;
  createDate: Date;
  updateDate: Date;
}
