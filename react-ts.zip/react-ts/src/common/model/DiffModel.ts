export class DiffModel<T> {
  entityId: string;
  oldValue: T;
  newValue: T;
}
