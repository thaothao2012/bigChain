export enum StatusCode {
  Success = 0, // 'S',
  Error = 1, // 'E',
  DataVersionError = 2, // 'I',
  DataCorruptError = 4, // 'C',
  DuplicateIdError = 8, // 'P',
  IdRequiredError = 16, // 'Q',
}
