export class ErrorMessage {
  id: number;
  code: string;
  attribute: string;
  value: any;
  message: string;
  param: any;
}
