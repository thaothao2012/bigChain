export enum ObjectStatus {
  New = 'N',
  Active = 'A', // active record
  Inactive = 'I', // active record
  Deleted = 'D', // deleted
  Suspended = 'S'
}
