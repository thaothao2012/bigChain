import * as React from 'react';

interface Props {
  oldValue: any;
  newValue: any;
  resource: any;
  resourceKey: string;
  name: string;
}

class DiffField extends React.Component<Props, any> {
  render() {
    const { oldValue, newValue, resource, resourceKey, name } = this.props;
    return (
      <p data-field={name}>
        <label>{resource[resourceKey]}</label>
        {this.formatResult(oldValue[name])}
        {this.formatResult(newValue[name])}
      </p>
    );
  }

  formatResult(result) {
    if (Array.isArray(result)) {
      return (
          <ul>
            {
              result.map((item, index) => (
                  <li key={index}>{item}</li>
              ))
            }
          </ul>
      );
    }
    return (
        <span> {result} </span>
    );
  }
}

export default DiffField;
