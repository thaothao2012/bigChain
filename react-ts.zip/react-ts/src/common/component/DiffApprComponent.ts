import {Model} from '../metadata/Model';
import {DiffModel} from '../model/DiffModel';
import {DiffApprService} from '../service/DiffApprService';
import {storage} from '../storage';
import {ReflectionUtil} from '../util/ReflectionUtil';
import {UIUtil} from '../util/UIUtil';
import {BaseDiffApprComponent} from './BaseDiffApprComponent';
import {DiffState} from './DiffState';
import {HistoryProps} from './HistoryProps';

export class DiffApprComponent<T, W extends HistoryProps, I extends DiffState<T>> extends BaseDiffApprComponent<T, W, I> {
  constructor(props, metadata: Model, protected service: DiffApprService<T>) {
    super(props, metadata);
    this.approve = this.approve.bind(this);
    this.reject = this.reject.bind(this);
    this.formatDiffModel = this.formatDiffModel.bind(this);
    this.formatFields = this.formatFields.bind(this);
  }

  formatDiffModel(obj: DiffModel<T>): DiffModel<T> {
    const obj2 = ReflectionUtil.clone(obj);
    if (ReflectionUtil.isObject(obj2.oldValue)) {
      if (ReflectionUtil.isObjEmpty(obj2.oldValue)) {
      } else {
        obj2.oldValue = this.formatFields(obj2.oldValue);
      }
    } else {
      obj2.oldValue = {};
    }
    if (ReflectionUtil.isObject(obj2.newValue)) {
      if (ReflectionUtil.isObjEmpty(obj2.newValue)) {
      } else {
        obj2.newValue = this.formatFields(obj2.newValue);
      }
    } else {
      obj2.newValue = {};
    }

    return obj2;
  }

  formatFields(value: T): T {
    return value;
  }

  loadData() {
    const id = this.getId();
    if (id != null && id !== '') {
      const user = storage.getUser();
      if (!user) {
        this.requireAuthentication();
      } else {
        const { diffInfo } = this.props as any;
        console.log('diffInfo', diffInfo);
        if (diffInfo) {
          this.service.checkDiff({
            id,
            callback: {
              execute: this.saveModelToState,
              handleError: this.handleError,
              formatDiffModel: this.formatDiffModel
            }
          });
        } else {
          this.service.checkDiff(id).subscribe((diff) => {
            // const oldValue = diff.oldValue ? JSON.parse(diff.oldValue) : null;
            // const newValue = diff.newValue ? JSON.parse(diff.newValue) : null;
            const formatdDiff = this.formatDiffModel(diff);
            this.setState({
              oldValue: formatdDiff.oldValue,
              newValue: formatdDiff.newValue
            }, this.format);
          }, this.handleError);
        }
      }
    }
  }

  approve(event) {
    event.preventDefault();
    const { diffInfo } = this.props as any;
    let body;
    if (diffInfo) {
      body = this.makeDiffBody(diffInfo.newValue);
      this.service.approve({
        obj: body,
        callback: { execute: this.callBackAfterUpdate, handleError: this.handleError }
      });
    } else {
      body = this.makeDiffBody();
      this.service.approve(body).subscribe(() => {
        this.setState({ approveSuccess: true, rejectSuccess: true });
        UIUtil.showToast(this.resource.msg_approve_success);
      }, err => {
        this.setState({ approveSuccess: false });
        this.handleError(err);
      });
    }
  }

  reject(event) {
    event.preventDefault();
    const { diffInfo } = this.props as any;
    let body;
    if (diffInfo) {
      body = this.makeDiffBody(diffInfo.newValue);
      this.service.reject({
        obj: body,
        callback: { execute: this.callBackAfterUpdate, handleError: this.handleError }
      });
    } else {
      body = this.makeDiffBody();
      this.service.reject(body).subscribe(() => {
        this.setState({ approveSuccess: true, rejectSuccess: true });
        UIUtil.showToast(this.resource.msg_reject_success);
      }, err => {
        this.handleError(err);
        this.setState({ rejectSuccess: false });
      });
    }
  }
}
