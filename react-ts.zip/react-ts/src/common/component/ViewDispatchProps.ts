export interface ReduxGetByIdCallBack<T> {
  execute: (model: T) => void;
  handleError: (response: any) => void;
}

export interface ReduxGetByIdModel<T> {
  id: any;
  callback: ReduxGetByIdCallBack<T>;
}

export interface ViewDispatchProps<T> {
  setGlobalState: (data) => void;
  getById: (data: ReduxGetByIdModel<T>) => any;
}
