export interface DiffApprDispatchProps {
  checkDiff?: (data: any) => any;
  approve?: (data: any) => any;
  reject?: (data: any) => any;
}
