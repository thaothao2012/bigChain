export interface ViewPermission {
  viewable: boolean;
}
