import {Model} from '../metadata/Model';
import {DiffModel} from '../model/DiffModel';
import {storage} from '../storage';
import {ReflectionUtil} from '../util/ReflectionUtil';
import {BaseDiffApprComponent} from './BaseDiffApprComponent';
import {BaseInternalState} from './BaseInternalState';
import {DiffApprDispatchProps} from './DiffApprDispatchProps';
import {HistoryProps} from './HistoryProps';

interface InternalDiffState {
  diffInfo?: any;
}

export type DiffApprPropsType = InternalDiffState & DiffApprDispatchProps & HistoryProps;

export class ReduxDiffApprComponent<T, W extends DiffApprPropsType, I extends BaseInternalState> extends BaseDiffApprComponent<T, W, I> {
  constructor(props, metadata: Model) {
    super(props, metadata);
    this.approve = this.approve.bind(this);
    this.reject = this.reject.bind(this);
    this.formatDiffModel = this.formatDiffModel.bind(this);
    this.formatFields = this.formatFields.bind(this);
  }

  formatDiffModel(obj: DiffModel<T>): DiffModel<T> {
    const obj2 = ReflectionUtil.clone(obj);
    if (ReflectionUtil.isObject(obj2.oldValue)) {
      if (ReflectionUtil.isObjEmpty(obj2.oldValue)) {
      } else {
        obj2.oldValue = this.formatFields(obj2.oldValue);
      }
    } else {
      obj2.oldValue = {};
    }
    if (ReflectionUtil.isObject(obj2.newValue)) {
      if (ReflectionUtil.isObjEmpty(obj2.newValue)) {
      } else {
        obj2.newValue = this.formatFields(obj2.newValue);
      }
    } else {
      obj2.newValue = {};
    }
    return obj2;
  }

  formatFields(value: T): T {
    return value;
  }


  loadData() {
    const id = this.getId();
    if (id != null && id !== '') {
      const user = storage.getUser();
      if (!user) {
        this.requireAuthentication();
      } else {
        this.props.checkDiff({id, callback: { execute: this.saveModelToState, handleError: this.handleError, formatDiffModel: this.formatDiffModel }});
      }
    }
  }

  approve(event) {
    event.preventDefault();
    const { diffInfo } = this.props as any;
    const body = this.makeDiffBody(diffInfo.newValue);
    this.props.approve({obj: body, callback: { execute: this.callBackAfterUpdate, handleError: this.handleError }});
  }

  reject(event) {
    event.preventDefault();
    const { diffInfo } = this.props as any;
    const body = this.makeDiffBody(diffInfo.newValue);
    this.props.reject({obj: body, callback: { execute: this.callBackAfterUpdate, handleError: this.handleError }});
  }
}
