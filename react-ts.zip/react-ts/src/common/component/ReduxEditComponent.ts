import {Model} from '../metadata/Model';
import {ResourceManager} from '../ResourceManager';
import {storage} from '../storage';
import {UIUtil} from '../util/UIUtil';
import {BaseEditComponent} from './BaseEditComponent';
import {BaseInternalState} from './BaseInternalState';
import {EditDispatchProps} from './EditDispatchProps';
import {EditPermissionBuilder} from './EditPermissionBuilder';
import {HistoryProps} from './HistoryProps';

export abstract class ReduxEditComponent<T, W extends (EditDispatchProps<T> & HistoryProps), I extends BaseInternalState> extends BaseEditComponent<T, W, I>  {
  constructor(props, metadata: Model, permissionBuilder: EditPermissionBuilder) {
    super(props, metadata, permissionBuilder);
  }

  loadData() {
    const id = this.getId();
    if (id != null && id !== '') {
      if (this.viewable !== true) {
        const msg = ResourceManager.getString('error_permission_view');
        UIUtil.alertError(msg);
        const user = storage.getUser();
        if (!!user) {
          this.navigateToHome();
        } else {
          this.requireAuthentication();
        }
      } else {
        this.setNewMode(false);
        this.props.getById({id, callback: { execute: this.saveModelToState, handleError: this.handleError }});
      }
    } else {
      // Call service state
      const obj = this.createModel();
      this.setNewMode(true);
      this.formatModel(obj);
      this.orginalModel = null;
      this.showModel(obj);
    }
  }

  protected save(obj, diff?: any) {
    this.running = true;
    if (this.isNewMode() === false) {
      if (this.updateChangedOnly === true) {
        const body = this.makePatchBodyFromDiff(diff);
        this.props.patch({obj, body, callback: { execute: this.afterUpdate, handleError: this.handleError }});
      } else {
        this.props.update({obj, callback: { execute: this.afterUpdate, handleError: this.handleError }});
      }
    } else {
      this.props.insert({obj, callback: { execute: this.afterInsert, handleError: this.handleError }});
    }
  }

  protected saveModelToState(model: T) {
    const props: any = this.props;
    this.orginalModelRedux = model;
    const form = this.getForm();
    props.setGlobalState({[form.name]: model});
    setTimeout(() => {
      if (this.editable === false) {
        UIUtil.setReadOnlyForm(form);
      }
    }, 100);
  }

  protected getModelFromState(): any {
    return this.props[this.getModelName()];
  }
}
