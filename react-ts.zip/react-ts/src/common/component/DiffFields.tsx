import * as React from 'react';
import DiffField from './DiffField';

interface Props {
  oldValue: any;
  newValue: any;
  resource: any;
  renderFields: any;
}

class DiffFields extends React.Component<Props, any> {
  render() {
    const {oldValue, newValue, resource, renderFields} = this.props;
    return (
        renderFields.map(field => {
          // tslint:disable-next-line:no-unused-expression
          // tslint:disable-next-line:jsx-key
          return <React.Fragment>
            <DiffField oldValue= {oldValue} newValue= {newValue} resource={resource} resourceKey={field.resourceKey} name={field.name} />
            <hr/>
          </React.Fragment>;
        })
    );
  }
}

export default DiffFields;
