import {ResultInfo} from '../model/ResultInfo';
import {ViewDispatchProps} from './ViewDispatchProps';

export interface ReduxCallBack<T> {
  execute: (model: ResultInfo<T>) => void;
  handleError: () => void;
}

export interface ReduxUpdateModel<T> {
  obj: T;
  callback: ReduxCallBack<T>;
}

export interface EditDispatchProps<T> extends ViewDispatchProps<T> {
  update?: (data: ReduxUpdateModel<T>) => void;
  patch?: (data: any) => any;
  insert: (data: ReduxUpdateModel<T>) => any;
}
