import {Model} from '../metadata/Model';
import {SearchModel} from '../model/SearchModel';
import {GenericSearchService} from '../service/GenericSearchService';
import {BaseGenericSearchComponent} from './BaseGenericSearchComponent';
import {HistoryProps} from './HistoryProps';
import {SearchPermissionBuilder} from './SearchPermissionBuilder';
import {SearchState} from './SearchState';

export class DetailSearchComponent<T, S extends SearchModel, W extends HistoryProps, I extends SearchState<T> & any> extends BaseGenericSearchComponent<T, S, W, I & any> {
  constructor(props, metadata: Model, service: GenericSearchService<T, S>, searchPermissionBuilder: SearchPermissionBuilder, autoSearch: boolean = true, listFormId: string = null) {
    super(props, metadata, service, searchPermissionBuilder, autoSearch, listFormId);
  }
}
