import * as React from 'react';
import DiffFields from './DiffFields';

interface Props {
  oldValue: any;
  newValue: any;
  resource: any;
  renderFields: any;
}

class DiffPanel extends React.Component<Props, any> {
  render() {
    const {oldValue, newValue, resource, renderFields} = this.props;
    return (
      <div className='diff'>
        <h4>
          <span>{resource.field}</span>
          <span>{resource.old_data_subject}</span>
          <span>{resource.new_data_subject}</span>
        </h4>
        <DiffFields oldValue= {oldValue} newValue= {newValue} resource={resource} renderFields={renderFields}/>
      </div>
    );
  }
}

export default DiffPanel;
