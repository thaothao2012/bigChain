import {SearchState} from './SearchState';

export interface ReduxSearchState<T> extends SearchState<T> {
  search: any;
}
