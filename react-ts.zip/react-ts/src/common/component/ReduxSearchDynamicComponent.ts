import {SearchModel} from '../model/SearchModel';
import {ResourceManager} from '../ResourceManager';
import {UIUtil} from '../util/UIUtil';
import {BaseSearchComponent} from './BaseSearchComponent';
import {HistoryProps} from './HistoryProps';
import {SearchDispatchProps} from './SearchDispatchProps';
import {SearchPermissionBuilder} from './SearchPermissionBuilder';
import {SearchState} from './SearchState';

export type SearchPropsType = SearchDispatchProps & HistoryProps;

export class ReduxSearchDynamicComponent<T, S extends SearchModel, W extends SearchPropsType, I extends SearchState<T> & any> extends BaseSearchComponent<T, S, W, I & any> {
  constructor(props, searchPermissionBuilder: SearchPermissionBuilder, autoSearch: boolean = true, listFormId: string = null, protected service: any = null) {
    super(props, autoSearch, listFormId, searchPermissionBuilder);
    this.search = this.search.bind(this);
    this.saveDynamicFormToState = this.saveDynamicFormToState.bind(this);
  }

  componentWillUnmount() {
    const props: any = this.props;
    const setGlobalState = props.props.setGlobalState;
    const form = this.getSearchForm();
    if (form) {
      const formName: string = form.name;
      // Remove current props when unmount
      setGlobalState(formName);
    }
  }

  search(s: S) {
    const { dynamicForm } = this.props as any;
    if (dynamicForm && Object.keys(dynamicForm).length === 0 && this.service.getDynamicFormByModelName) {
      const form = this.getSearchForm();
      this.service.getDynamicFormByModelName({name: form.name, callback: { execute: this.saveDynamicFormToState, handleError: this.handleError }});
    }
    this.props.search({ s, callback: {results: this.showResults, handleError: this.handleError}});
  }

  delete = (e, id) => {
    e.preventDefault();
    const confirmMsg = ResourceManager.getString('msg_confirm_delete');
    UIUtil.confirm(confirmMsg, () => {
      const s = this.getSearchModel();
      this.service.delete({ id, callback: { execute: this.search, handleError: this.handleError, data: s }});
    });
  }

  protected populateSearchModel(): S {
    let i = 0;
    const form = this.getSearchForm();
    const objState = {};
    for (i = 0; i < form.length; i++) {
      const name = form[i].name;
      if (name) {
        objState[name] = '';
        if (this.state[name]) {
          objState[name] = this.state[name];
        }
      }
    }

    let obj;
    obj = objState ? objState : {};
    if (this.tagName != null && this.tagName !== undefined) {
      obj.tagName = this.tagName;
    }

    // obj.fields = this.getDisplayFields();
    if (this.pageIndex != null && this.pageIndex >= 1) {
      obj.pageIndex = this.pageIndex;
    } else {
      obj.pageIndex = 1;
    }

    obj.pageSize = this.pageSize;
    if (this.appendMode === true) {
      obj.initPageSize = this.initPageSize;
    }

    obj.sortField = this.sortField;
    obj.sortType = this.sortType;
    obj.pageSize = this.pageSize;
    return obj;
  }

  protected saveDynamicFormToState(data: any) {
    const props: any = this.props;
    if (props.props.setGlobalState) {
      props.props.setGlobalState({dynamicForm: data.res});
    }
  }
}
