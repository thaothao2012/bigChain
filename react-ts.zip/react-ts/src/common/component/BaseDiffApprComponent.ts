import {ReflectionUtil} from 'src/core';
import {Model} from '../metadata/Model';
import {MetadataUtil} from '../metadata/util/MetadataUtil';
import {UIUtil} from '../util/UIUtil';
import {BaseInternalState} from './BaseInternalState';
import {BaseViewComponent} from './BaseViewComponent';
import {HistoryProps} from './HistoryProps';
import {IdBuilder} from './IdBuilder';

export class BaseDiffApprComponent<T, W extends HistoryProps, I extends BaseInternalState> extends BaseViewComponent<W, I> {
  constructor(props, protected metadata: Model) {
    super(props);
    // this._id = props['props'].match.params.id || props['props'].match.params.cId || props.match.params.cId;
    this.getId = this.getId.bind(this);
    this.saveModelToState = this.saveModelToState.bind(this);
    this.callBackAfterUpdate = this.callBackAfterUpdate.bind(this);
    this.state = {
      oldValue: {},
      newValue: {},
      approveSuccess: false,
      rejectSuccess: false
    };
  }

  private _id: any;

  protected getId(): any {
    if (this._id) {
      return this._id;
    } else {
      if (!this.metadata) {
        return null;
      } else {
        return IdBuilder.buildId(this.metadata, this.props);
      }
    }
  }

  protected callBackAfterUpdate(isSuccess?: boolean, err?: any) {
    if (isSuccess) {
      this.setState({ approveSuccess: true, rejectSuccess: true });
      UIUtil.showToast(this.resource.msg_approve_success);
    } else {
      this.setState({ approveSuccess: false });
      this.handleError(err);
    }
  }

  protected saveModelToState(model: T) {
    const props: any = this.props;
    const form: any = this.refs.form;
    const formName = form.name;
    if (props.props.setGlobalState) {
      props.props.setGlobalState({[formName]: model});
      this.format();
    }
  }

  format() {
    const { diffInfo } = this.props as any;
    if (diffInfo) {
      const form: any = this.refs.form;
      const differentObject = ReflectionUtil.isObjEmpty(diffInfo.oldValue) ? diffInfo.newValue : ReflectionUtil.diff(diffInfo.oldValue, diffInfo.newValue);
      const differentKeys = Object.keys(differentObject);
      const dataFields = UIUtil.getAllDataFields(form);
      dataFields.forEach(e => {
        if (differentKeys.indexOf(e.getAttribute('data-field')) >= 0) {
          if (e.childNodes.length === 3) {
            e.childNodes[1].classList.add('highlight');
            e.childNodes[2].classList.add('highlight');
          } else {
            e.classList.add('highlight');
          }
        }
      });

    } else {
      const { oldValue, newValue } = this.state;
      const form: any = this.refs.form;
      const differentObject = ReflectionUtil.isObjEmpty(oldValue) ? newValue : ReflectionUtil.diff(oldValue, newValue);
      const differentKeys = Object.keys(differentObject);
      const dataFields = UIUtil.getAllDataFields(form);
      dataFields.forEach(e => {
        if (differentKeys.indexOf(e.getAttribute('data-field')) >= 0) {
          if (e.childNodes.length === 3) {
            e.childNodes[1].classList.add('highlight');
            e.childNodes[2].classList.add('highlight');
          } else {
            e.classList.add('highlight');
          }
        }
      });
    }
  }

  makeDiffBody(data = null) {
    const newValue = data || this.state.newValue;
    const body = MetadataUtil.createModelJustContainPrimaryKeys(this.metadata);
    // tslint:disable-next-line:forin
    for (const item in body) {
      body[item] = newValue[item];
    }
    return body;
  }
}
