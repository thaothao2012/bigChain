export interface BaseInternalState {
  _message: string;
}
