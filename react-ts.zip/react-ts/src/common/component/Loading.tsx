import * as React from 'react';

export const Loading = (props) => {
  if (props.error) {
    return React.createElement('div', {}, 'Error Load Module!');
  } else {
    return (
      <div className='loader-wrapper'>
        <div className='loader-sign' style={{ top: '30%'}}>
          <div className='loader' />
        </div>
      </div>
    );
  }
};

