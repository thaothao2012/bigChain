import {Model} from '../metadata/Model';
import {ResultInfo} from '../model/ResultInfo';
import {ResourceManager} from '../ResourceManager';
import {GenericService} from '../service/GenericService';
import {storage} from '../storage';
import {UIUtil} from '../util/UIUtil';
import {BaseDynamicEditComponent} from './BaseDynamicEditComponent';
import {BaseInternalState} from './BaseInternalState';
import {EditPermissionBuilder} from './EditPermissionBuilder';
import {HistoryProps} from './HistoryProps';

export abstract class EditDynamicLayoutComponent<T, W extends HistoryProps, I extends BaseInternalState> extends BaseDynamicEditComponent<T, W, I>  {
  constructor(props, metadata: Model, protected service: GenericService<T>, permissionBuilder: EditPermissionBuilder) {
    super(props, metadata, permissionBuilder);
  }

  componentWillUnmount() {
    if  (this.props[this.getModelName()]) {
      const props: any = this.props;
      const setGlobalState = props.props.setGlobalState;
      const form = this.getForm();
      if (form) {
        const formName: string = form.name;
        // Remove current props when unmount
        setGlobalState(formName);
      }
    }
  }

  loadData() {
    const id = this.getId();
    if (id != null && id !== '') {
      if (this.viewable !== true) {
        const msg = ResourceManager.getString('error_permission_view');
        UIUtil.alertError(msg);
        const user = storage.getUser();
        if (!!user) {
          this.navigateToHome();
        } else {
          this.requireAuthentication();
        }
      } else {
        // Call service redux
        this.setNewMode(false);
        if (this.service.getDynamicFormByModelName) {
          this.service.getDynamicFormByModelName({name: this.form.name, callback: { execute: this.saveDynamicFormToState, handleError: this.handleError }});
          this.service.getById({id, callback: { execute: this.saveModelToState, handleError: this.handleError }});
        } else {
          this.service.getDynamicFormById({id, callback: { execute: this.saveDynamicFormToState, handleError: this.handleError }});
        }
      }
    } else {
      // Call service state
      const obj = this.createModel();
      this.setNewMode(true);
      this.formatModel(obj);
      this.orginalModel = null;
      this.showModel(obj);
    }
  }

  protected saveDynamicFormToState(data: any) {
    const props: any = this.props;
    if (props.props.setGlobalState) {
      this.orginalModelRedux = data;
      props.props.setGlobalState({dynamicForm: data.res});
    }
  }

  protected saveModelToState(model: T) {
    const props: any = this.props;
    if (props.props.setGlobalState) {
      this.orginalModelRedux = model;
      const form = this.getForm();
      props.props.setGlobalState({[form.name]: model});
      setTimeout(() => {
        if (this.editable === false) {
          UIUtil.setReadOnlyForm(form);
        }
      }, 100);
    } else {
      const modelName = this.getModelName();
      const objSet: any = {};
      objSet[modelName] = model;
      this.setState(objSet, () => {
        if (this.editable === false) {
          const form = this.getForm();
          UIUtil.setReadOnlyForm(form);
        }
      });
      // throw new Error('Component must add setGlobalState: (data) => dispatch(updateGlobalState(data)) into props');
    }
  }

  protected getModelFromState(): any {
    return this.props[this.getModelName()] || this.state[this.getModelName()];
  }

  protected save(obj, diff?: any) {
    this.running = true;
    const com = this;
    if (this.isNewMode() === false) {
      if (this.updateChangedOnly === true) {
        const body = this.makePatchBodyFromDiff(diff);
        this.service.patch(obj, body).subscribe((result: ResultInfo<T>) => {
          com.afterUpdate(result);
        }, this.handleError);
      } else {
        if (this.props[this.getModelName()]) {
          this.service.update({obj, callback: { execute: this.afterUpdate, handleError: this.handleError }});
        } else {
          this.service.update(obj).subscribe((result: ResultInfo<T>) => {
            com.afterUpdate(result);
          }, this.handleError);
        }
      }
    } else {
      if (this.props[this.getModelName()]) {
        this.service.insert({obj, callback: { execute: this.afterInsert, handleError: this.handleError }});
      } else {
        this.service.insert(obj).subscribe((result: ResultInfo<T>) => {
          com.afterInsert(result);
        }, this.handleError);
      }
    }
  }
}
