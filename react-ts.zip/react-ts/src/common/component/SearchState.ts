import {BaseInternalState} from './BaseInternalState';

export interface SearchState<T> extends BaseInternalState {
  keyword: string;
  results: T[];
}
