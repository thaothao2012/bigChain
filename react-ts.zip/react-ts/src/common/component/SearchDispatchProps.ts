export interface SearchDispatchProps {
  search?: (data: any) => any;
  getDynamicFormByModelName?: (data: any) => any;
}
