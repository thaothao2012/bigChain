import {BaseInternalState} from './BaseInternalState';

export interface DiffState<T> extends BaseInternalState {
  oldValue: T;
  newValue: T;
}
