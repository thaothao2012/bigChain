import {combineEpics} from 'redux-observable';
import {paccessRoleEpics} from '../access/component/access-role-assignment/AccessRoleObservableEpics';
import {EpicFormatter} from '../core';
import {bankEpics} from '../setup/component/bank/BankObservableEpics';
import {externalSysEpics} from '../setup/component/external-system/ExternalSystemObservableEpics';
import {payeeEpics} from '../setup/component/payee/PayeeObservableEpics';
import {payerEpics} from '../setup/component/payer/PayerObservableEpics';

const epicComponents = [
  payerEpics,
  payeeEpics,
  externalSysEpics,
  bankEpics,
  paccessRoleEpics
];
export const rootEpic = combineEpics(
  ...EpicFormatter.formatEpicComponents(epicComponents)
);
