import * as H from 'history';
import * as React from 'react';
import {Link} from 'react-router-dom';
import PageSizeSelect from 'src/control/PageSizeSelect';
import logoTitle from '../assets/images/logo-title.png';
import logo from '../assets/images/logo.png';
import topBannerLogo from '../assets/images/top-banner-logo.png';
import AvataIcon from '../assets/images/user_logo.png';
import {BaseComponent, BaseInternalState, HistoryProps, storage, StringUtil} from '../core';

interface WithProps {
  history: H.History;
}

interface InternalState extends BaseInternalState {
  pageSizes: number[];
  pageSize: number;
  authenticationService: any;
  se: any;
  isToggleMenu: boolean;
  isToggleSidebar: boolean;
  isToggleSearch: boolean;
}

export default class DefaultWrapper extends BaseComponent<HistoryProps, InternalState> {
  constructor(props) {
    super(props);
    this.renderForm = this.renderForm.bind(this);
    this.renderForms = this.renderForms.bind(this);
    // this.menuItemOnBlur = this.menuItemOnBlur.bind(this);
    this.state = {
      pageSizes: [10, 20, 40, 60, 100, 200, 400, 10000],
      pageSize: 10,
      authenticationService: undefined,
      se: {},
      keyword: '',
      classProfile: '',
      isToggleMenu: false,
      isToggleSidebar: false,
      isToggleSearch: false,
      forms: [],
      userName: '',
      roleType: ''
    };
  }
  pageSize = 20;
  pageSizes = [10, 20, 40, 60, 100, 200, 400, 10000];
  pageSizeChanged = (event) => {

  }

  componentWillMount() {
    // TODO : TB temporary fix form service null .
    /*
    if (!this.formService) {
      this.formService = new FormServiceImpl();
    }
    this.formService.getMyForm().subscribe(forms => {
      if (forms) {
        this.setState({ forms });
      } else {
        logger.warn('DefaultWrapper:  cannot load form from cache , re direct');
        this.props.history.push('/');
      }
    });
    */
    const forms = storage.getForms();
    this.setState({ forms });

    const storageName = storage.getUserName();
    const storageRole = storage.getRoleType();
    if (storageName || storageRole) {
      this.setState({ userName: storageName, roleType: storageRole });
    }
  }

  clearKeyworkOnClick = () => {
    this.setState({
      keyword: ''
    });
  }

  activeWithPath = (path) => {
    return path && this.props.location.pathname.startsWith(path) ? 'active' : '';
  }

  toggleMenuItem = (event) => {
    let target = event.currentTarget;
    const currentTarget = event.currentTarget;
    const elI = currentTarget.querySelectorAll('.menu-item > i')[1];
    if (elI) {
      if (elI.classList.contains('icon-down')) {
        elI.classList.remove('icon-down');
        elI.classList.add('icon-up');
      } else {
        if (elI.classList.contains('icon-up')) {
          elI.classList.remove('icon-up');
          elI.classList.add('icon-down');
        }
      }
    }
    if (currentTarget.nextElementSibling) {
      currentTarget.nextElementSibling.classList.toggle('expanded');
    }
    if (target.nodeName === 'A') {
      target = target.parentElement;
    }
    if (target.nodeName === 'LI') {
      target.classList.toggle('open');
    }
  }

  toggleMenu = () => {
    this.setState((prev) => ({ isToggleMenu: !prev.isToggleMenu }));
  }

  toggleSidebar = () => {
    this.setState((prev) => ({ isToggleSidebar: !prev.isToggleSidebar }));
  }

  searchOnClick = () => {

  }

  toggleSearch = () => {
    this.setState((prev) => ({ isToggleSearch: !prev.isToggleSearch }));
  }

  signout = ($event) => {
    $event.preventDefault();
    /*
    this.signoutService.signout(GlobalApps.getUserName()).subscribe(success => {
      if (success === true) {
        this.navigate('signin');
      }
    }, this.handleError);
    */
    /*
     const url = config.authenticationServiceUrl + '/authentication/signout/' + GlobalApps.getUserName();
     WebClientUtil.get(this.http, url).subscribe(
       success => {
         if (success) {
           sessionStorage.setItem('authService', null);
           sessionStorage.clear();
           GlobalApps.setUser(null);
           this.navigate('signin');
         }
       },
       err => this.handleError(err)
     );
     */
    sessionStorage.setItem('authService', null);
    sessionStorage.clear();
    storage.setUser(null);
    this.navigate('');
  }

  viewMyprofile = (e) => {
    e.preventDefault();
    this.navigate('/my-profile');
  }


  viewMySetting = (e) => {
    e.preventDefault();
    this.navigate('/my-profile/my-settings');
  }


  viewChangePassword = (e) => {
    e.preventDefault();
    this.navigate('/auth/change-password');
  }

  // menuItemOnBlur = (e) => {
  //   e.preventDefault();
  //   const sysBody = (window as any).sysBody;
  //   if (sysBody.classList.contains('top-menu')) {
  //     const currentTarget: any = event.currentTarget;
  //     const selectorChild = currentTarget.querySelector('.list-child');
  //     if (selectorChild) {
  //       if (selectorChild.classList.contains('expanded')) {
  //       }
  //     }
  //   }
  // }

  renderForms = (features) => {
    return (
      features.map((feature, index) => {
        return this.renderForm(index, feature);
      })
    );
  }

  onMouseHover = (e) => {
    e.preventDefault();
    const sysBody = (window as any).sysBody;
    if (sysBody.classList.contains('top-menu') && window.innerWidth > 768) {
      const navbar = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>ul.expanded'));
      const icons = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>a>i.icon-up'));
      if (navbar.length > 0) {
        let i = 0;
        for (i = 0; i < navbar.length; i++) {
          navbar[i].className = 'list-child';
          if (icons[i]) {
            icons[i].className = 'fa icon-down';
          }
        }
      }
    }
  }

  onShowAllMenu = (e) => {
    e.preventDefault();
    const sysBody = (window as any).sysBody;
    if (sysBody.classList.contains('top-menu2')) {
      const navbar = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>ul.list-child'));
      const icons = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>a>i.icon-down'));
      if (navbar.length > 0) {
        let i = 0;
        for (i = 0; i < navbar.length; i++) {
          navbar[i].className = 'list-child expanded';
          if (icons[i]) {
            icons[i].className = 'fa icon-up';
          }
        }
      }
    }
  }

  onHideAllMenu = (e) => {
    e.preventDefault();
    const sysBody = (window as any).sysBody;
    if (sysBody.classList.contains('top-menu2')) {
      const navbar = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>ul.expanded'));
      const icons = Array.from(document.querySelectorAll('.sidebar>nav>ul>li>a>i.icon-up'));
      if (navbar.length > 0) {
        let i = 0;
        for (i = 0; i < navbar.length; i++) {
          navbar[i].className = 'list-child';
          if (icons[i]) {
            icons[i].className = 'fa icon-down';
          }
        }
      }
    }
  }

  renderForm = (key: any, module: any) => {
    const name = StringUtil.isEmpty(this.resource[module.resourceKey]) ? module.name : this.resource[module.resourceKey];
    if (module.status !== 'A') {
      return (null);
    } else if (module.modules && Array.isArray(module.modules)) {
      const className = StringUtil.isEmpty(module.className) ? 'fa fa-id-card-o' : module.className;
      const link = module.link;
      const features = module.modules;
      return (
        <li key={key} className={'open ' + this.activeWithPath(link)} /* onBlur={this.menuItemOnBlur} */>
          <a className='menu-item' href='javascript:void(0)' onClick={this.toggleMenuItem}>
            <i className={className} /><span>{name}</span>
            <i className='fa icon-down' />
          </a>
          <ul className='list-child'>
            {this.renderForms(features)}
          </ul>
        </li>
      );
    } else {
      const className = StringUtil.isEmpty(module.className) ? 'fa fa-user-o' : module.className;
      return (
        <li key={key} className={this.activeWithPath(module.link)}>
          <Link to={module.link}>
            <i className={className} /><span>{name}</span>
          </Link>
        </li>
      );
    }
  }

  render() {
    const pageSize = this.pageSize;
    const pageSizes = this.pageSizes;
    const c = this.pageSizes;
    const { children } = this.props;
    const { isToggleSidebar, isToggleMenu, isToggleSearch, roleType, userName } = this.state;
    const topClassList = ['sidebar-parent'];
    if (isToggleSidebar) {
      topClassList.push('sidebar-off');
    }
    if (isToggleMenu) {
      topClassList.push('menu-on');
    }
    if (isToggleSearch) {
      topClassList.push('search');
    }
    const topClass = topClassList.join(' ');
    return (
      <div className={topClass}>
        <div className='top-banner'>
          <div className='logo-banner-wrapper'>
            <img src={topBannerLogo} alt='Logo of The Company' />
            <img src={logoTitle} className='banner-logo-title' alt='Logo of The Company' />
          </div>
        </div>
        <div className='menu sidebar' onMouseEnter={this.onMouseHover}>
          <nav>
            <ul>
              <li>
                <a className='toggle-menu' href='javascript:void(0)' onClick={this.toggleMenu}/>
                <p className='sidebar-off-menu' >
                  <i className='toggle' onClick={this.toggleSidebar} />
                  {!isToggleSidebar ? <i className='expand' onClick={this.onShowAllMenu} /> : null}
                  {!isToggleSidebar ? <i className='collapse' onClick={this.onHideAllMenu} /> : null}
                </p>
              </li>
              {this.renderForms(this.state.forms)}
            </ul>
          </nav>
        </div>
        <div className='page-container'>
          <div className='page-header'>
            <form>
              <div className='search-group'>
                <section>
                  <button type='button' className='toggle-menu' onClick={this.toggleMenu}/>
                  <button type='button' className='toggle-search' onClick={this.toggleSearch}/>
                  <button type='button' className='close-search' onClick={this.toggleSearch}/>
                </section>
                {/*
                <div className='logo-wrapper'>
                  <img className='logo' src={logo} alt='Logo of The Company'/>
                </div>
                <label className='search-input'>
                  <PageSizeSelect pageSize={pageSize} pageSizes={pageSizes} onPageSizeChanged={this.pageSizeChanged}/>
                  <input type='text' id='keyword' name='keyword' value={this.state.keyword} onChange={this.updateState}
                    maxLength={1000} placeholder={this.resource.keyword}/>
                  <button type='button' hidden={!this.state.keyword} className='btn-remove-text' onClick={this.clearKeyworkOnClick}/>
                  <button type='submit' className='btn-search' onClick={this.searchOnClick}/>
                </label>*/}
                <section>
                  {/*<button type='button'><i className='fa fa-bell-o'/></button>
                  <button type='button'><i className='fa fa-envelope-o'/></button>*/}
                  <div className='dropdown-menu-profile'>
                    <img onClick={(e) => {
                      this.setState(prevState => {
                        return { classProfile: prevState.classProfile === 'show' ? '' : 'show' };
                      });
                    }} id='btnProfile' src={AvataIcon} />
                    <ul id='dropdown-basic' className={this.state.classProfile + ' dropdown-content-profile'}>
                    {/*
                      <li><a className='dropdown-item-profile'
                             onClick={this.viewMyprofile}>{this.resource.my_profile}</a></li>
                      <li><a className='dropdown-item-profile'
                             onClick={this.viewMySetting}>{this.resource.my_settings}</a></li>
                      <li><a className='dropdown-item-profile'
                             onClick={this.viewChangePassword}>{this.resource.my_password}</a></li>*/}
                      <li>
                        <label>User Name: {userName} </label>
                        <br />
                        <label>Role : {roleType === 'M' ? 'Maker' : 'Checker'} </label>
                      </li>
                      <hr style={{ margin: 0 }} />
                      <li><a className='dropdown-item-profile'
                        onClick={this.signout}>{this.resource.button_signout}</a></li>
                    </ul>
                  </div>
                </section>
              </div>
            </form>
          </div>
          <div className='page-body'>
            {
              children
            }
          </div>
        </div>
      </div>
    );
  }

}

// export const WithDefaultLayout = (Component: any) => (props: HistoryProps) => {
//   return (
//     <DefaultWrapper history={props.history} location={props.location}>
//       <Component props={props} history={props.history} />
//     </DefaultWrapper>
//   );
// };

export const WithDefaultProps = (Component: any) => (props: HistoryProps) => {
  return (
    <Component props={props} history={props.history} />
  );
};
